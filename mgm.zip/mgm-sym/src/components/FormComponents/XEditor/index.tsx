/* eslint-disable react-hooks/exhaustive-deps */
import { useState, useEffect, memo } from 'react';
import type { ControlType } from 'braft-editor';
import BraftEditor from 'braft-editor';

import { uploadFile, getCosDownladUrl } from '@/services/api';

import 'braft-editor/dist/index.css';

const controls: ControlType[] = [
  {
    key: 'bold',
    text: <b>加粗</b>,
  },
  'undo',
  'redo',
  'emoji',
  'list-ul',
  'list-ol',
  'blockquote',
  'text-align',
  'font-size',
  'line-height',
  'letter-spacing',
  'text-color',
  'italic',
  'underline',
  'link',
  'media',
];

export default memo(function XEditor(props: any) {
  const { value, onChange } = props;
  const [editorState, setEditorState] = useState(BraftEditor.createEditorState(value));

  const myUploadFn = (param: any) => {
    uploadFile(
      param,
      async (key) => {
        param.success({
          url: getCosDownladUrl(key),
          meta: {
            id: Date.now(),
            title: key,
            alt: key,
          },
        });
      },
      async () => {
        param.error({
          msg: '上传失败.',
        });
      },
    );
  };

  const submitContent = () => {
    const htmlContent = editorState.toHTML();
    onChange?.(htmlContent);
  };

  const handleEditorChange = (editorStates: { toHTML: () => any }) => {
    setEditorState(editorStates);
    if (onChange) {
      const htmlContent = editorStates.toHTML();
      onChange?.(htmlContent);
    }
  };

  useEffect(() => {
    const htmlContent = value || '';
    setEditorState(BraftEditor.createEditorState(htmlContent));
  }, []);
  return (
    <BraftEditor
      value={editorState}
      controls={controls}
      onChange={handleEditorChange}
      onSave={submitContent}
      media={{ uploadFn: myUploadFn }}
    />
  );
});

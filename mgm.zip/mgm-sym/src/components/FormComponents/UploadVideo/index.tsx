import React from 'react';
import { Upload, Button } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { UploadFile, UploadChangeParam, RcFile } from 'antd/lib/upload/interface';

import { uuid } from '@/utils/tool';
import { getCosDownladUrl, uploadFile } from '@/services/api';
import { showErrorMessage } from '@/mamagement/Notification';

import './index.less';

interface UploadVideoType {
  fileList?: UploadFile<any>[];
  action?: string;
  headers?: any;
  withCredentials?: boolean;
  onChange?: (v: any) => void;
  text?: string;
}

const supportVideo = ['mp4'];
const supportVideoString = supportVideo.join(', ');

class UploadVideo extends React.Component<UploadVideoType> {
  state = {
    fileList: this.props.fileList || [],
    showFileList: true,
    isUploading: false,
  };

  customeUpload = (options: any) => {
    this.setState({ showFileList: true, isUploading: true });
    uploadFile(
      options,
      async (key) => {
        // 目前只是单文件上传，先控制单文件
        const fileList = [
          {
            uid: uuid(8, 16),
            name: `${key}`,
            status: 'done',
            url: getCosDownladUrl(key),
          },
        ];
        this.props.onChange?.(fileList);
        this.setState({ fileList, showFileList: false, isUploading: false });
      },
      async () => {
        showErrorMessage('文件上传失败，请重试');
        this.setState({ fileList: [], showFileList: false, isUploading: false });
      },
    );
  };

  handleChange = ({ file, fileList }: UploadChangeParam<UploadFile<any>>) => {
    this.setState({ fileList: fileList.length > 1 ? [fileList[fileList.length - 1]] : fileList });
    if (file.status === 'done') {
      const files = fileList.map((item) => {
        const { uid, name, status } = item;
        const url = item.url || item.response.result.url;
        return { uid, name, status, url };
      });
      this.props.onChange?.(files);
    } else {
      this.props.onChange?.([]);
    }
  };

  handleBeforeUpload = (file: RcFile) => {
    let isVideo = false;
    const fileName = file?.name || '';
    supportVideo.map((item) => {
      if (fileName.toLowerCase().endsWith(item)) {
        isVideo = true;
      }
      return item;
    });
    if (!isVideo) {
      showErrorMessage(`只能上传格式为 ${supportVideoString} 的文件`);
    }
    const isLt = file.size / 1024 / 1024 < 200;
    if (!isLt) {
      showErrorMessage('文件必须小于 200MB!');
    }
    if (!(isVideo && isLt)) this.setState({ fileList: [], showFileList: false });
    return isVideo && isLt;
  };

  render() {
    const { fileList } = this.state;
    const { headers, withCredentials = true } = this.props;

    return (
      <Upload
        accept={'video/*'}
        fileList={fileList}
        onChange={this.handleChange}
        name="file"
        listType="text"
        withCredentials={withCredentials}
        headers={{ ...headers }}
        beforeUpload={this.handleBeforeUpload}
        customRequest={this.customeUpload}
        showUploadList={this.state.showFileList}
      >
        <Button
          icon={<UploadOutlined />}
          loading={this.state.isUploading}
          disabled={this.state.isUploading}
        >
          {this.props.text ? this.props.text : '上传'}
        </Button>
      </Upload>
    );
  }
}

export default UploadVideo;

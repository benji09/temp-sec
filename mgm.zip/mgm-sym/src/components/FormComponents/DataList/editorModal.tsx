import React, { memo, useEffect } from 'react';
import { Form, Select, Input, Modal, Button } from 'antd';
import type { Store } from 'antd/lib/form/interface';
import type { FC } from 'react';

import Upload from '../Upload';
import type { TDataListDefaultTypeItem } from '../types';

// import styles from './index.less';

const normFile = (e: any) => {
  if (Array.isArray(e)) {
    return e;
  }
  return e && e.fileList;
};

const { Option } = Select;

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 14 },
};
declare global {
  interface Window {
    currentCates: unknown[] | null;
  }
}

export type EditorModalProps = {
  visible: boolean;
  onCancel: ((e: React.MouseEvent<HTMLElement, MouseEvent>) => void) | undefined;
  item?: TDataListDefaultTypeItem;
  onSave: (values?: Store) => void;
  cropRate: number;
};

const EditorModal: FC<EditorModalProps> = (props) => {
  const { item, onSave, visible, cropRate } = props;
  const [form] = Form.useForm();

  const onFinish = (values: Store) => {
    onSave(values);
  };
  const handleOk = () => {
    form
      .validateFields()
      .then((values) => {
        if (item) {
          values.id = item.id;
          onSave(values);
        }
      })
      .catch(() => {});
  };

  useEffect(() => {
    if (form && item && visible) {
      form.resetFields();
    }
  }, [form, item, visible]);
  return (
    <>
      {!!item && (
        <Modal
          title="编辑数据源"
          closable={false}
          visible={visible}
          onOk={handleOk}
          okText="确定"
          forceRender
          footer={
            <Button type={'primary'} onClick={() => handleOk()}>
              确定
            </Button>
          }
        >
          <Form
            form={form}
            name={`form_editor_modal`}
            {...formItemLayout}
            onFinish={onFinish}
            initialValues={item}
          >
            <Form.Item
              label="标题"
              name="title"
              rules={[{ required: true, message: '请输入标题!' }]}
            >
              <Input />
            </Form.Item>
            <Form.Item label="描述" name="desc">
              <Input />
            </Form.Item>
            <Form.Item label="链接地址" name="link">
              <Input />
            </Form.Item>
            {!!window.currentCates && (
              <Form.Item
                label="分类"
                name="type"
                rules={[{ required: true, message: '请选择分类!' }]}
              >
                <Select placeholder="请选择">
                  {window.currentCates.map((v: any, i: number | string) => {
                    return (
                      <Option value={i} key={String(i)}>
                        {v}
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            )}

            <Form.Item
              label="上传图片"
              name="imgUrl"
              valuePropName="fileList"
              getValueFromEvent={normFile}
            >
              <Upload cropRate={cropRate} isCrop />
            </Form.Item>
          </Form>
        </Modal>
      )}
    </>
  );
};

export default memo(EditorModal);

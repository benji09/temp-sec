import React from 'react';
import { Upload, Button, Row, Col, Spin } from 'antd';
import type { UploadFile, UploadChangeParam, RcFile } from 'antd/lib/upload/interface';
import { UploadOutlined, DeleteOutlined, LoadingOutlined } from '@ant-design/icons';

import { getCosDownladUrl, uploadPdfFile } from '@/services/api';
import { showErrorMessage } from '@/mamagement/Notification';
import { formatTime } from '@/utils/utils';
import KEYS from '@/utils/storageKeys';
import { getItemUserInfo } from '@/utils/userInfoEncrypt';

import './index.less';

interface UploadVideoType {
  fileList?: UploadFile<any>[];
  action?: string;
  headers?: any;
  withCredentials?: boolean;
  onChange?: (v: any) => void;
  text?: string;
}

class UploadPDF extends React.Component<UploadVideoType> {
  state = {
    fileList: this.props.fileList || [],
    fileUrlList: [],
    loading: false,
    name: '',
  };

  customeUpload = (options: any) => {
    this.setState({ loading: true });
    this.setState({ name: options.file.name });
    uploadPdfFile(
      options,
      async (key) => {
        this.setState({ loading: false });

        const list = JSON.parse(JSON.stringify(this.state.fileUrlList));
        list.push({
          name: options.file.name,
          time: formatTime(new Date().getTime()),
          url: getCosDownladUrl(key),
          key,
        });
        this.setState({
          fileUrlList: list,
        });
        this.props.onChange?.(this.state.fileUrlList);
        this.setState({ fileList: [] });
      },
      async () => {
        showErrorMessage('文件上传失败，请重试');
        this.setState({ fileList: [] });
        this.setState({ loading: false });
        this.setState({ name: '' });
      },
    );
  };
  handleChange = ({ file, fileList }: UploadChangeParam<UploadFile<any>>) => {
    this.setState({ fileList });
    if (file.status === 'done') {
      const files = fileList.map((item) => {
        const { uid, name, status } = item;
        const url = item.url || item.response.result.url;
        return { uid, name, status, url };
      });
      this.props.onChange?.(files);
    } else {
      this.setState({ fileList: [] });
    }
  };

  handleBeforeUpload = (file: RcFile) => {
    const isVideo = file.name.endsWith('pdf');
    if (!isVideo) {
      showErrorMessage('只能上传格式为 pdf 的文件');
    }
    const isLt50M = file.size / 1024 / 1024 < 50;
    if (!isLt50M) {
      showErrorMessage('文件必须小于50MB!');
    }
    return isVideo && isLt50M;
  };
  render() {
    const { fileList, loading, fileUrlList } = this.state;
    const { headers, withCredentials = true } = this.props;
    const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
    return (
      <div>
        <Upload
          accept={'.pdf'}
          fileList={fileList}
          onChange={this.handleChange}
          name="file"
          listType="text"
          withCredentials={withCredentials}
          headers={{ ...headers }}
          beforeUpload={this.handleBeforeUpload}
          customRequest={this.customeUpload}
        >
          <div>
            {fileUrlList &&
              fileUrlList.map((item: any, index: number) => {
                return (
                  <Row
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                    key={String(index)}
                    className="upLoadListItem"
                  >
                    <Col
                      span={8}
                      className="DownladUrlButton"
                      onClick={(e) => {
                        e.stopPropagation();
                        window.open(`${getCosDownladUrl(item.url)}`);
                      }}
                    >
                      {item.name}
                    </Col>
                    <Col span={7}>{item.time}</Col>
                    <Col span={7}>{getItemUserInfo(KEYS.KEY_USER_INFO)?.name}</Col>
                    <Col
                      span={2}
                      onClick={(e) => {
                        e.stopPropagation();
                        const list = JSON.parse(JSON.stringify(fileUrlList));
                        list.splice(index, 1);
                        this.setState({ fileUrlList: list });
                        this.props.onChange?.(list);
                      }}
                      className="deleteList"
                    >
                      <DeleteOutlined />
                    </Col>
                  </Row>
                );
              })}
            {!loading ? (
              ''
            ) : (
              <Row
                onClick={(e) => {
                  e.stopPropagation();
                }}
                className="upLoadListItem"
              >
                <Col span={8} style={{ color: '#0486FE' }}>
                  {this.state.name}
                </Col>
                <Col span={7}>{formatTime(new Date().getTime())}</Col>
                <Col span={7}>{getItemUserInfo(KEYS.KEY_USER_INFO).name}</Col>
                <Col span={2}>
                  <Spin indicator={antIcon} />
                </Col>
              </Row>
            )}
          </div>
          <Button className="uploadButton" icon={<UploadOutlined />}>
            {this.props.text ? this.props.text : '上传'}
          </Button>
        </Upload>
      </div>
    );
  }
}

export default UploadPDF;

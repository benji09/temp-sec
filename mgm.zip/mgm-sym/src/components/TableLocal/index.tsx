import { PageContainer } from '@ant-design/pro-layout';

import Table from './components/Table';

const TableLocal = (TableNode: any) => {
  return (props: any) => (
    <PageContainer>
      <TableNode {...props} />
      {props.children}
    </PageContainer>
  );
};
export default TableLocal(Table);

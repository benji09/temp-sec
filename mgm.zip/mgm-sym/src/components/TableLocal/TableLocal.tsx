import { useEffect, useState } from 'react';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';

import KEYS from '@/utils/storageKeys';
import { ModalPageList } from '@/utils/pageSizeOptions';
import { getItem, setItem } from '@/storage/index';

function TableLocal(props?: any) {
  const { search, pagination, children, ...data } = props;
  const [pageSize, setPageSize] = useState<number | undefined>(10);
  const [destinySize, setDestinySize] = useState<string>();
  const [columnsStateMap, setColumnsStateMap] = useState();
  const [collapsed, setCollapsed] = useState<boolean>(true);

  const [current, setCurrent] = useState<number>(1);

  useEffect(() => {
    setPageSize(JSON.parse(getItem(KEYS.KEY_TABLE_PAGE_SIZE) || '10'));
    setCollapsed(JSON.parse(getItem(`${window.location.pathname}${KEYS.KEY_COLLAPSED}`) || 'true'));

    setDestinySize(getItem(KEYS.KEYS_DESTINY_SIZE) || 'middle');
    const tempStatus = getItem(`${window.location.pathname}${KEYS.KEYS_COLUMN_STATUS}`);
    if (tempStatus) setColumnsStateMap(JSON.parse(tempStatus));
  }, []);

  // 更改每页条数
  const onChangePage = (value: any) => {
    setCurrent(value.current);
    setPageSize(value.pageSize);
    setItem(KEYS.KEY_TABLE_PAGE_SIZE, value.pageSize);
  };

  // 一页展示数量更改事件
  const onChangeDestiny = (value: any) => {
    setDestinySize(value);
    setItem(KEYS.KEYS_DESTINY_SIZE, value);
  };

  // 设置中列展示中更改事件
  const onColumnsChange = (value: any) => {
    setColumnsStateMap(value);
    setItem(`${window.location.pathname}${KEYS.KEYS_COLUMN_STATUS}`, JSON.stringify(value));
  };

  // 搜索框展开收起的更改事件
  const onCollapseChange = (value: any) => {
    setCollapsed(value);
    setItem(`${window.location.pathname}${KEYS.KEY_COLLAPSED}`, `${value}`);
  };
  return (
    <PageContainer>
      <ProTable
        pagination={
          pagination !== false
            ? {
                pageSize,
                current,
                pageSizeOptions: ModalPageList,
                ...pagination,
              }
            : pagination
        }
        onChange={onChangePage}
        onSizeChange={onChangeDestiny}
        size={destinySize}
        columnsState={{ value: columnsStateMap, onChange: onColumnsChange }}
        {...data}
        onLoad={(record) => {
          if (current > 1 && record.length === 0) {
            setCurrent((current || 0) - 1);
          }
        }}
        search={
          search && {
            collapsed: collapsed,
            onCollapse: onCollapseChange,
            optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
            ...search,
          }
        }
      />
      {children}
    </PageContainer>
  );
}
export default TableLocal;

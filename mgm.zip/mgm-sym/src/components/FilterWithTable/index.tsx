/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import type { ReactNode } from 'react';

import EnhanceTable from '@/components/common/EnhanceTable';
import FilterItems from '@/components/common/FilterItems';
import type { TableProps } from '@/components/common/EnhanceTable';
import type { FilterItemsProps } from '@/components/common/FilterItems';

import './index.less';

interface FilterWithTableProps {
  // 筛选
  filterProps: FilterItemsProps;
  // 筛选数据处理
  filterValueHandler?: (values: any) => any;
  // 表格
  tableProps: TableProps;
  // 表头
  tableHeader?: ReactNode;
  // 初始化表格数据
  tableInit?: boolean;
}

const FilterWithTable = forwardRef((props: FilterWithTableProps, ref) => {
  const { filterProps, tableProps, tableInit = true, filterValueHandler, tableHeader } = props;

  const enhanceTableRef = useRef<any>();

  useImperativeHandle(ref, () => ({
    reset: onFilterReset,
    refresh,
  }));

  useEffect(() => {
    if (tableInit) {
      enhanceTableRef.current.search();
    }
  }, []);

  return (
    <div className="filterWithTable">
      <div className="filterCon">
        <FilterItems onSearch={onFilterSearch} onReset={onFilterReset} {...filterProps} />
      </div>
      <div className="tableCon">
        <div className="tableHeader">{tableHeader}</div>
        <EnhanceTable ref={enhanceTableRef} {...tableProps} />
      </div>
    </div>
  );

  function onFilterSearch(values: any) {
    enhanceTableRef.current.search(filterValueHandler ? filterValueHandler(values) : values);
  }

  function onFilterReset() {
    enhanceTableRef.current.search();
  }

  function refresh() {
    enhanceTableRef.current.fetch();
  }
});

export default FilterWithTable;

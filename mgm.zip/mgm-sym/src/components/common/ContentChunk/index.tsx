import type { ReactNode } from 'react';
import './index.less';

interface NodeProps {
  title: string;
  children?: ReactNode;
}

export default (props: NodeProps) => {
  const { title, children } = props;
  return (
    <div className="contentChunk">
      <div className="conChunk_head">{title}</div>
      <div className="conChunk_con">{children}</div>
    </div>
  );
};

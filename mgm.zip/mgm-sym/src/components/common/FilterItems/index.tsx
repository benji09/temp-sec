import { Form, Button, Row, Col } from 'antd';
import _ from 'lodash';
import type { ReactNode } from 'react';

import './index.less';

export interface FormItem {
  name: string | string[];
  label: string;
  reactNode: ReactNode;
}

export type FormValues = Record<string, string | number | boolean | any>;

export interface FilterItemsProps {
  formItems: FormItem[];
  onSearch?: (values: FormValues) => void;
  onReset?: () => void;
}

export default (props: FilterItemsProps) => {
  const { formItems, onSearch, onReset } = props;
  const [form] = Form.useForm();

  const layout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 15 },
  };

  return (
    <div className="filterItems">
      <Form form={form} labelAlign="left" {...layout}>
        <Row gutter={[0, 16]}>
          {formItems.map((fitem: FormItem): ReactNode => {
            const itemProps = _.cloneDeep(fitem);
            Reflect.deleteProperty(itemProps, 'reactNode');
            return (
              <Col span={8} key={JSON.stringify(fitem.name)}>
                <Form.Item {...itemProps}>{fitem.reactNode}</Form.Item>
              </Col>
            );
          })}
          <Col span={8} style={{ marginLeft: 'auto', textAlign: 'right' }}>
            <Row>
              <Col span={layout.labelCol.span} />
              <Col span={layout.wrapperCol.span}>
                <Button type="primary" style={{ marginRight: '10px' }} onClick={search}>
                  查询
                </Button>
                <Button onClick={reset}>重置</Button>
              </Col>
            </Row>
          </Col>
        </Row>
      </Form>
    </div>
  );

  function search() {
    onSearch?.(form.getFieldsValue(true));
  }

  function reset() {
    form.resetFields();
    onReset?.();
  }
};

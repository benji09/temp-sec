/* eslint-disable react-hooks/exhaustive-deps */
// @ts-ignore
import { request } from 'umi';
import { useState, useEffect, useImperativeHandle, forwardRef } from 'react';
import { Table, Pagination } from 'antd';
import type { ReactNode } from 'react';

import { showErrorMessage } from '@/mamagement/Notification';

import './index.less';
import type { FormValues } from '../FilterItems';
import _ from 'lodash';

export interface TableColumn {
  title?: string | ReactNode;
  dataIndex?: string;
  render?: (text: string, record: FormValues) => string | ReactNode;
}

export interface HandleData {
  dataSource: any[];
  total: number;
}

export type HandleParams = Record<string, string | number | boolean | { HandleParams: any }>;

export interface TableProps {
  url?: string;
  columns: TableColumn[];
  dataSource?: any[];
  pagination?: any;
  pagingKeys?: string[];
  paramsHandler?: (params: any) => HandleParams;
  dataHandler?: (response: any) => HandleData;
  rowKey?: string;
}

export default forwardRef((props: TableProps, ref) => {
  const {
    url,
    columns,
    dataSource = [],
    pagination = {},
    pagingKeys = ['page', 'size'],
    dataHandler,
    paramsHandler,
    ...tableProps
  } = props;

  const pagingInitParams = {
    current: 1,
    pageSize: pagination?.pageSize || 10,
    total: 0,
  };

  const [topEffect, setTopEffect] = useState(true);
  const [loading, setLoading] = useState(false);
  const [list, setList] = useState(dataSource);
  const [sparams, setSparams] = useState<any>(null);
  const [pagingParams, setPagingParams] = useState({
    ...pagingInitParams,
    pageSizeOptions: ['5', '10', '15', '20'],
  });

  useImperativeHandle(ref, () => ({
    search,
    clear,
    fetch,
  }));

  // 监听分页参数变化
  useEffect((): void => {
    if (topEffect) return;
    fetch();
  }, [pagingParams.current, pagingParams.pageSize]);

  // 监听搜索参数变化
  useEffect((): void => {
    if (topEffect) return;
    const { planId } = sparams;
    if (planId && planId.trim().length > 0 && !planId.trim().match(/\d+/)) {
      showErrorMessage('请输入正确的 ID');
      setList([]);
      setPagingParams({ ...pagingParams, ...pagingInitParams, total: 0 });
      return;
    }
    if (
      pagingParams.current === pagingInitParams.current &&
      pagingParams.pageSize === pagingInitParams.pageSize
    ) {
      fetch();
    } else {
      setPagingParams({ ...pagingParams, ...pagingInitParams });
    }
  }, [JSON.stringify(sparams)]);

  useEffect(() => {
    if (topEffect) return setTopEffect(false);
    setList(dataSource);
  }, [JSON.stringify(dataSource)]);

  return (
    <div className="enhanceTable">
      <Table
        loading={loading}
        columns={columns}
        dataSource={list}
        {...tableProps}
        pagination={false}
      />
      {pagination && Boolean(pagingParams.total) && (
        <div className="enhanceTable_pagination">
          <Pagination
            onChange={onPaginationChange}
            onShowSizeChange={onShowSizeChange}
            {...pagingParams}
            {...pagination}
          />
        </div>
      )}
    </div>
  );

  function onPaginationChange(current: number, pageSize: number) {
    setPagingParams({ ...pagingParams, current, pageSize });
  }

  function onShowSizeChange(pageSize: number) {
    setPagingParams({ ...pagingParams, current: 1, pageSize });
  }

  function fetch() {
    if (!url || !sparams) return null;
    setLoading(true);
    const params = paramsHandler ? paramsHandler(_.cloneDeep(sparams)) : _.cloneDeep(sparams);
    params[pagingKeys[0]] = pagingParams.current;
    params[pagingKeys[1]] = pagingParams.pageSize;
    const { planId } = params;
    if (planId?.trim().length < 1) {
      params.planId = undefined;
    }

    request(url, { method: 'GET', params })
      .then((res) => {
        setLoading(false);
        if (res.status === 0) {
          const data = dataHandler ? dataHandler(res) : defaultDataHandle(res);
          setList(data.dataSource);
          setPagingParams({ ...pagingParams, total: data.total });
        }
      })
      .catch(() => {
        setLoading(false);
      });
    return '';
  }

  function defaultDataHandle(res: { content: any; totalElements: any }): HandleData {
    return {
      dataSource: res?.content || [],
      total: res?.totalElements || 0,
    };
  }

  function search(params = {}) {
    setSparams(params);
  }

  function clear() {
    setSparams(null);
    setList([]);
    setPagingParams({ ...pagingParams, current: 1, total: 0 });
  }
});

/*
 * @Author: zyx
 * @Date: 2021-06-18 15:19:31
 * @LastEditTime: 2021-08-31 14:22:45
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\access.ts
 */
/**
 * @see https://umijs.org/zh-CN/plugins/plugin-access
 * */
import KEYS from '@/utils/storageKeys';
import { getItemUserInfo } from '@/utils/userInfoEncrypt';

import { removeItem } from './services/localStorage';

export default function access() {
  const cacheStr = getItemUserInfo(KEYS.KEY_USER_INFO);
  let userCache;
  if (cacheStr && Object.keys(cacheStr).length > 0) {
    try {
      userCache = cacheStr;
    } catch (error) {
      removeItem(KEYS.KEY_USER_INFO);
    }
  }
  return {
    needLogin: userCache && userCache.token && userCache.token.length > 0,
  };
}

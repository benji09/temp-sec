export enum FixedEnum {
  leftTop = 'left top',
  leftBottom = 'left bottom',
  rightTop = 'right top',
  rightBottom = 'right bottom',
  top = 'top',
  right = 'right',
  left = 'left',
  bottom = 'bottom',
}

/* eslint-disable react-hooks/exhaustive-deps */
import { useMemo, memo } from 'react';
import type { FC } from 'react';
import { dynamic } from 'umi';

import Loading from '../components/LoadingCp';

export type componentsType = 'media' | 'base' | 'visible' | 'shop';

const DynamicFunc = (type: string, componentsType: string) => {
  return dynamic({
    loader: async function () {
      const { default: Graph } = await import(`@/materials/${componentsType}/${type}`);
      const Component = Graph;
      return (props: DynamicType) => {
        const { config, isTpl } = props;
        return <Component {...config} isTpl={isTpl} />;
      };
    },
    loading: () => (
      <div style={{ paddingTop: 10, textAlign: 'center' }}>
        <Loading />
      </div>
    ),
  });
};

type DynamicType = {
  isTpl: boolean;
  config: Record<string, any>;
  type: string;
  componentsType: componentsType;
  category: string;
  layout?: boolean;
};
const DynamicEngine = memo((props: DynamicType) => {
  const { type, config, category } = props;
  const Dynamic = useMemo(() => {
    return DynamicFunc(type, category) as unknown as FC<DynamicType>;
  }, [config]);

  return <Dynamic {...props} />;
});

export default DynamicEngine;

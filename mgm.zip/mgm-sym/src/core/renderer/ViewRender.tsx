import { memo } from 'react';
import { connect } from 'dva';
import GridLayout from 'react-grid-layout';
import type { StateWithHistory } from 'redux-undo';
import type { ItemCallback } from 'react-grid-layout';

import DynamicEngine from '@/core/DynamicEngine';

import styles from './viewRender.less';

interface PointDataItem {
  id: string;
  item: Record<string, any>;
  point: Record<string, any>;
}

interface ViewProps {
  pointData: PointDataItem[];
  pageData?: any;
  emodal?: any;
  width?: number;
  dragStop?: ItemCallback;
  onDragStart?: ItemCallback;
  onResizeStop?: ItemCallback;
}

const ViewRender = memo((props: ViewProps) => {
  const { pointData, width, dragStop, onDragStart, onResizeStop, emodal } = props;
  const { pageData } = emodal;

  return (
    <>
      <GridLayout
        cols={24}
        rowHeight={2}
        width={width}
        margin={[0, 0]}
        onDragStop={dragStop}
        onDragStart={onDragStart}
        onResizeStop={onResizeStop}
        verticalCompact
        useCSSTransforms={false}
        style={{
          minHeight: '70vh',
          backgroundColor: (pageData && pageData?.backgroundColor) || 'white',
          backgroundImage:
            pageData && pageData.bgImage ? `url(${pageData.bgImage[0].url})` : 'initial',
          backgroundSize: '100%',
          backgroundRepeat: 'no-repeat',
        }}
      >
        {pointData
          .filter((o) => !o.item.fixed)
          .map((value: PointDataItem) => (
            <div key={value.id} data-grid={value.point} className={onDragStart && styles.dragItem}>
              <DynamicEngine {...(value.item as any)} isTpl={false} />
            </div>
          ))}
      </GridLayout>
      {pointData
        .filter((o) => o.item.fixed)
        .map((value) => (
          <GridLayout
            key={`grid_layout_${value.id}`}
            cols={24}
            rowHeight={2}
            width={width}
            margin={[0, 0]}
            onDragStop={dragStop}
            onDragStart={onDragStart}
            onResizeStop={onResizeStop}
            verticalCompact
            useCSSTransforms={false}
          >
            <div key={value.id} data-grid={value.point} className={onDragStart && styles.dragItem}>
              <DynamicEngine {...(value.item as any)} isTpl={false} />
            </div>
          </GridLayout>
        ))}
    </>
  );
});

export default connect((state: StateWithHistory<any>) => ({
  emodal: state.present.editorModal,
}))(ViewRender);

import { useRef } from 'react';
import { Button, Input } from 'antd';
import { history, KeepAlive } from 'umi';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';

import { formatTime } from '@/utils/utils';
import FilterWithTable from '@/components/FilterWithTable';

import AddOrModifyModal from './AddOrModifyModal';

import './index.less';

function SportPlan() {
  const filterWithTable = useRef();
  const addOrModifyModal = useRef();

  return (
    <PageContainer>
      <FilterWithTable
        ref={filterWithTable}
        filterProps={{ formItems: formItems() }}
        tableHeader={
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => addOrModifyModal.current?.show()}
          >
            新增
          </Button>
        }
        tableProps={{
          url: '/plan/pageList',
          columns: tableColumns(),
          rowKey: 'planId',
          paramsHandler,
          dataHandler,
        }}
      />
      <AddOrModifyModal ref={addOrModifyModal} onCallback={onCallback} />
    </PageContainer>
  );

  function paramsHandler(params) {
    return { ...params, cat: 2 };
  }

  function dataHandler(res) {
    return {
      dataSource: res.result.content,
      total: res.result.totalElements,
    };
  }

  function formItems() {
    return [
      {
        name: 'planId',
        label: 'ID',
        reactNode: <Input placeholder="计划ID" />,
      },
      {
        name: 'planName',
        label: '计划名称',
        reactNode: <Input placeholder="计划名称" />,
      },
    ];
  }

  function tableColumns() {
    return [
      {
        title: 'ID',
        dataIndex: 'planId',
      },
      {
        title: '计划名称',
        dataIndex: 'planName',
      },
      {
        title: '创建时间',
        dataIndex: 'createdAt',
        render: (text) => formatTime(Number(text)),
      },
      {
        title: '计划时长',
        dataIndex: 'duration',
      },
      {
        title: '计划介绍',
        dataIndex: 'description',
      },
      {
        title: '操作',
        render: (text, record) => (
          <div className="operation_bar">
            <span
              className="operation_bar_btn"
              onClick={() => addOrModifyModal.current.show(record)}
            >
              编辑
            </span>
            <span
              className="operation_bar_btn"
              onClick={() => history.push(`/plan/sportPlan/handle?pid=${record.planId}`)}
            >
              配置
            </span>
          </div>
        ),
      },
    ];
  }

  function onCallback() {
    filterWithTable.current.refresh();
  }
}

export default () => (
  <KeepAlive>
    <SportPlan />
  </KeepAlive>
);

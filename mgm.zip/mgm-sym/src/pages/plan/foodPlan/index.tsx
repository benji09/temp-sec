/* eslint-disable react-hooks/exhaustive-deps */

import React, { useState, useRef, useEffect } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ActionType } from '@ant-design/pro-table';

import { showErrorMessage } from '@/mamagement/Notification';
import { getFoodList, addFoodList, categoryList, changeFoodList } from '@/services/api';

import AddFood from './components/addFood';
import ContentModal from './components/contentModal';

const FoodList: React.FC = () => {
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [cateList, setCateList] = useState<{ id: number; name: string; weight: number }[]>([]);
  const [modalTitle, setModalTitle] = useState<string>();
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [eidtorData, setEidtorData] = useState<any>({});
  const actionRef = useRef<ActionType | undefined>();
  const foodRef = useRef<any>();

  const columns = [
    {
      title: 'ID',
      ellipsis: true,
      dataIndex: 'pantryId',
    },
    {
      title: '封面',
      dataIndex: 'cover',
      hideInSearch: true,
      render: (text: any, record: { cover: string | undefined }) => {
        return <img src={record.cover} alt="" height="80" />;
      },
    },
    {
      title: '名称',
      dataIndex: 'name',
    },
    {
      title: '分类',
      dataIndex: 'categoryId',
      valueEnum: () => {
        const cateData = {};
        cateList?.forEach((list: any) => {
          cateData[list.id] = { text: list.name };
        });
        return cateData;
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_: any, record: any) => [
        <a key="config" onClick={() => onShowModal('EDITOR', record)}>
          编辑
        </a>,
      ],
    },
  ];

  useEffect(() => {
    categoryList({}).then((res) => {
      if (res.status === 0) {
        setCateList(res.result);
      }
    });
  }, []);

  useEffect(() => {
    if (!modalVisible) {
      foodRef.current?.reset();
    } else {
      foodRef.current?.setData(eidtorData);
    }
  }, [modalVisible]);

  return (
    <PageContainer>
      <ProTable
        actionRef={actionRef}
        rowKey="pantryId"
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
          labelWidth: 120,
        }}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              onShowModal('ADD');
            }}
          >
            <PlusOutlined /> 新增
          </Button>,
        ]}
        request={getFoodList}
        columns={columns}
      />
      <ContentModal
        modalVisible={modalVisible}
        btnLoading={btnLoading}
        onCancel={onCancel}
        modalTitle={modalTitle}
        onOk={onOk}
      >
        <AddFood ref={foodRef} cateList={cateList} eidtorData={eidtorData} />
      </ContentModal>
    </PageContainer>
  );

  /** 关闭窗口 */
  function onCancel() {
    setModalVisible(false);
  }

  /** 点击确定 */
  function onOk() {
    foodRef.current?.takeData().then((res: any) => {
      setBtnLoading(true);
      (res.pantryId ? changeFoodList(res) : addFoodList(res))
        .then((result: any) => {
          setBtnLoading(false);
          if (result.status === 0) {
            setModalVisible(false);
            actionRef.current?.reload();
          } else {
            showErrorMessage(result.message);
          }
        })
        .catch(() => {});
    });
  }

  function onShowModal(type: string, row: any = {}) {
    if (type === 'ADD') {
      setEidtorData({});
      setModalTitle('新增');
      setModalVisible(true);
    } else {
      getFoodList({ pantryId: row.pantryId, current: 1, pageSize: 1 }).then((res: any) => {
        if (res.data.length > 0) {
          setEidtorData(res.data[0]);
          setModalVisible(true);
          setModalTitle('编辑');
        }
      });
    }
  }
};

export default FoodList;

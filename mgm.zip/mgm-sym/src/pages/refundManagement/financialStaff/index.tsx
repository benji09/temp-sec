import RefundList from '../components/refundList';
import { REFUND_TYPE_FINANCIAL } from '../utils';

const FinancialStaff = () => <RefundList refundType={REFUND_TYPE_FINANCIAL} />;
export default FinancialStaff;

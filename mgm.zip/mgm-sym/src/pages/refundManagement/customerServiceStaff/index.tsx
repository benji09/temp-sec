import RefundList from '../components/refundList';
import { REFUND_TYPE_CUSTOMERSERVICE } from '../utils';

const customerServiceStaff = () => <RefundList refundType={REFUND_TYPE_CUSTOMERSERVICE} />;
export default customerServiceStaff;

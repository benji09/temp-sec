import { request } from 'umi';

import { getRequest, postRequest } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';

import { REFUND_TYPE_CUSTOMERSERVICE } from './utils';
import type { RefundType } from './typing';

let searchData = {};

const queryRefundList = async (params: any, refundType: RefundType) => {
  const { current, pageSize, ...data } = params;

  searchData = data;

  const msg: any = await postRequest(
    refundType === REFUND_TYPE_CUSTOMERSERVICE
      ? '/refund-management/customer-service-page'
      : '/refund-management/finance-page',
    {
      ...data,
      pageSize,
      currentPage: current,
    },
    {},
    { type: HOST_TYPE_POWER },
  );
  return {
    data: msg?.result?.orderRefundInfoList ?? [],
    total: msg?.result?.totalCount ?? 0,
  };
};

// 上传 EXCEL
async function importExcel(url: string, options: any) {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request(url, {
    method: 'POST',
    body: formData,
    timeout: 60 * 1000,
    type: HOST_TYPE_POWER,
  });
}

// 上传 EXCEL 文件接口
const uploadRefundList = async (refundType: RefundType, options: any) => {
  return importExcel(
    refundType === REFUND_TYPE_CUSTOMERSERVICE
      ? '/refund-management/customer-service-import'
      : '/refund-management/finance-import',
    options,
  );
};
const exportData = async (refundType: RefundType) => {
  return (await postRequest(
    refundType === REFUND_TYPE_CUSTOMERSERVICE
      ? '/refund-management/customer-service-export'
      : '/refund-management/finance-export',
    { ...searchData },
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  )) as unknown as any;
};
// 获取列表详情接口
const getRefundDetails = async (refundType: RefundType, id: string) => {
  return (await getRequest(
    refundType === REFUND_TYPE_CUSTOMERSERVICE
      ? '/refund-management/customer-service-detail'
      : '/refund-management/finance-detail',
    { id },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 退款页面字典
const refundDictionary = async () => {
  return (await getRequest(
    '/refund-management/refund-dictionary',
    { dicType: '' },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const findOrder = async (data: any) => {
  return (await getRequest('/refund-management/find-order', data, {
    type: HOST_TYPE_POWER,
  })) as unknown as APIS.BaseResponse<any>;
};
const financeAudit = async (data: any) => {
  return (await postRequest(
    '/refund-management/finance-audit',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const financeBatchPass = async (data: any) => {
  return (await postRequest(
    '/refund-management/finance-batch-pass',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 客服的新增和修改
const customerServiceInsert = async (data: any) => {
  return (await postRequest(
    '/refund-management/customer-service-insert',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 客服的保存
const financeInsert = async (data: any) => {
  return (await postRequest(
    '/refund-management/finance-insert',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 客服审核接口
const customerServiceAudit = async (data: any) => {
  return (await postRequest(
    '/refund-management/customer-service-audit',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

export {
  queryRefundList,
  uploadRefundList,
  exportData,
  getRefundDetails,
  refundDictionary,
  findOrder,
  financeAudit,
  customerServiceInsert,
  financeInsert,
  customerServiceAudit,
  financeBatchPass,
};

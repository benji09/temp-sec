type RefundType = 1 | 2 | undefined | null;
type RefundListProps = {
  refundType: RefundType;
};
type ModalType = 'create' | 'details' | undefined | null;
type TypeListType = Record<string | undefined, string | undefined>;

export { RefundType, RefundListProps, ModalType, TypeListType };

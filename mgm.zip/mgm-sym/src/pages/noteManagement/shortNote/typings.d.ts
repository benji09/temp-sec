type ShortNoteTableType = {
  actionId?: number;
  createdAt?: number;
  mobile?: string;
  notificationId?: string;
  notificationState?: number;
  relationTemplateId?: string;
  remark?: string;
  templateId?: number;
  templateName?: string;
};
type ModalPropType = {
  modalType?: number;
  visible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel?: () => void;
  onOk?: () => void;
  onSaveData?: () => void;
  onCancelSave?: () => void;
  children?: ReactNode;
};
type NotificationActionLogType = {
  createdAt?: number; // 操作时间
  operationDescription?: string; //操作描述
};
type DetailsType = {
  actionId?: number;
  createdAt?: number;
  mobile?: string;
  notificationActionLog?: NotificationActionLogType[];
  notificationContent?: string;
  notificationId?: number;
  notificationState?: number;
  relationTemplateId?: string;
  remark?: string;
  templateId?: number;
  templateName?: string;
};
export { ShortNoteTableType, ModalPropType, DetailsType, NotificationActionLogType };

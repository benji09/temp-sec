import _ from 'lodash';
import React, { useRef, useState } from 'react';
import { Button, Popconfirm } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/index';
import { formatTime } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { ClickDownXlsx } from '@/utils/downXlsx';

import Modal from './component/ShortNoteModal';
import Details from './component/Details';
import Import from './component/ImportConent';
import { SEND_STATE } from './utils';
import {
  exportNotification,
  getDetailedNotification,
  getNotificationMobile,
  getShortNoteList,
  importNotification,
  sendAgainNote,
} from './api';
import type { ShortNoteTableType } from './typings';

const MODAL_TYPE_IMPORT = 1;
const MODAL_TYPE_DETAILS = 2;

const ShortNote: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const importRef = useRef<any>();
  const detailsRef = useRef<any>();

  const [mobilesCache, setMobilesCache] = useState({});

  const [modalType, setModalType] = useState<undefined | number>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const [detailsData, setDetailsData] = useState({});

  const [exportLoading, setExportLoading] = useState<boolean>(false);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_IMPORT:
        return '导入数据';
      case MODAL_TYPE_DETAILS:
        return '详情';
    }
    return '';
  }

  // 查看手机号
  const queryMobile = (record: any) => {
    getNotificationMobile(record.notificationId ?? '')
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.notificationId ?? ''] = res.result.mobile;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };

  function onCancel() {
    setVisible(false);
    setLoading(false);

    setDetailsData({});
    setTimeout(() => {
      importRef.current?.reset();
      detailsRef.current?.reset();
      setModalType(undefined);
    });
  }
  function onOk() {
    if (modalType === MODAL_TYPE_IMPORT) {
      importRef.current?.takeData().then((res: any) => {
        setDetailsData(res);
        setVisible(true);
      });
    }
  }
  function onSaveData() {
    if (modalType === MODAL_TYPE_IMPORT) {
      setVisible(false);
      setLoading(true);
      importNotification(detailsData).then((res) => {
        setLoading(false);
        if (res.status === 0) {
          setDetailsData({});
          importRef.current?.reset();
          setModalType(undefined);
          actionRef.current?.reload();
        }
      });
    }
  }
  function onCancelSave() {
    setVisible(false);
    setLoading(false);
  }

  // 重发短信
  function reconfirm(record: ShortNoteTableType) {
    sendAgainNote(record.notificationId).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('重发短信成功');
        actionRef.current?.reload();
      } else {
        showErrorMessage('重发短信失败');
      }
    });
  }
  // 点击详情
  function detailsClick(record: ShortNoteTableType) {
    setModalType(MODAL_TYPE_DETAILS);
    getDetailedNotification(record.notificationId ?? '').then((res) => {
      if (res.status === 0) {
        detailsRef.current?.setData(res?.result ?? {});
      }
    });
  }
  const userMobile = (text: string, record: ShortNoteTableType) => {
    return (
      <>
        {mobilesCache[record?.notificationId ?? ''] || text}
        {(record?.mobile ?? '').indexOf('*') < 0 ||
        mobilesCache[record.notificationId ?? ''] ||
        (record?.mobile ?? '').trim().length < 1 ? null : (
          <Button type="link" key="lookMobile" onClick={() => queryMobile(record)}>
            查看
          </Button>
        )}
      </>
    );
  };

  // 导出
  function exportClick() {
    setExportLoading(true);
    exportNotification().then((res: any) => {
      setExportLoading(false);
      const { size } = res;
      if (size <= 500) {
        showErrorMessage('数据流异常，无法正常下载');
        return;
      }
      ClickDownXlsx(res, '短信发送管理');
      showSuccessMessage('导出成功');
    });
  }
  const columns: ProColumns<ShortNoteTableType>[] = [
    {
      title: '用户手机号',
      dataIndex: 'mobile',
      render: (text: any, record: ShortNoteTableType) => userMobile(text, record),
      hideInSearch: true,
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
      hideInTable: true,
    },

    {
      title: '模板 id',
      dataIndex: 'relationTemplateId',
    },
    {
      title: '模板名称',
      dataIndex: 'templateName',
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      renderText: (text) => formatTime(text ?? ''),
      hideInSearch: true,
    },
    {
      title: '发送状态',
      valueType: 'select',
      dataIndex: 'notificationState',
      valueEnum: SEND_STATE,
    },
    {
      title: '流水号',
      dataIndex: 'actionId',
      hideInSearch: true,
    },
    {
      title: '备注',
      dataIndex: 'remark',
      hideInSearch: true,
    },
    {
      title: '操作',
      dataIndex: '',
      hideInSearch: true,
      render: (text, record) => [
        <Button onClick={() => detailsClick(record)} key={'details'} type="link">
          详情
        </Button>,
        <Popconfirm
          key={'retry'}
          title="您确定重新短信吗？"
          onConfirm={() => reconfirm(record)}
          okText="是"
          cancelText="否"
        >
          <Button type="link">重发</Button>
        </Popconfirm>,
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="ShortNoteTable"
      columns={columns}
      actionRef={actionRef}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={getShortNoteList}
      rowKey="notificationId"
      toolBarRender={() => [
        <Button
          loading={exportLoading}
          key="export"
          onClick={() => {
            exportClick();
          }}
          type="primary"
        >
          导出
        </Button>,
        <Button
          key="import"
          onClick={() => {
            setModalType(MODAL_TYPE_IMPORT);
            console.log('导入数据');
          }}
          type="primary"
        >
          导入数据
        </Button>,
      ]}
    >
      <Modal
        modalType={modalType}
        visible={visible}
        title={getModalTitle()}
        loading={loading}
        onCancel={onCancel}
        onOk={onOk}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        {modalType === MODAL_TYPE_DETAILS && <Details ref={detailsRef} />}
        {modalType === MODAL_TYPE_IMPORT && <Import ref={importRef} />}
      </Modal>
    </TableLocal>
  );
};
export default ShortNote;

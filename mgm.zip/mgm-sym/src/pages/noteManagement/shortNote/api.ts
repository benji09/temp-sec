import { HOST_TYPE_POWER } from '@/utils/utils';
import { postRequest } from '@/services/api';

let search = {};

const getShortNoteList = async (params: any) => {
  const { current, pageSize, ...data } = params;

  search = data;
  const msg = (await postRequest(
    '/manual-sms-notification/list-notification',
    {
      ...data,
      size: pageSize,
      page: current,
    },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: msg?.result?.list || [],
    total: msg?.result?.total || 0,
  };
};
const sendAgainNote = async (notificationId: any) => {
  return (await postRequest(
    '/manual-sms-notification/retry-notification',
    { notificationId },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
// 查看手机号
const getNotificationMobile = async (notificationId: string | number) => {
  return (await postRequest(
    '/manual-sms-notification/get-notification-mobile',
    { notificationId },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
// 获取详情接口
const getDetailedNotification = async (notificationId: string | number) => {
  return (await postRequest(
    '/manual-sms-notification/get-detailed-notification',
    { notificationId },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
// 导入数据
const importNotification = async (data: any) => {
  return (await postRequest(
    '/manual-sms-notification/import-notification',
    { ...data },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};

// 搜索通知模板
const messageTemplateList = async (params: any) => {
  return (await postRequest(
    '/notice/list-notice-template',
    params,
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
// 导出
const exportNotification = async () => {
  return (await postRequest(
    '/manual-sms-notification/export-notification',
    search,
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  )) as unknown as APIS.BaseResponse<any>;
};
export {
  getShortNoteList,
  sendAgainNote,
  getNotificationMobile,
  getDetailedNotification,
  importNotification,
  messageTemplateList,
  exportNotification,
};

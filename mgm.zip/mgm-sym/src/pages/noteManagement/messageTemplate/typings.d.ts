type MessageTemplateType = {
  id?: number; //模板 ID
  placeholder?: number; //占位符数量
  relationTemplateId?: string; //关联模板 ID(展示在列表里)
  templateContent?: string; //模板内容
  templateName?: string; // 模板名称
};
export { MessageTemplateType };

import React from 'react';
import { Tooltip } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';
import type { ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/index';

import { getMessageTemplateList } from './api';
import type { MessageTemplateType } from './typings';

const MessageTemplate: React.FC = () => {
  // table中的内容
  const contentTooltip = () => (
    <>
      内容
      <Tooltip placement="top" title="%s 为变量内容，需自己补充">
        <QuestionCircleOutlined style={{ marginLeft: 4 }} />
      </Tooltip>
    </>
  );

  const columns: ProColumns<MessageTemplateType>[] = [
    {
      title: 'ID',
      dataIndex: 'relationTemplateId',
      width: '100px',
      align: 'center',
    },
    {
      title: '模板名称',
      dataIndex: 'templateName',
      width: '250px',
      align: 'center',
    },
    {
      title: contentTooltip,
      hideInSearch: true,
      dataIndex: 'templateContent',
      align: 'center',
    },
  ];

  return (
    <TableLocal
      tableClassName="messageTemplateTable"
      columns={columns}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={getMessageTemplateList}
      rowKey="id"
      toolBarRender={() => []}
    />
  );
};
export default MessageTemplate;

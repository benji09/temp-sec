import { HOST_TYPE_POWER } from '@/utils/utils';
import { postRequest } from '@/services/api';

// Banner列表
const getMessageTemplateList = async (params: any) => {
  const { current, pageSize, ...data } = params;

  const msg = (await postRequest(
    '/notice/list-notice-template',
    data,
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: msg?.result ?? [],
    total: (msg?.result ?? []).length,
  };
};

export { getMessageTemplateList };

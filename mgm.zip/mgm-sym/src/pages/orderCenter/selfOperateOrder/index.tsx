import React, { useRef, useState } from 'react';
import { Button, DatePicker, Upload } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';
import type { RcFile } from 'antd/lib/upload';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import {
  selfOperatedOrdersPage,
  listSubOrder,
  importLogisticsInformation,
  orderExport,
  downloadExcelTemplate,
} from '@/services/api';
import { ClickDownXlsx } from '@/utils/downXlsx';
import { changeTime, changeMoney } from '../util/tools';
import {
  selfOperateOrderStatus,
  selfOperateOrderFastMailStatus,
  selfOperateChannel,
} from '../util';
import { typeUploaded } from '@/utils/utils';
import dayjs from 'dayjs';
import MenuDetail from './components/MenuDetail';

import './index.less';

const { RangePicker } = DatePicker;

function disabledDate(current: any) {
  //  实际类型 DateType，由于无法导入，暂用 any 代替
  return current && current > new Date();
}

type NoteRetryType = {
  orderNo?: string;
  parentOrderNo?: string;
};

export default (): React.ReactNode => {
  const actionRef = useRef<ActionType | undefined>();
  const [exportLoading, setExportLoading] = useState<boolean>(false);
  const [scheduleLoading, setScheduleLoading] = useState(false);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [menuDetailInfo, setMenuDetailInfo] = useState({});
  const [searchData, setSearchData] = useState({});

  const columns: ProColumns<NoteRetryType>[] = [
    {
      title: '主子订单',
      dataIndex: '',
      hideInSearch: true,
      render: (_text, _record, index) => {
        return <span>主</span>;
      },
    },
    {
      title: '付款订单号',
      dataIndex: 'parentOrderNo',
    },
    {
      title: '订单号',
      dataIndex: 'subOrderNo',
      hideInTable: true,
    },
    {
      title: 'UserID',
      dataIndex: 'userId',
      // hideInTable: true,
      hideInSearch: true,
    },
    {
      title: '手机号',
      dataIndex: 'userPhone',
    },
    {
      title: '订单状态',
      dataIndex: 'orderStatus',
      valueType: 'select',
      valueEnum: selfOperateOrderStatus,
    },
    {
      title: '订单来源',
      dataIndex: 'sourceType',
      hideInSearch: true,
    },
    {
      title: '对应渠道',
      dataIndex: 'channel',
      hideInSearch: true,
    },
    {
      title: '对应渠道',
      dataIndex: 'orderChannel',
      hideInTable: true,
      valueType: 'select',
      valueEnum: selfOperateChannel,
    },
    {
      title: '优惠金额',
      dataIndex: 'discountAmount',
      hideInSearch: true,
      render: (_text, record?: any) => changeMoney(record?.discountAmount),
    },
    {
      title: '支付金额',
      dataIndex: 'payAmount',
      hideInSearch: true,
      render: (_text, record?: any) => changeMoney(record?.payAmount),
    },
    {
      title: '支付时间',
      dataIndex: 'payTime',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '支付时间',
      dataIndex: 'payTime',
      hideInSearch: true,
      render: (_text, record?: any) => changeTime(record.payTime),
    },
    {
      title: '是否录入完成物流单号',
      dataIndex: 'hasDeliveryNo',
      valueType: 'select',
      valueEnum: selfOperateOrderFastMailStatus,
    },
    {
      title: '生成订单时间',
      dataIndex: 'createOrderTime',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '生成订单时间',
      dataIndex: 'createTime',
      hideInSearch: true,
      render: (_text, record?: any) => changeTime(record.createTime),
    },
    {
      title: '备注',
      dataIndex: 'remark',
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text?: any, record?: any, index?: number) => {
        return (
          <Button type="link" onClick={() => handleMainMenu(_text, record, index)}>
            详情
          </Button>
        );
      },
    },
  ];

  // 获取主菜单列表
  const getMainOrderList = async (params?: any, options?: any) => {
    const payTimeStart =
      params?.payTime?.length === 2 ? dayjs(`${params?.payTime[0]} 00:00:00`).valueOf() : '';
    const payTimeEnd =
      params?.payTime?.length === 2 ? dayjs(`${params?.payTime[1]} 23:59:59`).valueOf() : '';
    const createOrderTimeStart =
      params?.createOrderTime?.length === 2
        ? dayjs(`${params?.createOrderTime[0]} 00:00:00`).valueOf()
        : '';
    const createOrderTimeEnd =
      params?.createOrderTime?.length === 2
        ? dayjs(`${params?.createOrderTime[1]} 23:59:59`).valueOf()
        : '';

    const getParams = {
      ...params,
      currentPage: params.current,
      payTimeStart,
      payTimeEnd,
      createOrderTimeStart,
      createOrderTimeEnd,
    };
    setSearchData(getParams);
    return await selfOperatedOrdersPage(getParams, options);
  };

  // 查看详情
  const handleMainMenu = (_text?: any, record?: any, index?: number) => {
    setMenuDetailInfo({
      ...record,
      rendom: Math.random() * 1e18,
    });
  };

  // 点击导出按钮
  function exportClick() {
    setExportLoading(true);
    orderExport(searchData)
      .then((res) => {
        setExportLoading(false);
        const { size } = res;
        if (size <= 500) {
          showErrorMessage('数据流异常，无法正常下载');
          return;
        }
        ClickDownXlsx(res, '自营订单-导出');
        showSuccessMessage('导出成功');
      })
      .finally(() => setExportLoading(false));
  }

  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name || '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(typeUploaded('xlsx'));
    return isXlsx;
  }

  function customeUpload(options: any) {
    setUploadLoading(true);
    importLogisticsInformation(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage('导入成功');
          window.location.reload();
        } else showErrorMessage(`导入失败：${res.message}`);
      })
      .finally(() => setUploadLoading(false));
  }

  const toolBarRender = () => [
    <Button loading={exportLoading} key="export" type="primary" onClick={exportClick}>
      <DownloadOutlined />
      导出
    </Button>,
    <Upload
      key="batchRefund"
      accept={'.xlsx'}
      maxCount={1}
      type={'select'}
      beforeUpload={handleBeforeUpload}
      customRequest={customeUpload}
      showUploadList={false}
      loading={uploadLoading}
    >
      <Button type="primary">导入物流信息</Button>
    </Upload>,
    <Button
      key="entering"
      type="primary"
      loading={scheduleLoading}
      onClick={() => {
        setScheduleLoading(true);
        downloadExcelTemplate('DDWL').finally(() => setScheduleLoading(false));
      }}
    >
      <DownloadOutlined />
      下载导入物流信息
    </Button>,
  ];

  const submenuColumns = [
    {
      title: '主子订单',
      dataIndex: '',
      hideInSearch: true,
      render: (_text?: any, _record?: any) => {
        return <span>{_record?.isParentOrder === 1 ? '主' : '子'}</span>;
      },
    },
    { title: '订单号', dataIndex: 'subOrderNo' },
    { title: '订单状态', dataIndex: 'orderStatus' },
    { title: '物流状态', dataIndex: 'deliveryStatus' },
    { title: '对应渠道', dataIndex: 'channel' },
    { title: '备注', dataIndex: 'remark' },
    {
      title: '操作',
      dataIndex: '',
      render: (_text?: any, record?: any, index?: number) => {
        return (
          <Button type="link" onClick={() => handleMainMenu(_text, record, index)}>
            详情
          </Button>
        );
      },
    },
  ];

  const expandedRowRender = (item?: any) => {
    return (
      <ProTable
        className="subList"
        columns={submenuColumns}
        request={() => listSubOrder(item)}
        headerTitle={false}
        rowKey="subOrderNo"
        search={false}
        options={false}
        pagination={false}
      />
    );
  };

  return (
    <div className="selfOperateOrder">
      <PageContainer>
        <ProTable<NoteRetryType>
          actionRef={actionRef}
          columns={columns}
          request={getMainOrderList}
          rowKey="parentOrderNo"
          pagination={{
            defaultPageSize: 10,
          }}
          search={{
            optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
          }}
          toolBarRender={toolBarRender}
          expandable={{
            expandedRowRender: (item) => expandedRowRender(item),
          }}
        />
      </PageContainer>

      {/* 主菜单详情 + 子菜单详情 */}
      <MenuDetail menuDetailInfo={menuDetailInfo} />
    </div>
  );
};

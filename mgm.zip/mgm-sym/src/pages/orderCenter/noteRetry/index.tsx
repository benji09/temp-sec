import React, { useRef } from 'react';
import { Button, Popconfirm } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { showSuccessMessage } from '@/mamagement/Notification';
import { orderManagementList, sendDrugOrderMessage } from '@/services/api';

import { insuranceStatusType } from '../util';

type NoteRetryType = {
  customerName?: string;
  customerPhone?: string;
  insuranceType?: number;
  orderId?: string;
};

export default (): React.ReactNode => {
  const actionRef = useRef<ActionType | undefined>();
  function confirm(orderId: string) {
    sendDrugOrderMessage({ orderId }).then((res: any) => {
      if (res.status === 0) {
        showSuccessMessage('已成功重发短信');
      }
    });
  }

  const columns: ProColumns<NoteRetryType>[] = [
    {
      title: '手机号',
      dataIndex: 'mobile',
      hideInTable: true,
    },
    {
      title: '序号',
      dataIndex: '',
      render: (_text, _record, index) => {
        return <span>{index + 1}</span>;
      },
      hideInSearch: true,
    },
    {
      title: '用户手机号',
      dataIndex: 'customerPhone',
      hideInSearch: true,
    },
    {
      title: '购买人姓名',
      dataIndex: 'customerName',
      hideInSearch: true,
    },
    {
      title: '购买版本',
      dataIndex: 'insuranceType',
      hideInSearch: true,
      valueType: 'select',
      valueEnum: insuranceStatusType,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => {
        return (
          <>
            <Popconfirm
              title="是否重新发送？"
              onConfirm={() => {
                confirm(record.orderId || '');
              }}
              okText="确认"
              cancelText="取消"
            >
              <Button type="link">重发短信</Button>
            </Popconfirm>
          </>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <ProTable<NoteRetryType>
        actionRef={actionRef}
        columns={columns}
        request={orderManagementList}
        rowKey="orderId"
        pagination={{
          defaultPageSize: 10,
        }}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
      />
    </PageContainer>
  );
};

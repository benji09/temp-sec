export const insuranceStatusType = {
  0: {
    text: '个人版',
  },
  1: {
    text: '家庭版',
  },
  2: {
    text: '屯卡',
  },
};

export const selfOperateOrderStatus = {
  1: {
    text: '预订单',
  },
  3: {
    text: '待提交',
  },
  9: {
    text: '已作废',
  },
  11: {
    text: '待支付',
  },
  20: {
    text: '已支付',
  },
  40: {
    text: '已完成',
  },
  12: {
    text: '支付过期',
  },
};

export const selfOperateOrderFastMailStatus = {
  1: {
    text: '否',
  },
  2: {
    text: '是',
  },
};

export const selfOperateChannel = {
  1: {
    text: '海典',
  },
  2: {
    text: '自营',
  },
};

export const changeTime = (num: number | string) => {
  if (!num || num === '0') return '-';
  num = Number(num);
  let add0 = (m: number) => (m < 10 ? '0' + m : m);
  var time = new Date(num);
  var y = time.getFullYear();
  var m = time.getMonth() + 1;
  var d = time.getDate();
  var h = time.getHours();
  var mm = time.getMinutes();
  var s = time.getSeconds();
  return `${y}-${add0(m)}-${add0(d)} ${add0(h)}:${add0(mm)}:${add0(s)}`;
};

export const changeMoney = (num: number | string) => {
  if (!num) return '-';
  return Number(num) / 100 + '元';
};

import { getRequest } from '@/services/api';
import { checkIsNumberForSearch } from '@/utils/utils';

import type { GetToolsListDataType } from './typings';

// tools列表
const getToolsList = async (data: GetToolsListDataType) => {
  const { mobile, userId } = data;
  const UserIdResult = checkIsNumberForSearch(userId, 'UserId');
  if (UserIdResult !== null) return UserIdResult;
  const MobileResult = checkIsNumberForSearch(mobile, '手机号');
  if (UserIdResult !== null) return MobileResult;

  return await getRequest<APIS.BaseResponse<any>>('/tool/exist/mobile/account', {
    mobile: mobile || '',
    userId: userId || 0,
  });
};
export { getToolsList };

import { useState } from 'react';
import _ from 'lodash';
import { Card, Col, Row, Form, Input, Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns } from '@ant-design/pro-table';

import { showErrorMessage } from '@/mamagement/Notification';
import { defaultFormLayout } from '@/utils/utils';

import { getToolsList } from './api';

import './index.less';

interface IhistoryList {
  mobile: string | number | undefined;
  userId: string | number | undefined;
}
function Tools() {
  const [orderloading, setOrderloading] = useState<boolean>(false);
  const [historyList, setHistoryList] = useState<IhistoryList[]>([]);
  const [formUserId] = Form.useForm();
  const [formMobile] = Form.useForm();

  const onUserIdFinish = (values: any) => {
    if (values.userId) {
      setOrderloading(true);
      getToolsList({ userId: values.userId }).then((res: any) => {
        if (res?.status === 0) {
          const { result } = res;
          if (!result.exist) {
            showErrorMessage('未找到用户手机号');
          } else {
            const list = _.cloneDeep(historyList);
            list.map((item, index) => {
              if (item.userId === JSON.parse(values.userId)) {
                list.splice(index, 1);
              }
            });
            list.unshift({ userId: result.userId, mobile: result.mobile });
            setHistoryList(list);
          }
        }
        setOrderloading(false);
      });
    } else {
      showErrorMessage('请输入要查找的 UserID');
    }
  };
  const onMobileFinish = (values: any) => {
    if (values.mobile) {
      setOrderloading(true);
      getToolsList({ mobile: values.mobile }).then((res: any) => {
        if (res?.status === 0) {
          const { result } = res;
          if (!result.exist) {
            showErrorMessage('未找到用户ID');
          } else {
            const list = _.cloneDeep(historyList);
            list.map((item, index) => {
              if (item.mobile === values.mobile) {
                list.splice(index, 1);
              }
            });
            list.unshift({ userId: result.userId, mobile: values.mobile });
            setHistoryList(list);
          }
        }
        setOrderloading(false);
      });
    } else {
      showErrorMessage('请输入要查找的手机号');
    }
  };
  const onUserIdFill = () => {
    formUserId.resetFields();
  };
  const onMobileFill = () => {
    formMobile.resetFields();
  };
  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 24 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 24 },
    },
  };

  const columns: ProColumns[] = [
    {
      title: '手机号',
      align: 'center',
      dataIndex: 'mobile',
    },
    {
      title: 'UserID',
      align: 'center',
      dataIndex: 'userId',
    },
  ];

  return (
    <PageContainer>
      <Card className="userQuery">
        <Form {...defaultFormLayout} form={formUserId} onFinish={onUserIdFinish}>
          <Row className="orderHeavyPushSearch">
            <Col span={16}>
              <Form.Item label="UserID" name="userId" style={{ marginBottom: '0px' }}>
                <Input allowClear maxLength={11} placeholder="请输入要查找的 UserID" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                {...formItemLayout}
                className="orderHeavyPushButton"
                style={{ marginBottom: '0px' }}
              >
                <Button loading={orderloading} type="primary" htmlType="submit">
                  查找
                </Button>
                <Button type="default" htmlType="button" onClick={onUserIdFill}>
                  重置
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <Form {...defaultFormLayout} form={formMobile} onFinish={onMobileFinish}>
          <Row className="orderHeavyPushSearch">
            <Col span={16}>
              <Form.Item label="手机号" name="mobile" style={{ marginBottom: '0px' }}>
                <Input allowClear maxLength={11} placeholder="请输入要查找的手机号" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item
                {...formItemLayout}
                className="orderHeavyPushButton"
                style={{ marginBottom: '0px' }}
              >
                <Button loading={orderloading} type="primary" htmlType="submit">
                  查找
                </Button>
                <Button type="default" htmlType="button" onClick={onMobileFill}>
                  重置
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
        <ProTable
          className={'table'}
          columns={columns}
          rowKey="userId"
          dateFormatter="string"
          dataSource={historyList}
          search={false}
          pagination={false}
          options={false}
          size={'small'}
          style={{ padding: '0px' }}
          bordered={true}
        />
      </Card>
    </PageContainer>
  );
}
export default Tools;

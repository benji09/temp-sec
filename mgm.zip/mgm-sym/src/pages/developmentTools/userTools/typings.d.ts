interface GetToolsListDataType {
  userId?: string;
  mobile?: string;
}
export { GetToolsListDataType };

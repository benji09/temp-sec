/* eslint-disable no-param-reassign */
import React from 'react';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns } from '@ant-design/pro-table';

import { getWorkList } from '@/services/api';

type GetWorkItem = {
  assistantId?: number;
  assistantName?: string;
  open?: boolean;
  orderNumber?: number;
  providerId?: number;
  providerName?: string;
  roomTagName?: string[];
  work?: boolean;
};
const Work: React.FC = () => {
  const columns: ProColumns<GetWorkItem>[] = [
    {
      title: '助手ID',
      dataIndex: 'assistantId',
      hideInSearch: true,
    },
    {
      title: '助手姓名',
      dataIndex: 'assistantName',
      hideInSearch: true,
    },
    {
      title: '医生ID',
      dataIndex: 'providerId',
      hideInSearch: true,
    },
    {
      title: '医生姓名',
      dataIndex: 'providerName',
      hideInSearch: true,
    },
    {
      title: '开诊',
      dataIndex: 'open',
      hideInSearch: true,

      filters: true,
      onFilter: true,
      valueEnum: {
        true: { text: '开诊' },
        false: { text: '关诊' },
      },
    },
    {
      title: '是否上班',
      hideInSearch: true,
      dataIndex: 'work',
      filters: true,
      onFilter: true,
      valueEnum: {
        true: { text: '上班' },
        false: { text: '下班' },
      },
    },
    {
      title: '当前进行单数',
      dataIndex: 'orderNumber',
      hideInSearch: true,
    },
    {
      title: '诊室tag',
      dataIndex: 'skuId',
      hideInSearch: true,
      render: (_text, record) => {
        return (
          record.roomTagName?.length &&
          record.roomTagName?.map((item: string, index: number) => {
            if (index !== (record.roomTagName?.length || 0) - 1) {
              item += '、';
            }
            return <span key={String(index)}>{item}</span>;
          })
        );
      },
    },
  ];

  return (
    <PageContainer>
      <ProTable<GetWorkItem>
        columns={columns}
        request={getWorkList}
        search={false}
        rowKey="assistantId"
        dateFormatter="string"
        pagination={false}
      />
    </PageContainer>
  );
};
export default Work;

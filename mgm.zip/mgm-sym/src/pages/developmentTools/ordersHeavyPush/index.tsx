import React, { useState } from 'react';
import { Card, Col, Row, Form, Input, Button } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import { PushOrderCallback } from '@/services/api';
import { showSuccessMessage } from '@/mamagement/Notification';

import './index.less';

export default (): React.ReactNode => {
  const [orderloading, setOrderloading] = useState<boolean>(false);
  const [mobileLoading, setMobileLoading] = useState<boolean>(false);

  const onOrderFinish = (values: any) => {
    setOrderloading(true);
    const data = { orderId: values.orderId, operating: 'PUSH', mobile: '' };

    PushOrderCallback(data).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('发送成功');
      }
      setOrderloading(false);
    });
  };

  const onMobileFinish = (values: any) => {
    setMobileLoading(true);
    const data = { orderId: values.orderId, mobile: values.mobile, operating: 'SMS' };

    PushOrderCallback(data).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('发送成功');
      }
      setMobileLoading(false);
    });
  };

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 24 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 24 },
    },
  };

  return (
    <PageContainer>
      <Card className="orderHeavyPush">
        <Row className="orderHeavyPushMsg">
          <h3>药无忧单售版订单重推</h3>
          <Col span={24}>
            <span className="orderHeavyPushHint">请由正生提供未正常透传健管的订单号</span>
          </Col>
          <Col span={24}>
            <span className="orderHeavyPushHint">或用户未收到激活码的订单号</span>
          </Col>
          <Col span={24}>
            <span className="orderHeavyPushHint">* 请勿擅自使用，将追究各种责任。</span>
          </Col>
        </Row>
        <Form {...formItemLayout} onFinish={onOrderFinish}>
          <Row>
            <Col span={7}>
              <Form.Item
                label="请输入待处理订单号"
                labelAlign="left"
                name="orderId"
                rules={[{ required: true, message: '请确认订单号是否正确' }]}
              >
                <Input placeholder="请输入待处理订单号" />
              </Form.Item>
            </Col>
            <Col span={5}>
              <Form.Item className="orderHeavyPushButton">
                <Button loading={orderloading} type="primary" htmlType="submit">
                  重推健管
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>

        <Form {...formItemLayout} onFinish={onMobileFinish}>
          <span className="noteHint">若用户使用原手机号接收请勿填写</span>
          <Row>
            <Col span={7}>
              <Form.Item
                label="请填写其他接收手机号"
                labelAlign="left"
                name="mobile"
                rules={[{ required: true, message: '请确认是否填写了手机号' }]}
              >
                <Form.Item style={{ marginBottom: 0 }} labelAlign="left" name="mobile">
                  <Input maxLength={11} placeholder="请填写其他接收手机号" />
                </Form.Item>
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={7}>
              <Form.Item
                label="请输入待处理订单号"
                labelAlign="left"
                name="orderId"
                rules={[{ required: true, message: '请确认是否填写了订单号' }]}
              >
                <Form.Item style={{ marginBottom: 0 }} labelAlign="left" name="orderId">
                  <Input placeholder="请输入待处理订单号" />
                </Form.Item>
              </Form.Item>
            </Col>
            <Col span={5}>
              <Form.Item className="orderHeavyPushButton noteButton">
                <Button loading={mobileLoading} type="primary" htmlType="submit">
                  重发短信
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Card>
    </PageContainer>
  );
};

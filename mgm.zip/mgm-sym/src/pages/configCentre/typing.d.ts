/*
 * @Author: Walker Denial
 * @Date: 2022-01-12 16:54:16
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-12 16:55:43
 * @Desc:
 */
type PrescriptionParams = {
  autoSign?: boolean; // 自动签发开关
  doctorSignDelay?: number; // 医生签发延迟时间
  signDelay?: number; // 药师签发延迟时间
};

export { PrescriptionParams };

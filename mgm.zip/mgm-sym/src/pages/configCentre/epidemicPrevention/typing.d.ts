type EpidemicPreventionType = {
  city?: string[];
  current: number;
  pageSize: number;
};
type ModalPropType = {
  modalType?: number;
  visible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel?: () => void;
  onOk?: () => void;
  onSaveData?: () => void;
  onCancelSave?: () => void;
  children?: ReactNode;
};
type EpidemicPreventionItemType = {
  beenDangerousArea?: number;
  city?: string;
  cityCode?: number;
  district?: string;
  districtCode?: number;
  id?: number;
  interceptionType?: number;
  preventionSymptoms?: number[];
  preventionTemperature?: number;
  province?: string;
  provinceCode?: number;
  touchBeenDangerousPeople?: number;
  turnOnData?: string;
};
type DetailsType = {
  preventionTemperature?: number;
  preventionSymptoms?: number[];
  beenDangerousArea?: number;
  touchBeenDangerousPeople?: number;
};
type AddressType = {
  code?: string;
  name?: string;
};
type CreateConfigType = {
  beenDangerousArea?: number;
  city?: string;
  cityCode?: number;
  district?: string;
  districtCode?: number;
  id?: number;
  interceptionType?: number;
  preventionSymptoms?: number[];
  preventionTemperature?: number;
  province?: string;
  provinceCode?: number;
  touchBeenDangerousPeople?: number;
  turnOnData?: string;
};
export {
  EpidemicPreventionType,
  EpidemicPreventionItemType,
  ModalPropType,
  DetailsType,
  AddressType,
  CreateConfigType,
};

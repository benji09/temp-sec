import { postRequest } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type { CreateConfigType, EpidemicPreventionType } from './typing';

const epidemicPreventionList = async (params: EpidemicPreventionType) => {
  const { current, pageSize, city, ...data } = params;
  const msg = (await postRequest(
    '/epidemic-prevention/list-config',
    {
      ...data,
      cityCode: (city && city[0]) || '0',
      provinceCode: (city && city[1]) || '0',
      size: pageSize,
      page: current,
    },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: msg?.result?.list || [],
    total: msg?.result?.total || 0,
  };
};
// 查询防疫配置开关状态
const getConfigState = async () => {
  return (await postRequest(
    '/epidemic-prevention/get-config-state',
    {},
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 更新防疫配置开关状态
const updateConfigState = async (state: boolean) => {
  return (await postRequest(
    '/epidemic-prevention/update-config-state',
    { state },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 删除操作
const deleteConfig = async (id: number | string) => {
  return (await postRequest(
    '/epidemic-prevention/delete-config',
    { id },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 新建
const createConfig = async (data: CreateConfigType) => {
  return (await postRequest(
    '/epidemic-prevention/create-config',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 查询省份
const addressListProvince = async () => {
  return (await postRequest(
    '/address/list-province',
    {},
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 通过省份代码获取城市
const addressListCity = async (code?: string) => {
  return (await postRequest(
    '/address/list-city',
    { code },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 通过城市代码获取区域
const addressListDistrict = async (code?: string) => {
  return (await postRequest(
    '/address/list-district',
    { code },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

export {
  epidemicPreventionList,
  getConfigState,
  updateConfigState,
  deleteConfig,
  addressListProvince,
  addressListCity,
  addressListDistrict,
  createConfig,
};

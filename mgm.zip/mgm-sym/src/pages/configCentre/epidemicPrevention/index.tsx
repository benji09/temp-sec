import _ from 'lodash';
import React, { useEffect, useRef, useState } from 'react';
import { Button, Cascader, Col, Popconfirm, Switch } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/TableLocal';

import Modal from './components/Modal';
import Details from './components/Details';
import Create from './components/Create';
import { getInterceptionType } from '../utils';
import {
  addressListCity,
  addressListProvince,
  createConfig,
  deleteConfig,
  epidemicPreventionList,
  getConfigState,
  updateConfigState,
} from './api';
import type { CreateConfigType, EpidemicPreventionItemType } from './typing';

const MODAL_TYPE_CREATE = 1;
const MODAL_TYPE_DETAILS = 2;

const EpidemicPrevention: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const createRef = useRef<any>();
  const detailsRef = useRef<any>();

  const [modalType, setModalType] = useState<undefined | number>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const [configState, setConfigState] = useState<boolean>(false);
  const [configStateLoading, setConfigStateLoading] = useState<boolean>(false);

  const [detailsData, setDetailsData] = useState<CreateConfigType>({});
  const [options, setOptions] = useState([]);

  useEffect(() => {
    getConfigState().then((res) => {
      if (res.status === 0) {
        setConfigState(res.result?.state);
      }
    });
    addressListProvince().then((res) => {
      if (res.status === 0) {
        res.result.unshift({
          code: '0',
          name: '全部',
        });
        const data: any = [];
        res.result.map((item: any) => {
          if (item.code === '0') {
            data.push(item);
          } else {
            item.isLeaf = false;
            data.push(item);
          }
        });
        setOptions(data);
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_CREATE:
        return '新建';
      case MODAL_TYPE_DETAILS:
        return '详情';
    }
    return '';
  }

  function onCancel() {
    setVisible(false);
    setLoading(false);

    setDetailsData({});
    setTimeout(() => {
      createRef.current?.reset();
      detailsRef.current?.reset();
      setModalType(undefined);
    });
  }
  function onOk() {
    if (modalType === MODAL_TYPE_CREATE) {
      createRef.current?.takeData().then((res: any) => {
        setDetailsData(res);
        setVisible(true);
      });
    }
  }
  function onSaveData() {
    if (modalType === MODAL_TYPE_CREATE) {
      createConfig(detailsData).then((res) => {
        setVisible(false);
        setLoading(false);
        if (res.status === 0) {
          setDetailsData({});
          createRef.current?.reset();
          setModalType(undefined);
          actionRef.current?.reload();
        }
      });
    }
  }
  function onCancelSave() {
    setVisible(false);
    setLoading(false);
  }

  // 点击删除
  function deleteClick(record: EpidemicPreventionItemType) {
    deleteConfig(record.id || '').then((res) => {
      if (res.status === 0) {
        actionRef.current?.reload();
      }
    });
  }
  // 点击详情
  function detailsClick(record: EpidemicPreventionItemType) {
    setModalType(MODAL_TYPE_DETAILS);
    setTimeout(() => {
      detailsRef.current?.setData(record);
    });
  }

  // 是否全部拦截 和 部分拦截的详情按钮
  const interception = (record: EpidemicPreventionItemType) => {
    const { interceptionType } = record;
    return (
      <span key={'interceptionType'}>
        {getInterceptionType[interceptionType || 0]?.text ?? '-'}
        {interceptionType === 1 && (
          <Button
            type="link"
            onClick={() => {
              detailsClick(record);
            }}
          >
            详情
          </Button>
        )}
      </span>
    );
  };

  // 操作中的删除
  const deleteOperation = (record: EpidemicPreventionItemType) => {
    return (
      <Popconfirm
        key={'delete'}
        title="是否删除本条防疫拦截地址？"
        onConfirm={() => deleteClick(record)}
      >
        <Button type="link">删除</Button>
      </Popconfirm>
    );
  };
  // 新增
  const createOperation = () => {
    return (
      <Button
        key={'create'}
        type="primary"
        onClick={() => {
          setModalType(MODAL_TYPE_CREATE);
        }}
      >
        <PlusOutlined />
        新增
      </Button>
    );
  };
  function switchChange(checked: boolean) {
    setConfigStateLoading(true);
    updateConfigState(checked).then((res) => {
      if (res.status === 0) {
        setConfigState(checked);
        setConfigStateLoading(false);
      }
    });
  }
  const epidemicPreventionSwitch = () => {
    return (
      <Col key={'switch'}>
        疫情防控开关{' '}
        <Switch loading={configStateLoading} checked={configState} onChange={switchChange} />
      </Col>
    );
  };
  const loadData = (selectedOptions: string | any[]) => {
    const targetOption = selectedOptions[selectedOptions.length - 1];
    targetOption.loading = true;
    addressListCity(targetOption.code).then((res) => {
      if (res.status === 0) {
        const tempCityList = _.cloneDeep(res.result);
        tempCityList.unshift({
          code: '0',
          name: '全部',
        });
        targetOption.loading = false;
        const data: any[] = [];
        tempCityList.map((item: any) => {
          data.push(item);
        });
        targetOption.children = data;
        setOptions([...options]);
      }
    });
  };

  const columns: ProColumns<EpidemicPreventionItemType>[] = [
    {
      title: '地区',
      dataIndex: 'city',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Cascader
            options={options}
            loadData={loadData}
            fieldNames={{ label: 'name', value: 'code', children: 'children' }}
            changeOnSelect
          />
        );
      },
    },
    {
      title: '',
      dataIndex: 'id',
      hideInSearch: true,
    },
    {
      title: '配置时间',
      dataIndex: 'turnOnData',
      hideInSearch: true,
    },
    {
      title: '省',
      dataIndex: 'province',
      hideInSearch: true,
    },
    {
      title: '市',
      dataIndex: 'city',
      hideInSearch: true,
    },
    {
      title: '区',
      dataIndex: 'district',
      hideInSearch: true,
    },
    {
      title: '是否全部拦截',
      dataIndex: 'interceptionType',
      valueType: 'select',
      valueEnum: getInterceptionType,
      initialValue: '0',
      hideInTable: true,
    },
    {
      title: '是否全部拦截',
      dataIndex: 'interceptionType',
      hideInSearch: true,
      renderText: (text: any, record: any) => interception(record),
    },
    {
      title: '管理',
      hideInSearch: true,
      render: (_text, record) => [deleteOperation(record)],
    },
  ];
  return (
    <TableLocal
      columns={columns}
      actionRef={actionRef}
      search={{
        labelWidth: 120,
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={epidemicPreventionList}
      rowKey="id"
      toolBarRender={() => [epidemicPreventionSwitch(), createOperation()]}
    >
      <Modal
        modalType={modalType}
        visible={visible}
        title={getModalTitle()}
        loading={loading}
        onCancel={onCancel}
        onOk={onOk}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        {modalType === MODAL_TYPE_DETAILS && <Details ref={detailsRef} />}
        {modalType === MODAL_TYPE_CREATE && <Create ref={createRef} />}
      </Modal>
    </TableLocal>
  );
};
export default EpidemicPrevention;

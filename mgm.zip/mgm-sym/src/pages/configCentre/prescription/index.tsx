/*
 * @Author: Walker Denial
 * @Date: 2022-01-06 19:01:44
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-15 18:43:30
 * @Desc:
 */
import { useState, useEffect } from 'react';
import { Typography, Card, Switch, Button, InputNumber } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { modifyPrescriptionConfig, queryPrescriptionConfig } from '../api';

import './index.less';

const PrescriptionConfig = () => {
  const { Title, Paragraph } = Typography;

  const [switchLoading, setSwitchLoading] = useState<boolean>(false);
  const [lastAutoSignChecked, setLastAutoSignChecked] = useState<boolean>(false);
  const [autoSignChecked, setAutoSignChecked] = useState<boolean>(false);
  const [delayConfigLoading, setDelayConfigLoading] = useState<boolean>(false);
  const [doctorDelay, setDoctorDelay] = useState<number | undefined>();
  const [signDelay, setSignDelay] = useState<number | undefined>();

  const queryConfig = () => {
    setSwitchLoading(true);
    setDelayConfigLoading(true);
    queryPrescriptionConfig()
      .then((res: any) => {
        const { status, result } = res;
        if (typeof status === 'undefined' || +status !== 0) return;
        const { autoSign, doctorSignDelay, signDelay: delay } = result;
        setAutoSignChecked(autoSign);
        setLastAutoSignChecked(autoSign);
        setDoctorDelay(doctorSignDelay);
        setSignDelay(delay);
      })
      .finally(() => {
        setSwitchLoading(false);
        setDelayConfigLoading(false);
      });
  };

  useEffect(() => {
    queryConfig();
  }, []);

  const onOkClick = () => {
    if (typeof doctorDelay === 'undefined' || doctorDelay < 0) {
      showErrorMessage('请正确输入医生签发延时配置');
      return;
    }
    if (typeof signDelay === 'undefined' || signDelay < 0) {
      showErrorMessage('请正确输入药师签发延时配置');
      return;
    }
    setDelayConfigLoading(true);
    modifyPrescriptionConfig({
      doctorSignDelay: doctorDelay,
      signDelay: signDelay,
      autoSign: autoSignChecked,
    })
      .then((res: any) => {
        const { status } = res;
        if (typeof status === 'undefined' || +status !== 0) return;
        showSuccessMessage('操作成功');
      })
      .finally(() => setDelayConfigLoading(false));
  };

  const onAutoSignChanged = (checked: boolean) => {
    if (checked === lastAutoSignChecked) return;
    setSwitchLoading(true);
    modifyPrescriptionConfig({ autoSign: checked })
      .then((res: any) => {
        const { status } = res;
        if (typeof status === 'undefined' || +status !== 0) {
          setAutoSignChecked(!checked);
        } else {
          setAutoSignChecked(checked);
          setLastAutoSignChecked(checked);
        }
      })
      .finally(() => setSwitchLoading(false));
  };

  return (
    <PageContainer className="prescription">
      <Card>
        <Title level={3}>商城处方药自动签发开关</Title>
        <div className="edit-area">
          <Title level={5}>商城处方药自动签发开关</Title>
          <Switch
            className="item-space"
            checkedChildren="开启"
            unCheckedChildren="关闭"
            loading={switchLoading}
            onChange={onAutoSignChanged}
            checked={autoSignChecked}
          />
        </div>
        <Paragraph style={{ marginTop: '6px' }}>
          当开关开启，商城用户自主购买的处方药，到签发平台医师、药师走自动签发。开关关闭，到签发平台医师走人工签发，药师走
          PASS 和时间段签发规则。
        </Paragraph>
      </Card>
      <Card>
        <Title level={3}>商城延时签发配置</Title>
        <div className="edit-area">
          <span className="mask">*</span>
          <Title level={5}>
            医生签发延时配置
            <InputNumber
              min={0}
              maxLength={9}
              className="item-space"
              value={doctorDelay}
              onChange={(value) => {
                if (value !== doctorDelay) setDoctorDelay(value);
              }}
              disabled={delayConfigLoading}
            />
            秒
          </Title>
        </div>
        <Paragraph>
          距离处方单生成多长时间医生自动签发的配置。
          <span className="mask">一但商城处方自动签签发开关关了，就不走这个延时了。</span>
        </Paragraph>
        <div className="edit-area">
          <span className="mask">*</span>
          <Title level={5}>
            药师签发延时配置
            <InputNumber
              min={0}
              maxLength={9}
              className="item-space"
              value={signDelay}
              onChange={(value) => {
                if (value !== signDelay) setSignDelay(value);
              }}
              disabled={delayConfigLoading}
            />
            秒
          </Title>
        </div>
        <Paragraph>
          距离医生签发成功多长时间药师自动签发的配置。
          <span className="mask">一但商城处方自动签签发开关关了，就不走这个延时了。</span>
        </Paragraph>
        <Button type="primary" className="btn" onClick={onOkClick} loading={delayConfigLoading}>
          确定
        </Button>
      </Card>
    </PageContainer>
  );
};

export default PrescriptionConfig;

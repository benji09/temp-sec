export const getInterceptionType = {
  0: {
    text: '全部拦截',
  },
  1: {
    text: '部分拦截',
  },
};

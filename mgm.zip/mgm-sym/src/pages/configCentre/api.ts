import { post } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';
import type { PrescriptionParams } from './typing';

// 延时签发配置显示
async function queryPrescriptionConfig() {
  return await post('/mall/show-ca-delay', { hostType: HOST_TYPE_POWER });
}

// 延时签发配置
async function modifyPrescriptionConfig(data: PrescriptionParams) {
  return await post('/mall/ca-delay', { data: data, hostType: HOST_TYPE_POWER });
}

export { queryPrescriptionConfig, modifyPrescriptionConfig };

import React, { useRef, useState } from 'react';
import { Button, DatePicker, Select } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { ClickDownXlsx } from '@/utils/downXlsx';
import { showErrorMessage } from '@/mamagement/Notification';
import TableLocal from '@/components/TableLocal/TableLocal';

import { evaluationDoctorExport, evaluationDoctorPage } from './api';
import { SEARCHSCORE, SCORE, SOURCE, ContentTypeState } from '../util';
import type { CouponNoteProvideListType, DoctorEvaluationType } from './typings';

import './index.less';

const { RangePicker } = DatePicker;
const { Option } = Select;

const DoctorEvaluation: React.ReactNode = () => {
  const actionRef = useRef<ActionType | undefined>();
  const [exportLoading, setExportLoading] = useState<boolean>(false);

  function disabledDate(current: any) {
    return current && current > new Date();
  }
  const columns: ProColumns<DoctorEvaluationType>[] = [
    {
      title: 'ProviderID',
      dataIndex: 'providerId',
      hideInTable: true,
    },
    {
      title: 'UserID',
      hideInTable: true,
      dataIndex: 'userId',
    },
    {
      title: '星数',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Select mode="multiple" placeholder="请选择星数" allowClear>
            {SEARCHSCORE.map((item) => {
              return (
                <Option value={item.value} key={item.value}>
                  {item.text}
                </Option>
              );
            })}
          </Select>
        );
      },
      dataIndex: 'score',
    },
    {
      title: '附属信息',
      hideInTable: true,
      dataIndex: 'extraInfo',
    },
    {
      title: '日期',
      dataIndex: 'date',
      renderFormItem: () => {
        return (
          <RangePicker
            format={['YYYY-MM-DD', 'YYYY-MM-DD']}
            picker="date"
            disabledDate={disabledDate}
            placeholder={['开始日期', '结束日期']}
          />
        );
      },
      search: {
        transform: (value) => {
          return {
            startDate: value[0].slice(0, value[0].indexOf(' ')),
            endDate: value[1].slice(0, value[1].indexOf(' ')),
          };
        },
      },
      hideInTable: true,
    },
    {
      title: '医生姓名',
      hideInTable: true,
      dataIndex: 'doctorName',
    },
    {
      title: '用户姓名',
      hideInTable: true,
      dataIndex: 'userName',
    },
    {
      title: '助理姓名',
      hideInTable: true,
      dataIndex: 'assistantName',
    },
    {
      title: '评价内容',
      dataIndex: 'filterReviewContent',
      valueEnum: ContentTypeState,
      hideInTable: true,
    },
    {
      title: '日期',
      hideInSearch: true,
      dataIndex: 'createdTime',
    },
    {
      title: '医生',
      hideInSearch: true,
      dataIndex: 'doctorName',
    },
    {
      title: 'ProviderID',
      dataIndex: 'providerId',
      hideInSearch: true,
    },
    {
      title: '医生助理',
      hideInSearch: true,
      dataIndex: 'assistantName',
    },
    {
      title: '用户',
      hideInSearch: true,
      dataIndex: 'userName',
    },
    {
      title: 'UserID',
      hideInSearch: true,
      dataIndex: 'userId',
    },
    {
      title: '星数',
      hideInSearch: true,
      dataIndex: 'score',
      valueEnum: SCORE,
    },

    {
      title: '是否为匿名',
      dataIndex: 'anonymous',
      renderText: (text) => (text ? '是' : '否'),
      hideInSearch: true,
    },
    {
      title: '标签',
      dataIndex: 'doctorTag',
      hideInSearch: true,
    },
    {
      title: '评价内容',
      // width: 300,
      dataIndex: 'content',
      render: (text) => {
        return <span>{text}</span>;
      },
      hideInSearch: true,
    },
    {
      title: '评价来源',
      hideInSearch: true,
      valueEnum: SOURCE,
      dataIndex: 'source',
    },
    {
      title: '附加信息',
      hideInSearch: true,
      dataIndex: 'extraInfo',
    },
  ];
  return (
    <TableLocal
      tableClassName="DoctorEvaluationList"
      columns={columns}
      request={evaluationDoctorPage}
      expandable={{
        expandedRowRender: (record: any) => <p style={{ margin: 0 }}>{record.content}</p>,
      }}
      rowKey="extraInfo"
      dateFormatter="string"
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [
          <Button
            onClick={() => {
              formProps.form.validateFields().then((res: CouponNoteProvideListType) => {
                setExportLoading(true);
                evaluationDoctorExport(res).then((newRes) => {
                  setExportLoading(false);
                  if (newRes.size <= 500) {
                    showErrorMessage('数据流异常，无法正常下载');
                    return;
                  }
                  ClickDownXlsx(newRes, '医生评价');
                });
              });
            }}
            key="out"
            type="primary"
            loading={exportLoading}
          >
            导出
          </Button>,
          ...dom.reverse(),
          ,
        ],
      }}
      actionRef={actionRef}
    />
  );
};
export default DoctorEvaluation;

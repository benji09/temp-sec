// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import { POWER_HOST } from '@/services/hosts';
import { checkIsNumberForSearch, HOST_TYPE_POWER } from '@/utils/utils';

import type { CouponNoteProvideListType } from './typings';

// 列表
const evaluationDoctorPage = async (params: CouponNoteProvideListType) => {
  const { providerId, userId, current, pageSize, ...data } = params;
  const ProviderIdResult = checkIsNumberForSearch(providerId, 'providerId');
  if (ProviderIdResult !== null) return ProviderIdResult;
  const UserIdResult = checkIsNumberForSearch(userId, 'userId');
  if (UserIdResult !== null) return UserIdResult;

  const msg = await request('/evaluation_doctor/page', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      ...data,
      providerId,
      userId,
      pageNo: current || 1,
      pageSize,
    },
  });
  return {
    data: (msg?.result && msg?.result.evaluationDoctorInfo) || [],
    total: (msg?.result && msg?.result.totalCount) || 0,
  };
};
const evaluationDoctorExport = async (params: CouponNoteProvideListType) => {
  const { current, pageSize, date, ...data } = params;
  return await request('/evaluation_doctor/export-doctor-evaluation', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      ...data,
      startDate: date
        ? dayjs(date?.[0]).toISOString().slice(0, dayjs(date?.[0]).toISOString().indexOf('T'))
        : undefined,
      endDate: date
        ? dayjs(date?.[1]).toISOString().slice(0, dayjs(date?.[1]).toISOString().indexOf('T'))
        : undefined,
    },
    responseType: 'blob',
  });
};
export { evaluationDoctorPage, evaluationDoctorExport };

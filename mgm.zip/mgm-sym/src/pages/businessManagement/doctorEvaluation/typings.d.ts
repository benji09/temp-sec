type CouponNoteProvideListType = {
  assistantName?: string;
  doctorName?: string;
  date?: any[];
  endDate?: string;
  orderId?: string;
  orderType?: string;
  providerId?: string;
  score?: string;
  startDate?: string;
  userId?: string;
  userName?: string;

  current?: number;
  pageSize?: number;
  pageNo?: number;
};
type DoctorEvaluationType = {
  orderType?: number;
  score?: number;
  doctorName?: string;
  assistantName?: string;
  orderId?: string;
  providerId?: string;
  createdTime?: string;
  anonymous?: boolean;
  userName?: string;
  userId?: string;
  content?: string;
};
export { CouponNoteProvideListType, DoctorEvaluationType };

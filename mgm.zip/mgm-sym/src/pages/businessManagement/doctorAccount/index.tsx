/* eslint-disable react-hooks/exhaustive-deps */
import React, { useRef, useState, useEffect } from 'react';
import { Button, Select, Upload } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import {
  checkPermission,
  PERMISSION_ADD,
  PERMISSION_SCHEDULE,
  PERMISSION_EDIT,
  PERMISSION_CONFIG,
  PERMISSION_ASSISTANT,
  PERMISSION_PROTECTION,
  PERMISSION_TEAM,
} from '@/utils/power';
import { formatTime } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { getDepartmentList, getProviderList, getProviderTags, uploadExcel } from '@/services/api';

import ContentModal from './components/contentModal';
import CreateOrModifyModal from './components/createOrModifyModal';
import ConfigModal from './components/configModal';
import MemberModal from './components/memberModal';
import ProtectionModal from './components/protectionModal';
import { JobStatus } from '../util';

import './index.less';

const permissionGroups = [
  PERMISSION_ADD,
  PERMISSION_SCHEDULE,
  PERMISSION_EDIT,
  PERMISSION_CONFIG,
  PERMISSION_ASSISTANT,
  PERMISSION_PROTECTION,
  PERMISSION_TEAM,
];

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_EDIT = 2;
const MODAL_TYPE_CONFIG = 3;
const MODAL_TYPE_MEMBERS = 4;
const MODAL_TYPE_PROTECTION = 5;
const MODAL_TYPE_TEAM = 6;

const { Option } = Select;

export default (): React.ReactNode => {
  const [powers, setPowers] = useState({});
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);
  const [modalType, setModalType] = useState<number | undefined>();
  const [providerId, setProviderId] = useState<number>();
  const [scheduleLoading, setScheduleLoading] = useState(false);
  const [departmentList, setDepartmentList] = useState<string[]>([]);
  const [providerTags, setProviderTags] = useState<APIS.ProviderTagItem[]>([]);
  const [doctorMsg, setDoctorMsg] = useState<APIS.DoctorAccountItem>();
  const actionRef = useRef<ActionType | undefined>();
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  useEffect(() => {
    if (departmentList.length < 1) {
      getDepartmentList().then((res) => {
        if (res.status === 0) setDepartmentList(res.result);
      });
    }
    if (providerTags.length < 1) {
      getProviderTags().then((res) => {
        if (res) setProviderTags(res);
      });
    }
  }, [powers]);
  const addOrModifyRef = useRef<any>();
  const configRef = useRef<any>();
  const memberRef = useRef<any>();
  const protection = useRef<any>();

  const columns: ProColumns<APIS.DoctorAccountItem>[] = [
    {
      title: 'Provider_ID',
      dataIndex: 'providerId',
    },
    {
      title: '姓名',
      dataIndex: 'name',
    },
    {
      title: '所属科室',
      dataIndex: 'department',
      hideInSearch: true,
    },
    {
      title: '职级',
      dataIndex: 'title',
      hideInSearch: true,
    },
    {
      title: '备注',
      dataIndex: 'description',
      hideInSearch: true,
    },
    {
      title: '在职状态',
      dataIndex: 'jobStatus',
      hideInSearch: true,
      valueEnum: JobStatus,
    },
    {
      title: '创建日期',
      dataIndex: 'createdAt',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '擅长标',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Select mode="multiple" placeholder="请选择擅长标" allowClear>
            {providerTags.length > 0 &&
              providerTags?.map((item) => {
                return (
                  <Option value={item.tagId} key={item.tagId}>
                    {item.name}
                  </Option>
                );
              })}
          </Select>
        );
      },
      dataIndex: 'tags',
    },
    {
      title: '擅长标',
      dataIndex: 'tags',
      hideInSearch: true,
      render: (text, record) => {
        const tagsListText: string[] = [];
        if (record.tags?.length) {
          providerTags?.map((item) => {
            record.tags?.map((tagsItem) => {
              if (item.tagId === tagsItem) {
                tagsListText.push(item.name);
              }
            });
          });
        }
        return <span>{tagsListText.join(',') || '-'}</span>;
      },
    },
    {
      title: '操作',
      hideInSearch: true,
      valueType: 'option',
      render: (_text, record) => {
        return (
          <>
            {powers[`${PERMISSION_EDIT}`] ? (
              <Button
                type="link"
                onClick={() => updateModalInfo(MODAL_TYPE_EDIT, record.providerId, record)}
              >
                编辑
              </Button>
            ) : null}
            {powers[`${PERMISSION_CONFIG}`] ? (
              <Button
                type="link"
                onClick={() => updateModalInfo(MODAL_TYPE_CONFIG, record.providerId, record)}
              >
                配置
              </Button>
            ) : null}
            {powers[`${PERMISSION_ASSISTANT}`] ? (
              <Button
                type="link"
                onClick={() => updateModalInfo(MODAL_TYPE_MEMBERS, record.providerId, record)}
              >
                组员
              </Button>
            ) : null}
            {powers[`${PERMISSION_PROTECTION}`] ? (
              <Button
                type="link"
                onClick={() => updateModalInfo(MODAL_TYPE_PROTECTION, record.providerId, record)}
              >
                保健团
              </Button>
            ) : null}
            {powers[`${PERMISSION_TEAM}`] ? (
              <Button
                type="link"
                onClick={() => updateModalInfo(MODAL_TYPE_TEAM, record.providerId, record)}
              >
                工作组
              </Button>
            ) : null}
          </>
        );
      },
    },
  ];

  function updateModalInfo(
    updateModalType: number,
    updateProviderId: number | undefined,
    record: APIS.DoctorAccountItem,
  ) {
    setDoctorMsg(record);
    setProviderId(updateProviderId);
    setModalType(updateModalType);
  }

  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name || '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(`只能上传格式为 xlsx 的文件`);
    return isXlsx;
  }

  function customeUpload(options: any) {
    setScheduleLoading(true);
    uploadExcel(options)
      .then((res) => {
        if (res.status === 0) showSuccessMessage('导入成功');
        else showErrorMessage(`导入失败：${res.message}`);
      })
      .finally(() => setScheduleLoading(false));
  }

  function generateToolBar() {
    const childs = [];
    if (powers[`${PERMISSION_ADD}`])
      childs.push(
        <Button
          key="primary"
          type="primary"
          onClick={() => updateModalInfo(MODAL_TYPE_ADD, undefined, {})}
        >
          <PlusOutlined />
          新增
        </Button>,
      );
    if (powers[`${PERMISSION_SCHEDULE}`])
      childs.push(
        <Upload
          maxCount={1}
          type={'select'}
          beforeUpload={handleBeforeUpload}
          customRequest={customeUpload}
          showUploadList={false}
          accept={'.xlsx'}
        >
          <Button key="primary" type="primary" loading={scheduleLoading}>
            {scheduleLoading ? null : <UploadOutlined />}
            导入排班表
          </Button>
        </Upload>,
      );
    return childs;
  }

  function onCancel() {
    setModalType(undefined);
  }
  function emptyData() {
    protection.current?.empty();
  }

  function getModalTitle(): string {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_EDIT:
        return '编辑';
      case MODAL_TYPE_CONFIG:
        return '配置';
      case MODAL_TYPE_MEMBERS:
        return '组员';
      case MODAL_TYPE_PROTECTION:
        return '康无忧保健团';
      case MODAL_TYPE_TEAM:
        return '儿科医生工作组';
    }
    return '';
  }

  function onOk() {
    if (modalType === undefined) return;
    switch (modalType) {
      case MODAL_TYPE_ADD:
      case MODAL_TYPE_EDIT:
        addOrModifyRef.current?.onOk(actionRef);
        break;
      case MODAL_TYPE_CONFIG:
        configRef.current?.onOk(actionRef);
        break;
      case MODAL_TYPE_MEMBERS:
        memberRef.current?.onOk();
        break;
      case MODAL_TYPE_PROTECTION:
        protection.current?.onOk(actionRef);
        break;
      case MODAL_TYPE_TEAM:
        protection.current?.onOk(actionRef);
        break;
    }
  }

  return (
    <PageContainer>
      <ProTable<APIS.DoctorAccountItem>
        columns={columns}
        request={getProviderList}
        rowKey="providerId"
        dateFormatter="string"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{ defaultPageSize: 10 }}
        toolBarRender={generateToolBar}
        actionRef={actionRef}
      />
      <ContentModal
        modalVisible={modalType !== undefined}
        onCancel={onCancel}
        emptyData={emptyData}
        modalTitle={getModalTitle()}
        onOk={onOk}
        btnLoading={confirmLoading}
      >
        {modalType && (modalType === MODAL_TYPE_ADD || modalType === MODAL_TYPE_EDIT) ? (
          <CreateOrModifyModal
            ref={addOrModifyRef}
            providerId={providerId}
            createdAt={doctorMsg?.createdAt}
            visible={modalType === MODAL_TYPE_ADD || modalType === MODAL_TYPE_EDIT}
            departmentList={departmentList}
            setConfirmLoading={setConfirmLoading}
            setModalType={setModalType}
          />
        ) : null}
        {modalType && modalType === MODAL_TYPE_CONFIG ? (
          <ConfigModal
            ref={configRef}
            visible={modalType === MODAL_TYPE_CONFIG}
            tags={providerTags}
            setModalType={setModalType}
            setConfirmLoading={setConfirmLoading}
            record={doctorMsg || {}}
          />
        ) : null}
        {modalType && modalType === MODAL_TYPE_MEMBERS ? (
          <MemberModal
            ref={memberRef}
            visible={modalType === MODAL_TYPE_MEMBERS}
            setModalType={setModalType}
            setConfirmLoading={setConfirmLoading}
            record={doctorMsg || {}}
          />
        ) : null}
        {modalType && (modalType === MODAL_TYPE_PROTECTION || modalType === MODAL_TYPE_TEAM) ? (
          <ProtectionModal
            ref={protection}
            doctorMsg={doctorMsg}
            providerId={providerId}
            setModalType={setModalType}
            modalType={modalType}
            visible={modalType === MODAL_TYPE_PROTECTION}
            departmentList={departmentList}
          />
        ) : null}
      </ContentModal>
    </PageContainer>
  );
};

/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useRef, useEffect } from 'react';
import { Button } from 'antd';
import _, { reject } from 'lodash';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import { showErrorMessage } from '@/mamagement/Notification';
import { checkPermission, ASSISTANT_ADD, ASSISTANT_EDIT, ASSISTANT_VIEW } from '@/utils/power';
import { assistantList, LookAssistantMobile, EditorAddAssistant } from '@/services/api';

import AssitantModal from './components/AssitantModal';
import ModalContant from './components/ModalContant';
import { JobStatus } from '../util';

type AssistantItem = {
  assistantId: number;
  birthday?: string;
  createdAt?: number;
  description?: string;
  gender?: number;
  isLeader?: boolean;
  key?: string;
  mobile?: string;
  name?: string;
  portrait?: string;
  size?: number;
};
type DetailsDataType = {
  assistantId?: number;
  birthday?: string;
  createdAt?: number;
  description?: string;
  gender?: number;
  isLeader?: boolean;
  key?: string;
  mobile?: string;
  name?: string;
  portrait?: string;
  size?: number;
};

const permissionGroups = [ASSISTANT_ADD, ASSISTANT_EDIT, ASSISTANT_VIEW];
export default (): React.ReactNode => {
  const [mobilesCache, setMobilesCache] = useState({});

  const [assitantVisible, handleAssitantVisible] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);

  const [title, setTitle] = useState<string>('');
  const actionRef = useRef<ActionType | undefined>();
  const [detailsData, setDetailsData] = useState<DetailsDataType>({});
  const foodRef = useRef<any>();
  const [upData, setUpData] = useState({});

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);
  useEffect(() => {
    if (!assitantVisible) {
      foodRef.current?.reset();
    } else {
      foodRef.current?.setData(detailsData);
    }
  }, [assitantVisible]);

  const queryMobile = (record: AssistantItem) => {
    LookAssistantMobile(record.assistantId)
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.assistantId] = res.result;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };

  function onShowModal(type: string, row: any = {}) {
    if (type === 'ADD') {
      setDetailsData({});
      setTitle('新增');
      handleAssitantVisible(true);
    } else {
      setDetailsData(row);
      handleAssitantVisible(true);
      setTitle('编辑');
    }
  }
  function onSaveData() {
    setBtnLoading(true);

    if (title === '新增') {
      EditorAddAssistant(upData, 'POST').then((res) => {
        setBtnLoading(false);
        setVisible(false);
        if (res.status === 0) {
          handleAssitantVisible(false);
          actionRef.current?.reload();
        }
      });
    } else {
      EditorAddAssistant(upData, 'PUT')
        .then((res) => {
          setBtnLoading(false);
          setVisible(false);
          if (res.status === 0) {
            handleAssitantVisible(false);
            actionRef.current?.reload();
          }
        })
        .catch((error: Error) => {
          reject(error);
        });
    }
  }
  function onOk() {
    foodRef.current?.takeData().then((value: any) => {
      setUpData(value);
      setVisible(true);
    });
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }
  // 取消
  function onCancel() {
    setVisible(false);
    setBtnLoading(false);
    setTimeout(() => {
      setDetailsData({});
      handleAssitantVisible(false);
    }, 0);
  }
  const columns: ProColumns<AssistantItem>[] = [
    {
      title: 'ID',
      dataIndex: 'assistantId',
      hideInTable: true,
    },
    {
      title: 'Assistant_ID',
      dataIndex: 'assistantId',
      hideInSearch: true,
    },
    {
      title: '姓名',
      dataIndex: 'name',
    },
    {
      title: '账户',
      dataIndex: 'login',
      hideInTable: true,
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
      render: (text, record) => {
        return (
          <>
            {mobilesCache[record.assistantId] || text}
            {mobilesCache[record.assistantId] || (record.mobile || '').trim().length < 1
              ? null
              : powers[`${ASSISTANT_VIEW}`] && (
                  <Button type="link" key="lookMobile" onClick={() => queryMobile(record)}>
                    查看
                  </Button>
                )}
          </>
        );
      },
    },
    {
      title: '备注',
      dataIndex: 'description',
      hideInSearch: true,
    },
    {
      title: '在职状态',
      dataIndex: 'jobStatus',
      hideInSearch: true,
      valueEnum: JobStatus,
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      hideInSearch: true,
      render: (_text, record) => {
        return <span>{formatTime(record.createdAt)}</span>;
      },
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => {
        return (
          <>
            {powers[`${ASSISTANT_ADD}`] ? (
              <Button type="link" onClick={() => onShowModal('EDITOR', record)}>
                编辑
              </Button>
            ) : (
              ''
            )}
          </>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <ProTable<AssistantItem>
        actionRef={actionRef}
        columns={columns}
        request={assistantList}
        rowKey="assistantId"
        pagination={{
          defaultPageSize: 10,
        }}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        toolBarRender={() => [
          <>
            {powers[`${ASSISTANT_ADD}`] ? (
              <Button
                key="primary"
                type="primary"
                onClick={() => {
                  onShowModal('ADD');
                }}
              >
                <PlusOutlined />
                新增
              </Button>
            ) : null}
          </>,
        ]}
      />
      <AssitantModal
        assitantVisible={assitantVisible}
        btnLoading={btnLoading}
        title={title}
        onOk={onOk}
        onCancel={onCancel}
        onCancelSave={onCancelSave}
        onSaveData={onSaveData}
        visible={visible}
      >
        <ModalContant title={title} ref={foodRef} detailsData={detailsData} />
      </AssitantModal>
    </PageContainer>
  );
};

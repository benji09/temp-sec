// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

const abilityList = async () => {
  return await request('/assistant/ability-list', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
  });
};

export { abilityList };

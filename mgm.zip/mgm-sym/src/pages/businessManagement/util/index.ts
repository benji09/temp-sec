export const doctorTitleList = [
  '主任医师',
  '副主任医师',
  '主治医师',
  '住院医师',
  '营养师',
  '运动康复师',
  '药师',
];

export const mobileRegex = /^\d{11}$/;

export function defaultParser(
  values: string | undefined,
  requireInteger: boolean = true,
  fractionDigits: number = 2,
  defaultValue: number = 0,
) {
  if (!values || !/^\d+(.)?\d*$/.test(values)) return defaultValue;
  if (requireInteger || values.indexOf('.') < 0) return parseInt(values, 10);
  const temp = values.split('.');
  if (temp.length > 1 && temp[1].length > fractionDigits)
    return parseFloat(values).toFixed(fractionDigits);
  return parseFloat(values);
}
export const SCORE = {
  1: {
    text: '1星',
  },
  2: {
    text: '2星',
  },
  3: {
    text: '3星',
  },
  4: {
    text: '4星',
  },
  5: {
    text: '5星',
  },
};
export const SEARCHSCORE = [
  {
    text: '1星',
    value: 1,
  },
  {
    text: '2星',
    value: 2,
  },
  {
    text: '3星',
    value: 3,
  },
  {
    text: '4星',
    value: 4,
  },
  {
    text: '5星',
    value: 5,
  },
];
export const SOURCE = {
  1: {
    text: 'IM',
  },
};
export const ContentTypeState = {
  1: {
    text: '无',
  },
  2: {
    text: '有',
  },
};

export const JobStatus = {
  1: {
    text: '在职',
  },
  2: {
    text: '离职',
  },
};

import _ from 'lodash';

export const SECTRCY_ALL = 0;
export const SECTRCY_APPLICANT_MOBILE = 1;
export const SECTRCY_APPLICANT_BANK_CARD = 2;
export const SECTRCY_APPLICANT_EMAIL = 3;
export const SECTRCY_INSURED_ID_CARD = 4;
export const SECTRCY_BUSINESS_BANK_CARD = 12;

export const refundStatus = {
    '-1': '已成交',
    100: '申请退款中',
    200: '已退款',
    300: '已驳回',
}

export const policyStatus = {
    1: '已成交',
    2: '已退保',
    3: '拒保',
}

export function getCardDescByStatus(status: string): string {
  let desc = '';
  switch (status) {
    case 'HAVE_NOT':
      desc = '（暂无此权益）';
      break;
    case 'NOT_USABLE':
      desc = '（未到可用时间）';
      break;
    case 'EXHAUST':
      desc = '（已用完）';
      break;
    case 'DISABLED':
      desc = '（已禁用）';
      break;
    case 'OVERDUE':
      desc = '（已过期）';
      break;
    default:
      desc = '';
  }
  return desc;
}

export function getNewDetail(
  detail: APIS.DrugOrderDetail,
  content: string | undefined,
  secrecy: number,
): APIS.DrugOrderDetail {
  const temp = _.cloneDeep(detail);
  if (!temp.refundPolicyInfo) return detail;
  switch (secrecy) {
    case SECTRCY_APPLICANT_MOBILE:
      temp.refundPolicyInfo.applicantMobile = content;
      break;
    case SECTRCY_APPLICANT_BANK_CARD:
      temp.refundPolicyInfo.applicantBankAccount = content;
      break;
    case SECTRCY_APPLICANT_EMAIL:
      temp.refundPolicyInfo.applicantEmail = content;
      break;
    case SECTRCY_INSURED_ID_CARD:
      temp.refundPolicyInfo.insuredIdCard = content;
      break;
    case SECTRCY_BUSINESS_BANK_CARD:
      temp.refundPolicyInfo.businessBankAccount = content;
      break;
    default:
      break;
  }
  return temp;
}

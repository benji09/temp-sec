import { useEffect, useState } from 'react';
import { history } from 'umi';
import { Button, Card, Col, Modal, Row } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import {
  applyDrugOrderRefund,
  hasPower,
  queryDrugOrderDetail,
  queryRealInfo,
} from '@/services/api';
import { formatDate } from '@/utils/formatDate';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import {
  getCardDescByStatus,
  getNewDetail,
  policyStatus,
  refundStatus,
  SECTRCY_APPLICANT_BANK_CARD,
  SECTRCY_APPLICANT_EMAIL,
  SECTRCY_APPLICANT_MOBILE,
  SECTRCY_BUSINESS_BANK_CARD,
  SECTRCY_INSURED_ID_CARD,
} from '../utils';
import AgreeRefundModal from './components/AgreeRefundModal';
import RejectRefundModal from './components/RejectRefundModal';

import './index.less';

/**
 * 根据状态返回权益信息结果展示
 *
 * @param result 对应权益信息
 * @param status 状态
 * @returns
 */
function getCardResult(result: string, status: string) {
  return (
    <>
      <span className="deleteLine">{result}</span>
      {getCardDescByStatus(status)}
    </>
  );
}

const MedicalOrderDetail: React.FC = () => {
  const urlPolicyPhaseId = history.location.search.match(/policyPhaseId=(\d+)/)?.[1];

  const [power, setPower] = useState(false);
  const [loading, setLoading] = useState(false);
  const [agreeVisible, setAgreeVisible] = useState(false);
  const [rejectVisible, setRejectVisible] = useState(false);
  const [detail, setDetail] = useState<APIS.DrugOrderDetail>({});
  const [secrecyValue, setSecrecyValue] = useState<number | undefined>(undefined);
  const [policyPhase, setPolicyPhase] = useState({ id: urlPolicyPhaseId });
  const [applyId, setApplyId] = useState('');

  useEffect(() => {
    setLoading(true);
    queryDrugOrderDetail({ policyPhaseId: policyPhase.id })
      .then((res) => {
        if (res && res.status === 0) setDetail(res.result);
      })
      .finally(() => setLoading(false));
  }, [policyPhase]);

  useEffect(() => {
    hasPower(26).then((res) => {
      setPower(res && res.status === 0 && res.result === true);
    });
  }, []);

  const queryInfo = (secrecy: number) => {
    setSecrecyValue(secrecy);
    queryRealInfo({ ywyPolicyRecordId: detail.refundPolicyInfo?.policyRecordId, secrecy })
      .then((res) => {
        if (res && res.status !== 0) return;
        setDetail(getNewDetail(detail, res.result.content, secrecy));
      })
      .finally(() => setSecrecyValue(undefined));
  };

  const getLookButton = (text: string | undefined, secrecy: number) =>
    (text || '').indexOf('*') >= 0 ? (
      <Button
        type="link"
        onClick={() => queryInfo(secrecy)}
        disabled={!!secrecyValue}
        loading={!!(secrecyValue && secrecyValue === secrecy)}
      >
        查看
      </Button>
    ) : null;

  const getOrderStatus = (status: number | undefined) => (
    <p className="spaceTop">药无忧订单状态：{refundStatus[`${status || 0}`]}</p>
  );

  function applyRefund(phaseId: number) {
    Modal.confirm({
      title: `申请退款`,
      content: '是否申请退款?',
      okText: '确定',
      cancelText: '取消',
      onOk() {
        submitApply(phaseId);
      },
    });
  }

  function handleAgree(id: string) {
    setApplyId(id);
    setAgreeVisible(true);
  }

  function handleReject(id: string) {
    setApplyId(id);
    setRejectVisible(true);
  }

  function submitApply(phaseId: number) {
    applyDrugOrderRefund(phaseId).then((res) => {
      if (res && res.status === 0) {
        showSuccessMessage('申请提交成功');
        setPolicyPhase({ id: `${phaseId}` });
      } else {
        showErrorMessage(res.message || '申请提交失败，请重试');
      }
    });
  }

  return (
    <PageContainer>
      <Card className="orderDetailcontainer" loading={loading}>
        <h3>订单详情</h3>
        <Row>
          <Col span={8}>保单号：{detail?.refundPolicyInfo?.policyCode}</Col>
          <Col span={8}>投保单号：{detail?.refundPolicyInfo?.insuredCode}</Col>
          <Col span={8}>成交时间：{formatDate(detail?.refundPolicyInfo?.dealTime || 0)}</Col>
        </Row>
        <Row className="spaceTop">
          <Col span={8}>
            保单状态：{policyStatus[`${detail?.refundPolicyInfo?.policyStatus || 0}`]}
          </Col>
          <Col span={8}>成交金额：￥{detail?.refundPolicyInfo?.dealAmount}</Col>
          <Col span={8}>生效时间：{formatDate(detail?.refundPolicyInfo?.effectTime || 0)}</Col>
        </Row>

        <h3 className="spaceTopLarge">权益信息</h3>
        <Row>
          {detail &&
            detail.cards &&
            detail.cards.map((card) => {
              const right = card.right || [];
              return right.map((item) => {
                const ext = JSON.parse(item.displayExt || '{}');
                const unit = ext.unit || '次';
                const resultCombine =
                  item.infinitely && item.infinitely === true ? '无限次' : `${item.number} ${unit}`;
                return (
                  <Col key={item.rightMasterId} span={12} className="spaceTop">
                    {item.name}：
                    {item.usable && item.usable === true
                      ? resultCombine
                      : getCardResult(resultCombine, item.disabledReason || '')}
                  </Col>
                );
              });
            })}
        </Row>

        <h3 className="spaceTopLarge">投保人信息</h3>
        <Row className="spaceTop">
          <Col span={8}>姓名：{detail?.refundPolicyInfo?.applicantName}</Col>
          <Col span={8}>
            手机号码：{detail?.refundPolicyInfo?.applicantMobile}
            {getLookButton(detail?.refundPolicyInfo?.applicantMobile, SECTRCY_APPLICANT_MOBILE)}
          </Col>
          <Col span={8}>
            邮箱：{detail?.refundPolicyInfo?.applicantEmail}
            {getLookButton(detail?.refundPolicyInfo?.applicantEmail, SECTRCY_APPLICANT_EMAIL)}
          </Col>
        </Row>
        <Row className="spaceTop">
          <Col span={8}>开户行：{detail?.refundPolicyInfo?.applicantBankAddress}</Col>
          <Col span={8}>
            银行账号：{detail?.refundPolicyInfo?.applicantBankAccount}
            {getLookButton(
              detail?.refundPolicyInfo?.applicantBankAccount,
              SECTRCY_APPLICANT_BANK_CARD,
            )}
          </Col>
        </Row>

        {power ? (
          <>
            <h3 className="spaceTopLarge">被保人信息</h3>
            <Row className="spaceTop">
              <Col span={12}>姓名：{detail?.refundPolicyInfo?.insuredName}</Col>
              <Col span={12}>
                身份证：{detail?.refundPolicyInfo?.insuredIdCard}
                {getLookButton(detail?.refundPolicyInfo?.insuredIdCard, SECTRCY_INSURED_ID_CARD)}
              </Col>
            </Row>

            <h3 className="spaceTopLarge">业务员信息</h3>
            <Row className="spaceTop">
              <Col span={4}>ID：{detail?.refundPolicyInfo?.businessId}</Col>
              <Col span={4}>姓名：{detail?.refundPolicyInfo?.businessName}</Col>
              <Col span={8}>开户行：{detail?.refundPolicyInfo?.businessBankAddress}</Col>
              <Col span={8}>
                银行账号：{detail?.refundPolicyInfo?.businessBankAccount}
                {getLookButton(
                  detail?.refundPolicyInfo?.businessBankAccount,
                  SECTRCY_BUSINESS_BANK_CARD,
                )}
              </Col>
            </Row>
            <Row className="spaceTop">
              <Col span={8}>所属主管</Col>
              <Col span={8}>ID：{detail?.refundPolicyInfo?.supervisorId}</Col>
              <Col span={8}>姓名：{detail?.refundPolicyInfo?.supervisorName}</Col>
            </Row>
            <Row className="spaceTop">
              <Col span={8}>所属部门经理</Col>
              <Col span={8}>ID：{detail?.refundPolicyInfo?.managerId}</Col>
              <Col span={8}>姓名：{detail?.refundPolicyInfo?.managerName}</Col>
            </Row>
            <Row className="spaceTop">
              <Col span={8}>所属总监</Col>
              <Col span={8}>ID：{detail?.refundPolicyInfo?.directorId}</Col>
              <Col span={8}>姓名：{detail?.refundPolicyInfo?.directorName}</Col>
            </Row>
          </>
        ) : null}

        <h3 className="spaceTopLarge">药无忧订单详情</h3>
        {(detail.applyInfos?.length || 0) === 0 ? (
          getOrderStatus(detail?.refundPolicyInfo?.refundStatus)
        ) : (
          <>
            {detail.applyInfos?.map((item) => {
              return (
                <Row key={item.applyId}>
                  <Col span={24}>{getOrderStatus(item.applyStatus)}</Col>
                  <Col span={24} className={'subCard'}>
                    <Row>
                      <Col span={12}>退款编号：{item.applyId}</Col>
                      <Col span={12}>申请退款时间：{formatDate(item.applyTime || 0)}</Col>
                      {item.applyStatus === 200 ? (
                        <Col span={12}>实际退款金额：￥{(item.amount || 0) / 100}</Col>
                      ) : null}
                      {item.applyStatus === 200 ? (
                        <Col span={12}>同意申请时间：{formatDate(item.endTime || 0)}</Col>
                      ) : null}
                      {item.applyStatus === 300 ? (
                        <Col span={12}>驳回申请时间：{formatDate(item.endTime || 0)}</Col>
                      ) : null}
                      {item.applyStatus === 200 ? (
                        <Col span={12}>退款说明：{item.reason}</Col>
                      ) : null}
                      {item.applyStatus === 300 ? (
                        <Col span={12}>驳回原因：{item.reason}</Col>
                      ) : null}
                    </Row>
                  </Col>
                  <Col span={24} className="handleButton">
                    {power && item.applyStatus === 100 ? (
                      <>
                        <Button type="primary" onClick={() => handleAgree(`${item.applyId}`)}>
                          同意退款
                        </Button>
                        <Button
                          className={'spaceLeft'}
                          type="primary"
                          onClick={() => handleReject(`${item.applyId}`)}
                        >
                          驳回退款
                        </Button>
                      </>
                    ) : null}
                    {!power && (item.applyStatus === -1 || item.applyStatus === 300) ? (
                      <Button type="primary" onClick={() => applyRefund(detail.policyPhaseId || 0)}>
                        申请退款
                      </Button>
                    ) : null}
                  </Col>
                </Row>
              );
            })}
          </>
        )}
      </Card>
      <AgreeRefundModal
        visible={agreeVisible}
        setVisible={setAgreeVisible}
        title={'同意退款'}
        onSuccess={() => {
          setPolicyPhase({ id: `${detail.policyPhaseId}` });
        }}
        applyId={applyId}
      />
      <RejectRefundModal
        visible={rejectVisible}
        setVisible={setRejectVisible}
        title={'驳回申请'}
        onSuccess={() => {
          setPolicyPhase({ id: `${detail.policyPhaseId}` });
        }}
        applyId={applyId}
      />
    </PageContainer>
  );
};

export default MedicalOrderDetail;

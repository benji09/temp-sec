import React, { useState } from 'react';
import _ from 'lodash';
import { history, KeepAlive } from 'umi';
import { Button, DatePicker } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns } from '@ant-design/pro-table';

import { queryDrugOrder, queryRealInfo } from '@/services/api';
import { formatTime } from '@/utils/utils';
import { showErrorMessage } from '@/mamagement/Notification';

import { policyStatus, refundStatus } from '../utils';

const { RangePicker } = DatePicker;

function disabledDate(current: any) {
  //  实际类型 DateType，由于无法导入，暂用 any 代替
  return current && current > new Date();
}

const MedicalOrder: React.FC = () => {
  const [mobilesCache, setMobilesCache] = useState({});

  const queryMobile = (record: APIS.DrugOrderItem) => {
    const res = queryRealInfo({ ywyPolicyRecordId: record.policyRecordId });
    res
      .then((value) => {
        if (value && value.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.policyRecordId] = value.result.content;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };
  const columns: ProColumns<APIS.DrugOrderItem>[] = [
    {
      title: '保单号',
      dataIndex: 'policyCode',
    },
    {
      title: '投保单号',
      dataIndex: 'insuredCode',
    },
    {
      title: '投保人姓名',
      dataIndex: 'applicantName',
      hideInSearch: true,
    },
    {
      title: '投保人手机号',
      dataIndex: 'applicantMobile',
      render: (text, record) => {
        return (
          <>
            {mobilesCache[record.policyRecordId] || text}
            {mobilesCache[record.policyRecordId] ||
            (record.applicantMobile || '').trim().length < 1 ? null : (
              <Button type="link" onClick={() => queryMobile(record)}>
                查看
              </Button>
            )}
          </>
        );
      },
    },
    {
      title: '药无忧订单状态',
      dataIndex: 'refundStatus',
      valueType: 'select',
      valueEnum: refundStatus,
      renderText: (entity) => refundStatus[entity],
    },
    {
      title: '保单状态',
      dataIndex: 'policyStatus',
      valueType: 'select',
      valueEnum: policyStatus,
      renderText: (entity) => policyStatus[entity],
    },
    {
      title: '成交时间',
      dataIndex: 'dealTime',
      hideInSearch: true,
      renderText: (text: number) => formatTime(text),
    },
    {
      title: '成交日期',
      hideInTable: true,
      dataIndex: 'timeRange',
      valueType: 'dateRange',
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '操作',
      hideInSearch: true,
      valueType: 'option',
      render: (_text, record) => {
        return (
          <Button
            type="link"
            onClick={() =>
              history.push(`/medical/orderList/orderDetail?policyPhaseId=${record.policyPhaseId}`)
            }
          >
            查看详情
          </Button>
        );
      },
    },
  ];
  return (
    <PageContainer>
      <ProTable<APIS.DrugOrderItem>
        columns={columns}
        request={queryDrugOrder}
        rowKey="policyRecordId"
        dateFormatter="string"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{ defaultPageSize: 10 }}
      />
    </PageContainer>
  );
};
export default () => (
  <KeepAlive>
    <MedicalOrder />
  </KeepAlive>
);

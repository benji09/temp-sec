import React, { useState, useRef, useEffect } from 'react';
import { connect } from 'dva';
import { history, KeepAlive } from 'umi';
import { Button, DatePicker, Select } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { StateWithHistory } from 'redux-undo';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import {
  contentList,
  contentDetail,
  contentOwnedPlate,
  recommendTag,
  updateRecommend,
  getQRCode,
  saveQRCode,
} from '@/services/api';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import ContentModal from '../components/contentModal';
import LinkSet from '../components/linkSet';
import RecommendSet from '../components/recommendSet';
import Preview from '../editor/components/Preview';
import {
  checkCmsEdited,
  getDefaultPageData,
  getDefaultRichTextContent,
  getDefaultVideoData,
} from '../util';

interface takeType {
  takeData: () => any;
  reset: () => void;
}

function disabledDate(current: any) {
  return current && current > new Date();
}

const TableList: React.FC<{ toPreview?: any }> = (props) => {
  const { toPreview } = props;
  const [updateModalVisible, setUpdateModalVisible] = useState<boolean>(false);
  const [modalInfo, setModalTitle] = useState<{ modalTitle: string; id: number }>();
  const [currentDetail, setCurrentDetail] = useState<any>();
  const [options, setOptions] = useState<any[]>([]);
  const [idAndNameList, setIdAndNameList] = useState<{ label: string; value: string }[]>();
  const [codeUrlData, setCodeUrlData] = useState<{ qrCodeIcon: string; qrCodeLink: string }>();
  const [loading, setLoading] = useState<boolean>(false);
  const [contentLoading, setContentLoading] = useState<boolean>(false);

  const commendRef = useRef<takeType | undefined>();
  const linkRef = useRef<takeType | undefined>();
  const actionRef = useRef<ActionType | undefined>();

  useEffect(() => {
    contentOwnedPlate({}).then((res: any) => {
      const { result } = res;
      if (res.status === 0 && result.code === 0) {
        setOptions(handleData(result.idAndNameList));
      }
    });

    recommendTag({}).then((res: any) => {
      const { result } = res;
      if (res.status === 0 && result.code === 0) {
        setIdAndNameList(handleData(result.idAndNameList));
      }
    });
  }, []);

  const columns: ProColumns<APIS.CmsAddOrUpdateResponse>[] = [
    {
      title: '内容ID',
      dataIndex: 'id',
    },
    {
      title: '封面',
      dataIndex: 'coverImage',
      valueType: 'option',
      render: (_, record) => {
        return <img src={record.coverImage} alt="" height="80" />;
      },
    },
    {
      title: '内容标题',
      dataIndex: 'contentTitle',
    },
    {
      title: '所属板块',
      dataIndex: 'ownedPlate',
      hideInTable: true,
      renderFormItem: (_, { type, defaultRender, ...rest }) => {
        if (type === 'form') {
          return null;
        }
        return (
          <Select
            size={'middle'}
            placeholder="请选择"
            options={options}
            defaultActiveFirstOption={false}
            showArrow={true}
            filterOption={false}
            allowClear={true}
            style={{ width: '100%' }}
            {...rest}
          />
        );
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createdTime',
      hideInForm: true,
      valueType: 'option',
      render: (_, record) => {
        return record.createdTime;
      },
    },
    {
      title: '内容类型',
      dataIndex: 'contentType',
      valueEnum: {
        1: {
          text: '图文',
        },
        2: {
          text: '视频',
        },
        3: {
          text: '页面',
        },
      },
    },
    {
      title: '是否推荐',
      dataIndex: 'isRecommended',
      hideInForm: true,
      valueEnum: {
        0: {
          text: '否',
        },
        1: {
          text: '是',
        },
      },
      render: (_, val) => {
        return val?.isRecommended ? '是' : '否';
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createdTime',
      renderFormItem: () => (
        <DatePicker disabledDate={disabledDate} placeholder={'请选择申请时间'} />
      ),
      hideInTable: true,
      // hideInSearch: true,
    },
    {
      title: '备注',
      dataIndex: 'remark',
      valueType: 'option',
      render: (_, record) => {
        return record.remark;
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => [
        <a key="config" onClick={() => handleEditOrAdd(record.id || 0)}>
          编辑
        </a>,
        <a key="subscribeAlert" onClick={() => toPreview(record.id)}>
          预览
        </a>,
        <a
          key="subscribeAlert1"
          onClick={() => {
            showModal('推荐配置', record);
          }}
        >
          推荐配置
        </a>,
        <a
          key="subscribeAlert1"
          onClick={() => {
            showModal('外链设置', record);
          }}
        >
          外链设置
        </a>,
      ],
    },
  ];

  checkCmsEdited(actionRef);

  return (
    <>
      <ProTable<APIS.CmsAddOrUpdateResponse>
        headerTitle={''}
        actionRef={actionRef}
        rowKey="id"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        toolBarRender={() => [
          <Button type="primary" key="primary" onClick={() => handleEditOrAdd(-1)}>
            <PlusOutlined /> 新增
          </Button>,
        ]}
        request={contentList}
        columns={columns}
      />
      <ContentModal
        loading={loading}
        updateModalVisible={updateModalVisible}
        onCancel={onCancel}
        modalTitle={modalInfo?.modalTitle}
        onOk={onOk}
        contentLoading={contentLoading}
      >
        {modalInfo?.modalTitle === '外链设置' ? (
          <LinkSet ref={linkRef} codeUrlData={codeUrlData} currentDetail={currentDetail} />
        ) : (
          <RecommendSet
            ref={commendRef}
            currentDetail={currentDetail}
            options={options}
            idAndNameList={idAndNameList}
          />
        )}
      </ContentModal>
    </>
  );

  function onCancel() {
    setUpdateModalVisible(false);
  }

  function onOk() {
    if (modalInfo?.modalTitle === '推荐配置') {
      commendRef.current?.takeData().then((res: any) => {
        setContentLoading(true);
        updateRecommend(res).then((result: any) => {
          setContentLoading(false);
          if (result.status === 0 && result.result.code === 0) {
            showSuccessMessage('推荐配置成功');
            actionRef.current?.reload();
            commendRef.current?.reset();
            setUpdateModalVisible(false);
          } else {
            showErrorMessage(result.message);
          }
        });
      });
    } else {
      const params = linkRef.current && linkRef.current.takeData();
      setContentLoading(true);
      saveQRCode(params).then((res: any) => {
        const { result } = res;
        setContentLoading(false);
        if (res.status === 0 && result.code === 0) {
          showSuccessMessage('保存成功');
          setUpdateModalVisible(false);
        } else {
          showErrorMessage(result.message || '保存失败');
        }
      });
    }
  }

  function showModal(modalTitle: string, record: any) {
    if (modalTitle === '外链设置' && !record.externalLink) {
      showErrorMessage('请配置外链');
      return;
    }
    setLoading(true);
    contentDetail({ id: record.id }, {})
      .then((res: any) => {
        const { result } = res;
        if (res.status === 0 && result.code === 0) {
          setCurrentDetail({
            ...currentDetail,
            ...result.contentDetail,
            externalLink: record.externalLink,
          });
          setModalTitle({
            modalTitle,
            id: record.id,
          });
          setUpdateModalVisible(true);
          if (modalTitle === '外链设置') {
            getCodeImg(record.id);
          }
        }
      })
      .finally(() => setLoading(false));
  }

  // 获取code
  function getCodeImg(id: number) {
    getQRCode({ id }).then((res: any) => {
      const { result } = res;
      if (res.status === 0 && result.code === 0) {
        const { qrCodeIcon, qrCodeLink } = result;
        setCodeUrlData({
          qrCodeIcon,
          qrCodeLink,
        });
      }
    });
  }
  // 处理数据
  function handleData(result: { id: string; name: string }[]) {
    const new_array: { label: string; value: string }[] = [];
    result.forEach((item: { id: string; name: string }, index: number) => {
      new_array[index] = { label: '', value: '0' };
      new_array[index].label = item.name;
      new_array[index].value = item.id.toString();
    });
    return new_array;
  }

  function handleEditOrAdd(id: number) {
    history.push(`/cms/contentSystem/createOrModify?cmsId=${id}`);
  }
};

const TableListContainer: React.FC<{ dispatch: any }> = (props) => {
  const { dispatch } = props;
  const previewRef = useRef<any>();
  function toPreview(id: number) {
    contentDetail({ id }, {}).then((res: any) => {
      const { result } = res;
      if (res.status === 0 && result.code === 0) {
        const { contentType, content, coverImage } = result.contentDetail;
        if (content?.length < 1) {
          showErrorMessage('内容为空，无法预览');
          return;
        }
        let pageData = getDefaultPageData();
        let pointData = [];
        if (contentType === 1) {
          pointData = [getDefaultRichTextContent(content)];
        } else if (contentType === 2) {
          pointData = [getDefaultVideoData(content, coverImage)];
        } else if (contentType === 3) {
          const config = JSON.parse(content);
          pageData = config.pageData;
          pointData = config.pointData;
        } else {
          showErrorMessage(`未知 contentType: ${contentType}`);
          return;
        }
        dispatch({
          type: 'editorModal/modPageAndPointData',
          payload: { pageData, pointData },
        });
        previewRef.current.show({ pageData, pointData });
      } else {
        showErrorMessage(res.message || result.message);
      }
    });
  }
  return (
    <KeepAlive>
      <PageContainer>
        <TableList toPreview={toPreview} />
        <Preview ref={previewRef} />
      </PageContainer>
    </KeepAlive>
  );
};
export default connect((state: StateWithHistory<any>) => ({
  emodal: state.present.editorModal,
}))(TableListContainer);

import React from 'react';
import { Modal } from 'antd';
import type { ReactNode } from 'react';

interface modalPropType {
  modalTitle: string | undefined;
  updateModalVisible?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children?: ReactNode;
  contentLoading?: boolean;
  loading?: boolean;
}

const ContentModal: React.FC<modalPropType> = (props) => {
  const { updateModalVisible, modalTitle, onCancel, contentLoading, onOk, children } = props;

  return (
    <Modal
      width={640}
      bodyStyle={{
        padding: '32px 40px 48px',
      }}
      centered
      title={modalTitle}
      visible={updateModalVisible}
      confirmLoading={contentLoading}
      onCancel={() => {
        onCancel();
      }}
      onOk={() => {
        onOk();
      }}
    >
      {children}
    </Modal>
  );
};

export default ContentModal;

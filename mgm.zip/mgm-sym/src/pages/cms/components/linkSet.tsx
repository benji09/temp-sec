/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import _ from 'lodash';
import QRCode from 'qrcode.react';
import copy from 'copy-to-clipboard';
import { Button, Input, Upload } from 'antd';
import { ArrowDownOutlined } from '@ant-design/icons';
import ProTable from '@ant-design/pro-table';
import type { ProColumns } from '@ant-design/pro-table';

import { COS_HOST } from '@/services/hosts';
import { cmsLinkConfigList, cmsLinkConfigSave, uploadFile } from '@/services/api';
import { showErrorMessage, showSuccessMessage, showWarnMessage } from '@/mamagement/Notification';

import '../contentSystem/index.less';

const LinkSet: React.FC<any> = forwardRef((props, ref) => {
  const { currentDetail, codeUrlData } = props;
  const [qrDescUrl, setCodeUrls] = useState<string>(codeUrlData?.qrCodeIcon || '');
  const [isShowCode, setShowCode] = useState<boolean>(false);
  const [linkConfig, setLinkConfig] = useState<APIS.LinkConfigProps[]>([]);
  const [linkParams, setLinkParams] = useState('');
  const [save, setSave] = useState(false);

  const queryCmsLinkConfigList = () => {
    cmsLinkConfigList({ id: currentDetail.id }).then((res: any) => {
      const temp = res?.result?.linkConfigs || [];
      temp.push({
        fullLink: '',
        linkParams: '',
      });
      for (let i = 0; i < temp.length; i += 1) temp[i].key = `${currentDetail.id}_${i}`;
      setLinkConfig(temp);
      setLinkParams('');
    });
  };

  useImperativeHandle(ref, () => ({
    takeData,
    reset,
  }));

  useEffect(() => {
    setShowCode(codeUrlData?.qrCodeLink);
    setCodeUrls(codeUrlData?.qrCodeIcon || '');
    queryCmsLinkConfigList();
  }, [codeUrlData]);

  const saveLinkConfig = () => {
    if (linkParams.trim().length < 1) {
      showWarnMessage('请填写完整参数配置');
      return;
    }
    setSave(true);
    cmsLinkConfigSave({
      id: currentDetail.id,
      params: linkParams,
    })
      .then((res: any) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(linkConfig);
          temp[temp.length - 1].linkParams = linkParams;
          temp.push({
            key: `${currentDetail.id}_${temp.length + 1}`,
            fullLink: '',
            linkParams: '',
          });
          setLinkParams('');
          setLinkConfig(temp);
        }
      })
      .finally(() => setSave(false));
  };

  const columns: ProColumns<APIS.LinkConfigProps>[] = [
    {
      title: '序号',
      align: 'center',
      render: (_text, _record, index) => <span>{index + 1}</span>,
    },
    {
      title: '参数配置',
      align: 'center',
      render: (_text, record, index) =>
        index !== linkConfig.length - 1 ? (
          <span>{record.linkParams}</span>
        ) : (
          <Input
            value={linkParams}
            onChange={(event) => setLinkParams(event.target?.value || '')}
          />
        ),
    },
    {
      title: '带参外链',
      align: 'center',
      dataIndex: 'linkParams',
      hideInTable: true,
      renderText: (text) =>
        text && text.trim().length > 0 ? `${currentDetail?.externalLink || ''}&${text}` : '',
    },
    {
      title: '操作',
      hideInSearch: true,
      valueType: 'option',
      align: 'center',
      render: (_text, record, index) => {
        return index === linkConfig.length - 1 ? (
          <Button type="link" loading={save} onClick={saveLinkConfig}>
            保存
          </Button>
        ) : (
          <Button
            type="link"
            onClick={() => copyLink(`${currentDetail?.externalLink || ''}&${record.linkParams}`)}
          >
            复制链接
          </Button>
        );
      },
    },
  ];

  return (
    <div className="link-set">
      <div className="link-wrap">
        <ul className="lists">
          <li className="list">
            <div className="label">ID：</div>
            <div className="content">{currentDetail?.id}</div>
          </li>
          <li className="list">
            <div className="label">页面标题：</div>
            <div className="content">{currentDetail?.contentTitle}</div>
          </li>
          <li className="list">
            <div className="label">备注：</div>
            <div className="content">{currentDetail?.remark}</div>
          </li>
          <li className="list">
            <div className="label">内容类型：</div>
            <div className="content">
              {currentDetail && currentDetail?.contentType === 1 ? '图文' : ''}
              {currentDetail && currentDetail?.contentType === 2 ? '视频' : ''}
              {currentDetail && currentDetail?.contentType === 3 ? '页面' : ''}
            </div>
          </li>
          <li className="list">
            <div className="label">外链：</div>
            <div className="content">
              <span style={{ width: 300, display: 'block' }}>{currentDetail?.externalLink}</span>
              <Button
                type="primary"
                style={{ marginLeft: 20 }}
                onClick={() => copyLink(currentDetail?.externalLink || '')}
              >
                复制外链
              </Button>
            </div>
          </li>
          <li className="list">
            <div className="label">二维码：</div>
            <div className="content">
              <div className="upload">
                <Upload
                  accept={'image/*'}
                  name="avatar"
                  listType="picture-card"
                  className="avatar-uploader"
                  showUploadList={false}
                  customRequest={customRequest}
                  style={{ width: 30, height: 30 }}
                >
                  {qrDescUrl ? <img src={qrDescUrl} alt="avatar" style={{ width: '100%' }} /> : '+'}
                </Upload>
                <span className="tip">上传二维码标签 30pt * 30pt</span>
                <Button
                  type="primary"
                  style={{ marginLeft: 20 }}
                  onClick={() => {
                    setShowCode(true);
                  }}
                >
                  生成二维码
                </Button>
              </div>
            </div>
          </li>
          <div className="qrcode-wrap">
            {isShowCode && (
              <QRCode
                id="qrCode"
                value={codeUrlData?.qrCodeLink || currentDetail?.externalLink}
                size={150} // 二维码的大小
                fgColor="#000" // 二维码的颜色
                imageSettings={{
                  // 二维码中间的logo图片
                  src: qrDescUrl,
                  excavate: qrDescUrl.length > 0,
                  width: 15,
                  height: 15,
                }}
              />
            )}
            {isShowCode && (
              <a id="aId" className="download" onClick={downLoadCode}>
                <ArrowDownOutlined style={{ color: '#fff', fontSize: 30 }} />
              </a>
            )}
          </div>
        </ul>
      </div>
      <ProTable<APIS.LinkConfigProps>
        columns={columns}
        rowKey="key"
        dateFormatter="string"
        dataSource={linkConfig || []}
        search={false}
        pagination={false}
        options={false}
        size={'small'}
        style={{ padding: '0px', marginTop: '16px' }}
        bordered={true}
      />
    </div>
  );

  // 上传
  function customRequest(option: any) {
    uploadFile(
      option,
      (key) => {
        setCodeUrls(`${COS_HOST}/cos/public/download?id=${key}`);
      },
      () => {
        showErrorMessage('上传失败');
      },
    );
  }
  // 复制链接
  function copyLink(link: string) {
    if (copy(link)) {
      showSuccessMessage('复制成功');
    } else {
      showErrorMessage('复制失败');
    }
  }

  // 下载二维码
  function downLoadCode() {
    const Qr = document.getElementById('qrCode');
    const image = new Image();
    image.setAttribute('crossOrigin', 'anonymous');
    image.src = (Qr as HTMLCanvasElement).toDataURL('image/png');
    const a_link = document.getElementById('aId');
    (a_link as HTMLAnchorElement).href = image.src;
    (a_link as HTMLAnchorElement).download = '二维码';
  }

  function takeData() {
    const { id, externalLink } = currentDetail;
    return {
      id,
      qrCodeIcon: qrDescUrl,
      qrCodeLink: externalLink,
    };
  }

  // 重置
  function reset() {
    setShowCode(false);
    setCodeUrls('');
    setLinkConfig([]);
    setLinkParams('');
  }
});

export default LinkSet;

/* eslint-disable react-hooks/exhaustive-deps */
import React, { forwardRef, useEffect, useState, useImperativeHandle } from 'react';
import { Checkbox, Select, Form, Spin } from 'antd';

import { useDebounce } from '@/utils/utils';
import { searchTagList } from '@/services/api';

import '../contentSystem/index.less';

const RecommendSet: React.FC<any> = forwardRef((props, ref) => {
  const { currentDetail, options } = props;
  const [keyword, setKeyword] = useState<string>();
  const [loading, setLoading] = useState(false);
  const [tagList, setTagList] = useState([]);
  const [submitTags, setSubmitTags] = useState<any[]>([]);
  const [form] = Form.useForm();

  useEffect(() => {
    const temp = keyword?.trim() || '';
    if (temp && temp.length > 0) {
      setLoading(true);
      searchTagList({ tagName: temp })
        .then((res: any) => {
          if (res.status === 0) {
            setTagList(
              res.result.threeTagInfo.map((opts: any) => {
                return {
                  ...opts,
                  value: opts.id,
                  label: opts.name,
                };
              }),
            );
          }
        })
        .finally(() => setLoading(false));
    }
  }, [useDebounce(keyword, 500)]);

  useImperativeHandle(ref, () => ({
    takeData,
    reset: () => {
      form.resetFields();
    },
  }));

  useEffect(() => {
    const { isRecommended, recommendTag } = currentDetail;
    setSubmitTags(recommendTag);
    setTagList(
      recommendTag.map((tag: { id: any; name: any }) => {
        return {
          ...tag,
          value: tag.id,
          label: tag.name,
        };
      }),
    );
    form.setFieldsValue({
      ...currentDetail,
      isRecommended: isRecommended ? 1 : 0,
      recommendTag:
        recommendTag.length > 0
          ? recommendTag.map((tag: { name: string; id: string }) => tag.id)
          : [],
    });
  }, [currentDetail]);

  return (
    <div className="recommend-set">
      <div className="inner-wrapper">
        <ul className="lists">
          <Form form={form}>
            <li className="list">
              <div className="label">ID：</div>
              <div className="content">{currentDetail?.id}</div>
            </li>
            <li className="list">
              <div className="label">页面标题：</div>
              <div className="content">{currentDetail?.contentTitle}</div>
            </li>
            <li className="list">
              <div className="label">备注：</div>
              <div className="content">{currentDetail?.remark}</div>
            </li>
            <li className="list">
              <div className="label">内容类型：</div>
              <div className="content">
                {currentDetail && currentDetail?.contentType === 1 ? '图文' : ''}
                {currentDetail && currentDetail?.contentType === 2 ? '视频' : ''}
                {currentDetail && currentDetail?.contentType === 3 ? '页面' : ''}
              </div>
            </li>
            <Form.Item
              label="是否推荐"
              name="isRecommended"
              rules={[{ required: true, message: '请选择是否推荐' }]}
            >
              <Select placeholder="请选择">
                <Select.Option value={0}>否</Select.Option>
                <Select.Option value={1}>是</Select.Option>
              </Select>
            </Form.Item>
            <Form.Item
              label="所属板块"
              name="ownedPlate"
              rules={[{ required: true, message: '请选择所属板块' }]}
            >
              <Checkbox.Group options={options} />
            </Form.Item>
            <Form.Item
              label="推荐标签"
              name="recommendTag"
              rules={[{ required: true, message: '请选择推荐标签' }]}
            >
              <Select
                mode="multiple"
                size={'middle'}
                placeholder="请选择"
                defaultActiveFirstOption={false}
                notFoundContent={loading ? <Spin size="small" /> : null}
                showArrow={false}
                filterOption={false}
                options={tagList}
                onSearch={onIdcSearch}
                onChange={onIdChange}
                style={{ width: '100%' }}
              />
            </Form.Item>
          </Form>
        </ul>
      </div>
    </div>
  );

  // 标签选项
  function onIdcSearch(val: string) {
    setKeyword(val);
  }

  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          const { isRecommended, ownedPlate, recommendTag } = values;
          resolve({
            id: currentDetail?.id,
            isRecommended: isRecommended === 1,
            ownedPlate,
            recommendTag,
          });
        })
        .catch(reject);
    });
  }

  // 存储标签数据
  function onIdChange(value: string, option: any) {
    const len = option.length;
    if (len > submitTags.length) {
      const { id, name } = option[len - 1];
      setSubmitTags(submitTags.concat({ id, name }));
    } else {
      setSubmitTags(
        submitTags.filter((label: { name?: any }) => {
          return value.includes(label.name);
        }),
      );
    }
  }
});

export default RecommendSet;

import { removeItem, setItem } from '@/storage';
import KEYS from '@/utils/storageKeys';
import { uuid } from '@/utils/tool';

export const getDefaultVideoData = (content: string, coverage: string) => {
  return {
    id: uuid(6, 10),
    item: {
      type: 'Video',
      config: {
        poster: [
          {
            url: coverage,
          },
        ],
        videoUrl: content,
      },
      h: 360,
      editableEl: [
        {
          key: 'poster',
          name: '视频封面',
          type: 'Upload',
        },
        {
          key: 'url',
          name: '视频链接',
          type: 'Text',
        },
      ],
      category: 'media',
      x: 0,
    },
    point: {
      i: 'x-0',
      x: 0,
      y: 59,
      w: 24,
      h: 360,
      isBounded: true,
    },
    status: 'inToCanvas',
  };
};

export const getDefaultRichTextContent = (content: string) => {
  return {
    id: uuid(6, 10),
    item: {
      type: 'RichText',
      config: {
        round: 0,
        borderWidth: 0,
        borderColor: 'rgba(255,255,255,1)',
        padding: 0,
        content: content,
      },
      h: 960,
      editableEl: [
        {
          key: 'round',
          name: '边框圆角',
          type: 'Number',
        },
        {
          key: 'borderWidth',
          name: '边框宽度',
          type: 'Number',
        },
        {
          key: 'borderColor',
          name: '边框颜色',
          type: 'Color',
        },
        {
          key: 'padding',
          name: '内边距',
          type: 'Number',
        },
        {
          key: 'content',
          name: '内容',
          type: 'RichText',
        },
      ],
      category: 'base',
      x: 0,
    },
    point: {
      i: 'x-0',
      x: 0,
      y: 129,
      w: 24,
      h: 960,
      isBounded: true,
    },
    status: 'inToCanvas',
  };
};

export const getDefaultPageData = () => {
  return {
    backgroundColor: 'rgba(255, 255, 255, 100)',
  };
};

export const updateCmsEdited = (status: boolean | undefined = true) => {
  setItem(KEYS.KEYS_EDITED_CMS, String(status));
};

export const checkCmsEdited = (actionRef: any) => {
  const editFlag = localStorage.getItem(KEYS.KEYS_EDITED_CMS);
  if (actionRef && editFlag && editFlag === String(true)) {
    removeItem(KEYS.KEYS_EDITED_CMS);
    actionRef?.current?.reloadAndRest();
  }
};

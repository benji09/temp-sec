import type { ReactNode } from 'react';

interface ListBannerType {
  id?: number;
  bannerName?: string;
  createdTime?: number;
  startTime?: number;
  endTime?: number;
  status?: number;
  sortedNo?: number;
  bannerType?: number;
}
interface ModalPropType {
  ModalVisible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children: ReactNode;
}
interface SaveOrUpdateType {
  id?: number;
  bannerName?: string;
  bannerImg?: number;
  bannerUrl?: number;
  startTime?: number;
  endTime?: number;
  sortedNo?: number;
  status?: number;
  createdTime?: number;
}
export { ListBannerType, ModalPropType, SaveOrUpdateType };

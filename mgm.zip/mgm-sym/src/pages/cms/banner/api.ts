/*
 * @Author: zyx
 * @Date: 2021-09-16 14:22:42
 * @LastEditors: zyx
 * @LastEditTime: 2021-11-03 17:51:50
 * @Desc:
 */
// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { checkIsNumberForSearch, HOST_TYPE_POWER } from '@/utils/utils';

import type { SaveOrUpdateType } from './typings';

// Banner列表
const getBannerList = async (params: any) => {
  const { current, pageSize, admissionDate, applyTime, dischargeDate, bannerName, ...data } =
    params;
  data.pageNo = current;
  data.pageSize = Number(pageSize);
  data.name = bannerName;

  const IdResult = checkIsNumberForSearch(params.id, 'ID');
  if (IdResult !== null) return IdResult;

  const msg = await request('/banner/page', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: data,
  });
  return {
    data: msg.result.bannerInfos || [],
    total: msg.result.totalCount || 0,
  };
};
// Banner列表新增
const bannerListAdd = async (data: SaveOrUpdateType) => {
  return await request('/banner/save-update', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// Banner列表详情
const bannerDetail = async (id?: string | number) => {
  return await request('/banner/detail', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { id },
  });
};

export { getBannerList, bannerListAdd, bannerDetail };

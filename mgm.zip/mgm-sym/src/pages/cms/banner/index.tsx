import React, { useRef, useState, useEffect } from 'react';
import { Button } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';

import { checkPermission, BANNER_PAGE, BANNER_DETAIL, BANNER_SAVE_UPDATE } from '@/utils/power';
import { formatTime } from '@/utils/utils';
import TableLocal from '@/components/TableLocal/TableLocal';

import { BANNERTYPE, STATUS } from './util';
import { bannerDetail, bannerListAdd, getBannerList } from './api';
import Modal from './components/Modal';
import CreateOrEdit from './components/CreateOrEdit';
import type { ListBannerType } from './typings';
import type { RightsListType } from '@/pages/mallDrugs/mallDrugsData/typings';
import type { TypeListType } from '@/pages/mallDrugs/typing';
import { transferPlanCodeToObj } from '@/pages/mallDrugs/utils';
import { queryAllRights } from '@/services/api';

const MODAL_TYPE_VIEW = 1;
const MODAL_TYPE_ADD = 2;

// 权限
const permissionGroups = [BANNER_PAGE, BANNER_DETAIL, BANNER_SAVE_UPDATE];

const Banner: React.FC = () => {
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [ModalVisible, setModalVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const actionRef = useRef<ActionType | undefined>();
  const createOrEditRef = useRef<any>();

  const [powers, setPowers] = useState({});

  const [rightsList, setRightsList] = useState<RightsListType[]>([]);
  const [planCodeStatus, setPlanCodeStatus] = useState<TypeListType>({});

  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_VIEW:
        return '查看';
      case MODAL_TYPE_ADD:
        return '新增';
    }
    return '';
  }

  function getPlanCodeDesc(data?: string[]) {
    const _list: string[] = [];
    (data ?? []).map((value: string) => {
      _list.push(planCodeStatus[value] ?? '');
      return value;
    });
    return _list.join('、');
  }

  const onModalOk = () => {
    if (modalType === 1) {
      createOrEditRef.current
        ?.takeData()
        .then((data: any) => {
          bannerListAdd(data).then((res) => {
            if (res.status === 0) {
              setModalType(undefined);
              setModalVisible(false);
              actionRef.current?.reload();
            }
          });
        })
        .finally(() => {
          setLoading(false);
        });
    } else if (modalType === 2) {
      createOrEditRef.current?.takeData().then((data: any) => {
        bannerListAdd(data)
          .then((res) => {
            if (res.status === 0) {
              setModalType(undefined);
              setModalVisible(false);
              actionRef.current?.reload();
            }
          })
          .finally(() => {
            setLoading(false);
          });
      });
    }
  };
  const onModalCancel = () => {
    setLoading(false);
    setModalType(undefined);
    setModalVisible(false);
    createOrEditRef.current?.reset();
  };

  useEffect(() => {
    queryAllRights().then((res) => {
      if (res && res.status === 0 && res.result) {
        setRightsList(res.result);
        setPlanCodeStatus(transferPlanCodeToObj(res.result));
      }
    });
  }, []);

  const columns: ProColumns<ListBannerType>[] = [
    {
      title: 'ID',
      dataIndex: 'id',
    },
    {
      title: '名称',
      dataIndex: 'bannerName',
    },
    {
      title: '创建时间',
      dataIndex: 'createdTime',
      render: (text: any) => {
        return <span>{formatTime(text)}</span>;
      },
      hideInSearch: true,
    },
    {
      title: '展示时间',
      dataIndex: 'startTime',
      render: (text: any) => {
        return <span>{formatTime(text)}</span>;
      },
      hideInSearch: true,
    },
    {
      title: '结束时间',
      dataIndex: 'endTime',
      render: (text: any) => {
        return <span>{formatTime(text)}</span>;
      },
      hideInSearch: true,
    },
    {
      title: '所属权益',
      dataIndex: 'planCode',
      hideInSearch: true,
      renderText: (text) => getPlanCodeDesc(text),
    },
    {
      title: '展示时间',
      dataIndex: 'startTime',
      valueType: 'date',
      hideInTable: true,
    },
    {
      title: '结束时间',
      dataIndex: 'endTime',
      valueType: 'date',
      hideInTable: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueEnum: STATUS,
    },
    {
      title: '排序',
      dataIndex: 'sortedNo',
      hideInSearch: true,
    },
    {
      title: '位置',
      dataIndex: 'bannerType',
      hideInSearch: true,
      valueEnum: BANNERTYPE,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        powers[`${BANNER_DETAIL}`] && (
          <Button
            key="view"
            type="link"
            onClick={() => {
              setModalType(MODAL_TYPE_VIEW);
              setModalVisible(true);
              bannerDetail(record.id).then((res) => {
                createOrEditRef.current?.setData(res.result);
              });
            }}
          >
            详情
          </Button>
        ),
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="BannerTable"
      columns={columns}
      actionRef={actionRef}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={powers[`${BANNER_PAGE}`] && getBannerList}
      rowKey="id"
      toolBarRender={() => [
        powers[`${BANNER_SAVE_UPDATE}`] && (
          <Button
            key="primary"
            type="primary"
            onClick={() => {
              setModalType(MODAL_TYPE_ADD);
              setModalVisible(true);
            }}
          >
            <PlusOutlined />
            新增
          </Button>
        ),
      ]}
    >
      <Modal
        title={getModalTitle()}
        loading={loading}
        ModalVisible={ModalVisible}
        onOk={onModalOk}
        onCancel={onModalCancel}
      >
        {(modalType === 1 || modalType === 2) && (
          <CreateOrEdit ref={createOrEditRef} rightsList={rightsList} />
        )}
      </Modal>
    </TableLocal>
  );
};
export default Banner;

import React, { useRef } from 'react';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { DndProvider, createDndContext } from 'react-dnd';

import { removeItem } from '@/services/localStorage';
import KEYS from '@/utils/storageKeys';

import Container from './Container';

import styles from './index.less';

const RNDContext = createDndContext(HTML5Backend);

function BasicLayout(props) {
  const manager = useRef(RNDContext);
  removeItem(KEYS.KEY_IS_PREVIEW);
  return (
    <div className={styles.layout}>
      <DndProvider manager={manager.current.dragDropManager}>
        <Container {...props} />
      </DndProvider>
    </div>
  );
}

export default BasicLayout;

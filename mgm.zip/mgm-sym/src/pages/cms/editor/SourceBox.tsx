/* eslint-disable react-hooks/exhaustive-deps */
import { useMemo, memo, useCallback } from 'react';
import { connect } from 'dva';
import { useDrag } from 'react-dnd';
import type { StateWithHistory } from 'redux-undo';
import type { ReactNode, CSSProperties } from 'react';

import schema from '@/materials/schema';

import styles from './index.less';

interface TargetBoxProps {
  item: any;
  emodal: any;
  children: ReactNode;
  canvasId: string;
}

const SourceBox = memo((props: TargetBoxProps) => {
  const { item, emodal } = props;
  const { pointData } = emodal;

  const allowDrag: any = useCallback(() => {
    if (item.only) {
      return !pointData.some((o: any) => item.type === o.item.type);
    }
    return true;
  }, [pointData]);

  const itemAllowDrag = allowDrag();

  const [{ isDragging }, drag] = useDrag({
    item: {
      type: item.type,
      config: schema[item.type as keyof typeof schema].config,
      h: item.h,
      editableEl: schema[item.type as keyof typeof schema].editData,
      category: item.category,
      x: item.x || 0,
      only: Boolean(item.only),
      fixed: item.fixed,
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const containerStyle: CSSProperties = useMemo(
    () => ({
      opacity: isDragging ? 0.4 : 1,
      cursor: 'move',
      height: '140px',
    }),
    [isDragging],
  );

  return (
    <>
      <div className={styles.listWrap}>
        <div
          className={styles.module}
          style={{ ...containerStyle }}
          ref={itemAllowDrag ? drag : null}
        >
          <div
            style={{
              height: '110px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              flexDirection: 'column',
              overflow: 'hidden',
            }}
          >
            {props.children}
          </div>
          <div
            style={{
              height: '30px',
              lineHeight: '30px',
              textAlign: 'center',
              backgroundColor: 'rgba(245, 245, 245, 1)',
              color: 'rgba(118, 118, 118, 1)',
            }}
          >
            {item.displayName}
          </div>
        </div>
      </div>
    </>
  );
});

export default connect((state: StateWithHistory<any>) => {
  return { emodal: state.present.editorModal };
})(SourceBox);

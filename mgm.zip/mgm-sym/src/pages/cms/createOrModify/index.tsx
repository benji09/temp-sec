import { useRef, useState, useEffect } from 'react';
import { history } from 'umi';
import { connect } from 'dva';
import { Button, Card, Col, Divider, Form, Input, Modal, Row, Select, Upload } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';
import { CloseCircleOutlined, LoadingOutlined, PlusOutlined } from '@ant-design/icons';
import type { StateWithHistory } from 'redux-undo';
import type { RcFile } from 'antd/lib/upload';

import { setItem } from '@/storage';
import KEYS from '@/utils/storageKeys';
import VideoPlayer from '@/materials/media/Video';
import { checkImageTypeAndSize, checkImageTypeAndSizeAndWideAndHight } from '@/utils/utils';
import { showErrorMessage } from '@/mamagement/Notification';
import { cmsAddOrUpdate, contentDetail, getCosDownladUrl, uploadFile } from '@/services/api';
import XEditor from '@/components/FormComponents/XEditor';
import UploadVideo from '@/components/FormComponents/UploadVideo';

import Preview from '../editor/components/Preview';
import {
  getDefaultPageData,
  getDefaultRichTextContent,
  getDefaultVideoData,
  updateCmsEdited,
} from '../util';

import './index.less';

class SelectProp {
  id: number;
  name: string;
  constructor(id: number, name: string) {
    this.id = id;
    this.name = name;
  }
}

const CreateOrModifyCMS = (props: { dispatch: any }) => {
  const { dispatch } = props;

  const [form] = Form.useForm();
  const { TextArea } = Input;
  const types = [new SelectProp(1, '图文'), new SelectProp(2, '视频'), new SelectProp(3, '页面')];
  const formLayout = {
    labelCol: { span: 5 },
    wrapperCol: { span: 19 },
  };
  const [contentType, setContentType] = useState(1);
  const [videoUrl, setVideoUrl] = useState('');
  const [iconUrl, setIconUrl] = useState('');
  const [weChatShareImage, setWeChatShareImage] = useState('');
  const [weChatShareImageLoading, setWeChatShareImageLoading] = useState<boolean>(false);
  const [coverImage, setCoverImage] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadContent, setLoadContent] = useState(false);
  const [richTextContent, setRichTextContent] = useState<string>('');
  const [pageContent, setPageContent] = useState<string>('');
  const previewRef = useRef<any>();

  const id = history.location.search.match(/cmsId=(\d+)/)?.[1];

  const [cmsId, setCmsId] = useState<number>(id && id.match(/\d+/) ? +id : -1);

  const [contentDetails, setContentDetails] = useState<any | null>(null);

  useEffect(() => {
    if (cmsId < 0) {
      setContentDetails(null);
    } else {
      setLoadContent(true);
      contentDetail({ id: cmsId }, {})
        .then((res: any) => {
          const { result } = res;
          if (res.status === 0 && result.code === 0) {
            setContentDetails(result.contentDetail);
            form.setFieldsValue(result.contentDetail);

            const currType = result.contentDetail.contentType;
            const {
              content,
              contentTitleIcon,
              weChatShareImage: weChatShareImg,
              coverImage: coverImg,
            } = result.contentDetail;
            if (currType === 1) setRichTextContent(content);
            else if (currType === 2) setVideoUrl(content);
            else if (currType === 3) setPageContent(content);
            setContentType(currType);
            setIconUrl(contentTitleIcon);
            setWeChatShareImage(weChatShareImg); // 微信分享图片
            setCoverImage(coverImg);
          }
        })
        .finally(() => setLoadContent(false));
    }
  }, [cmsId, form]);

  function onSelectChange(value: any) {
    setContentType(value);
  }

  function getRequest(value: any, content: string) {
    return {
      contentTitle: value.contentTitle,
      weChatShareDescription: value.weChatShareDescription || '',
      contentTitleIcon: iconUrl || '',
      weChatShareImage: weChatShareImage || '',
      remark: value.remark,
      coverImage,
      contentType,
      content,
    };
  }

  const uploadProps = {
    beforeUpload: (file: RcFile, fileList: RcFile[]) => {
      return checkImageTypeAndSize(file, fileList, 'image', 200, 3);
    },
  };
  const shareUploadProps = {
    beforeUpload: (file: RcFile) => {
      return checkImageTypeAndSizeAndWideAndHight(file, 300, 300);
    },
  };
  const IconUploadProps = {
    beforeUpload: checkImageTypeAndSize,
  };
  function editPageData() {
    form.validateFields().then((value) => {
      if (coverImage?.length < 1) {
        showErrorMessage('请上传封面');
      } else {
        const request = { id: cmsId, ...getRequest(value, pageContent) };
        setItem(KEYS.KEY_CMS_ADD_OR_MODIFY, JSON.stringify(request));
        if (request.content.length > 0) {
          dispatch({
            type: 'editorModal/modPageAndPointData',
            payload: JSON.parse(request.content),
          });
        } else {
          dispatch({ type: 'editorModal/clearAll' });
        }
        history.push('/cms/contentSystem/editor');
      }
    });
  }

  function saveData(values: any, isPreview: boolean) {
    if (values.contentTitle.trim().length < 1) {
      showErrorMessage('内容标题不能为空');
      return;
    }
    if (values.remark.trim().length < 1) {
      showErrorMessage('内容标题不能为空');
      return;
    }
    if (coverImage?.length < 1) {
      showErrorMessage('请上传封面');
      return;
    }

    if (contentType === 1 && (!richTextContent || richTextContent.length < 1)) {
      showErrorMessage('请输入图文信息');
      return;
    }

    if (contentType === 2 && videoUrl?.length < 1) {
      showErrorMessage('请输入视频地址');
      return;
    }

    if (contentType === 3 && pageContent?.length < 1) {
      showErrorMessage('页面内容为空，请先进行编辑');
      return;
    }

    let content = '';
    if (contentType === 1) {
      content = richTextContent || '';
      if (content === '<p></p>') content = '';
    } else if (contentType === 2) content = videoUrl;
    else if (contentType === 3) content = pageContent;
    else content = '';

    if (content.length < 1) {
      showErrorMessage('请输入内容详情');
      return;
    }

    Modal.confirm({
      title: '提示信息',
      content: '是否确认保存？',
      okText: '是',
      onOk() {
        const request = getRequest(values, content);
        setLoading(true);
        cmsAddOrUpdate(cmsId < 0 ? request : { id: cmsId, ...request })
          .then((res: any) => {
            if (res.status === 0) {
              updateCmsEdited(true);
              if (isPreview) {
                setCmsId(res.result.id);
                toPreview(request.contentType, request.content, request.coverImage);
              } else {
                form.resetFields();
                history.goBack();
              }
            }
          })
          .finally(() => setLoading(false));
      },
      cancelText: '否',
    });
  }

  function toPreview(contentTypes: number, content: string, coverImages: string) {
    let pageData = getDefaultPageData();
    let pointData = [];
    if (contentTypes === 1) {
      pointData = [getDefaultRichTextContent(content)];
    } else if (contentTypes === 2) {
      pointData = [getDefaultVideoData(content, coverImages)];
    } else if (contentTypes === 3) {
      const config = JSON.parse(content);
      pageData = config.pageData;
      pointData = config.pointData;
    } else {
      showErrorMessage(`未知 contentType: ${contentTypes}`);
      return;
    }
    dispatch({
      type: 'editorModal/modPageAndPointData',
      payload: { pageData, pointData },
    });
    // dispatch({ type: 'editorModal/clearAll' });
    previewRef.current.show({ pageData, pointData });
  }

  function iconCustomRequest(option: any) {
    uploadFile(
      option,
      async (key) => {
        setIconUrl(getCosDownladUrl(key));
      },
      async () => {
        showErrorMessage('上传失败.');
      },
    );
  }
  function coverImageCustomRequest(option: any) {
    uploadFile(
      option,
      async (key) => {
        setCoverImage(getCosDownladUrl(key));
      },
      async () => {
        showErrorMessage('上传失败.');
      },
    );
  }
  function shareCustomRequest(option: any) {
    setWeChatShareImageLoading(true);
    uploadFile(
      option,
      async (key) => {
        setWeChatShareImageLoading(false);
        setWeChatShareImage(getCosDownladUrl(key));
      },
      async () => {
        setWeChatShareImageLoading(false);
        showErrorMessage('上传失败.');
      },
    );
  }
  const onPreView = () => {
    form.validateFields().then((value) => {
      saveData(value, true);
    });
  };

  const onFinish = (value: any) => {
    saveData(value, false);
  };

  return (
    <PageContainer>
      <Card loading={loadContent}>
        {contentDetails !== null ? (
          <Row>
            <Col span={2}>ID: {contentDetails.id}</Col>
            <Col span={7}>创建日期: {contentDetails.createdAt}</Col>
            <Col span={4}>创建人: {contentDetails.creator}</Col>
            <Col span={7}>修改日期: {contentDetails.updatedAt}</Col>
            <Col span={4}>修改人: {contentDetails.updater}</Col>
          </Row>
        ) : null}
        <Form form={form} {...formLayout} onFinish={onFinish}>
          <h2>基本信息</h2>
          <Row gutter={16}>
            <Col span={14}>
              <Form.Item
                name="contentTitle"
                label="页面标题"
                required={true}
                rules={[
                  {
                    required: true,
                    type: 'string',
                    min: 1,
                    max: 100,
                    message: '请输入页面标题',
                  },
                ]}
              >
                <Input placeholder="请输入页面标题(1~100字)" maxLength={100} />
              </Form.Item>
            </Col>
            <Col span={10}>
              <Form.Item label="Icon" className="upload">
                <Upload
                  accept={'image/*'}
                  name="contentTitleIcon"
                  listType="picture-card"
                  className="icon-uploader"
                  showUploadList={false}
                  customRequest={iconCustomRequest}
                  style={{ width: 30, height: 30 }}
                  {...IconUploadProps}
                >
                  {iconUrl ? <img src={iconUrl} alt="icon" style={{ width: '100%' }} /> : '+'}
                </Upload>
                <span>30pt * 30pt</span>
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={14}>
              <Form.Item
                name="remark"
                label="备注"
                required={true}
                rules={[{ required: true, type: 'string', min: 3, message: '请输入备注(3~250字)' }]}
              >
                <TextArea placeholder="请输入备注" rows={4} maxLength={250} minLength={3} />
              </Form.Item>
            </Col>
            <Col span={10}>
              <Form.Item label="封面" required={true} className="upload">
                <Upload
                  accept={'image/*'}
                  name="coverImage"
                  listType="picture-card"
                  className="coverage-uploader"
                  showUploadList={false}
                  {...uploadProps}
                  customRequest={coverImageCustomRequest}
                >
                  {coverImage ? (
                    <img
                      src={coverImage}
                      alt="coverImage"
                      style={{ maxWidth: '100%', maxHeight: '100%' }}
                    />
                  ) : (
                    <PlusOutlined />
                  )}
                </Upload>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={14}>
              <Form.Item name="weChatShareDescription" label="微信分享描述">
                <TextArea
                  showCount={true}
                  placeholder="请输入微信分享描述"
                  rows={6}
                  maxLength={100}
                />
              </Form.Item>
            </Col>
            <Col span={10}>
              <Form.Item label="微信分享图片" className="upload">
                <Upload
                  accept={'image/*'}
                  name="weChatShareImage"
                  listType="picture-card"
                  className="share-uploader"
                  showUploadList={false}
                  customRequest={shareCustomRequest}
                  style={{ width: '150px', height: '150px' }}
                  {...shareUploadProps}
                >
                  {weChatShareImage ? (
                    <div>
                      <i
                        onClick={(e) => {
                          e.stopPropagation();
                          setWeChatShareImage('');
                          form.setFieldsValue({ weChatShareImage: '' });
                        }}
                        className="delWeChatShareImage"
                      >
                        <CloseCircleOutlined />
                      </i>
                      <img
                        onClick={(e) => {
                          e.stopPropagation();
                        }}
                        src={weChatShareImage}
                        alt="icon"
                        style={{ width: '100%' }}
                      />
                    </div>
                  ) : !weChatShareImageLoading ? (
                    <PlusOutlined />
                  ) : (
                    <LoadingOutlined />
                  )}
                </Upload>
                <span>300pt * 300pt</span>
              </Form.Item>
            </Col>
          </Row>
          <h2>内容详情</h2>

          <Row gutter={16}>
            <Col span={14}>
              <Form.Item
                name="contentType"
                label="内容类型"
                required={true}
                initialValue={contentType}
              >
                <Select onChange={onSelectChange}>
                  {types?.map((item) => (
                    <Select.Option key={item.id} value={item.id}>
                      {item.name}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col span={10} style={{ alignItems: 'flex-end' }}>
              {contentType === 3 ? (
                <Button
                  type="primary"
                  style={{ borderRadius: '8px', marginLeft: '36px' }}
                  onClick={editPageData}
                >
                  编辑
                </Button>
              ) : null}
              <Button
                type="primary"
                onClick={onPreView}
                loading={loading}
                style={{ borderRadius: '8px', marginLeft: '36px' }}
              >
                预览
              </Button>
            </Col>
          </Row>

          {contentType === 1 ? (
            <Form.Item>
              <div className="richText">
                <XEditor
                  isTpl={false}
                  round={8}
                  borderColor={'#000000'}
                  borderWidth={4}
                  padding={8}
                  value={richTextContent}
                  onChange={(value: any) => setRichTextContent(value || '')}
                />
              </div>
            </Form.Item>
          ) : null}
          {contentType === 2 ? (
            <>
              <Row gutter={16}>
                <Col span={14}>
                  <Form.Item label="视频地址">
                    <Input value={videoUrl} onChange={(res) => setVideoUrl(res.target.value)} />
                  </Form.Item>
                </Col>
                <Col span={10} style={{ alignItems: 'flex-end' }}>
                  <UploadVideo
                    text="本地上传"
                    onChange={(v) => setVideoUrl(v && v.length > 0 ? v[0].url : '')}
                  />
                </Col>
              </Row>
              {videoUrl && videoUrl.startsWith('http') ? (
                <div style={{ width: '70%' }}>
                  <VideoPlayer
                    marginTop={16}
                    videoUrl={videoUrl}
                    poster={coverImage ? [{ url: coverImage }] : []}
                    isTpl={false}
                    uploadVideo={[]}
                  />
                </div>
              ) : null}
            </>
          ) : null}
          <Divider />
          {/* {contentType !== 3 ? ( */}
          <Form.Item style={{ textAlign: 'right', marginTop: '12px' }}>
            <Button
              type={'dashed'}
              htmlType={'submit'}
              onClick={() => {
                form.resetFields();
                history.goBack();
              }}
            >
              取消
            </Button>
            <Button
              type={'primary'}
              htmlType={'submit'}
              loading={loading}
              style={{ marginLeft: '18px' }}
            >
              提交
            </Button>
          </Form.Item>
          {/* ) : null} */}
        </Form>
      </Card>
      <Preview ref={previewRef} />
    </PageContainer>
  );
};

export default connect((state: StateWithHistory<any>) => {
  return { emodal: state.present.editorModal };
})(CreateOrModifyCMS);

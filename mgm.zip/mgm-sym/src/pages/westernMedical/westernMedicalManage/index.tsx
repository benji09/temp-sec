import React, { useState, useRef, useEffect } from 'react';
import { Button } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import TableLocal from '@/components/TableLocal/TableLocal';
import {
  checkPermission,
  PRESCRIPTIONS_PAGE,
  PRESCRIPTIONS_ADD,
  PRESCRIPTIONS_DETAIL,
  PRESCRIPTIONS_UPDATE_PARTS,
  PRESCRIPTIONS_ADD_PARTS,
  PRESCRIPTIONS_UPDATE_DETAIL,
} from '@/utils/power';

import {
  westernMedicalManageList,
  getDictionary,
  addPrescription,
  updatePrescription,
  getPrescription,
} from './api';
import type { GainCardMsgInfosType } from './typings.d';
import Modal from './components/modal';
import CreateOrDetails from './components/createOrDetails';
import ConfigParts from './components/configParts';
import { EnableStatus } from './utils/utils';

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_DETAIL = 2;
const MODAL_TYPE_CONFIG = 3;

const permissionGroups = [
  PRESCRIPTIONS_PAGE,
  PRESCRIPTIONS_ADD,
  PRESCRIPTIONS_DETAIL,
  PRESCRIPTIONS_UPDATE_DETAIL,
  PRESCRIPTIONS_UPDATE_PARTS,
  PRESCRIPTIONS_ADD_PARTS,
];

const WesternMedicalManage: React.ReactNode = () => {
  const createOrDetailsRef = useRef<any>();
  const configPartsRef = useRef<any>();
  const actionRef = useRef<ActionType | undefined>();

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [details, setDetails] = useState({});

  const [useTime, setUseTime] = useState([]); // 频率列表
  const [useTimeUnit, setUseTimeUnit] = useState([]); // 数量单位列表
  const [usage, setUsage] = useState([]); // 用法列表
  const [usageUnit, setUsageUnit] = useState([]); // 用量单位列表

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  useEffect(() => {
    getDictionary().then((res) => {
      const { result, status } = res;
      if (status === 0) {
        setUseTime(result.use_time);
        setUseTimeUnit(result.use_time_unit);
        setUsage(result.usage);
        setUsageUnit(result.usage_unit);
      }
    });
  }, []);
  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_DETAIL:
        return '编辑';
      case MODAL_TYPE_CONFIG:
        return '配置';
    }
    return '';
  }

  // 弹框取消
  function onCancel() {
    setTimeout(() => {
      setVisible(false);
      setDetails({});
      createOrDetailsRef.current?.reset();
      configPartsRef.current?.reset();
      setModalType(undefined);
    }, 300);
  }

  // 取消保存
  function onCancelSave() {
    setVisible(false);
    setBtnLoading(false);
  }

  // 弹框保存 开启二次确认
  function onOk() {
    if (modalType === MODAL_TYPE_ADD || modalType === MODAL_TYPE_DETAIL) {
      createOrDetailsRef.current?.takeData().then((res: any) => {
        setDetails(res);
        setVisible(true);
      });
    }
  }

  // 二次确认后保存
  function onSaveData() {
    setBtnLoading(true);
    if (modalType === MODAL_TYPE_ADD) {
      // 新增
      addPrescription(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          setDetails({});
          actionRef.current?.reload();
          setModalType(undefined);
          setTimeout(() => {
            createOrDetailsRef.current?.reset();
          });
        }
      });
    } else if (modalType === MODAL_TYPE_DETAIL) {
      // 编辑
      updatePrescription(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          setDetails({});
          actionRef.current?.reload();
          setModalType(undefined);
          setTimeout(() => {
            createOrDetailsRef.current?.reset();
          });
        }
      });
    }
  }
  // 点击编辑
  function detailClick(record: GainCardMsgInfosType) {
    getPrescription(record.id).then((res) => {
      if (res.status === 0) {
        setModalType(MODAL_TYPE_DETAIL);
        createOrDetailsRef.current?.setData(res.result);
      }
    });
  }
  // 点击配置
  function configClick(id?: string) {
    getPrescription(id).then((res) => {
      if (res.status === 0) {
        setModalType(MODAL_TYPE_CONFIG);
        configPartsRef.current?.setData(res.result);
      }
    });
  }

  const columns: ProColumns<GainCardMsgInfosType>[] = [
    {
      title: 'ID',
      dataIndex: 'id',
      hideInSearch: true,
    },
    {
      title: '西药套餐名',
      dataIndex: 'name',
    },
    {
      title: '是否启用',
      dataIndex: 'status',
      valueEnum: EnableStatus,
    },
    {
      title: '创建日期',
      dataIndex: 'created',
      renderText: (text) => formatTime(new Date(text).getTime()),
      hideInSearch: true,
    },
    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (_text, record: GainCardMsgInfosType) => [
        (powers[PRESCRIPTIONS_DETAIL] || powers[PRESCRIPTIONS_UPDATE_DETAIL]) && (
          <Button key={'detail'} onClick={() => detailClick(record)} type="link">
            编辑
          </Button>
        ),
        (powers[PRESCRIPTIONS_UPDATE_PARTS] || powers[PRESCRIPTIONS_ADD_PARTS]) && (
          <Button key={'detail'} onClick={() => configClick(record.id)} type="link">
            配置
          </Button>
        ),
      ],
    },
  ];

  return (
    <TableLocal
      columns={columns}
      request={powers[PRESCRIPTIONS_PAGE] && westernMedicalManageList}
      rowKey="id"
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      pagination={{ defaultPageSize: 10 }}
      actionRef={actionRef}
      toolBarRender={() => [
        powers[PRESCRIPTIONS_ADD] && (
          <Button
            key="primary"
            type="primary"
            onClick={() => {
              setModalType(MODAL_TYPE_ADD);
            }}
          >
            <PlusOutlined />
            新增
          </Button>
        ),
      ]}
    >
      <Modal
        title={getModalTitle()}
        modalType={modalType}
        onCancel={onCancel}
        onCancelSave={onCancelSave}
        onOk={onOk}
        onSaveData={onSaveData}
        modalVisible={!!modalType}
        btnLoading={btnLoading}
        visible={visible}
      >
        {modalType === MODAL_TYPE_ADD && (
          <CreateOrDetails modalType={modalType} ref={createOrDetailsRef} />
        )}
        {modalType === MODAL_TYPE_DETAIL && (
          <CreateOrDetails modalType={modalType} ref={createOrDetailsRef} />
        )}
        {modalType === MODAL_TYPE_CONFIG && (
          <ConfigParts
            configClick={configClick}
            useTime={useTime}
            useTimeUnit={useTimeUnit}
            usage={usage}
            usageUnit={usageUnit}
            ref={configPartsRef}
          />
        )}
      </Modal>
    </TableLocal>
  );
};
export default WesternMedicalManage;

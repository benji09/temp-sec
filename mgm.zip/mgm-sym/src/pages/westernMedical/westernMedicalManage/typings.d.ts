import type { ReactNode } from 'react';

type GainCardMsgInfosType = {
  id?: string;
  name?: string;
  status?: number;
  created?: string;
};
type WesternMedicalManageListType = {
  current: number;
  pageSize: number;
  name?: string;
  status?: string;
};
type ModalPropType = {
  modalType?: number;
  title?: string | undefined;
  modalVisible?: boolean;
  btnLoading?: boolean;
  visible?: boolean;
  onCancel: () => void;
  onCancelSave: () => void;
  onOk: () => void;
  onSaveData: () => void;
  children?: ReactNode;
};

// 新增或配置中药品列表
type DataSourceType = {
  skuId?: number | string;
  brand?: string;
  name?: string;
  spec?: string;
  usage?: string;
  dosage?: number | string;
  dosageUnit?: string;
  useTime?: string;
  quantity?: number | string;
  quantityUnit?: string;
  treatmentCourse?: number | string;
  id?: string;
};

// 使用频率
type UseTimeType = {
  concept?: string;
  key?: string;
  value?: string;
};

// 数量单位
type UseTimeUnitType = {
  concept?: string;
  key?: string;
  value?: string;
};
// 用法
type UsageType = {
  concept?: string;
  key?: string;
  value?: string;
};
// 用量单位
type UsageUnitType = {
  concept?: string;
  key?: string;
  value?: string;
};
type ConfigPartsType = {
  useTime?: UseTimeType[];
  useTimeUnit?: UseTimeUnitType[];
  usage?: UsageType[];
  usageUnit?: UsageUnitType[];
  configClick?: (id?: string) => void;
};

// 搜索药品的下拉选项
type OptionItemType = {
  shopName?: string;
  adverseReactions?: string;
  attention?: string;
  brand?: string;
  dosage?: string;
  forbiddance?: string;
  interaction?: string;
  name?: string;
  sku?: string;
  usage?: string;
  usageUnit?: string;
  useTime?: string;
  useTimeUnit?: string;
  spec?: string;
  standardId?: number;
};
// 新增时向后段传入的数据类型
type AddPrescriptionType = {
  description?: string;
  diacrisisName?: string;
  name?: string;
  searchName?: string;
  status?: number;
  thirdBusiness?: number;
  id?: number | string;
};
// 查找药品接口向后段传入的数据类型
type GetRegularUsageType = {
  name?: string;
  shopId?: string;
  thirdBusiness?: number;
};
type AddPartsListType = {
  brand?: string;
  dosage?: string;
  dosageUnit?: string;
  name?: string;
  prescriptionId?: string;
  quantity?: string;
  quantityUnit?: string;
  skuId?: string;
  spec?: string;
  treatmentCourse?: string;
  usage?: string;
  useTime?: string;
  shopName?: string;
  standardId?: number;
};
export {
  GainCardMsgInfosType,
  WesternMedicalManageListType,
  ModalPropType,
  DataSourceType,
  ConfigPartsType,
  AddPrescriptionType,
  OptionItemType,
  GetRegularUsageType,
  AddPartsListType,
};

// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type {
  WesternMedicalManageListType,
  AddPrescriptionType,
  GetRegularUsageType,
  AddPartsListType,
  DataSourceType,
} from './typings';

// 医生账号管理列表
const westernMedicalManageList = async (params: WesternMedicalManageListType) => {
  const { current, pageSize, ...data } = params;

  const msg = await request('/prescriptions/get-prescription-by-page', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      ...data,
      currentPage: current || 1,
      pageSize,
    },
  });
  return {
    data: (msg?.result && msg?.result.pageItems) || [],
    total: (msg?.result && msg?.result.total) || 0,
  };
};

// 获取药品的详情
const getPrescription = async (id?: number | string) => {
  return await request('/prescriptions/get-prescription', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'Get',
    params: { id },
  });
};
// 获取字典表 ( 数量单位、使用频率、用法、用量单位 )
const getDictionary = async () => {
  return await request('/prescriptions/get-dictionary', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
  });
};
// 新增药方
const addPrescription = async (data: AddPrescriptionType) => {
  return await request('/prescriptions/add-prescription', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { ...data, shopId: '001' },
  });
};
// 更新药方
const updatePrescription = async (data: AddPrescriptionType) => {
  return await request('/prescriptions/update-prescription', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { ...data, shopId: '001' },
  });
};
// 更新药品
const updateParts = async (data: DataSourceType[]) => {
  return await request('/prescriptions/update-parts', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};

const addPartsList = async (data: AddPartsListType) => {
  return await request('/prescriptions/add-parts', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
const getRegularUsage = async (data: GetRegularUsageType) => {
  return await request('/prescriptions/get-regular-usage', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
const deleteParts = async (id: string) => {
  return await request('/prescriptions/delete-parts', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { id },
  });
};
export {
  westernMedicalManageList,
  getDictionary,
  addPrescription,
  updatePrescription,
  updateParts,
  getPrescription,
  addPartsList,
  getRegularUsage,
  deleteParts,
};

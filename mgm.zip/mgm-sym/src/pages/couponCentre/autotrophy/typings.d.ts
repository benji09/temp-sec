import type { ReactNode } from 'react';
type AutotrophyType = {
  cardId?: number;
  cardName?: string;
  cardSecret?: string;
  disabledAt?: number;
  generateAt?: number;
  id?: number;
  opUserId?: number;
  opUserName?: string;
  payOrderId?: string;
  planCode?: string;
};
type ModalPropType = {
  modalVisible?: boolean;
  visible?: boolean;
  title?: string;
  loading?: boolean;
  modalType?: number;
  onSaveData?: () => void;
  onCancel?: () => void;
  onOk?: () => void;
  onCancelSave?: () => void;
  children?: ReactNode;
};
type DisableOperateType = {
  orderId?: string;
};
export { AutotrophyType, ModalPropType, DisableOperateType };

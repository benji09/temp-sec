import { forwardRef, useImperativeHandle } from 'react';
import { Col, Form, Input } from 'antd';

import './AutotrophyAdd.less';

const AutotrophyAdd = forwardRef((props, ref) => {
  const [form] = Form.useForm();

  useImperativeHandle(ref, () => ({
    takeData,
    reset,
  }));

  return (
    <Form className="AutotrophyAdd" form={form}>
      <Col span={24} className="tooltipText">
        请输入待禁用的订单号
      </Col>
      <Form.Item name="orderId" rules={[{ required: true, message: '请输入待禁用的订单号' }]}>
        <Input width={'100%'} placeholder="请输入待禁用的订单号" />
      </Form.Item>
    </Form>
  );
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          resolve(values);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  function reset() {
    form.resetFields();
  }
});

export default AutotrophyAdd;

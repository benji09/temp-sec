import React from 'react';
import { Button, Modal, Popconfirm } from 'antd';

import type { ModalPropType } from '../typings';

const BannerModal: React.FC<ModalPropType> = (props) => {
  const {
    modalVisible,
    visible,
    title,
    loading,
    onCancel,
    onOk,
    onCancelSave,
    onSaveData,
    children,
  } = props;
  return (
    <Modal
      className="autotrophyModal"
      width={'40%'}
      title={title}
      visible={modalVisible}
      centered
      onCancel={onCancel}
      onOk={onOk}
      footer={[
        <Button key="back" onClick={onCancel}>
          取消
        </Button>,
        <Popconfirm
          key="submit"
          icon={''}
          title={'是否确认禁用'}
          visible={visible}
          onConfirm={onSaveData}
          okButtonProps={{ loading: loading }}
          onCancel={onCancelSave}
        >
          <Button type="primary" onClick={onOk}>
            确定
          </Button>
        </Popconfirm>,
      ]}
    >
      {children}
    </Modal>
  );
};
export default BannerModal;

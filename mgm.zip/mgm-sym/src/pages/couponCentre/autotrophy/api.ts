// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type { DisableOperateType } from './typings';

const autotrophyList = async (params: any) => {
  const { current, pageSize, disabled, generate, ...data } = params;

  data.disabledStart =
    disabled && disabled.length === 2 ? dayjs(`${disabled[0]} 00:00:00`).valueOf() : undefined;
  data.disabledEnd =
    disabled && disabled.length === 2 ? dayjs(`${disabled[1]} 23:59:59`).valueOf() : undefined;

  data.generateStart =
    generate && generate.length === 2 ? dayjs(`${generate[0]} 00:00:00`).valueOf() : undefined;
  data.generateEnd =
    generate && generate.length === 2 ? dayjs(`${generate[1]} 23:59:59`).valueOf() : undefined;

  const msg = await request('/card-disable-log/self-list', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      ...data,
      page: current,
      size: pageSize,
    },
  });
  return {
    data: msg.result.list || [],
    total: msg.result.total || 0,
  };
};
const disableOperate = async (data: DisableOperateType) => {
  return await request<APIS.BaseResponse<any>>('/card-disable-log/self-disable-operate', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export { autotrophyList, disableOperate };

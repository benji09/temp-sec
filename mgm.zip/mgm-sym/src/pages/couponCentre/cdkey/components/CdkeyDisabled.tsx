import { forwardRef, useImperativeHandle } from 'react';
import { Col, Form, Input } from 'antd';

import './CdkeyDisabled.less';

const CdkeyDisabled = forwardRef((props, ref) => {
  const [form] = Form.useForm();

  useImperativeHandle(ref, () => ({
    takeData,
    reset,
  }));

  return (
    <Form className="CdkeyDisabled" form={form}>
      <Col span={24} className="tooltipText">
        请输入待禁用的兑换码
      </Col>
      <Form.Item name="cardSecret" rules={[{ required: true, message: '请输入待禁用的兑换码' }]}>
        <Input width={'100%'} placeholder="请输入待禁用的兑换码" />
      </Form.Item>
    </Form>
  );
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          resolve(values);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  function reset() {
    form.resetFields();
  }
});

export default CdkeyDisabled;

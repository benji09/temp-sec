import type { ReactNode } from 'react';
interface CdkeyType {
  cardId?: number;
  cardName?: string;
  cardSecret?: string;
  disabledAt?: number;
  generateAt?: number;
  id?: number;
  opUserId?: number;
  opUserName?: string;
  payOrderId?: string;
  planCode?: string;
}
interface ModalPropType {
  modalVisible?: boolean;
  visible?: boolean;
  title?: string;
  loading?: boolean;
  modalType?: number;
  onSaveData?: () => void;
  onCancel?: () => void;
  onOk?: () => void;
  onCancelSave?: () => void;
  children?: ReactNode;
}
type DisableOperateType = {
  cardSecret?: string;
};
export { CdkeyType, ModalPropType, DisableOperateType };

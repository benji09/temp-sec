import React, { useRef, useState } from 'react';
import moment from 'moment';
import { Button, DatePicker } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import TableLocal from '@/components/TableLocal/TableLocal';
import { showErrorMessage } from '@/mamagement/Notification';

import { cdkeyList, disableOperate } from './api';
import Modal from './components/Modal';
import CdkeyDisabled from './components/CdkeyDisabled';
import type { CdkeyType, DisableOperateType } from './typings';

function disabledDate(current: any) {
  return current && (current > moment() || current < moment().subtract(3, 'month'));
}

const { RangePicker } = DatePicker;
const MODAL_TYPE_ADD = 1;

const Cdkey: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const CdkeyDisabledRef = useRef<any>();

  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [loading, setLoading] = useState<boolean>(false);
  const [dateils, setDateils] = useState<DisableOperateType>({});

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '禁用兑换码';
    }
    return '';
  }

  const onSaveData = () => {
    setLoading(true);
    disableOperate(dateils).then((res) => {
      setLoading(false);
      setVisible(false);
      if (res.status === 0) {
        if (res.result.opStatus === false) {
          showErrorMessage('兑换码不存在');
        } else {
          setModalVisible(false);
          CdkeyDisabledRef.current.reset();
          actionRef.current?.reload();
          setModalType(undefined);
        }
      }
    });
  };
  const onCancel = () => {
    setLoading(false);
    setVisible(false);
    setModalType(undefined);
    setModalVisible(false);
    CdkeyDisabledRef.current.reset();
  };
  const onOk = () => {
    CdkeyDisabledRef.current?.takeData().then((res: any) => {
      setDateils(res);
      setVisible(true);
    });
  };
  const onCancelSave = () => {
    setVisible(false);
    setLoading(false);
  };

  const columns: ProColumns<CdkeyType>[] = [
    {
      title: 'plancode',
      dataIndex: 'plancode',
      hideInTable: true,
    },
    {
      title: '名称',
      dataIndex: 'cardName',
      hideInTable: true,
    },
    {
      title: '禁用时间',
      dataIndex: 'disabled',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '禁用时间',
      dataIndex: 'disabledAt',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '兑换码',
      dataIndex: 'cardSecret',
    },
    {
      title: '卡号',
      dataIndex: 'cardId',
      hideInSearch: true,
    },
    {
      title: '操作员',
      dataIndex: 'opUserName',
    },
    {
      title: '对应权益包名称',
      dataIndex: 'cardName',
      hideInSearch: true,
    },
    {
      title: '生成时间',
      dataIndex: 'generate',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '兑换码生成时间',
      dataIndex: 'generateAt',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: () => [],
    },
  ];

  return (
    <TableLocal
      tableClassName=""
      columns={columns}
      actionRef={actionRef}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      toolBarRender={() => [
        <Button
          key="primary"
          type="primary"
          onClick={() => {
            setModalVisible(true);
            setModalType(MODAL_TYPE_ADD);
          }}
        >
          <PlusOutlined />
          新增
        </Button>,
      ]}
      request={cdkeyList}
      rowKey="id"
    >
      <Modal
        modalVisible={modalVisible}
        visible={visible}
        modalType={modalType}
        title={getModalTitle()}
        loading={loading}
        onSaveData={onSaveData}
        onCancel={onCancel}
        onOk={onOk}
        onCancelSave={onCancelSave}
      >
        <CdkeyDisabled ref={CdkeyDisabledRef} />
      </Modal>
    </TableLocal>
  );
};
export default Cdkey;

/*
 * @Author: zyx
 * @Date: 2021-08-17 13:37:44
 * @LastEditTime: 2021-09-08 13:44:16
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\pages\couponCentre\cardSelling\api.ts
 */
import { postRequest, getRequest } from '@/services/api';

import type { DetailsType, GoodsImgConfigType } from './typings';
// 详情 入参 列表id
const queryCardSellingDetails = async (id?: string) => {
  return (await getRequest('/goods/detail', { id })) as unknown as APIS.BaseResponse<any>;
};
// 保存短信内容  入参:{id:列表ID, isSend:是否发送, msgCode:模板代码}
const goodsMsgConfig = async (data: DetailsType) => {
  return (await postRequest('/goods/msg/config', data)) as unknown as APIS.BaseResponse<any>;
};
// 获取短信模板下拉选项
const noticeList = async () => {
  return (await getRequest('/notice/list')) as unknown as APIS.BaseResponse<any>;
};
const autoRenewPlanCode = async () => {
  return (await getRequest('/goods/auto/renew/plan/code')) as unknown as APIS.BaseResponse<any>;
};
// 详情 入参 列表id
const goodsImgConfig = async (data: GoodsImgConfigType) => {
  return (await postRequest('/goods/img/config', data)) as unknown as APIS.BaseResponse<any>;
};
export { queryCardSellingDetails, goodsMsgConfig, noticeList, autoRenewPlanCode, goodsImgConfig };

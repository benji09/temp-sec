import React, { useState, useRef } from 'react';

import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { queryCardSellingList } from '@/services/api';
import { checkPermission, CARDSELL_ADD, CARDSELL_CONFIG, CARDSELL_NOTE } from '@/utils/power';

import CreateOrMdifyModal from './components/CreateOrMdifyModal';
import NoteMessageModal from './components/NoteMessageModal';
import GoodsDetails from './components/GoodsDetails';

import './index.less';

const permissionGroups = [CARDSELL_ADD, CARDSELL_CONFIG, CARDSELL_NOTE];
export default (): React.ReactNode => {
  const [title, seTitle] = useState('');
  const [record, setRecord] = useState<APIS.CardSelling | undefined>(undefined);

  const [createOrModifyVisible, setCreateOrModifyVisible] = useState(false);
  const [noteMessageVisible, setNoteMessageVisible] = useState(false);
  const [goodsDetailsVisible, setGoodsDetailsVisible] = useState(false);

  const actionRef = useRef<ActionType | undefined>();
  const createOrModifyRef = useRef<any>();
  const NoteMessageRef = useRef<any>();
  const goodsDetailsRef = useRef<any>();

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  const showCreateOrModifyModal = (_record: APIS.CardSelling | undefined) => {
    setCreateOrModifyVisible(true);
    setRecord(_record);
    seTitle(_record ? '配置' : '新增');
  };
  const NoteMessage = (_record?: APIS.CardSelling) => {
    setNoteMessageVisible(true);
    setRecord(_record);
    seTitle('短信');
  };
  const goodsDetails = (_record?: APIS.CardSelling) => {
    setGoodsDetailsVisible(true);
    setRecord(_record);
    seTitle('商品详情');
  };
  const columns: ProColumns<APIS.CardSelling>[] = [
    {
      title: 'SKU',
      dataIndex: 'skuNo',
    },
    {
      title: '权益卡名称',
      dataIndex: 'goodsName',
      renderText: (text, records) => {
        return (
          <span>
            {records.planCode || ''}
            <br />
            {text || ''}
          </span>
        );
      },
    },
    {
      title: 'PlanCode',
      key: 'planCode',
      hideInTable: true,
    },
    {
      title: '销售价格',
      dataIndex: 'sellPrice',
      renderText: (text) => `￥${Number(text) / 100}`,
      hideInSearch: true,
    },
    {
      title: '销售状态',
      dataIndex: 'sellStatus',
      renderText: (text) => (text ? '开启' : '关闭'),
      hideInSearch: true,
    },
    {
      title: '创建时间',
      dataIndex: 'createdTime',
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      valueType: 'option',
      render: (text, _record) => {
        return (
          <>
            {powers[`${CARDSELL_CONFIG}`] && (
              <Button type="link" onClick={() => showCreateOrModifyModal(_record)}>
                配置
              </Button>
            )}
            {powers[`${CARDSELL_NOTE}`] && (
              <Button type="link" onClick={() => NoteMessage(_record)}>
                短信
              </Button>
            )}
            <Button type="link" onClick={() => goodsDetails(_record)}>
              商品详情
            </Button>
          </>
        );
      },
    },
  ];
  return (
    <PageContainer>
      <ProTable<APIS.CardSelling>
        actionRef={actionRef}
        columns={columns}
        request={queryCardSellingList}
        rowKey="id"
        pagination={{
          defaultPageSize: 10,
        }}
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        toolBarRender={() => [
          powers[`${CARDSELL_ADD}`] && (
            <Button key="primary" type="primary" onClick={() => showCreateOrModifyModal(undefined)}>
              <PlusOutlined />
              新增
            </Button>
          ),
        ]}
      />
      <CreateOrMdifyModal
        ref={createOrModifyRef}
        visible={createOrModifyVisible}
        setVisible={setCreateOrModifyVisible}
        title={title}
        record={record}
        actionRef={actionRef}
      />

      <NoteMessageModal
        ref={NoteMessageRef}
        visible={noteMessageVisible}
        record={record}
        setVisible={setNoteMessageVisible}
        title={title}
        actionRef={actionRef}
      />
      <GoodsDetails
        ref={goodsDetailsRef}
        visible={goodsDetailsVisible}
        record={record}
        setVisible={setGoodsDetailsVisible}
        title={title}
        actionRef={actionRef}
      />
    </PageContainer>
  );
};

/*
 * @Author: your name
 * @Date: 2021-08-16 15:01:20
 * @LastEditTime: 2021-12-22 18:01:22
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\pages\couponCentre\cardSelling\typings.d.ts
 */
// 短信props
type NoteProps = {
  visible?: boolean;
  setVisible: (visible: boolean) => void;
  title?: string;
  record?: CardSelling;
  actionRef?: any;
};
// 带入props中的列表信息
type CardSelling = {
  createdTime?: string;
  goodsName?: string;
  id?: string;
  sellPrice?: string;
  sellStatus?: boolean;
  skuNo?: string;
};
// 短信模板代码的下拉框
type TemplateNoteListType = {
  aliasId?: number;
  placeholder?: number;
  templateTitle?: string;
  templateDesc?: string;
};
// 短信详情
type DetailsType = {
  id?: string | number;
  isSend?: boolean | string;
  msgCode?: number | string;
  noteMsg?: string;
};
type AutoRenewPlanIdType = {
  desc: string;
  planId: string;
};

type CreateOrMdifyProps = {
  visible: boolean;
  title: string;
  setVisible: (visible: boolean) => void;
  record?: APIS.CardSelling;
  actionRef?: any;
};

type CardItem = {
  masterId?: number;
  name?: string;
};

type RightItem = {
  isInfinitely?: boolean;
  number?: number;
  unit?: string;
  code?: string;
  name?: string;
  usableOffset?: number;
  description?: string;
  rightsMasterId?: string;
  order?: number;
  infinity?: boolean;
  displayExt?: string;
};

type CardDetail = {
  expireMessage?: string;
  selectableRelation?: boolean;
  rightsList?: RightItem[];
  maxRelation?: number;
  mustRelate?: boolean;
  name?: string;
  description?: string;
  showType?: string;
  cardMasterId?: string;
};
type GoodsImgConfigType = {
  id?: number | string;
  goodsImgList?: {
    img?: string;
    url?: string;
  }[];
};
export {
  NoteProps,
  TemplateNoteListType,
  DetailsType,
  AutoRenewPlanIdType,
  CreateOrMdifyProps,
  CardItem,
  RightItem,
  CardDetail,
  GoodsImgConfigType,
};

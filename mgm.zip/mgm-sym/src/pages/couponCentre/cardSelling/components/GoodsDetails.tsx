// node_modules
import { forwardRef, useImperativeHandle, useState, useEffect } from 'react';
import _ from 'lodash';
import { Modal, Row, Col, Button, Popconfirm, Spin, Upload, Input } from 'antd';
import { PlusOutlined } from '@ant-design/icons';

// 公共组件
import { checkImageTypeAndSize } from '@/utils/utils';

// 当前业务耦合模块
import { queryCardSellingDetails, goodsImgConfig } from '../api';
import type { NoteProps } from '../typings';

import { getCosDownladUrl, uploadFile } from '@/services/api';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
// css
import './GoodsDetails.less';

const NoteMessageModal = forwardRef((props: NoteProps, ref) => {
  const { visible, setVisible, title, record, actionRef } = props;
  // 调用详情接口中
  const [loading, setLoading] = useState(false);
  // 二次确认弹框
  const [confirmVisible, setConfirmVisible] = useState<boolean>(false);
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);

  const [goodsImgList, setGoodsImgList] = useState<any[]>([]);

  // 详情信息
  const [details, setDetails] = useState<APIS.CardSellingDetail | undefined>({});

  // 重置数据
  const reset = () => {
    setGoodsImgList([]);
    setDetails({});
  };

  // 获取详情接口
  useEffect(() => {
    if (!visible) return;
    reset();
    setLoading(true);
    queryCardSellingDetails(record?.id)
      .then((res) => {
        const { status, result } = res;
        if (status === 0) {
          setDetails(result);
          const imgUrlList: any[] = [];
          result.imgAndUrls.map((item: any, index: number) => {
            imgUrlList.push({ ...item, id: index });
          });
          setGoodsImgList(imgUrlList);
        }
      })
      .finally(() => setLoading(false));
  }, [record, visible]);

  // modal弹框确认
  const handleOk = () => {
    let CanIntact = false;
    const ImgEmpty: number[] = [];
    goodsImgList.map((item, index) => {
      if (!item.goodsImg) {
        CanIntact = true;
        ImgEmpty.push(index + 1);
      }
    });

    // 判断数组是否为空和数组中图片是否都存在
    if (CanIntact) {
      showErrorMessage(`请确认列表中第 ${ImgEmpty.join('、')} 行图片是否存在`);
    } else {
      setConfirmVisible(true);
    }
  };
  // modal弹框取消
  const handleCancel = () => {
    setConfirmLoading(false);
    setConfirmVisible(false);
    reset();

    setTimeout(() => {
      setVisible(false);
    });
  };

  // 二次确认确定
  const handleConfirmOk = () => {
    const list: any[] = [];
    goodsImgList.map((item) => {
      const { goodsImg, goodsUrl } = item;

      list.push({ img: goodsImg || '', url: goodsUrl || '' });
    });

    goodsImgConfig({ id: record?.id, goodsImgList: list })
      .then((res) => {
        if (res.status === 0) {
          reset();
          setTimeout(() => {
            setVisible(false);
            actionRef?.current.reload();
          });
        }
      })
      .finally(() => {
        setConfirmVisible(false);
        setConfirmLoading(false);
      });
  };
  // 二次确认取消
  const handleConfirmCancel = () => {
    setConfirmLoading(false);
    setConfirmVisible(false);
  };

  // 上传图片要求
  const uploadProps = {
    beforeUpload: checkImageTypeAndSize,
  };
  // 上传
  function customRequestListImg(option: any, index: number) {
    uploadFile(option, (key) => {
      const list = _.cloneDeep(goodsImgList);
      list[index].goodsImg = getCosDownladUrl(key);
      setGoodsImgList(list);
    });
  }
  // 更改链接
  function urlOnChange(index: number, e: any) {
    const list = _.cloneDeep(goodsImgList);
    list[index].goodsUrl = e.target.value || '';
    setGoodsImgList(list);
  }

  // 删除确定
  function deleteConfirm(item: any, index: number) {
    const list = _.cloneDeep(goodsImgList);
    list.splice(index, 1);
    setGoodsImgList(list);
    showSuccessMessage('删除成功');
  }
  const goodsDetailsConfigList = (item: any, index: number) => {
    return (
      <Row className={'goodsDetailsConfigList'} key={item.id}>
        <Col className={'goodsDetailsConfigLeft'} span={7}>
          <Col>图片{index + 1}：</Col>
          <Col>
            <Upload
              listType="picture-card"
              className="avatar-uploader"
              showUploadList={false}
              customRequest={(options) => customRequestListImg(options, index)}
              {...uploadProps}
              accept={'image/*'}
            >
              {item?.goodsImg ? <img src={item?.goodsImg} alt="图片" /> : <PlusOutlined />}
            </Upload>
          </Col>
        </Col>
        <Col className={'goodsDetailsConfigRight'} span={13}>
          <Row>
            <Col span={3}>链接:</Col>
            <Col span={21}>
              <Input.TextArea
                placeholder="请输入链接"
                maxLength={250}
                style={{
                  width: '100%',
                  height: '102px',
                }}
                value={item?.goodsUrl}
                onChange={(e) => {
                  urlOnChange(index, e);
                }}
              />
            </Col>
          </Row>
        </Col>
        <Col className={'goodsDetailsConfigButton'} span={4}>
          <Popconfirm
            title="确定是否删除"
            onConfirm={() => {
              deleteConfirm(item, index);
            }}
            icon={''}
            okText="是"
            cancelText="否"
          >
            <Button type="primary">删除</Button>
          </Popconfirm>
        </Col>
      </Row>
    );
  };
  const addImgAndUrl = () => {
    const list = _.cloneDeep(goodsImgList);
    list.push({ id: (list.length && list[list.length - 1].id + 1) || 0 });
    setGoodsImgList(list);
  };
  useImperativeHandle(ref, () => ({}));

  return (
    <Modal
      width="50%"
      style={{ minWidth: '720px' }}
      className="GoodsDetails"
      title={title}
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <Button key="cancel" type="ghost" onClick={handleCancel}>
          取消
        </Button>,
        <Popconfirm
          key="ok"
          title="是否确认添加?"
          visible={confirmVisible}
          onConfirm={handleConfirmOk}
          okButtonProps={{ loading: confirmLoading }}
          onCancel={handleConfirmCancel}
        >
          <Button type="primary" onClick={handleOk}>
            确定
          </Button>
        </Popconfirm>,
      ]}
    >
      {!loading ? (
        <div>
          <Row style={{ marginBottom: '12px' }}>
            <Col span={12}>权益卡名称：{details?.goodsName}</Col>
          </Row>
          <h3>商详配置</h3>
          {goodsImgList.map((item, index) => {
            return goodsDetailsConfigList(item, index);
          })}
          <Col span={24}>
            <Button onClick={addImgAndUrl} className={'addGoodsDetailsConfigList'}>
              <PlusOutlined /> 新增图片
            </Button>
          </Col>
        </div>
      ) : (
        <Spin size="large" className={'loading'} />
      )}
    </Modal>
  );
});
export default NoteMessageModal;

/*
 * @Author: zyx
 * @Date: 2021-08-16 14:50:24
 * @LastEditors: zyx
 * @LastEditTime: 2021-12-22 18:07:37
 * @Description: In User Settings Edit
 */
/* eslint-disable react-hooks/exhaustive-deps */
// node_modules
import { forwardRef, useImperativeHandle, useState, useEffect } from 'react';
import { Modal, Row, Col, Button, Popconfirm, Form, Select, Spin } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';
// 公共组件
import { defaultFormLayout } from '@/utils/utils';
// 当前业务耦合模块
import { queryCardSellingDetails, goodsMsgConfig, noticeList } from '../api';
import type { NoteProps, TemplateNoteListType, DetailsType } from '../typings';
// 样式引入
import './NoteMessageModal.less';

const { Option } = Select;

const NoteMessageModal = forwardRef((props: NoteProps, ref) => {
  const { visible, setVisible, title, record, actionRef } = props;
  const [loading, setLoading] = useState(false);
  // 二次确认弹框
  const [confirmVisible, setConfirmVisible] = useState<boolean>(false);
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);
  // 点击问号
  const [showModalHintMsg, setShowModalHintMsg] = useState<boolean>(false);

  const [form] = Form.useForm();
  // 详情信息
  const [details, setDetails] = useState<DetailsType>({});
  // 判断是否开启
  const [isNoteSend, setIsNoteSend] = useState<boolean>(false);
  // 短信模板列表
  const [templateNoteList, setTemplateNoteList] = useState<TemplateNoteListType[]>([]);

  // 重置数据
  const reset = () => {
    form.resetFields();
    setIsNoteSend(false);
    setShowModalHintMsg(false);
    setDetails({});
  };

  // 获取短信模板代码下拉选项
  useEffect(() => {
    noticeList().then((res) => {
      const { result, status } = res;
      if (status === 0) {
        const { smsTemplate } = result;
        setTemplateNoteList(smsTemplate);
      }
    });
  }, []);

  // 获取详情接口
  useEffect(() => {
    if (!visible) return;
    reset();
    setLoading(true);
    queryCardSellingDetails(record?.id)
      .then((res) => {
        const { status, result } = res;
        if (status === 0) {
          const { msgCode, isSend, id } = result;
          let noteMsg: string = '';
          templateNoteList.map((item: TemplateNoteListType): void | string => {
            if (item.aliasId === Number(msgCode)) {
              noteMsg = item.templateDesc || '';
            }
          });
          form.setFieldsValue({ msgCode: msgCode !== '0' ? msgCode : '' });
          setDetails({
            noteMsg: noteMsg || '',
            msgCode: msgCode !== '0' ? msgCode : '',
            isSend,
            id,
          });
          setIsNoteSend(isSend);
        }
      })
      .finally(() => setLoading(false));
  }, [record, visible]);

  // 监听发送是否开启关闭清空下面数据
  useEffect(() => {
    if (!isNoteSend) {
      setDetails({ ...details, msgCode: '', noteMsg: '' });
      form.setFieldsValue({ msgCode: '' });
    }
  }, [isNoteSend]);
  // modal弹框确认
  const handleOk = () => {
    form.validateFields().then((res) => {
      const { isSend, msgCode } = res;
      setConfirmVisible(true);
      setDetails({ ...details, msgCode: msgCode || 0, isSend });
    });
  };
  // modal弹框取消
  const handleCancel = () => {
    setConfirmVisible(false);
    reset();
    setVisible(false);
  };

  // 二次确认确定
  const handleConfirmOk = () => {
    const { id, msgCode } = details;
    setConfirmLoading(true);
    goodsMsgConfig({
      id: Number(id),
      isSend: Boolean(isNoteSend),
      msgCode: Number(msgCode),
    }).then((res) => {
      setConfirmLoading(false);
      setConfirmVisible(false);
      if (res.status === 0) {
        reset();
        actionRef?.current.reload();
        setVisible(false);
      }
    });
  };
  // 二次确认取消
  const handleConfirmCancel = () => {
    setConfirmLoading(false);
    setConfirmVisible(false);
  };

  useImperativeHandle(ref, () => ({}));

  return (
    <Modal
      width="50%"
      style={{ minWidth: '720px' }}
      className="NoteMessage"
      title={title}
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <Button key="cancel" type="ghost" onClick={handleCancel}>
          取消
        </Button>,
        <Popconfirm
          key="ok"
          title="是否确认添加?"
          visible={confirmVisible}
          onConfirm={handleConfirmOk}
          okButtonProps={{ loading: confirmLoading }}
          onCancel={handleConfirmCancel}
        >
          <Button type="primary" onClick={handleOk}>
            确定
          </Button>
        </Popconfirm>,
      ]}
    >
      {!loading ? (
        <Row>
          <Col span={17}>
            <Form form={form} {...defaultFormLayout}>
              <Form.Item
                name="isSend"
                label="是否发送"
                initialValue={
                  details
                    ? details.isSend !== undefined
                      ? String(details.isSend)
                      : undefined
                    : undefined
                }
              >
                <Select
                  placeholder="请选择是否开启"
                  onChange={(e: any) => {
                    setIsNoteSend(e === 'true');
                  }}
                >
                  <Option key={1} value={`${true}`}>
                    开启
                  </Option>
                  <Option key={0} value={`${false}`}>
                    关闭
                  </Option>
                </Select>
              </Form.Item>
              <Form.Item
                name="msgCode"
                label="短信模板代码"
                rules={[{ required: isNoteSend, message: '短信模板代码' }]}
                initialValue={details ? details.msgCode : undefined}
              >
                <Select
                  placeholder="请选择短信模板代码"
                  disabled={!isNoteSend}
                  defaultActiveFirstOption={false}
                  onChange={(e) => {
                    let IsNoteSendOption: TemplateNoteListType = {};
                    templateNoteList.map((item: TemplateNoteListType) => {
                      if (item.aliasId === Number(e)) {
                        IsNoteSendOption = item;
                      }
                      return;
                    });
                    setDetails({ ...details, noteMsg: IsNoteSendOption?.templateDesc || '' });
                  }}
                  notFoundContent={null}
                >
                  {templateNoteList.length &&
                    templateNoteList.map((item: TemplateNoteListType) => {
                      return (
                        <Option value={`${item.aliasId}`} key={`${item.aliasId}`}>
                          {item.templateTitle}
                        </Option>
                      );
                    })}
                </Select>
              </Form.Item>
              <Form.Item label="短信内容">
                <span className="noteTextMsg">{details?.noteMsg}</span>
              </Form.Item>
            </Form>
          </Col>
          <Col span={7}>
            <div className="modalHint">
              <span
                className="modalHintIcon"
                onClick={() => {
                  setShowModalHintMsg(!showModalHintMsg);
                }}
              >
                <QuestionCircleOutlined />
              </span>
              {showModalHintMsg && (
                <p className={'modalHintMsgShow'}>
                  开启后，用户购买成功时将对购买手机号发送提示短信。
                  <br />
                  <br />
                  关闭时将不再发送短信。
                </p>
              )}
            </div>
          </Col>
        </Row>
      ) : (
        <Spin size="large" className={'loading'} />
      )}
    </Modal>
  );
});
export default NoteMessageModal;

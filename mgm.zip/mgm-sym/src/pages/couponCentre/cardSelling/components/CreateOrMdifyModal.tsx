/* eslint-disable react-hooks/exhaustive-deps */

import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import dayjs from 'dayjs';
import moment from 'moment';
import {
  Modal,
  Select,
  Form,
  Spin,
  DatePicker,
  InputNumber,
  Input,
  Checkbox,
  Row,
  Col,
} from 'antd';
import ProTable from '@ant-design/pro-table';
import type { ProColumns } from '@ant-design/pro-table';

import {
  queryCardSellingDetails,
  queryCardByName,
  queryCardDetailByMasterId,
  addOrUpdateSellCard,
} from '@/services/api';
import { defaultFormLayout, TIME_FORMAT_DAY, useDebounce } from '@/utils/utils';

import { defaultParser } from '@/pages/businessManagement/util';
import { showSuccessMessage } from '@/mamagement/Notification';

import type {
  CreateOrMdifyProps,
  CardItem,
  RightItem,
  CardDetail,
  AutoRenewPlanIdType,
} from '../typings';
import { autoRenewPlanCode } from '../api';

import './index.less';

const CreateOrMdifyModal = forwardRef((props: CreateOrMdifyProps, ref) => {
  const { visible, title, record, setVisible, actionRef } = props;
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [confirmLoading, setConfirmLoading] = useState(false);
  const [searchParam, setSearchParam] = useState('');
  const [cardList, setCardList] = useState<CardItem[]>([]);
  const [cardItem, setCardItem] = useState<CardItem | undefined>();
  const [cardDetail, setCardDetail] = useState<CardDetail | undefined>();
  const [detail, setDetail] = useState<APIS.CardSellingDetail | undefined>();
  const [validPeriodMethodValue, setValidPeriodMethodValue] = useState<number | undefined>(
    undefined,
  );
  const [preferentialMethodValue, setPreferentialMethodValue] = useState<number | undefined>(
    undefined,
  );

  const [planIdValue, setPlanIdValue] = useState<number | undefined>(undefined);

  const [autoRenewFlag, setAutoRenewFlag] = useState<boolean | undefined>(false);
  const [autoRenewPlanIdList, setAutoRenewPlanIdList] = useState<AutoRenewPlanIdType[]>([]);

  const validPeriodMethodList = [
    { text: '固定日期', id: 1 },
    { text: '购买日期', id: 2 },
  ];
  const preferentialMethodList = [
    { text: '不使用优惠价计算', id: 1 },
    { text: '使用优惠价结算', id: 2 },
    { text: '自动续费时使用优惠价结算', id: 3 },
  ];

  const columns: ProColumns<RightItem>[] = [
    {
      title: '序号',
      align: 'center',
      render: (text, _record, index) => <>{index + 1}</>,
    },
    {
      title: '权益名称',
      align: 'center',
      dataIndex: 'name',
      render: (text, _record) => (
        <>
          {text} {_record.code}
        </>
      ),
    },
    {
      title: '权益次数',
      align: 'center',
      dataIndex: 'number',
      render: (text: any, _record) => (
        <>
          {record
            ? _record.isInfinitely
              ? '不限次'
              : `${text} ${_record.unit}`
            : _record.infinity
            ? '不限次'
            : `${text} ${JSON.parse(_record.displayExt || '').unit}`}
        </>
      ),
    },
    {
      title: '生效延迟时间',
      align: 'center',
      dataIndex: 'usableOffset',
    },
  ];

  const reset = () => {
    setDetail(undefined);
    form.resetFields();
    setSearchParam('');
    setCardList([]);
    setCardDetail(undefined);
    setCardItem(undefined);
    setValidPeriodMethodValue(undefined);
    setPreferentialMethodValue(undefined);
    setPlanIdValue(undefined);
    setAutoRenewFlag(false);
  };

  useEffect(() => {
    autoRenewPlanCode()
      .then((res: { result: any; status: any }) => {
        const { result, status } = res;
        if (status === 0) {
          setAutoRenewPlanIdList(result.wxPlanIdInfos);
        }
      })
      .finally(() => {});
  }, []);

  useEffect(() => {
    if (searchParam.trim().length < 1) {
      setCardList([]);
      return;
    }
    queryCardByName(searchParam).then((res) => {
      if (res.status === 0) {
        setCardList(res.result || []);
      } else setCardList([]);
    });
  }, [useDebounce(searchParam, 500)]);

  useImperativeHandle(ref, () => ({}));

  useEffect(() => {
    if (visible && record) {
      setLoading(true);
      queryCardSellingDetails(record.id)
        .then((res) => {
          reset();
          const success = res.status === 0;
          if (success) {
            const { result } = res;
            const { validPeriodMethod, preferentialMethod, autoRenew, planId, ...data } = result;
            setPreferentialMethodValue(preferentialMethod);

            setPlanIdValue(planId);

            setAutoRenewFlag(autoRenew);
            setDetail({
              validPeriodMethod: validPeriodMethod || 1,
              preferentialMethod: preferentialMethod || undefined,
              autoRenew,
              planId,
              ...data,
            });
            setCardDetail({ rightsList: result.cardDetail });
            form.setFieldsValue({
              ...data,
              validPeriodMethod: validPeriodMethod || 1,
              goodsName: `${data?.planCode} | ${data?.goodsName}`,
            });
            setValidPeriodMethodValue(validPeriodMethod || 1);
          }
        })
        .catch(() => reset())
        .finally(() => setLoading(false));
    } else {
      reset();
    }
  }, [visible]);

  const querCardDetail = (masterId: number) => {
    queryCardDetailByMasterId(String(masterId))
      .then((res) => setCardDetail(res.status === 0 ? res.result : undefined))
      .catch(() => setCardDetail(undefined));
    for (let i = 0; i < cardList.length; i += 1) {
      const item = cardList[i];
      if (item.masterId === masterId) {
        setCardItem(item);
        break;
      }
    }
  };

  const onSubmit = () => {
    form.validateFields().then((res) => {
      Modal.confirm({
        title: '提示信息',
        content: `是否确认${title}？`,
        okText: '确定',
        onOk() {
          const requestData = {
            allowTransfer: !res.disallowTransfer,
            mwyAgreement: res.disMwyAgreement,
            autoRenew: res.disAutoRenew,

            horseRaceLamp: res.disHorseRaceLamp,

            discountPrice: Number(res.discountPriceObj) * 100,
            effectiveDays: Number(res.effectiveDays),
            goodsDesc: res.goodsDesc || '',
            goodsName: detail?.goodsName || cardItem?.name?.split(' | ')[1],
            isOpen: !!res.isOpenObj,
            lastActivationDate:
              validPeriodMethodValue === 1
                ? dayjs(res.lastActivationDateObj).format(TIME_FORMAT_DAY)
                : '',
            preferentialMethod: preferentialMethodValue,

            planId: planIdValue,

            masterId: record ? detail?.masterId : cardItem?.masterId,
            planCode: detail?.planCode || cardItem?.name?.split(' | ')[0],
            price: Number(res.priceObj) * 100,
            skuNo: detail?.skuNo,
            id: detail?.id,
            addValidPeriodDays: validPeriodMethodValue === 2 ? Number(res.addValidPeriodDays) : 0,
            validPeriodMethod: Number(res.validPeriodMethod),
          };
          setConfirmLoading(true);
          addOrUpdateSellCard(requestData)
            .then((resp) => {
              if (resp && resp.status === 0) {
                showSuccessMessage(!record ? '新增成功' : '修改成功');
                actionRef?.current.reload();
                setVisible(false);
              }
            })
            .finally(() => setConfirmLoading(false));
        },
        cancelText: '取消',
      });
    });
  };

  const getMonment = (time: string | undefined) => {
    return (time?.trim().length || 0) > 0 ? moment(time, 'YYYY-MM-DD') : undefined;
  };

  return (
    <Modal
      width="60%"
      className="cardSelling"
      title={title}
      visible={visible}
      centered
      onCancel={() => setVisible(false)}
      destroyOnClose={true}
      confirmLoading={confirmLoading}
      onOk={onSubmit}
      forceRender={true}
    >
      {loading && <Spin size="large" />}
      {!loading && (
        <Form form={form} {...defaultFormLayout}>
          {detail && (
            <Row style={{ marginBottom: '12px' }}>
              <Col span={12}>SKU：{detail?.skuNo}</Col>
              <Col>创建时间：{detail?.createdTime}</Col>
            </Row>
          )}
          <h3>权益卡信息</h3>
          <Form.Item
            label="权益卡"
            name="goodsName"
            rules={[{ required: true, message: '请选择权益卡' }]}
          >
            <Select
              style={{ width: '65%' }}
              showSearch
              disabled={!!record}
              placeholder="请输入权益卡名称或 PlanCode"
              showArrow={false}
              filterOption={false}
              onSearch={setSearchParam}
              className={'formRight'}
              onChange={(masterId: number) => querCardDetail(masterId)}
              notFoundContent={null}
            >
              {cardList.map((item: CardItem) => {
                return (
                  <Select.Option key={item.masterId} value={item.masterId || 0}>
                    {item.name}
                  </Select.Option>
                );
              })}
            </Select>
          </Form.Item>
          <Form.Item
            label="领用有效期计算方式"
            name="validPeriodMethod"
            rules={[{ required: true, message: '请选择领用有效期计算方式' }]}
          >
            <Select
              style={{ width: '65%' }}
              placeholder="请选择领用有效期计算方式"
              filterOption={false}
              onChange={(e: number) => {
                setValidPeriodMethodValue(e);
              }}
              className={'formRight'}
              notFoundContent={null}
            >
              {validPeriodMethodList.map((item) => {
                return (
                  <Select.Option key={item.id} value={item.id || 0}>
                    {item.text}
                  </Select.Option>
                );
              })}
            </Select>
          </Form.Item>
          {validPeriodMethodValue === 2 && (
            <Form.Item label="领用有效期增加天数" required={true}>
              <Form.Item
                name="addValidPeriodDays"
                noStyle
                rules={[{ required: true, message: '请输入领用有效期增加天数' }]}
              >
                <InputNumber
                  placeholder="请输入领用有效期增加天数"
                  className={'formRight'}
                  min={0}
                  max={999999}
                  parser={defaultParser}
                />
              </Form.Item>
              <span className={'unit'}>天</span>
            </Form.Item>
          )}
          {(validPeriodMethodValue === 1 || !validPeriodMethodValue) && (
            <Form.Item
              label="最后领用日期"
              name="lastActivationDateObj"
              rules={[{ required: true, message: '请选择最后领用日期' }]}
              initialValue={detail ? getMonment(detail.lastActivationDate) : undefined}
            >
              <DatePicker className={'formRight'} format="YYYY-MM-DD" />
            </Form.Item>
          )}
          <Form.Item label="激活生效日期" required={true}>
            <Form.Item
              name="effectiveDays"
              noStyle
              rules={[{ required: true, message: '请输入激活生效日期' }]}
            >
              <InputNumber
                placeholder="请输入激活生效日期"
                className={'formRight'}
                min={0}
                max={999999}
                parser={defaultParser}
              />
            </Form.Item>
            <span className={'unit'}>天</span>
          </Form.Item>
          <ProTable<RightItem>
            columns={columns}
            rowKey="order"
            dataSource={cardDetail?.rightsList}
            search={false}
            pagination={false}
            options={false}
            size={'small'}
            style={{ padding: '15px' }}
            bordered={true}
          />
          <h3>权益卡介绍</h3>
          <Form.Item
            name="goodsDesc"
            labelCol={{ span: 0 }}
            wrapperCol={{ span: 24 }}
            className="desc"
          >
            <Input.TextArea maxLength={250} placeholder="请输入权益卡介绍" showCount={true} />
          </Form.Item>
          <h3>销售信息</h3>
          <Form.Item
            label="是否开启"
            name="isOpenObj"
            rules={[{ required: true, message: '请选择是否开启' }]}
            initialValue={detail ? (detail.isOpen ? 1 : 0) : undefined}
          >
            <Select className={'formRight'} style={{ width: '65%' }}>
              <Select.Option key={1} value={1}>
                开启
              </Select.Option>
              <Select.Option key={0} value={0}>
                关闭
              </Select.Option>
            </Select>
          </Form.Item>
          <Form.Item label="原价" required={true}>
            <Form.Item
              name="priceObj"
              noStyle
              rules={[{ required: true, message: '请输入原价' }]}
              initialValue={detail ? Number(detail?.price || 0) / 100 : undefined}
            >
              <InputNumber
                className={'formRight'}
                min={0}
                max={999999}
                parser={(val) => defaultParser(val, false, 2)}
              />
            </Form.Item>
            <span className={'unit'}>元</span>
          </Form.Item>
          <Form.Item label="优惠价" required={true}>
            <Form.Item
              name="discountPriceObj"
              noStyle
              rules={[{ required: true, message: '请输入优惠价' }]}
              initialValue={detail ? Number(detail?.discountPrice || 0) / 100 : undefined}
            >
              <InputNumber
                className={'formRight'}
                min={0}
                max={999999}
                parser={(val) => defaultParser(val, false, 2)}
              />
            </Form.Item>
            <span className={'unit'}>元</span>
          </Form.Item>
          <Form.Item
            label="是否使用优惠价"
            name="preferentialMethod"
            rules={[{ required: true, message: '请选择是否使用优惠价' }]}
            initialValue={detail ? detail.preferentialMethod : undefined}
          >
            <Select
              style={{ width: '65%' }}
              placeholder="请选择是否使用优惠价"
              filterOption={false}
              onChange={(e: number) => {
                setPreferentialMethodValue(e);
              }}
              className={'formRight'}
              notFoundContent={null}
            >
              {preferentialMethodList.map((item) => {
                return (
                  <Select.Option key={item.id} value={item.id || 0}>
                    {item.text}
                  </Select.Option>
                );
              })}
            </Select>
          </Form.Item>
          <Form.Item
            name="disallowTransfer"
            style={{ marginLeft: '13%' }}
            valuePropName={'checked'}
            initialValue={detail ? !detail?.allowTransfer : false}
          >
            <Checkbox>购买后禁用转赠</Checkbox>
          </Form.Item>

          <Form.Item
            name="disMwyAgreement"
            style={{ marginLeft: '13%' }}
            valuePropName={'checked'}
            initialValue={detail ? detail?.mwyAgreement : false}
          >
            <Checkbox>购买前药无忧协议</Checkbox>
          </Form.Item>
          <Form.Item
            name="disAutoRenew"
            style={{ marginLeft: '13%' }}
            valuePropName={'checked'}
            initialValue={detail ? detail?.autoRenew : false}
          >
            <Checkbox
              onChange={(e) => {
                setAutoRenewFlag(e.target.checked);
              }}
            >
              可自动续费
            </Checkbox>
          </Form.Item>
          <Form.Item
            name="disHorseRaceLamp"
            style={{ marginLeft: '13%' }}
            valuePropName={'checked'}
            initialValue={detail ? detail?.horseRaceLamp : false}
          >
            <Checkbox>展示已购买跑马灯</Checkbox>
          </Form.Item>

          {autoRenewFlag ? (
            <Form.Item
              label="自动续费模板"
              name="planId"
              rules={[{ required: true, message: '请选择自动续费模板' }]}
              initialValue={detail ? detail.planId : undefined}
            >
              <Select
                style={{ width: '65%' }}
                placeholder="请选择自动续费模板"
                filterOption={false}
                onChange={(e: number) => {
                  setPlanIdValue(e);
                }}
                className={'formRight'}
                notFoundContent={null}
              >
                {autoRenewPlanIdList.map((item) => {
                  return (
                    <Select.Option key={item.planId} value={item.planId || 0}>
                      {item.desc} | {item.planId}
                    </Select.Option>
                  );
                })}
              </Select>
            </Form.Item>
          ) : null}
        </Form>
      )}
    </Modal>
  );
});
export default CreateOrMdifyModal;

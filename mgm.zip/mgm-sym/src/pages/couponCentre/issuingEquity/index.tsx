import React, { useState, useRef } from 'react';
import ProTable from '@ant-design/pro-table';
import { Button, Popconfirm, Upload } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import {
  checkPermission,
  ISSUING_UOLOADEXCEL,
  ISSUING_ADD,
  ISSUING_CLOSE,
  ISSUING_DETAILED,
} from '@/utils/power';
import {
  customerCardPalletList,
  bulkImportExcel,
  customerCloseCard,
  CustomerFindDetailed,
} from '@/services/api';
import { formatTime } from '@/utils/utils';
import { showErrorMessage } from '@/mamagement/Notification';

import AddModal from './components/addModal';

const permissionGroups = [ISSUING_UOLOADEXCEL, ISSUING_ADD, ISSUING_CLOSE, ISSUING_DETAILED];
export default (): React.ReactNode => {
  const [ModalVisible, setModalVisible] = useState(false);
  const [title, seTitle] = useState<string>('');
  const [amount, seAmount] = useState<{ batchNo?: string; count?: number }>({
    batchNo: '',
    count: 0,
  });
  const [scheduleLoading, setScheduleLoading] = useState(false);
  const actionRef = useRef<ActionType | undefined>();
  const AddModalRef = useRef<any>();
  const [disabledClose, setDisabledClose] = useState<boolean>(false);

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name || '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(`只能上传格式为 xlsx 的文件`);
    return isXlsx;
  }

  function customeUpload(options: any) {
    setScheduleLoading(true);
    bulkImportExcel(options)
      .then((res) => {
        if (res.status === 0) {
          setModalVisible(true);
          seTitle('批量导入');
          seAmount(res.result);
        } else {
          showErrorMessage(res.message ? res.message : '导入失败');
        }
      })
      .finally(() => setScheduleLoading(false));
  }

  const onSubmit = () => {
    seTitle('');
    seAmount({});
    setModalVisible(false);

    actionRef.current?.reload();
  };
  const onCancel = () => {
    seTitle('');
    setModalVisible(false);
  };

  const columns: ProColumns<APIS.CardPalletListType>[] = [
    {
      title: '用户 ID',
      dataIndex: 'userId',
      hideInTable: true,
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
      hideInTable: true,
    },
    {
      title: '发卡时间',
      dataIndex: 'createdAt',
      hideInSearch: true,
      renderText: (text) => formatTime(text),
    },
    {
      title: '发卡手机号',
      dataIndex: 'ownerMobile',
      hideInSearch: true,
    },
    {
      title: '姓名',
      dataIndex: 'ownerName',
      hideInSearch: true,
    },
    {
      title: '权益卡SKU',
      dataIndex: 'skuNo',
      hideInSearch: true,
    },
    {
      title: '权益卡名称',
      dataIndex: 'skuName',
      hideInSearch: true,
    },
    {
      title: '最后激活日期',
      dataIndex: 'latestActiveTime',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '激活状态',
      dataIndex: 'status',
      hideInSearch: true,
      valueType: 'select',
      renderText: (text, record) => {
        return record.closed
          ? '已关闭'
          : text === 1
          ? '未激活'
          : text === 5
          ? '赠送中'
          : text === 8
          ? '已激活'
          : '已赠送';
      },
    },
    {
      title: '激活信息',
      dataIndex: 'activeMessage',
      hideInSearch: true,
    },
    {
      title: '激活日期',
      dataIndex: 'activeTime',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      width: '140px',
      title: '操作',
      hideInSearch: true,
      valueType: 'option',
      render: (text, record) => {
        return (
          <>
            {powers[`${ISSUING_CLOSE}`] && (
              <Popconfirm
                disabled={disabledClose || record.closed}
                title="是否确认关闭？"
                onConfirm={() => {
                  setDisabledClose(true);
                  customerCloseCard(record.cardId).then((res) => {
                    setDisabledClose(false);
                    if (res.status === 0) {
                      actionRef.current?.reload();
                    } else {
                      showErrorMessage('关闭失败');
                    }
                  });
                }}
                onCancel={() => {}}
                okText="确定"
                cancelText="取消"
              >
                <Button disabled={disabledClose || record.closed} type="link">
                  关闭
                </Button>
              </Popconfirm>
            )}
            {powers[`${ISSUING_DETAILED}`] && (
              <Button
                type="link"
                onClick={() => {
                  CustomerFindDetailed({
                    cardId: record.cardId,
                    gainWay: record.gainWay,
                    relationshipNumber: record.relationshipNumber,
                    skuNo: record.skuNo,
                  }).then((res) => {
                    if (res.status === 0) {
                      setModalVisible(true);
                      seTitle('查看');
                      AddModalRef.current.setData({
                        ...res.result,
                        planCode: record.planCode,
                        skuNo: record.skuNo,
                        genTime: record.createdAt,
                        userMobile: record.ownerMobile,
                        userName: record.ownerName,
                        allowedTransfer: record.allowedTransfer,
                        goodsInfo: record.skuName,
                        lastActivationDate: record.latestActiveTime,
                      });
                    }
                  });
                }}
              >
                查看
              </Button>
            )}
          </>
        );
      },
    },
  ];
  return (
    <PageContainer>
      <ProTable<APIS.CardPalletListType>
        actionRef={actionRef}
        columns={columns}
        request={customerCardPalletList}
        rowKey="cardId"
        dateFormatter="string"
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          powers[`${ISSUING_UOLOADEXCEL}`] && (
            <Upload
              accept={'.xlsx'}
              maxCount={1}
              type={'select'}
              beforeUpload={handleBeforeUpload}
              customRequest={customeUpload}
              showUploadList={false}
            >
              <Button key="primary" type="primary" loading={scheduleLoading}>
                {scheduleLoading ? null : <UploadOutlined />}
                批量导入
              </Button>
            </Upload>
          ),
          powers[`${ISSUING_ADD}`] && (
            <Button
              key="primary"
              type="primary"
              onClick={() => {
                setModalVisible(true);
                seTitle('新增');
              }}
            >
              <PlusOutlined />
              新增
            </Button>
          ),
        ]}
      />
      <AddModal
        ref={AddModalRef}
        ModalVisible={ModalVisible}
        title={title}
        type={title}
        amount={amount}
        onSubmit={onSubmit}
        onCancel={onCancel}
      />
    </PageContainer>
  );
};

export const activatedState = {
  1: {
    text: '已购买',
  },
  5: {
    text: '赠送中',
  },
  8: {
    text: '已激活',
  },
  9: {
    text: '已赠送',
  },
};

/* eslint-disable react-hooks/exhaustive-deps */
import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import { Modal, Select, Input, Form, Popconfirm, Button, Col, Checkbox, Upload, Image } from 'antd';
import { CloseCircleOutlined, PlusOutlined } from '@ant-design/icons';
import type { ProColumns } from '@ant-design/pro-table';
import ProTable from '@ant-design/pro-table';

import {
  rightsCardName,
  rightsCardDetails,
  AddCardSingle,
  AddCardBatch,
  getCosDownladUrl,
  uploadFile,
} from '@/services/api';
import { formatTime } from '@/utils/utils';
import { cardSingleMobilePhoneReg } from '@/utils/RegExp';
import { checkImageTypeAndSize, useDebounce } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import './index.less';

const { Option } = Select;

export type EditModalProps = {
  ModalVisible: boolean;
  amount?: { batchNo?: string; count?: number };
  title: string;
  type: string;
  onSubmit: () => void;
  onCancel: () => void;
};
type optionItemType = {
  goodsInfo: string;
  skuNo: string;
};
type goodsInfosType = {
  code?: string;
  description?: string;
  isInfinitely?: boolean;
  name?: string;
  number?: number;
  order?: number;
  rightsMasterId?: string;
  unit?: string;
};
type cardType = {
  goodsInfos?: goodsInfosType[];
  lastActivationDate?: string;
  validDays?: string;
};
// const EditModal: React.FC<EditModalProps> = (props) => {
const EditModal = forwardRef((props: EditModalProps, ref) => {
  const { ModalVisible, amount, title, type, onSubmit, onCancel } = props;
  const [certify, setCertify] = useState<string>('');

  const [form] = Form.useForm();
  const [visible, setVisible] = useState<boolean>(false);
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);
  const [allowTransfer, setAllowTransfer] = useState<boolean>(false);
  const [card, setCard] = useState<cardType>({});

  const [optionItem, setOptionItem] = useState<optionItemType[]>([]);
  const [searchParam, setSearchParam] = useState<string>('');
  const [details, setDetails] = useState({});

  // 保存数据（二次确认）
  const handleOk = () => {
    setConfirmLoading(true);
    if (type === '新增') {
      AddCardSingle({ ...details, allowTransfer: !allowTransfer, certify }).then((res) => {
        setConfirmLoading(false);
        setVisible(false);
        if (res.status === 0) {
          showSuccessMessage('操作成功');
          reset();
          onSubmit();
        }
      });
    } else {
      AddCardBatch({ ...details, batchNo: amount?.batchNo, certify }).then((res) => {
        setConfirmLoading(false);
        setVisible(false);
        if (res.status === 0) {
          showSuccessMessage('操作成功');
          reset();
          onSubmit();
        }
      });
    }
  };
  // 第一次点击确认
  const verifyData = (values: any) => {
    setDetails(values);
    setVisible(true);
  };
  // 取消保存
  const handleCancel = () => {
    setConfirmLoading(false);
    setVisible(false);
    onCancel();
    reset();
  };

  // 是否禁止转赠
  function onChange() {
    setAllowTransfer(!allowTransfer);
  }
  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 4 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 20 },
    },
  };

  const uploadProps = {
    beforeUpload: checkImageTypeAndSize,
  };

  const columns: ProColumns<goodsInfosType>[] = [
    {
      title: '序号',
      dataIndex: 'name',
      render: (text, record, index) => <>{index + 1}</>,
    },
    {
      title: '权益',
      dataIndex: 'name',
      render: (text, record) => (
        <>
          {text} {record.code}
        </>
      ),
    },
    {
      title: '可使用',
      dataIndex: 'number',
      render: (text: any, record) => <>{record.isInfinitely ? '不限次' : text + record.unit}</>,
    },
    {
      title: '延迟生效时间',
      dataIndex: 'usableOffset',
    },
  ];

  // 获取权益卡名称
  useEffect(() => {
    const temp = searchParam?.trim() || '';
    if (temp && temp.length > 0) {
      rightsCardName(temp).then((res) => {
        setOptionItem(res.result?.goodsSearchInfos);
      });
    } else {
      setOptionItem([]);
    }
  }, [useDebounce(searchParam, 400)]);

  useImperativeHandle(ref, () => ({
    takeData,
    setData,
    reset,
  }));

  return (
    <Modal
      className="issuingEquityAddModal"
      width="60%"
      style={{ minWidth: '720px' }}
      title={title}
      visible={ModalVisible}
      centered
      onCancel={handleCancel}
      destroyOnClose={true}
      footer={[
        <Button key="back" onClick={handleCancel}>
          关闭
        </Button>,
        <span style={{ margin: '8px' }} key="clear">
          {title === '查看' ? (
            ''
          ) : (
            <Popconfirm
              key="submit"
              icon={''}
              title={type === '批量导入' ? '是否确认导入?' : '是否确认发卡?'}
              visible={visible}
              okButtonProps={{ loading: confirmLoading }}
              onConfirm={handleOk}
              onCancel={() => {
                setVisible(false);
              }}
            >
              <Button type="primary" onClick={takeData}>
                确定
              </Button>
            </Popconfirm>
          )}
        </span>,
      ]}
    >
      <Form form={form} {...formItemLayout}>
        {type === '新增' && (
          <>
            <h3>用户信息</h3>
            <Form.Item
              label="手机号"
              name="userMobile"
              rules={[{ required: true, message: '请输入账户名' }]}
            >
              <Input maxLength={11} width={'100%'} placeholder="请输入手机号" />
            </Form.Item>
            <Form.Item
              label="姓名"
              name="userName"
              rules={[{ required: true, message: '请输入账户名' }]}
            >
              <Input width={'100%'} placeholder="请输入姓名" />
            </Form.Item>
          </>
        )}
        {type === '批量导入' && <h3>是否确认导入 {amount?.count} 条数据？</h3>}
        {type === '查看' && (
          <>
            <Form.Item label="发卡时间">
              <span>{formatTime(form.getFieldValue('genTime'))}</span>
            </Form.Item>
            <h3>用户信息</h3>
            <Form.Item label="手机号" rules={[{ required: true, message: '请输入账户名' }]}>
              {form.getFieldValue('userMobile')}
            </Form.Item>
            <Form.Item label="姓名">{form.getFieldValue('userName')}</Form.Item>
          </>
        )}
        <h3>权益信息</h3>
        <Form.Item
          label="权益卡名称"
          name="skuNo"
          rules={[{ required: true, message: '请输入权益卡名称' }]}
        >
          {type !== '查看' ? (
            <Select
              style={{ width: '100%' }}
              showSearch
              placeholder="请输入权益卡名称"
              showArrow={false}
              filterOption={false}
              onSearch={setSearchParam}
              onChange={(value: number) => {
                rightsCardDetails(value).then((res) => {
                  if (res.status === 0) {
                    setCard(res.result);
                  }
                });
              }}
              notFoundContent={null}
            >
              {optionItem?.map((item: optionItemType) => {
                return (
                  <Option key={item.skuNo} value={item.skuNo}>
                    {item.goodsInfo}
                  </Option>
                );
              })}
            </Select>
          ) : (
            <span>
              {form.getFieldValue('skuNo') || ''} | {form.getFieldValue('goodsInfo') || ''} |{' '}
              {form.getFieldValue('planCode') || ''}
            </span>
          )}
        </Form.Item>

        {Object.keys(card).length ? (
          <>
            <Form.Item label="最后激活日期" style={{ marginBottom: '0' }}>
              <span> {card.lastActivationDate} </span>
            </Form.Item>
            <Form.Item label="激活后可使用日期" style={{ marginBottom: '0' }}>
              <span> {card.validDays} </span>
            </Form.Item>
            <ProTable<goodsInfosType>
              columns={columns}
              rowKey="code"
              dataSource={card.goodsInfos}
              search={false}
              pagination={false}
              options={false}
              size={'small'}
              style={{ padding: '15px' }}
              bordered={true}
            />
            {type === '新增' ? (
              <Checkbox className="givePresent" value={allowTransfer} onChange={onChange}>
                禁止转赠
              </Checkbox>
            ) : type === '查看' ? (
              <Form.Item label="是否禁止转赠">
                {<span>{allowTransfer ? '否' : '是'}</span>}
              </Form.Item>
            ) : null}
          </>
        ) : null}
        <h3>审批信息</h3>
        <Form.Item
          label="关联流水号"
          name="transNo"
          rules={[{ required: true, message: '请输入关联流水号' }]}
        >
          {type === '查看' ? (
            <span>{form.getFieldValue('relationshipNo')}</span>
          ) : (
            <Input maxLength={50} width={'100%'} placeholder="请输入关联流水号" />
          )}
        </Form.Item>
        <Form.Item
          label="业务备注"
          name="remark"
          rules={[{ required: true, message: '请输入业务备注' }]}
        >
          {type === '查看' ? (
            <span>{form.getFieldValue('remark')}</span>
          ) : (
            <Input maxLength={50} width={'100%'} placeholder="请输入业务备注" />
          )}
        </Form.Item>
        <Col>
          <Form.Item label="上传凭证" name="certifyStr" initialValue={certify ? [{}] : undefined}>
            {title === '查看' ? (
              certify ? (
                <Image width={100} height="100px" src={certify} />
              ) : null
            ) : (
              <Upload
                accept={'image/*'}
                listType="picture-card"
                className="avatar-uploader "
                showUploadList={false}
                disabled={!!certify}
                customRequest={(options) => customRequest(options)}
                {...uploadProps}
              >
                {certify ? (
                  <div className="portrait">
                    {!certify ? (
                      ''
                    ) : (
                      <i
                        className="imageClose"
                        onClick={() => {
                          setCertify('');
                        }}
                      >
                        <CloseCircleOutlined />
                      </i>
                    )}
                    <img
                      src={certify}
                      alt="上传凭证"
                      style={{ width: '100%', maxHeight: '104px' }}
                    />
                  </div>
                ) : (
                  <PlusOutlined />
                )}
              </Upload>
            )}
          </Form.Item>
        </Col>
      </Form>
    </Modal>
  );

  function customRequest(option: any) {
    uploadFile(option, (key) => {
      setCertify(getCosDownladUrl(key));
    });
  }
  /** 父组件传递数据 */
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          const { certifyStr, ...data } = values;
          if (cardSingleMobilePhoneReg(values.userMobile) || !values.userMobile) {
            verifyData(data);
          } else {
            showErrorMessage('手机号格式不对');
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /** 设置数据 */
  function setData(data: any) {
    reset();
    if (Object.keys(data).length) {
      form.setFieldsValue(data);
      setAllowTransfer(data.allowedTransfer);
      setCard({ ...data.detailed, lastActivationDate: formatTime(data.lastActivationDate || 0) });
      setCertify(data.certify);
    }
  }
  // 重置数据
  function reset() {
    form.resetFields();
    setAllowTransfer(false);
    setOptionItem([]);

    setCard({});
    setCertify('');
  }
});
export default EditModal;

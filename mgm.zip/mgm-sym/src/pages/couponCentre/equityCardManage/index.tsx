import { useRef, useState } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import { checkPermission, EQUITYCARD_ADD, EQUITYCARD_DETAILED } from '@/utils/power';

import { listCardMaster, createCardMaster, updateCardMaster } from './api';
import Ceil from './components/Ceil';
import EquityCardModal from './components/modal';
import AddOrViewSetails from './components/addOrViewDetails';
import type { CeilDetailsType, ContentType } from './typings.d';

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_DETAIL = 2;
const MODAL_TYPE_CEIL = 3;

const permissionGroups = [EQUITYCARD_ADD, EQUITYCARD_DETAILED];
function EquityCardManage() {
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [equilCardVisible, setEquilCardVisible] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [details, setDetails] = useState<ContentType>({});
  const [ceilDetails, setCeilDetails] = useState<CeilDetailsType>({}); // 将数据传入 Ceil 组件中

  const AddorviewsetailsRef = useRef<any>();
  const CeilRef = useRef<any>();
  const actionRef = useRef<ActionType>();

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_DETAIL:
        return '详情';
      case MODAL_TYPE_CEIL:
        return '限额';
    }
    return '';
  }

  // 点击详情按钮
  const clickViewDetails = (record: ContentType) => {
    setEquilCardVisible(true);
    setModalType(MODAL_TYPE_DETAIL);
    setTimeout(() => {
      AddorviewsetailsRef.current?.setData(record);
    });
  };

  // 点击限额按钮
  const clickCeil = (record: ContentType) => {
    setEquilCardVisible(true);
    setModalType(MODAL_TYPE_CEIL);
    setCeilDetails({
      cardMasterId: record.cardMasterId,
      name: record.name,
      createdNumber: record.createdNumber,
      limitNumber: record.limitNumber,
      warnNumber: record.warnNumber,
      limitCreate: record.limitCreate,
    });
  };
  const onOk = () => {
    if (modalType === 1 || modalType === 2) {
      AddorviewsetailsRef.current?.takeData().then((values: any) => {
        setDetails(values);
        setVisible(true);
      });
    }
    // 限额
    if (modalType === 3) {
      CeilRef.current?.takeData().then((values: any) => {
        setDetails(values);
        setVisible(true);
      });
    }
  };
  const onCancel = () => {
    AddorviewsetailsRef.current?.reset();
    CeilRef.current?.reset();
    setCeilDetails({});
    setModalType(undefined);
    setVisible(false);
    setBtnLoading(false);
    setTimeout(() => {
      setEquilCardVisible(false);
    }, 0);
  };
  const onSaveData = () => {
    if (modalType === 1) {
      createCardMaster(details)
        .then((res) => {
          if (res.status === 0) {
            AddorviewsetailsRef.current?.reset();
            setModalType(undefined);
            actionRef.current?.reload();
            setTimeout(() => {
              setEquilCardVisible(false);
            }, 0);
          }
        })
        .finally(() => {
          setBtnLoading(false);
          setVisible(false);
        });
    } else if (modalType === 2) {
      updateCardMaster(details)
        .then((res) => {
          if (res.status === 0) {
            AddorviewsetailsRef.current?.reset();
            setModalType(undefined);
            actionRef.current?.reload();
            setTimeout(() => {
              setEquilCardVisible(false);
            }, 0);
          }
        })
        .finally(() => {
          setBtnLoading(false);
          setVisible(false);
        });
    } else if (modalType === 3) {
      updateCardMaster(details)
        .then((res) => {
          if (res.status === 0) {
            CeilRef.current?.reset();
            setCeilDetails({});
            setModalType(undefined);
            actionRef.current?.reload();
            setTimeout(() => {
              setEquilCardVisible(false);
            }, 0);
          }
        })
        .finally(() => {
          setBtnLoading(false);
          setVisible(false);
        });
    }
  };
  const onCancelData = () => {
    setVisible(false);
    setBtnLoading(false);
  };

  const columns: ProColumns<ContentType>[] = [
    {
      title: 'ID',
      dataIndex: 'cardMasterId',
    },
    {
      title: 'PlanCode',
      dataIndex: 'planCode',
      hideInTable: true,
    },
    {
      title: 'planCode',
      dataIndex: 'planCode',
      hideInSearch: true,
    },
    {
      title: '卡名称',
      dataIndex: 'name',
      hideInTable: true,
    },
    {
      title: '权益卡名称',
      dataIndex: 'name',
      hideInSearch: true,
    },
    {
      title: '配置时间',
      dataIndex: 'updatedAt',
      render: (text) => text && formatTime(Number(text)),
      hideInSearch: true,
    },
    {
      title: '使用人数',
      dataIndex: 'maxRelation',
      hideInSearch: true,
    },
    {
      title: '激活后有效期',
      dataIndex: 'expireMessage',
      hideInSearch: true,
    },
    {
      title: '备注',
      dataIndex: 'description',
      hideInSearch: true,
    },
    {
      title: '操作',
      dataIndex: 'option',
      hideInSearch: true,
      render: (text, record) => [
        powers[`${EQUITYCARD_DETAILED}`] && (
          <Button
            type="link"
            key="viewDetails"
            onClick={() => {
              clickViewDetails(record);
            }}
          >
            详情
          </Button>
        ),
        <Button
          type="link"
          key="ceil"
          onClick={() => {
            clickCeil(record);
          }}
        >
          限额
        </Button>,
      ],
    },
  ];
  return (
    <PageContainer>
      <ProTable<ContentType>
        columns={columns}
        actionRef={actionRef}
        request={listCardMaster}
        rowKey="cardMasterId"
        pagination={{
          defaultPageSize: 10,
        }}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        toolBarRender={() => [
          powers[`${EQUITYCARD_ADD}`] && (
            <Button
              key="add"
              icon={<PlusOutlined />}
              onClick={() => {
                setModalType(MODAL_TYPE_ADD);
                setEquilCardVisible(true);
              }}
              type="primary"
            >
              新建
            </Button>
          ),
        ]}
      />
      <EquityCardModal
        title={getModalTitle()}
        modalType={modalType}
        EquilCardVisible={equilCardVisible}
        btnLoading={btnLoading}
        visible={visible}
        onOk={onOk}
        onCancel={onCancel}
        onSaveData={onSaveData}
        onCancelData={onCancelData}
      >
        {(modalType === 1 || modalType === 2) && (
          <AddOrViewSetails ref={AddorviewsetailsRef} modalType={modalType} />
        )}
        {modalType === 3 && <Ceil ref={CeilRef} ceilDetails={ceilDetails} />}
      </EquityCardModal>
    </PageContainer>
  );
}
export default EquityCardManage;

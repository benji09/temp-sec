/*
 * @Author: your name
 * @Date: 2021-07-29 10:06:55
 * @LastEditTime: 2021-10-09 14:25:30
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\pages\couponCentre\equityCardManage\components\modal.tsx
 */
import React from 'react';
import { Button, Modal, Popconfirm } from 'antd';

import type { ModalPropsType } from '../typings';

const EquilCardModal: React.FC<ModalPropsType> = (props) => {
  const {
    title,
    modalType,
    EquilCardVisible,
    visible,
    btnLoading,
    onOk,
    onCancel,
    onSaveData,
    onCancelData,
    children,
  } = props;

  return (
    <Modal
      width={modalType === 1 || modalType === 2 ? '60%' : '50%'}
      title={title}
      visible={EquilCardVisible}
      onCancel={onCancel}
      centered
      footer={[
        <Button key="back" onClick={onCancel}>
          取消
        </Button>,
        <Popconfirm
          key="submit"
          icon={''}
          title={
            modalType === 1 ? '是否确认添加?' : modalType === 2 ? '是否确认修改?' : '是否确认?'
          }
          visible={visible}
          onConfirm={onSaveData}
          okButtonProps={{ loading: btnLoading }}
          onCancel={() => {
            onCancelData();
          }}
        >
          <Button type="primary" onClick={onOk}>
            确定
          </Button>
        </Popconfirm>,
      ]}
    >
      {children}
    </Modal>
  );
};
export default EquilCardModal;

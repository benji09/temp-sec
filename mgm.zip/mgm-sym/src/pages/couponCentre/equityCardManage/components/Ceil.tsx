import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import { Col, InputNumber, Checkbox, Row } from 'antd';
import _ from 'lodash';

import { defaultParser } from '@/utils/utils';

import type { CeilDetailsType, PropsType } from '../typings';

import './Ceil.less';

const Ceil = forwardRef((props: PropsType, ref) => {
  const { ceilDetails } = props;
  const [details, setDetails] = useState<CeilDetailsType>({});

  useEffect(() => {
    const data = _.cloneDeep(ceilDetails);
    data.changeLimitNumber = 0;
    setDetails(data);
  }, [ceilDetails]);

  // 调整数量更改
  function onChangeInputNumber(value: any) {
    const data = _.cloneDeep(details);
    data.changeLimitNumber = value;
    setDetails(data);
  }
  // 剩余几张报警
  function onChangeCloseAlarm(value: any) {
    const data = _.cloneDeep(details);
    data.warnNumber = value;
    setDetails(data);
  }

  // 超过数量不再制卡改变
  function onChangeCheckBox(e: any) {
    const data = _.cloneDeep(details);
    data.limitCreate = e.target.checked;
    setDetails(data);
  }

  useImperativeHandle(ref, () => ({
    takeData,
    reset,
  }));

  return (
    <Row className="Ceil">
      <Col span={24}>权益卡名称：{details.name}</Col>
      <Col span={24}>已制卡数量：{details.createdNumber}</Col>
      <Col span={24}>剩余数量：{(details.limitNumber || 0) - (details.createdNumber || 0)}</Col>
      <Col span={24}>
        调整数量：
        <InputNumber
          style={{ width: '30%' }}
          value={details.changeLimitNumber}
          onChange={onChangeInputNumber}
          parser={(values?: string) => {
            return values && /^\d+$/.test(values) ? parseInt(values) : parseInt(values || '0') || 0;
          }}
        />{' '}
        张
      </Col>
      <Col span={24} className="textPrompt">
        请按照业务规则留有余量卡
      </Col>

      <Col span={24}>
        剩余：
        <InputNumber
          style={{ width: '30%' }}
          value={details.warnNumber}
          onChange={onChangeCloseAlarm}
          parser={defaultParser}
          min={0}
        />{' '}
        张 报警
      </Col>
      <Col span={24}>
        <Checkbox checked={details.limitCreate} onChange={onChangeCheckBox}>
          超过数量不再制卡
        </Checkbox>
      </Col>
    </Row>
  );

  /** 父组件传递数据 */
  function takeData() {
    return new Promise((resolve) => {
      const { cardMasterId, changeLimitNumber, warnNumber, limitCreate } = details;
      resolve({ cardMasterId, changeLimitNumber, warnNumber, limitCreate });
    });
  }

  // 重置数据
  function reset() {
    setDetails({});
  }
});
export default Ceil;

/* eslint-disable react-hooks/exhaustive-deps */

import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import _ from 'lodash';
import {
  Form,
  Input,
  Row,
  Col,
  Select,
  Button,
  InputNumber,
  Table,
  Space,
  Popconfirm,
  Checkbox,
} from 'antd';
import { PlusOutlined } from '@ant-design/icons';

import { formatTime, useDebounce } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import { listRightsMaster } from '../api';
import type {
  ListRightsMasterType,
  PropsType,
  RightsListType,
  SelectValueType,
  ContentType,
} from '../typings';

import './index.less';

const { Option } = Select;

const AddOrViewDetails = forwardRef((props: PropsType, ref) => {
  const { modalType } = props;
  const [searchParam, setSearchParam] = useState<string>('');
  const [optionItem, setOptionItem] = useState<ListRightsMasterType[]>([]);
  const [rightsList, setRightsList] = useState<RightsListType[]>([]);
  const [cardMasterId, setCardMasterId] = useState(undefined);
  const [form] = Form.useForm();
  const [vipTag, setVipTag] = useState<boolean>(false);
  const [selectableRelation, setSelectableRelation] = useState<boolean>(false);
  const [details, setDetails] = useState<ContentType>({});

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 5 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 15 },
    },
  };

  useEffect(() => {
    const temp = searchParam?.trim() || '';
    if (temp && temp.length > 0) {
      listRightsMaster({ keyword: temp }).then((res) => {
        if (res.status === 0) {
          setOptionItem(res.result || []);
        } else {
          setOptionItem([]);
        }
      });
    } else {
      setOptionItem([]);
    }
  }, [useDebounce(searchParam, 400)]);

  // 添加列表
  const addtableData = () => {
    const list = _.cloneDeep(rightsList);
    list.push({ id: rightsList.length ? rightsList.length : 0 });
    setRightsList(list);
  };

  const columns = [
    {
      title: '序号',
      render: (_text: any, _record: RightsListType, index: number) => <span>{index + 1}</span>,
    },
    {
      title: '权益',
      dataIndex: 'name',
      render: (text: string, record: RightsListType, index: number) => {
        if (modalType === 1) {
          return (
            <Select
              disabled={!!cardMasterId}
              style={{ width: '100%', minWidth: '150px' }}
              labelInValue
              onChange={(value: SelectValueType) => {
                const list = _.cloneDeep(rightsList);
                list[index].name = value.label[2] || '';
                list[index].rightsMasterId = value.value;
                setRightsList(list);
                setSearchParam('');
              }}
              showSearch
              placeholder="请输入权益名称"
              showArrow={false}
              filterOption={false}
              onSearch={setSearchParam}
              notFoundContent={null}
            >
              {optionItem?.map((item: ListRightsMasterType) => {
                return (
                  <Option key={item.rightsMasterId} value={item.rightsMasterId || ''}>
                    {item.code} {item.name}
                  </Option>
                );
              })}
            </Select>
          );
        }
        return (
          <span>
            {record.code} {text}
          </span>
        );
      },
    },
    {
      title: '数量',
      dataIndex: 'number',
      render: (text: string | number, _record: RightsListType, index: number) => {
        if (modalType === 1) {
          return (
            <InputNumber
              placeholder="请输入数量"
              value={text}
              onChange={(value) => {
                const list = _.cloneDeep(rightsList);
                list[index].number = value;
                setRightsList(list);
              }}
              disabled={!!cardMasterId}
              parser={(values) => (values ? parseInt(values, 10) : 0)}
              min={0}
            />
          );
        }
        return <span>{text}</span>;
      },
    },
    {
      title: '延迟生效期',
      dataIndex: 'offsetType',
      render: (text: any, _record: RightsListType, index: number) => {
        if (modalType === 1) {
          return (
            <Select
              placeholder="请选择延迟生效期"
              value={text}
              disabled={!!cardMasterId}
              style={{ width: 100 }}
              onChange={(value) => {
                const list = _.cloneDeep(rightsList);
                list[index].offsetType = value;
                setRightsList(list);
              }}
            >
              <Option value={''}>无</Option>
              <Option value={'YYQ'}>犹豫期</Option>
              <Option value={'DDQ'}>等待期</Option>
              <Option value={'SXQ'}>生效期</Option>
            </Select>
          );
        }
        return (
          <span>
            {text === '' && '无'}
            {text === 'YYQ' && '犹豫期'}
            {text === 'DDQ' && '等待期'}
            {text === 'SXQ' && '生效期'}
          </span>
        );
      },
    },
    {
      title: '延迟生效天数',
      dataIndex: 'offsetTime',
      render: (text: any, _record: RightsListType, index: number) => {
        if (modalType === 1) {
          return (
            <InputNumber
              placeholder="请选择延迟生效天数"
              value={text}
              onChange={(value) => {
                const list = _.cloneDeep(rightsList);
                list[index].offsetTime = value;
                setRightsList(list);
              }}
              disabled={!!cardMasterId}
              parser={(values) => (values ? parseInt(values, 10) : 0)}
              min={0}
            />
          );
        }
        return <span>{text}</span>;
      },
    },
    {
      title: '默认有效期(小时)',
      dataIndex: 'defaultLifeTime',
      render: (text: any, _record: RightsListType, index: number) => {
        if (modalType === 1) {
          return (
            <InputNumber
              placeholder="请输入默认有效期"
              value={text}
              onChange={(value) => {
                const list = _.cloneDeep(rightsList);
                list[index].defaultLifeTime = value;
                setRightsList(list);
              }}
              disabled={!!cardMasterId}
              parser={(values) => (values ? parseInt(values, 10) : 0)}
              min={0}
            />
          );
        }
        return <span>{text}</span>;
      },
    },
    {
      title: '操作',
      width: 100,
      render: (_text: any, _record: RightsListType, index: number) => {
        if (modalType === 1) {
          return (
            <Space size="middle">
              <Popconfirm
                title="您确定要删除这个数据吗？"
                onConfirm={() => {
                  const data = JSON.parse(JSON.stringify(rightsList));
                  data.splice(index, 1);
                  setRightsList(data);
                  showSuccessMessage('删除成功');
                }}
                okText="确定"
                cancelText="取消"
              >
                <Button>删除</Button>
              </Popconfirm>
            </Space>
          );
        }
        return null;
      },
    },
  ];

  useImperativeHandle(ref, () => ({
    takeData,
    setData,
    reset,
  }));

  return (
    <Form className="AddOrViewDetails" {...formItemLayout} form={form}>
      {modalType === 1 ? null : (
        <Row>
          <Col span={12}>ID：{details.cardMasterId}</Col>
          <Col span={12}>创建时间：{formatTime(Number(details.createdAt))}</Col>
        </Row>
      )}
      <h3 className="title">权益卡信息</h3>
      <Row>
        <Col span={24}>
          <Form.Item name="name" label="权益卡名称" rules={[{ required: true }]}>
            <Input maxLength={50} disabled={!!cardMasterId} placeholder="请输入权益卡名称" />
          </Form.Item>
          <Form.Item name="group" label="Group" rules={[{ required: true }]}>
            <Input maxLength={50} disabled={!!cardMasterId} placeholder="请输入Group" />
          </Form.Item>
          <Form.Item name="cat" label="cat" rules={[{ required: true }]}>
            <Input maxLength={50} disabled={!!cardMasterId} placeholder="请输入cat" />
          </Form.Item>
          <Form.Item name="planCode" label="Plancode" rules={[{ required: true }]}>
            <Input maxLength={50} disabled={!!cardMasterId} placeholder="请输入Plancode" />
          </Form.Item>
          <Form.Item name="showType" label="卡面" rules={[{ required: true }]}>
            <Input maxLength={50} disabled={!!cardMasterId} placeholder="请输入卡面" />
          </Form.Item>
          <Form.Item name="expireMessage" label="激活提示" rules={[{ required: true }]}>
            <Input maxLength={50} disabled={!!cardMasterId} placeholder="请输入激活提示" />
          </Form.Item>
          <Form.Item name="maxRelation" label="使用人数" rules={[{ required: true }]}>
            <InputNumber
              style={{ width: '100%' }}
              maxLength={50}
              disabled={!!cardMasterId}
              parser={(values) => (values ? parseInt(values, 10) : '')}
              min={0}
              placeholder="请输入使用人数"
            />
          </Form.Item>

          <Form.Item label="是否有可选关联人">
            <Checkbox
              className="givePresent"
              checked={selectableRelation}
              disabled={!!cardMasterId}
              onChange={() => {
                setSelectableRelation(!selectableRelation);
              }}
            />
          </Form.Item>
          <Form.Item label="是否是VIP卡">
            <Checkbox
              className="givePresent"
              disabled={!!cardMasterId}
              checked={vipTag}
              onChange={() => {
                setVipTag(!vipTag);
              }}
            />
          </Form.Item>
        </Col>
      </Row>
      <h3 className="title">权益信息</h3>
      <Row>
        <Col span={24}>
          <Table
            pagination={false}
            rowKey={modalType === 1 ? 'id' : 'rightsMasterId'}
            columns={columns}
            dataSource={rightsList}
          />
          {modalType === 1 ? (
            <Button
              className="addTableData"
              onClick={addtableData}
              style={{ width: '100%' }}
              type="dashed"
            >
              <PlusOutlined />
              新增
            </Button>
          ) : null}
        </Col>
      </Row>
      <h3 className="title">备注</h3>
      <Row>
        <Col span={24}>
          <Form.Item name="description" label="备注">
            <Input maxLength={250} placeholder="请输入备注" />
          </Form.Item>
        </Col>
      </Row>
    </Form>
  );

  /** 父组件传递数据 */
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          const { description } = values;
          values.selectableRelation = selectableRelation;
          values.vipTag = vipTag;

          let hasComplete = false;
          const list = rightsList.map((item: RightsListType) => {
            const { id, ...ListItem } = item;
            if (
              item.defaultLifeTime === undefined ||
              item.name === undefined ||
              item.number === undefined ||
              item.offsetTime === undefined ||
              item.offsetType === undefined ||
              item.rightsMasterId === undefined
            ) {
              hasComplete = true;
            }
            return ListItem;
          });
          // setRightsList(list)
          if (modalType === 1) {
            if (!hasComplete && rightsList.length) {
              values.rightsList = list;
              resolve(values);
            } else {
              showErrorMessage('请确定是否填写完毕');
            }
          } else {
            resolve({ description, cardMasterId });
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /** 设置数据 */
  function setData(data: any) {
    reset();
    if (Object.keys(data).length) {
      const {
        rightsList: list,
        cardMasterId: detailsId,
        vipTag: vipTags,
        selectableRelation: selectableRelations,
      } = data;
      form.setFieldsValue(data);
      setCardMasterId(detailsId);
      setRightsList(list);
      setVipTag(vipTags);
      setSelectableRelation(selectableRelations);
      setDetails(data);
    }
  }
  // 重置数据
  function reset() {
    setVipTag(false);
    setSelectableRelation(false);
    form.resetFields();
    setCardMasterId(undefined);
    setRightsList([]);
  }
});
export default AddOrViewDetails;

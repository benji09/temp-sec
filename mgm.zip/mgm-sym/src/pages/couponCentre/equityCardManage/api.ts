import { checkIsNumberForSearch } from '@/utils/utils';
import { postRequest } from '@/services/api';

import type {
  ListCardMasterType,
  ListCardMasterParams,
  ListRightsMasterData,
  ListRightsMasterType,
  ContentType,
  UpdateCardMasterType,
} from './typings';

// 查询权益卡列表
const listCardMaster = async (data: ListCardMasterParams) => {
  const { current, pageSize, cardMasterId, name, planCode, ...rest } = data;
  const checkCardMasterIdResult = checkIsNumberForSearch(cardMasterId, 'ID');
  if (checkCardMasterIdResult !== null) return checkCardMasterIdResult;
  const msg = (await postRequest(`/rights/list-card-master`, {
    cardMasterId,
    name,
    planCode,
    page: (current || 1) - 1,
    size: pageSize,
    ...rest,
  })) as unknown as APIS.BaseResponse<ListCardMasterType>;
  return {
    data: msg.result?.content || [],
    total: msg.result?.totalElements || 0,
  };
};
// 搜索权益列表
const listRightsMaster = async (data: ListRightsMasterData) => {
  return (await postRequest('/rights/list-rights-master', data)) as unknown as APIS.BaseResponse<
    ListRightsMasterType[]
  >;
};
// 保存新增 配置权益卡
const createCardMaster = async (data: ContentType) => {
  return (await postRequest(
    '/rights/create-card-master',
    data,
  )) as unknown as APIS.BaseResponse<any>;
};

// 限额和详细更改
const updateCardMaster = async (data: UpdateCardMasterType) => {
  return (await postRequest(
    '/rights/update-card-master',
    data,
  )) as unknown as APIS.BaseResponse<any>;
};

export { listCardMaster, listRightsMaster, createCardMaster, updateCardMaster };

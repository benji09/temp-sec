import type { ReactNode } from 'react';

interface ListCardMasterParams {
  current?: number;
  pageSize?: number;
  cardMasterId?: number;
  name?: string;
  planCode?: string;
}
interface ContentType {
  cardMasterId?: string;
  cat?: string;
  createdAt?: string;
  description?: string;
  expireMessage?: string;
  showType?: string;
  group?: string;
  maxRelation?: number;
  name?: string;
  planCode?: string;
  rightsList?: RightsListType;
  updatedAt?: string;
  selectableRelation?: boolean;
  vipTag?: boolean;
  createdNumber?: number;
  limitNumber?: number;
  warnNumber?: number;
  limitCreate?: boolean;
}
interface CeilDetailsType {
  name?: string;
  createdNumber?: number;
  limitNumber?: number;
  warnNumber?: number;
  limitCreate?: boolean;
  changeLimitNumber?: number;
  cardMasterId?: string;
}
interface ListCardMasterType {
  content?: ContentType[];
  number?: number;
  size?: number;
  totalElements?: number;
  totalPages?: number;
}
interface ListRightsMasterData {
  keyword?: string;
}
interface ListRightsMasterType {
  code?: string;
  name?: string;
  rightsMasterId?: string;
}
interface RightsListType {
  code?: string;
  id?: number;
  defaultLifeTime?: number;
  name?: string | number;
  number?: number | string;
  offsetTime?: number;
  offsetType?: string;
  rightsMasterId?: string | number;
  defaultLifeTime?: number | string;
}
interface UpdateCardMasterType {
  description?: string;
  detailsId?: string | number;
}

interface PropsType {
  modalType?: number;
  ceilDetails?: any;
}

interface ModalPropsType {
  modalType?: number;
  title?: string;
  EquilCardVisible?: boolean;
  visible?: boolean;
  btnLoading?: boolean;
  onOk: () => void;
  onCancel: () => void;
  onSaveData: () => void;
  onCancelData: () => void;
  children?: ReactNode;
}
interface SelectValueType {
  label: string;
  key: string;
  value: string;
}
export {
  ContentType,
  CeilDetailsType,
  ListCardMasterType,
  ListCardMasterParams,
  ListRightsMasterData,
  ListRightsMasterType,
  RightsListType,
  UpdateCardMasterType,
  PropsType,
  ModalPropsType,
  SelectValueType,
};

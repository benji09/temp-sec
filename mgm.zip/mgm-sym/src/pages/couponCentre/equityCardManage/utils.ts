export const rightsoffsetTypeTable = {
  YYQ: {
    text: '生效期',
  },
  DDQ: {
    text: '犹豫期',
  },
  SXQ: {
    text: '生效期',
  },
};
export function rightsoffsetType(offsetType: string | undefined): string {
  if (offsetType === undefined) return '';
  switch (offsetType) {
    case 'YYQ':
      return '身份证';
    case 'DDQ':
      return '护照';
    case 'SXQ':
      return '军官证';
    default:
      return '';
  }
}

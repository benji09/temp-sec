import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import {
  generateActivateCodeList,
  activationCodeDownload,
  activationCodeDetail,
} from '@/services/api';
import { checkPermission, CODE_ADD, CODE_DOWNLOAD, CODE_DETAILED } from '@/utils/power';

import AddModal from './components/addModal';
import { showErrorMessage } from '@/mamagement/Notification';
import { ClickDownXlsx } from '@/utils/downXlsx';

const permissionGroups = [CODE_ADD, CODE_DOWNLOAD, CODE_DETAILED];
export default (): React.ReactNode => {
  const [ModalVisible, setModalVisible] = useState(false);
  const actionRef = useRef<ActionType | undefined>();
  const [title, setTitle] = useState<string>('');
  const AddModalRef = useRef<any>();

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  const onSubmit = () => {
    setModalVisible(false);
    actionRef.current?.reload();
  };
  const onCancel = () => {
    setModalVisible(false);
  };

  const columns: ProColumns[] = [
    {
      title: 'SKU',
      dataIndex: 'skuNo',
      hideInTable: true,
    },
    {
      title: '生成时间',
      dataIndex: 'genTime',
      hideInSearch: true,
    },
    {
      title: '权益卡SKU',
      dataIndex: 'skuNo',
      hideInSearch: true,
    },
    {
      title: '权益卡名称',
      dataIndex: 'goodsName',
      hideInSearch: true,
    },
    {
      title: '最后激活日期',
      dataIndex: 'lastActivationDate',
      hideInSearch: true,
    },
    {
      title: '生成数量',
      dataIndex: 'genCount',
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => {
        return (
          <>
            {powers[`${CODE_DOWNLOAD}`] && (
              <Button
                type="link"
                onClick={() => {
                  activationCodeDownload(record.batchNo).then((res) => {
                    const { size } = res;
                    if (size <= 500) {
                      showErrorMessage('数据流异常，无法正常下载');
                      return;
                    }
                    ClickDownXlsx(res, record.batchNo);
                  });
                }}
              >
                下载激活码
              </Button>
            )}
            {powers[`${CODE_DETAILED}`] && (
              <Button
                type="link"
                onClick={() => {
                  activationCodeDetail(record.id).then((res: any) => {
                    AddModalRef.current.setData(res.result);
                    setModalVisible(true);
                    setTitle('查看');
                  });
                }}
              >
                查看
              </Button>
            )}
          </>
        );
      },
    },
  ];
  return (
    <PageContainer>
      <ProTable<APIS.RightCardItem>
        actionRef={actionRef}
        columns={columns}
        request={generateActivateCodeList}
        rowKey="id"
        dateFormatter="string"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          powers[`${CODE_ADD}`] && (
            <Button
              key="primary"
              type="primary"
              onClick={() => {
                setModalVisible(true);
                setTitle('新增');
              }}
            >
              <PlusOutlined />
              新增
            </Button>
          ),
        ]}
      />
      <AddModal
        ref={AddModalRef}
        ModalVisible={ModalVisible}
        title={title}
        onSubmit={onSubmit}
        onCancel={onCancel}
      />
    </PageContainer>
  );
};

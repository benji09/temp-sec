/* eslint-disable react-hooks/exhaustive-deps */

import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import {
  Modal,
  Select,
  Input,
  Form,
  Popconfirm,
  Button,
  Col,
  Image,
  Upload,
  InputNumber,
} from 'antd';
import ProTable from '@ant-design/pro-table';
import type { ProColumns } from '@ant-design/pro-table';
import { CloseCircleOutlined, PlusOutlined } from '@ant-design/icons';

import { cardSingleMobilePhoneReg } from '@/utils/RegExp';
import { checkImageTypeAndSize, useDebounce } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import {
  rightsCardName,
  rightsCardDetails,
  ActivationCodeInsert,
  getCosDownladUrl,
  uploadFile,
} from '@/services/api';

import './index.less';

const { Option } = Select;

export type EditModalProps = {
  ModalVisible: boolean;
  title: string;
  onSubmit: () => void;
  onCancel: () => void;
};
type optionItemType = {
  goodsInfo: string;
  skuNo: string;
};
type goodsInfosType = {
  code?: string;
  description?: string;
  isInfinitely?: boolean;
  name?: string;
  number?: number;
  order?: number;
  rightsMasterId?: string;
  unit?: string;
  usableOffset?: number;
};
type cardType = {
  goodsInfos?: goodsInfosType[];
  lastActivationDate?: string;
  validDays?: string;
};
const EditModal = forwardRef((props: EditModalProps, ref) => {
  const { ModalVisible, title, onSubmit, onCancel } = props;
  const [certify, setCertify] = useState<string>('');

  const [form] = Form.useForm();
  const [visible, setVisible] = useState<boolean>(false);
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);
  const [card, setCard] = useState<cardType | goodsInfosType[]>({});

  const [optionItem, setOptionItem] = useState<optionItemType[]>([]);
  const [searchParam, setSearchParam] = useState<string>('');
  const [details, setDetails] = useState({});

  // 保存数据（二次确认）
  const handleOk = () => {
    setConfirmLoading(true);
    ActivationCodeInsert({ ...details, certify }).then((res) => {
      setConfirmLoading(false);
      setVisible(false);
      if (res.status === 0) {
        showSuccessMessage('操作成功');
        reset();
        onSubmit();
      }
    });
  };
  // 第一次点击确认
  const verifyData = (values: any) => {
    setDetails(values);
    setVisible(true);
  };
  // 取消保存
  const handleCancel = () => {
    setConfirmLoading(false);
    setVisible(false);
    onCancel();
    reset();
  };

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 4 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 20 },
    },
  };

  const uploadProps = {
    beforeUpload: checkImageTypeAndSize,
  };

  const columns: ProColumns<goodsInfosType>[] = [
    {
      title: '序号',
      dataIndex: 'name',
      render: (text, record, index) => <>{index + 1}</>,
    },
    {
      title: '权益',
      dataIndex: 'name',
      render: (text, record) => (
        <>
          {text} {record.code}
        </>
      ),
    },
    {
      title: '可使用',
      dataIndex: 'number',
      render: (text: any, record) => <>{record.isInfinitely ? '不限次' : text + record.unit}</>,
    },
    {
      title: '延迟生效时间',
      key: 'usableOffset',
      render: (_text: any, record) => <>{record.usableOffset}</>,
    },
  ];

  // 获取权益卡名称
  useEffect(() => {
    const temp = searchParam?.trim() || '';
    if (temp && temp.length > 0) {
      rightsCardName(temp).then((res) => {
        setOptionItem(res.result?.goodsSearchInfos);
      });
    } else {
      setOptionItem([]);
    }
  }, [useDebounce(searchParam, 500)]);

  useImperativeHandle(ref, () => ({
    takeData,
    setData,
    reset,
  }));

  return (
    <Modal
      className="issuingEquityAddModal"
      width="60%"
      style={{ minWidth: '720px' }}
      title={title}
      visible={ModalVisible}
      centered
      onCancel={handleCancel}
      destroyOnClose={true}
      footer={[
        <Button key="back" onClick={handleCancel}>
          关闭
        </Button>,
        <span style={{ margin: '8px' }} key="clear">
          {title === '查看' ? (
            ''
          ) : (
            <Popconfirm
              key="submit"
              icon={''}
              title="是否确认制卡？"
              visible={visible}
              okButtonProps={{ loading: confirmLoading }}
              onConfirm={handleOk}
              onCancel={() => {
                setVisible(false);
              }}
            >
              <Button type="primary" onClick={takeData}>
                确定
              </Button>
            </Popconfirm>
          )}
        </span>,
      ]}
    >
      <Form form={form} {...formItemLayout}>
        {title === '查看' ? (
          <Form.Item label="生成时间">
            <span>{form.getFieldValue('genTime')}</span>
          </Form.Item>
        ) : null}
        <h3>权益信息</h3>
        <Form.Item
          label="权益卡名称"
          name="skuNo"
          rules={[{ required: true, message: '请输入权益卡名称' }]}
        >
          {title === '查看' ? (
            <span>{form.getFieldValue('goodsName')}</span>
          ) : (
            <Select
              style={{ width: '100%' }}
              showSearch
              placeholder="请输入权益卡名称"
              showArrow={false}
              filterOption={false}
              onSearch={setSearchParam}
              onChange={(value: number) => {
                rightsCardDetails(value).then((res) => {
                  if (res.status === 0) {
                    setCard(res.result);
                  }
                });
              }}
              notFoundContent={null}
            >
              {optionItem?.map((item: optionItemType) => {
                return (
                  <Option key={item.skuNo} value={item.skuNo}>
                    {item.goodsInfo}
                  </Option>
                );
              })}
            </Select>
          )}
        </Form.Item>
        {Object.keys(card).length ? (
          <>
            <Form.Item label="最后激活日期" style={{ marginBottom: '0' }}>
              <span>
                {' '}
                {title === '查看'
                  ? form.getFieldValue('lastActivationDate')
                  : card.lastActivationDate}{' '}
              </span>
            </Form.Item>
            <Form.Item label="激活后可使用日期" style={{ marginBottom: '0' }}>
              <span> {title === '查看' ? form.getFieldValue('validDays') : card.validDays} </span>
            </Form.Item>
            <ProTable<goodsInfosType>
              columns={columns}
              rowKey="code"
              dataSource={title === '查看' ? card : card.goodsInfos}
              search={false}
              pagination={false}
              options={false}
              size={'small'}
              style={{ padding: '15px' }}
              bordered={true}
            />
          </>
        ) : null}
        <Col span={24} className="generateCardNumber">
          <Form.Item
            label="生成卡数量"
            style={{ width: '50%' }}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 16 }}
            name="genCount"
            rules={[{ required: true, message: '请输入生成卡数量' }]}
          >
            {title === '查看' ? (
              <span>{form.getFieldValue('genCount')}</span>
            ) : (
              <InputNumber
                parser={(values?: string) => {
                  return values ? parseInt(values, 10) : 0;
                }}
                style={{ width: '100%' }}
                min={1}
                placeholder="请输入生成卡数量"
              />
            )}
          </Form.Item>
          <span>张</span>
        </Col>
        <h3>审批信息</h3>
        <Form.Item
          label="关联流水号"
          name="transNo"
          rules={[{ required: true, message: '请输入关联流水号' }]}
        >
          {title === '查看' ? (
            <span>{form.getFieldValue('transNo')}</span>
          ) : (
            <Input maxLength={50} width={'100%'} placeholder="请输入关联流水号" />
          )}
        </Form.Item>
        <Form.Item
          label="业务备注"
          name="remark"
          rules={[{ required: true, message: '请输入业务备注' }]}
        >
          {title === '查看' ? (
            <span>{form.getFieldValue('remark')}</span>
          ) : (
            <Input maxLength={50} width={'100%'} placeholder="请输入业务备注" />
          )}
        </Form.Item>
        <Col>
          <Form.Item label="上传凭证" name={'certifyStr'} initialValue={certify ? [{}] : undefined}>
            {title === '查看' ? (
              certify ? (
                <Image width={100} height="100px" src={certify} />
              ) : null
            ) : (
              <Upload
                accept={'image/*'}
                listType="picture-card"
                className="avatar-uploader "
                showUploadList={false}
                disabled={!!certify}
                customRequest={(options) => customRequest(options)}
                {...uploadProps}
              >
                {certify ? (
                  <div className="portrait">
                    {!certify ? (
                      ''
                    ) : (
                      <i
                        className="imageClose"
                        onClick={() => {
                          setCertify('');
                        }}
                      >
                        <CloseCircleOutlined />
                      </i>
                    )}
                    <img
                      src={certify}
                      alt="上传凭证"
                      style={{ width: '100%', maxHeight: '104px' }}
                    />
                  </div>
                ) : (
                  <PlusOutlined />
                )}
              </Upload>
            )}
          </Form.Item>
        </Col>
      </Form>
    </Modal>
  );

  function customRequest(option: any) {
    uploadFile(option, (key) => {
      setCertify(getCosDownladUrl(key));
    });
  }
  /** 父组件传递数据 */
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          const { certifyStr, ...data } = values;
          if (cardSingleMobilePhoneReg(values.userMobile) || !values.userMobile) {
            verifyData(data);
          } else {
            showErrorMessage('手机号格式不对');
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /** 设置数据 */
  function setData(data: any) {
    reset();
    if (Object.keys(data).length) {
      form.setFieldsValue(data);
      setCard(data.rightsInfos);
      setCertify(data.certify);
    }
  }
  // 重置数据
  function reset() {
    form.resetFields();
    setOptionItem([]);

    setCard({});
    setCertify('');
  }
});
export default EditModal;

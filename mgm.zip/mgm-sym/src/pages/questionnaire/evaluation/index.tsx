import React, { useState, useRef, useEffect } from 'react';
import _ from 'lodash';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import {
  templateList,
  labelGroups,
  addLabels,
  labelLists,
  createQuestion,
  searchQuestion,
} from '@/services/api';
import { formatTime } from '@/utils/utils';
import { showSuccessMessage } from '@/mamagement/Notification';

import ContentModal from './components/contentModal';
import AddQuestion from './components/add';
import TagLibrary from './components/tagLibrary';

interface libraryTypeList {
  id: number;
  name: string;
  remark: string;
  sort: number;
  groupIds: number[];
}

interface labelType {
  id: number;
  name: string;
}

const Evaluation: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [modalType, setModalType] = useState<number>(1);
  const [alreadyList, setAlreadyList] = useState([]);
  const [modalTitle, setModalTitle] = useState<string>('');
  const [currentQuestion, setCurrentQuestion] = useState({});
  const [groups, setGroups] = useState<{ id: number; name: string }[]>([]);
  const tagLibrary = useRef<any>();
  const addQuestion = useRef<any>();
  const contentModal = useRef<any>();

  const columns: ProColumns<APIS.RuleListItem>[] = [
    {
      title: 'ID',
      dataIndex: 'id',
    },
    {
      title: '题目名称',
      dataIndex: 'name',
    },
    {
      title: '创建时间',
      valueType: 'option',
      render: (text, record: any) => {
        return <span>{formatTime(record.createdTime)}</span>;
      },
    },
    {
      title: '题目类型',
      dataIndex: 'type',
      valueEnum: {
        1: {
          text: '单选题',
        },
        2: {
          text: '多选',
        },
        3: {
          text: '填空题',
        },
        4: {
          text: '文件上传',
        },
      },
    },
    {
      title: '备注',
      valueType: 'option',
      dataIndex: 'description',
      render: (text, record: any) => {
        return <span>{record.description}</span>;
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (text, record) => [
        <a
          key="editor"
          onClick={() => {
            showModal(2, record.id);
          }}
        >
          编辑
        </a>,
      ],
    },
  ];

  useEffect(() => {
    labelGroups({}).then((res: any) => {
      if (res.status === 0) {
        setGroups(res.result);
      }
    });
  }, []);

  useEffect(() => {
    if (!modalVisible) {
      addQuestion.current?.reset();
    }
  }, [modalVisible]);

  return (
    <PageContainer>
      <ProTable<APIS.RuleListItem>
        headerTitle={modalTitle}
        actionRef={actionRef}
        rowKey="id"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              showModal(1);
            }}
          >
            标签库
          </Button>,
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              showModal(2);
            }}
          >
            <PlusOutlined /> 新增
          </Button>,
        ]}
        request={templateList}
        columns={columns}
      />

      <ContentModal
        modalVisible={modalVisible}
        onCancel={onCancel}
        ref={contentModal}
        modalTitle={modalTitle}
        onOk={onOk}
      >
        {modalType === 1 && (
          <TagLibrary ref={tagLibrary} alreadyList={alreadyList} groups={groups} key={modalTitle} />
        )}
        {modalType === 2 && (
          <AddQuestion
            ref={addQuestion}
            currentQuestion={currentQuestion}
            modalTitle={modalTitle}
            key={modalTitle}
          />
        )}
      </ContentModal>
    </PageContainer>
  );

  function onCancel() {
    setModalVisible(false);
  }

  function onOk() {
    contentModal.current.setLoading(true);
    if (modalType === 1) {
      tagLibrary.current
        .takeData()
        .then((res: any) => {
          const data = _.cloneDeep(res);
          const result = handleData(data);
          addLabels(result).then((resData) => {
            contentModal.current.setLoading(false);
            if (resData.status === 0) {
              showSuccessMessage('保存成功');
              setModalVisible(false);
            }
          });
        })
        .catch(() => contentModal.current.setLoading(false));
    } else {
      addQuestion.current
        ?.takeData()
        .then((res: any) => {
          createQuestion(res).then((result) => {
            contentModal.current.setLoading(false);
            if (result.status === 0) {
              showSuccessMessage('提交成功');
              actionRef.current?.reload();
              setModalVisible(false);
            }
          });
        })
        .catch(() => contentModal.current.setLoading(false));
    }
  }

  function handleData(data: any) {
    const keys = Object.keys(data);
    const newArray: libraryTypeList[] = [];
    keys.forEach((item) => {
      if (Number(item) < 0) {
        data[item].id = 0;
      }
      newArray.push(data[item]);
    });
    return newArray;
  }

  function showModal(type: number, id?: number) {
    if (type === 1) {
      labelLists({}).then((res) => {
        if (res.status === 0) {
          setAlreadyList(res.result);
          setModalTitle('标签库');
          setModalVisible(true);
        }
      });
    } else {
      if (!id) {
        setModalVisible(true);
        setModalType(type);
        setModalTitle('新增');
        setCurrentQuestion({
          type: 1,
          labels: [],
          other: false,
        });
        return;
      }
      searchQuestion({ questionId: id }).then((res) => {
        if (res.status === 0) {
          const {
            type: questionType,
            sort,
            labels,
            name,
            desc,
            remark,
            options,
            createdTime,
            id: questionId,
            createdName,
            updatedTime,
            updatedName,
            required,
          } = res.result;
          setCurrentQuestion({
            type: questionType,
            sort,
            name,
            desc,
            remark,
            labels: handleLabels(labels),
            options: options.length && handleOptions(options),
            other: options.length && options[options.length - 1].name === '其他',
            id: questionId,
            createdTime,
            createdName,
            updatedName,
            updatedTime,
            required,
            group: creadGroup(labels),
          });
          setModalTitle('编辑');
          setModalVisible(true);
        }
      });
    }
    setModalType(type);
  }

  // 处理数据
  function handleLabels(labels: labelType[]) {
    return labels.map((label: labelType) => {
      const { name } = label;
      return name;
    });
  }

  function handleOptions(options: any) {
    const newData = {};
    options.forEach((option: any, index: number) => {
      if (option.name !== '其他') {
        newData[`label${index + 1}`] = option.name;
      }
    });
    return newData;
  }

  function creadGroup(labels: labelType[]) {
    return labels.map((label: labelType) => {
      const { id, name } = label;
      return {
        id,
        name,
        value: name,
        label: name,
      };
    });
  }
};

export default Evaluation;

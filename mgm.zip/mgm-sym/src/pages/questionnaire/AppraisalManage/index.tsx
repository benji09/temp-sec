import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { timeStamp } from '@/utils/formatDate';
import { getAppraisalManageList } from '@/services/api';

import Assess from './components/assess';

type GetAppraisalItem = {
  assessmentId: string;
  createdAt?: number;
  doctorName?: string;
  labelTexts?: string[];
  questions?: [];
  remark?: string;
  reports?: [];
  status?: number;
  type?: number;
  updatedAt?: number;
  userName?: string;
};

const AppraisalManage: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();

  const [assessVisible, handleAssessVisible] = useState<boolean>(false);
  const [assessmentId, setAssessmentId] = useState<string>('');
  const [modalTitle, setModalTitle] = useState<string>('');

  const columns: ProColumns<GetAppraisalItem>[] = [
    {
      title: 'ID',
      key: 'assessmentId',
      dataIndex: 'assessmentId',
    },
    {
      title: '测评用户',
      key: 'userName',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: '测评提交时间',
      key: 'createdAt',
      hideInSearch: true,
      render: (_text, record) => {
        return timeStamp(record.createdAt);
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      valueType: 'select',
      valueEnum: {
        0: {
          text: '全部',
        },
        1: {
          text: '待评估',
        },
        2: {
          text: '已完成',
        },
      },
    },
    {
      title: '问卷场景',
      dataIndex: 'type',
      key: 'type',
      valueType: 'select',
      valueEnum: {
        0: {
          text: '全部',
        },
        1: {
          text: '个人健康评估',
        },
      },
    },
    {
      title: '用户 ID',
      key: 'userId',
      hideInTable: true,
    },
    {
      title: '完成评估时间',
      key: 'updatedAt',
      hideInSearch: true,
      render: (_text, record) => {
        if (record.status === 2) {
          return timeStamp(record.updatedAt);
        }
        return '-';
      },
    },
    {
      title: '评估医生',
      key: 'doctorName',
      dataIndex: 'doctorName',
      hideInSearch: true,
    },
    {
      title: '操作',
      key: 'action',
      hideInSearch: true,

      render: (_text, record) => [
        <Button
          type="link"
          key="config"
          title={record.status === 2 ? '查看' : '评估'}
          onClick={() => {
            setModalTitle(record.status === 2 ? '查看' : '评估');
            setAssessmentId(record.assessmentId);
            handleAssessVisible(true);
          }}
        >
          {record.status === 2 ? '查看' : '评估'}
        </Button>,
      ],
    },
  ];

  return (
    <PageContainer>
      <ProTable<GetAppraisalItem>
        columns={columns}
        actionRef={actionRef}
        request={getAppraisalManageList}
        rowKey="assessmentId"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{
          defaultPageSize: 10,
        }}
        dateFormatter="string"
      />
      <Assess
        assessVisible={assessVisible}
        title={modalTitle}
        assessmentId={assessmentId}
        onSubmit={() => {
          setAssessmentId('');
          actionRef.current?.reload();
          handleAssessVisible(false);
        }}
        onCancel={() => {
          setAssessmentId('');
          handleAssessVisible(false);
        }}
      />
    </PageContainer>
  );
};
export default AppraisalManage;

import React, { useRef, useState } from 'react';
import { Button } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/TableLocal';

import { getUsersReportList, reportDetail, reportUpdate, reportUpload } from './api';
import Modal from './components/Modal';
import Particulars from './components/Particulars';
import UpLoadFilePdf from './components/UpLoadFilePdf';
import type { GetUsersReportListType } from './typings';
import { CategoryStatus, CategoryType } from './util';

const MODAL_TYPE_DETAIL = 1;
const MODAL_TYPE_UPLOAD = 2;

const UsersReport: React.FC = () => {
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [ModalVisible, setModalVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const [patientId, setPatientId] = useState<number | undefined>(undefined);

  const actionRef = useRef<ActionType | undefined>();
  const ParticularsRef = useRef<any>();
  const UpLoadFilePdfRef = useRef<any>();

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_DETAIL:
        return '报告详情';
      case MODAL_TYPE_UPLOAD:
        return '上传报告';
    }
    return '';
  }

  const onModalOk = () => {
    if (modalType === 1) {
      ParticularsRef.current?.takeData().then((data: any) => {
        setLoading(true);
        reportUpdate({ patientId: patientId, files: data }).then((res) => {
          setLoading(false);
          if (res.status === 0) {
            setModalType(undefined);
            setModalVisible(false);
            actionRef.current?.reload();
          }
        });
      });
    } else if (modalType === 2) {
      UpLoadFilePdfRef.current?.takeData().then((data: any) => {
        setLoading(true);
        reportUpload({ patientId: patientId, files: [data] }).then((res) => {
          setLoading(false);
          if (res.status === 0) {
            setModalType(undefined);
            setModalVisible(false);
            actionRef.current?.reload();
          }
        });
      });
    }
  };
  const onModalCancel = () => {
    setLoading(false);
    setModalType(undefined);
    setModalVisible(false);
    ParticularsRef.current?.reset();
    UpLoadFilePdfRef.current?.reset();
  };

  // 点击操作中的事件
  const onClickOperate = (type: number, record: GetUsersReportListType) => {
    setPatientId(record.patientId || 0);
    setModalType(type);
    setModalVisible(true);
    if (type === 1) {
      reportDetail(record.patientId).then((res) => {
        if (res.status === 0) {
          ParticularsRef.current?.setData(res.result);
        }
      });
    }
  };
  const columns: ProColumns<GetUsersReportListType>[] = [
    {
      title: '用户ID',
      dataIndex: 'patientId',
    },
    {
      title: '用户手机号',
      dataIndex: 'mobile',
      hideInTable: true,
    },
    {
      title: '用户账号',
      dataIndex: 'account',
      hideInSearch: true,
    },
    {
      title: '报告类别',
      dataIndex: 'fileMap',
      render: (_text, record) => {
        const reportList: string[] = [];
        Object.keys(record.fileMap).map((item) => {
          reportList.push(CategoryType(Number(item)));
        });
        return reportList.join(',');
      },
      valueEnum: CategoryStatus,
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        <Button
          key="view"
          type="link"
          onClick={() => {
            onClickOperate(MODAL_TYPE_DETAIL, record);
          }}
        >
          详情
        </Button>,
        <Button
          key="uploading"
          type="link"
          onClick={() => {
            onClickOperate(MODAL_TYPE_UPLOAD, record);
          }}
        >
          上传报告
        </Button>,
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="UsersReport"
      columns={columns}
      actionRef={actionRef}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={getUsersReportList}
      pagination={false}
      rowKey="patientId"
    >
      <Modal
        title={getModalTitle()}
        loading={loading}
        ModalVisible={ModalVisible}
        onOk={onModalOk}
        onCancel={onModalCancel}
      >
        {modalType === 1 && <Particulars ref={ParticularsRef} />}
        {modalType === 2 && <UpLoadFilePdf ref={UpLoadFilePdfRef} />}
      </Modal>
    </TableLocal>
  );
};
export default UsersReport;

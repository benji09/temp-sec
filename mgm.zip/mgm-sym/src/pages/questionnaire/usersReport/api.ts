// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { checkIsNumberForSearch, HOST_TYPE_POWER } from '@/utils/utils';

import type { GetToolsListDataType } from './typings';

// Banner列表
const getUsersReportList = async (params: GetToolsListDataType) => {
  const { patientId, mobile } = params;
  const UserIdResult = checkIsNumberForSearch(params.patientId, 'userId');
  if (UserIdResult !== null) return UserIdResult;
  if (patientId || mobile) {
    const msg: any = await await request('/report/detail', {
      host: POWER_HOST,
      type: HOST_TYPE_POWER,
      method: 'GET',
      params: { patientId, mobile },
    });
    return {
      data: msg.result || [],
    };
  }
  return {
    data: [],
  };
};
const reportUpload = async (data: any) => {
  return await request('/report/upload', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
const reportDetail = async (patientId?: number) => {
  return await request('/report/detail', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { patientId },
  });
};
const reportUpdate = async (data: any) => {
  return await request('/report/update', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export { getUsersReportList, reportUpload, reportDetail, reportUpdate };

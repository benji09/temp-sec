import type { ReactNode } from 'react';

type GetUsersReportListType = {
  patientId?: number;
  account?: string;
  fileMap?: any;
};
type ModalPropType = {
  ModalVisible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children: ReactNode;
};
type ParticularsDetailsType = {
  fileUrl?: string;
  fileName?: string;
  type?: number;
};
type ReportFileType = {
  fileUrl?: string;
  fileName?: string;
};
type GetToolsListDataType = {
  patientId?: string;
  mobile?: string;
  current?: number;
  pageSize?: number;
};

export {
  GetUsersReportListType,
  ModalPropType,
  ParticularsDetailsType,
  ReportFileType,
  GetToolsListDataType,
};

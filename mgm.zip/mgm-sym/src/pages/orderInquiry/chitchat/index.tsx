/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from 'react';
import { history } from 'umi';
import { List, Image, Card, Row, Col } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import { formatDate } from '@/utils/formatDate';
import { getChitchatList, getCosDownlad, OrderDetailsData } from '@/services/api';

import type { dataSourceType } from './typings';

import './index.less';

const Chitchat: React.FC = () => {
  const orderId: string | undefined = String(history.location.query?.orderId) || undefined;
  const [dataSource, setDataSource] = useState<dataSourceType[]>([]);
  const [detailsData, SetDetailsData] = useState<APIS.MedicalOrdersDetails>({});
  const [loading, setLoading] = useState<boolean>(false);

  function ChitchatDetails(params: any) {
    setLoading(true);
    // 获取聊天记录
    getChitchatList(params)
      .then((res) => {
        const { status, result } = res;
        if (status === 0) {
          const { content } = result;
          content.forEach((item: dataSourceType, index: number) => {
            if (item.userId === -1 && item.messageType === 6) {
              content.splice(index, 1);
            }
          });
          setDataSource(content);
        }
      })
      .finally(() => {
        setLoading(false);
      });
  }
  useEffect(() => {
    if (orderId) {
      ChitchatDetails({ orderId, size: 10000, page: 1 });
      OrderDetailsData(Number(orderId))
        .then((res) => {
          if (res && res.status === 0) SetDetailsData(res.result);
        })
        .finally(() => setLoading(false));
    }
  }, [orderId]);

  const getGender = (gender?: number) => {
    if (gender === undefined || gender === null) return '';
    switch (gender) {
      case 0:
        return '男';
      case 1:
        return '女';
    }
    return '';
  };

  return (
    <PageContainer>
      <Card className="ChitchatDetails" loading={loading}>
        <h3 className="title">订单详情</h3>
        <Row>
          <Col span={12}>订单ID: {orderId}</Col>
          <Col span={12}>创建时间: {detailsData.createTime}</Col>
          <Col span={12}>订单类型: {detailsData.orderType}</Col>
          <Col span={12}>结束时间: {detailsData.endTime}</Col>
          <Col span={12}>医生姓名: {detailsData.doctorName}</Col>
          <Col span={12}>医助名称: {detailsData.assistantName}</Col>
          <Col span={12}>就诊人姓名: {detailsData.diagnoseName}</Col>
          <Col span={12}>性别: {getGender(detailsData.diagnoseGender)}</Col>
          <Col span={12}>出生日期: {detailsData.diagnoseBirthDay}</Col>
        </Row>
        <h3 className="title spaceTopLarge">聊天记录</h3>
        <List
          className="ChitchatList"
          itemLayout="horizontal"
          dataSource={dataSource}
          renderItem={(item: dataSourceType) => (
            <List.Item>
              <List.Item.Meta
                title={
                  <div className="chitchatUserMsg">
                    <span>
                      {item.messageType === 6 || item.messageType === 12
                        ? '系统信息'
                        : item.userName}
                    </span>
                    <span> {formatDate(item.sendTime)}</span>
                  </div>
                }
                description={
                  item.messageType !== 2 ? (
                    item.content
                  ) : (
                    <Image.PreviewGroup>
                      <Image width={100} src={getCosDownlad(item.content)} />
                    </Image.PreviewGroup>
                  )
                }
              />
            </List.Item>
          )}
        />
      </Card>
    </PageContainer>
  );
};
export default Chitchat;

type dataSourceType = {
  content: string;
  messageType: number;
  sendTime: number;
  userId: number;
  userName: string;
};
export { dataSourceType };

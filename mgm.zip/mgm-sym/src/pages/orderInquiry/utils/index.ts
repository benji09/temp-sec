export const orderStatus = {
  320: {
    text: '排队中',
  },
  330: {
    text: '排队中',
  },
  340: {
    text: '问诊中',
  },
  350: {
    text: '未完成小结',
  },
  90000: {
    text: '取消',
  },
  200000: {
    text: '完成',
  },
  210000: {
    text: '自动完成',
  },
};

export const payStatus = {
  0: {
    text: '免除',
  },
  320: {
    text: '-',
  },
  330: {
    text: '-',
  },
  340: {
    text: '-',
  },
  350: {
    text: '-',
  },
  90000: {
    text: '-',
  },
  200000: {
    text: '权益',
  },
};

export const orderTypeStatus = {
  1: {
    text: '快速问医生',
  },
  2: {
    text: '我要挂专家',
  },
  3: {
    text: '视频问诊',
  },
  4: {
    text: '重疾住院协助',
  },
  5: {
    text: '咨询专家',
  },
  15: {
    text: '义诊',
  },
  500: {
    text: '减重咨询',
  },
  301: {
    text: '康养视频问诊',
  },
  303: {
    text: '一键呼叫健康管家',
  },
  400: {
    text: '商城开方问诊',
  },
  401: {
    text: '商城购药问诊',
  },
};
export function OrderStatus(status?: null | number) {
  if (status === undefined || status === null) return '';
  switch (status) {
    case 0: {
      return '初始化订单';
    }
    case 50: {
      return '订单审核通过/订单待提交';
    }
    case 100: {
      return '提交订单';
    }
    case 150: {
      return '取消';
    }
    case 200: {
      return '已支付';
    }
    case 250: {
      return '退款';
    }
    case 300: {
      return '制药中';
    }
    case 350: {
      return '配货中';
    }
    case 400: {
      return '配送中';
    }
    case 500: {
      return '妥投';
    }
    case 550: {
      return '妥投并提交权益';
    }
    case 1000: {
      return '订单关闭(已流传)';
    }
    case 1050: {
      return '订单关闭(未流传)';
    }
    case 1999: {
      return '已作废';
    }
  }
  return '';
}

export function ShopInfosStatus(status?: null | number) {
  if (status === undefined || status === null) return '';
  switch (status) {
    case 1: {
      return '叮当';
    }
    case 2: {
      return '宝中堂';
    }
    case 3: {
      return '小药药';
    }
    case 4: {
      return '商城';
    }
    case 5: {
      return '商城';
    }
  }
  return '';
}

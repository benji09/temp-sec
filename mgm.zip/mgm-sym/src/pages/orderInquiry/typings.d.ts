type PrescribeProps = {
  orderId?: string;
  Visible?: boolean;
  onSubmit?: () => void;
};
type ShopsType = {
  bigImgUrl?: string;
  brandName?: string;
  comments?: string;
  dosage?: string;
  dosageUnit?: string;
  medicineFreq?: string;
  midImgUrl?: string;
  name?: string;
  prescription?: boolean;
  price?: string;
  skuId?: string;
  smallImgUrl?: string;
  spec?: string;
  totalCharge?: string;
  totalDosage?: string;
  usage?: string;
  totalDosageUnit?: string;
};
type dataItemType = {
  medicalOrder?: string;
  orderStatus?: number;
  type?: number;
  shops?: ShopsType[];
  pregnant?: string;
  weight?: string;
  diseaesName?: string;
  allergies?: string;
  contraindications?: string;
};
export { PrescribeProps, ShopsType, dataItemType };

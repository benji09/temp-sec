import React from 'react';
import { history, KeepAlive } from 'umi';
import { Button, DatePicker } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import { getServiceChat } from '@/services/api';

import { orderStatus } from '../utils/index';

const { RangePicker } = DatePicker;

type ServiceChatItem = {
  assistantId?: number;
  assistantName?: string;
  createdAt?: number;
  gender?: number;
  orderId?: number;
  orderType?: number;
  providerId?: number;
  sessionId?: number;
  status?: number;
  updateAt?: number;
  userId?: number;
  userName?: string;
  usrBirthday?: string;
};

function disabledDate(current: any) {
  //  实际类型 DateType，由于无法导入，暂用 any 代替
  return current && current > new Date();
}
const ServiceChat: React.FC = () => {
  const columns: ProColumns<ServiceChatItem>[] = [
    {
      title: '订单ID',
      dataIndex: 'orderId',
    },
    {
      title: '日期',
      dataIndex: 'TimeDate',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: 'userID',
      dataIndex: 'userId',
      hideInTable: true,
    },
    {
      title: '客服姓名',
      dataIndex: 'assistantName',
    },
    {
      title: '客服ID',
      dataIndex: 'assistantId',
      hideInTable: true,
    },
    {
      title: '用户姓名',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: '开始时间',
      dataIndex: 'createdAt',
      hideInSearch: true,
      render: (_text, record) => {
        return <span>{formatTime(record.createdAt)}</span>;
      },
    },
    {
      title: '结束时间',
      dataIndex: 'updatedAt',
      hideInSearch: true,
      render: (_text, record) => {
        return <span>{formatTime(record.updatedAt)}</span>;
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueType: 'select',
      valueEnum: orderStatus,
      hideInSearch: true,
    },
    {
      title: '操作',
      key: 'action',
      hideInSearch: true,
      render: (_text, record) => [
        <Button
          type="link"
          key="config"
          onClick={() => {
            history.push(
              `/orderInquiry/serviceChat/orderDetails?orderId=${
                record.orderId
              }&title=${'客服咨询'}`,
            );
          }}
        >
          详情
        </Button>,
      ],
    },
  ];

  return (
    <PageContainer>
      <ProTable<ServiceChatItem>
        tableClassName="ServiceChat"
        request={getServiceChat}
        columns={columns}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
          labelWidth: 120,
        }}
        rowKey="orderId"
        dateFormatter="string"
        pagination={{
          defaultPageSize: 10,
        }}
      />
    </PageContainer>
  );
};
export default () => (
  <KeepAlive>
    <ServiceChat />
  </KeepAlive>
);

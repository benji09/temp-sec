/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import _ from 'lodash';
import { history } from 'umi';
import { Card, Col, Row, Button, Divider, Input, Form, List } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import {
  OrderDetailsData,
  OrderDetailsMobile,
  orderNotes,
  ServiceChatDetails,
} from '@/services/api';
import { formatTime } from '@/utils/utils';
import { showErrorMessage } from '@/mamagement/Notification';

import Prescribe from '../components/Prescribe';
import Chitchat from './components/Chitchat/index';

import './index.less';
import ModalContent from '../components/ModalContent';

const { TextArea } = Input;
const MODAL_TYPE_PRESCRIDE = 1;

const OrderDetails: React.FC = () => {
  const [form] = Form.useForm();

  const [modalType, setModalType] = useState<number | undefined>(undefined);

  const [loading, setLoading] = useState<boolean>(false);
  const [detailsData, SetDetailsData] = useState<APIS.MedicalOrdersDetails>({});
  const orderId: string | undefined = String(history.location.query?.orderId) || undefined;
  const title = history.location.query?.title || '';
  const [secrecyValue, setSecrecyValue] = useState<boolean>(false);
  const [PrescribeVisible, setPrescribeVisible] = useState<boolean>(false);
  const [ChitchatVisible, setChitchatVisible] = useState<boolean>(false);
  const [remarkFlag, setRemarkFlag] = useState<boolean>(false);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_PRESCRIDE:
        return '开药详情';
      default:
        return '';
    }
  }

  const getData = () => {
    OrderDetailsData(Number(orderId))
      .then((res) => {
        if (res && res.status === 0) SetDetailsData(res.result);
      })
      .finally(() => setLoading(false));
  };

  // 获取客服咨询详情
  const getServiceData = () => {
    ServiceChatDetails(Number(orderId))
      .then((res) => {
        const { userMobile, createdAt, updatedAt, userBirthday, remark, ...data } = res;
        data.orderType = '客服咨询';
        data.mobile = userMobile;
        data.createTime = formatTime(Number(createdAt));
        data.endTime = formatTime(Number(updatedAt));
        data.userBirthDay = userBirthday;
        data.remarks = remark;
        if (res && res.status !== 0) SetDetailsData(data);
      })
      .finally(() => setLoading(false));
  };
  useEffect(() => {
    if (orderId) {
      setLoading(true);
      if (title === '客服咨询') {
        getServiceData();
      } else {
        getData();
      }
    }
  }, []);
  // 点击查看手机号
  const queryInfo = () => {
    setSecrecyValue(true);
    OrderDetailsMobile(detailsData?.userId)
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(detailsData);
          temp.mobile = res.result;
          SetDetailsData(temp);
        }
      })
      .finally(() => {
        setSecrecyValue(false);
      });
  };
  // 查看手机号
  const getLookButton = (mobile?: string) =>
    (mobile || '').indexOf('*') >= 0 ? (
      <Button type="link" onClick={queryInfo} loading={secrecyValue}>
        查看
      </Button>
    ) : null;
  const getGender = (gender?: number) => {
    return gender === 0 ? '男' : gender === 1 ? '女' : '';
  };
  const DetailsModal = (type?: string) => {
    if (type === '开药详情') {
      setModalType(MODAL_TYPE_PRESCRIDE);
      setPrescribeVisible(true);
    } else if (type === '聊天记录') {
      setChitchatVisible(true);
    }
  };
  const getLookDetails = (type?: string) => {
    return (
      <Button type="link" onClick={() => DetailsModal(type)}>
        查看详情
      </Button>
    );
  };
  const onFinishFailed = () => {
    showErrorMessage(`提交失败，请重试`);
  };
  const onFinish = (values: any) => {
    orderNotes({ orderId: Number(orderId), remark: values.introduction })
      .then((res) => {
        if (res.status === 0) {
          // getData();
          if (title === '客服咨询') {
            getServiceData();
          } else {
            getData();
          }
          setSecrecyValue(false);
          setRemarkFlag(false);
          form.resetFields();
        }
      })
      .catch(() => {
        onFinishFailed();
      });
  };

  return (
    <PageContainer>
      <Card className="orderDetails" loading={loading}>
        <h3>订单详情</h3>
        <Row>
          <Col span={12}>订单ID：{detailsData?.orderId}</Col>
          <Col span={12}>创建时间：{detailsData?.createTime}</Col>
        </Row>
        <Row className="spaceTop">
          <Col span={12}>订单类型：{detailsData?.orderType}</Col>
          <Col span={12}>结束时间：{detailsData?.endTime}</Col>
        </Row>
        {title !== '客服咨询' && (
          <>
            <h3 className="spaceTopLarge">就诊人信息</h3>
            <Row>
              <Col span={8}>姓名：{detailsData?.diagnoseName}</Col>
              <Col span={8}>性别：{getGender(detailsData?.diagnoseGender)}</Col>
              <Col span={8}>出生日期：{detailsData?.diagnoseBirthDay}</Col>
            </Row>
          </>
        )}
        <h3 className="spaceTopLarge">用户信息</h3>
        <Row>
          <Col span={4}>用户ID：{detailsData?.userId}</Col>
          <Col span={4}>姓名：{detailsData?.userName}</Col>
          <Col span={4}>性别：{getGender(detailsData?.gender)}</Col>
          <Col span={6}>出生日期：{detailsData?.userBirthDay}</Col>
          <Col span={6}>
            电话号码：{detailsData?.mobile}
            {getLookButton(detailsData?.mobile)}
          </Col>
        </Row>
        {title !== '客服咨询' && (
          <>
            <h3 className="spaceTopLarge">咨询医生信息</h3>
            <Row>
              <Col span={12}>医助姓名：{detailsData?.assistantName}</Col>
              <Col span={12}>医生姓名：{detailsData?.doctorName}</Col>
            </Row>
          </>
        )}
        {title !== '客服咨询' && (
          <>
            <h3 className="spaceTopLarge">主诉</h3>
            <Row>
              <Col span={24}>{detailsData?.appeal}</Col>
            </Row>
          </>
        )}
        {title !== '客服咨询' && detailsData?.diagnosis && (
          <>
            <h3 className="spaceTopLarge">诊断</h3>
            <Row>
              <Col span={24}>{detailsData?.diagnosis}</Col>
            </Row>
          </>
        )}

        {detailsData?.summary && title !== '客服咨询' && (
          <>
            <h3 className="spaceTopLarge">小结建议</h3>
            <Row>
              <Col span={24}>{detailsData?.summary}</Col>
            </Row>
          </>
        )}

        {detailsData?.prescribe && title !== '客服咨询' && (
          <h3 className="spaceTopLarge">开药详情 {getLookDetails('开药详情')}</h3>
        )}
        {detailsData?.chat && title !== '客服咨询' && (
          <h3 className="spaceTopLarge">聊天记录 {getLookDetails('聊天记录')}</h3>
        )}
        {title === '客服咨询' && (
          <h3 className="spaceTopLarge">聊天记录 {getLookDetails('聊天记录')}</h3>
        )}
        <Divider dashed />

        <h3 className="spaceTopLarge">订单备注</h3>
        <Form
          form={form}
          onValuesChange={(changedValues) => {
            if (changedValues.introduction) {
              setRemarkFlag(true);
            } else {
              setRemarkFlag(false);
            }
          }}
          onFinish={onFinish}
          onFinishFailed={onFinishFailed}
        >
          <Row className="orderRemark">
            <Col span={24}>
              <Form.Item name={'introduction'}>
                <TextArea showCount maxLength={250} />
              </Form.Item>
              <Form.Item>
                <Button disabled={!remarkFlag} type="primary" htmlType="submit">
                  提交
                </Button>
              </Form.Item>
            </Col>
          </Row>
        </Form>
        {detailsData?.remarks && detailsData?.remarks.length > 0 && (
          <List
            itemLayout="horizontal"
            dataSource={detailsData?.remarks}
            renderItem={(item) => (
              <List.Item>
                <List.Item.Meta
                  title={
                    <div
                      style={{ display: 'flex', justifyContent: 'space-between' }}
                      className="chitchatUserMsg"
                    >
                      <span>{item.name}</span>
                      <span>
                        {title === '客服咨询' ? formatTime(Number(item.createdAt)) : item.createdAt}
                      </span>
                    </div>
                  }
                  description={item.remarks || item.remark}
                />
              </List.Item>
            )}
          />
        )}
      </Card>

      {/* 开药记录 */}
      <ModalContent
        visible={PrescribeVisible}
        title={getModalTitle()}
        onSubmit={() => {
          setModalType(undefined);
          setPrescribeVisible(false);
        }}
      >
        <Prescribe orderId={detailsData?.orderId} />
      </ModalContent>
      {/* 聊天记录 */}
      <Chitchat
        Visible={ChitchatVisible}
        orderId={orderId}
        onSubmit={() => {
          setChitchatVisible(false);
        }}
      />
    </PageContainer>
  );
};
export default OrderDetails;

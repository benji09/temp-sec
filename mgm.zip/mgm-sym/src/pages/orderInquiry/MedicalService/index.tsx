import React, { useRef, useState } from 'react';
import { history, KeepAlive } from 'umi';
import { Button, DatePicker } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { getMedicalOrders } from '@/services/api';
import TableLocal from '@/components/TableLocal/TableLocal';

import Prescribe from '../components/Prescribe';
import ModalContent from '../components/ModalContent';
import { orderStatus, orderTypeStatus } from '../utils/index';

const { RangePicker } = DatePicker;

function disabledDate(current: any) {
  //  实际类型 DateType，由于无法导入，暂用 any 代替
  return current && current > new Date();
}

const MODAL_TYPE_PRESCRIDE = 1;

const MedicalService: React.FC = () => {
  const [orderId, setOrderId] = useState<string | undefined>(undefined);

  const [modalVisible, setModalVisible] = useState<boolean>(false);

  const [modalType, setModalType] = useState<number | undefined>(undefined);

  const prescribeRef = useRef<any>();
  const actionRef = useRef<ActionType | undefined>();

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_PRESCRIDE:
        return '开药详情';
      default:
        return '';
    }
  }

  const getPayTypeDesc = (status: number, payType: number): string => {
    if (status === 320 || status === 330 || status === 340 || status === 350 || status === 90000)
      return '-';
    return payType === 0 ? '免除' : '权益';
  };

  const columns: ProColumns<APIS.MedicalServiceItem>[] = [
    {
      title: '订单ID',
      dataIndex: 'orderId',
    },
    {
      title: '订单类型',
      dataIndex: 'orderType',
      valueType: 'select',
      valueEnum: orderTypeStatus,
    },
    {
      title: '医生姓名',
      dataIndex: 'doctorName',
    },
    {
      title: '医助姓名',
      dataIndex: 'assistantName',
    },
    {
      title: 'userID',
      dataIndex: 'userId',
      hideInTable: true,
    },
    {
      title: 'providerID',
      dataIndex: 'providerId',
      hideInTable: true,
    },
    {
      title: '就诊人姓名',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: '日期',
      dataIndex: 'TimeDate',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      hideInSearch: true,
    },
    {
      title: '结束时间',
      dataIndex: 'endTime',
      hideInSearch: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueType: 'select',
      valueEnum: orderStatus,
      hideInSearch: true,
    },
    {
      title: '支付方式',
      valueType: 'select',
      hideInSearch: true,
      render: (_text, record, index) => [
        <span key={index}>{getPayTypeDesc(record.status ?? -1, record.payType ?? -1)}</span>,
      ],
    },
    {
      title: '操作',
      key: 'action',
      hideInSearch: true,
      render: (_text, record) => [
        <Button
          type="link"
          key="config"
          onClick={() => {
            history.push(`/orderInquiry/medicalService/orderDetails?orderId=${record.orderId}`);
          }}
        >
          详情
        </Button>,
        <Button
          type="link"
          key="chitchat"
          onClick={() => {
            history.push(`/orderInquiry/medicalService/chitchat?orderId=${record.orderId}`);
          }}
        >
          聊天记录
        </Button>,
        <div key="prescribe">
          {record.medicine ? (
            <Button
              type="link"
              onClick={() => {
                setModalVisible(true);
                setOrderId(record.orderId);
                setModalType(MODAL_TYPE_PRESCRIDE);
              }}
            >
              开药详情
            </Button>
          ) : null}
        </div>,
      ],
    },
  ];

  return (
    <>
      <TableLocal
        tableClassName="MedicalService"
        columns={columns}
        actionRef={actionRef}
        search={{
          labelWidth: 120,
        }}
        request={getMedicalOrders}
        rowKey="orderId"
        dateFormatter="string"
      />
      <ModalContent
        visible={modalVisible}
        title={getModalTitle()}
        onSubmit={() => {
          setModalVisible(false);
          setOrderId(undefined);
        }}
      >
        {modalType === 1 && <Prescribe ref={prescribeRef} orderId={orderId} />}
      </ModalContent>
    </>
  );
};
export default () => (
  <KeepAlive>
    <MedicalService />
  </KeepAlive>
);

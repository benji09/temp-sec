import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import { List, Spin, Image } from 'antd';

import { formatDate } from '@/utils/formatDate';
import { getChitchatList, getCosDownlad } from '@/services/api';

import './Chitchat.less';

type ChitchatProps = {
  orderId?: string | number;
};
type dataSourceType = {
  content: string;
  messageType: number;
  sendTime: number;
  userId: number;
  userName: string;
};
const Chitchat = forwardRef((props: ChitchatProps, ref) => {
  const { orderId } = props;
  const [dataSource, setDataSource] = useState<dataSourceType[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  function ChitchatDetails(params: any) {
    setLoading(true);
    getChitchatList(params)
      .then((res) => {
        const { status, result } = res;
        if (status === 0) {
          const { content } = result;
          content.forEach((item: dataSourceType, index: number) => {
            if (item.userId === -1 && item.messageType === 6) {
              content.splice(index, 1);
            }
          });
          setDataSource(content);
        }
      })
      .finally(() => {
        setLoading(false);
      });
  }
  useEffect(() => {
    if (orderId) {
      ChitchatDetails({ orderId, size: 10000, page: 1 });
    }
  }, [orderId]);

  useImperativeHandle(ref, () => ({}));
  return !loading ? (
    <List
      className="ChitchatList"
      itemLayout="horizontal"
      dataSource={dataSource}
      renderItem={(item: dataSourceType) => (
        <List.Item>
          <List.Item.Meta
            title={
              <div className="chitchatUserMsg">
                <span>
                  {item.messageType === 6 || item.messageType === 12 ? '系统信息' : item.userName}
                </span>
                <span>{formatDate(item.sendTime)}</span>
              </div>
            }
            description={
              item.messageType !== 2 ? (
                item.content
              ) : (
                <Image.PreviewGroup>
                  <Image width={100} src={getCosDownlad(item.content)} />
                </Image.PreviewGroup>
              )
            }
          />
        </List.Item>
      )}
    />
  ) : (
    <Spin />
  );
});
export default Chitchat;

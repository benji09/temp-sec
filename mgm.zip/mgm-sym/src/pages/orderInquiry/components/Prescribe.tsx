import { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import { Table, Spin, Tabs, Row, Col, Space } from 'antd';

import { getPrescribeList } from '@/services/api';

import { OrderStatus, ShopInfosStatus } from '../utils';
import type { dataItemType, PrescribeProps, ShopsType } from '../typings';

const { TabPane } = Tabs;

const ModalContent = forwardRef((props: PrescribeProps, ref) => {
  const { orderId } = props;
  const [data, setData] = useState<dataItemType[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (orderId) {
      setLoading(true);
      getPrescribeList(orderId)
        .then((res) => {
          if (res.status === 0) {
            setData(res.result?.shopInfos ?? []);
          }
        })
        .finally(() => {
          setLoading(false);
        });
    }
  }, [orderId]);

  const columns = [
    {
      title: '序号',
      render: (text: any, record: ShopsType, index: number) => index + 1,
    },
    {
      title: '药品名称',
      dataIndex: 'name',
    },
    {
      title: '品牌名',
      dataIndex: 'brandName',
    },
    {
      title: '规格',
      dataIndex: 'spec',
      key: 'spec',
    },
    {
      title: '用法',
      dataIndex: 'usage',
      key: 'usage',
    },
    {
      title: '用量',
      dataIndex: 'dosage',
      key: 'dosage',
      render: (text: string, record: ShopsType) =>
        `${record.dosage !== '0' ? record.dosage : ''} ${record.dosageUnit}`,
    },
    {
      title: '频率',
      dataIndex: 'medicineFreq',
      key: 'medicineFreq',
    },
    {
      title: '总疗程',
      dataIndex: 'totalCharge',
      key: 'totalCharge',
      render: (text: any) => text + ' 天',
    },
    {
      title: '数量',
      dataIndex: 'totalDosage',
      key: 'totalDosage',
      render: (text: any, record: ShopsType) => `${text} ${record.totalDosageUnit}`,
    },
  ];

  useImperativeHandle(ref, () => ({}));
  return loading ? (
    <Spin />
  ) : (
    <Tabs defaultActiveKey="1">
      {data.map((item, index) => {
        return (
          <TabPane
            tab={`处方笺${data.length - index} ( ${OrderStatus(item.orderStatus)} ) `}
            key={String(index + 1)}
          >
            <Table
              pagination={false}
              columns={columns}
              dataSource={item?.shops || []}
              rowKey="skuId"
              footer={() => {
                return (
                  <Row>
                    <Col span={24}>类型: {ShopInfosStatus(item?.type) || ''} </Col>
                    <Col span={24}>医嘱: {item?.medicalOrder || ''} </Col>

                    <Space size={'middle'} wrap>
                      <Col>是否孕哺: {item?.pregnant ?? ''} </Col>
                      <Col>体重: {(item?.weight && item?.weight + 'kg') ?? ''} </Col>
                      <Col>诊断结果: {item?.diseaesName ?? ''} </Col>
                      <Col>过敏史: {item?.allergies ?? ''} </Col>
                      <Col>用药禁忌: {item?.contraindications ?? ''} </Col>
                    </Space>
                  </Row>
                );
              }}
            />
          </TabPane>
        );
      })}
    </Tabs>
  );
});
export default ModalContent;

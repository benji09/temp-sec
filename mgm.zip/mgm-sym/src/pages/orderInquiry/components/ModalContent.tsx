import React from 'react';
import { Modal } from 'antd';
import type { ReactNode } from 'react';

import './ModalContent.less';

export type PrescribeProps = {
  visible?: boolean;
  orderId?: string;
  title?: string;
  onSubmit: () => void;
  children?: ReactNode;
};
export type dataItemType = {
  brand?: string;
  consumption?: string;
  drugId?: string;
  drugName?: string;
  frequency?: string;
  medicalAdvice?: string;
  size?: number;
  specs?: string;
  totalTreatment?: string;
  usage?: string;
};
const ModalContent: React.FC<PrescribeProps> = (props) => {
  const { visible, onSubmit, children, title } = props;
  const handleOk = () => {
    onSubmit();
  };

  const handleCancel = () => {
    onSubmit();
  };

  return (
    <Modal
      className="OrderModal"
      centered
      width="60%"
      title={title}
      visible={visible}
      onOk={handleOk}
      onCancel={handleCancel}
      destroyOnClose={true}
      footer={null}
    >
      {children}
    </Modal>
  );
};
export default ModalContent;

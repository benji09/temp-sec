import React, { useEffect, useState, useRef } from 'react';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import { showErrorMessage } from '@/mamagement/Notification';
import { getDrugOrderSellList, saleOpenInvoice, saleRefund } from '@/services/api';

import SellMode from './components/SellMode';
import RefundMsg from './components/refundMsg';
import BillingMsg from './components/billingMsg';
import ViewDetails from './components/viewDetails';
import { getListActiveVersion, getLiatStatus, getListSaleType } from './utils/index';

const DrougOrderSell: React.FC = () => {
  const [title, setTitle] = useState<string>();
  const [SellVisible, setSellVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [orderNo, setOrderNo] = useState<string | undefined>(undefined);
  const [logId, setLogId] = useState<string | undefined>(undefined);
  const actionRef = useRef<ActionType | undefined>();

  const [createdTime, setCreatedTime] = useState<string>('');
  const [userId, setUserId] = useState<string>('');
  const viewDetailsRef = useRef<any>();
  const refundMsgRef = useRef<any>();
  const billingMsgRef = useRef<any>();
  const [upData, setUpData] = useState({});
  const onCancel = () => {
    setOrderNo(undefined);
    setLogId(undefined);
    setBtnLoading(false);
    setVisible(false);
    setTimeout(() => {
      setSellVisible(false);
    }, 0);
  };
  const onOk = () => {
    if (title === '退款信息') {
      refundMsgRef.current
        ?.takeData()
        .then((value: any) => {
          setUpData(value);
          setVisible(true);
        })
        .catch(() => {
          showErrorMessage('请确认是否填完信息');
        });
    } else if (title === '开票信息') {
      billingMsgRef.current
        ?.takeData()
        .then((value: any) => {
          setUpData(value);
          setVisible(true);
        })
        .catch(() => {
          showErrorMessage('请确认是否填完信息');
        });
    }
  };
  const onSaveData = () => {
    setBtnLoading(true);
    if (title === '退款信息') {
      saleRefund({ ...upData, logId }).then((res) => {
        setBtnLoading(false);
        setVisible(false);
        if (res.status === 0) {
          setOrderNo(undefined);
          setLogId(undefined);
          actionRef.current?.reload();
          setTimeout(() => {
            setSellVisible(false);
          }, 0);
        }
      });
    } else if (title === '开票信息') {
      saleOpenInvoice({ ...upData, logId }).then((res) => {
        setBtnLoading(false);
        setVisible(false);
        if (res.status === 0) {
          setOrderNo(undefined);
          setLogId(undefined);
          actionRef.current?.reload();
          setTimeout(() => {
            setSellVisible(false);
          }, 0);
        }
      });
    }
  };
  const onCancelSave = () => {
    setVisible(false);
    setBtnLoading(false);
  };
  const columns: ProColumns<APIS.getDrugOrderSellListType>[] = [
    {
      title: '订单号',
      dataIndex: 'orderNo',
    },
    {
      title: '投保人/购买人',
      dataIndex: 'customerName',
      hideInSearch: true,
    },
    {
      title: '销售方式',
      dataIndex: 'saleType',
      hideInSearch: true,
      valueType: 'select',
      valueEnum: getListSaleType,
    },
    {
      title: '激活版本',
      dataIndex: 'activeVersion',
      hideInSearch: true,
      valueType: 'select',
      valueEnum: getListActiveVersion,
    },
    {
      title: '权益状态',
      dataIndex: 'status',
      hideInSearch: true,
      valueType: 'select',
      valueEnum: getLiatStatus,
    },
    {
      title: '是否已退费',
      dataIndex: 'isRefund',
      hideInSearch: true,
      renderText: (text: boolean) => (text ? '已退费' : '未退费'),
    },
    {
      title: '是否已开票',
      dataIndex: 'isOpenInvoice',
      hideInSearch: true,
      renderText: (text: boolean) => (text ? '已开票' : '未开票'),
    },
    {
      title: '数据接收日期',
      dataIndex: 'createdTime',
      hideInSearch: true,
      renderText: (text: number) => formatTime(Number(text)),
    },
    {
      title: '操作',
      key: 'action',
      dataIndex: 'option',
      hideInSearch: true,
      valueType: 'option',
      render: (_text, record) => [
        <a
          key="look"
          onClick={() => {
            setOrderNo(record.orderNo);
            setCreatedTime(record.createdTime || '');
            setTitle('查看');
            setUserId(record.userId || '');
            setSellVisible(true);
          }}
        >
          查看
        </a>,
        <a
          key="refund"
          onClick={() => {
            setLogId(record.id);
            setTitle('退款信息');
            setSellVisible(true);
          }}
        >
          退款信息
        </a>,
        <a
          key="billing"
          onClick={() => {
            setLogId(record.id);
            setTitle('开票信息');
            setSellVisible(true);
          }}
        >
          开票信息
        </a>,
      ],
    },
  ];
  useEffect(() => {});
  return (
    <PageContainer>
      <ProTable<APIS.getDrugOrderSellListType>
        columns={columns}
        actionRef={actionRef}
        request={getDrugOrderSellList}
        rowKey="orderNo"
        dateFormatter="string"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{
          defaultPageSize: 10,
        }}
      />
      <SellMode
        title={title}
        SellVisible={SellVisible}
        btnLoading={btnLoading}
        visible={visible}
        onCancel={onCancel}
        onOk={onOk}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        {title === '查看' ? (
          <ViewDetails
            createdTime={createdTime}
            userId={userId}
            ref={viewDetailsRef}
            orderNo={orderNo}
          />
        ) : null}
        {title === '退款信息' ? <RefundMsg ref={refundMsgRef} logId={logId} /> : null}
        {title === '开票信息' ? <BillingMsg ref={billingMsgRef} logId={logId} /> : null}
      </SellMode>
    </PageContainer>
  );
};
export default DrougOrderSell;

export function getCardNameByCardType(type: number | undefined): string {
  if (type === undefined) return '';
  switch (type) {
    case 0:
      return '身份证';
    case 1:
      return '护照';
    case 2:
      return '军官证';
    case 3:
      return '驾照';
    case 4:
      return '出生证明';
    case 5:
      return '户口薄';
    case 6:
      return '港澳台胞证';
    case 8:
      return '其他';
    default:
      return '';
  }
}
export function getActivationNameByType(type: number | undefined): string {
  if (type === undefined) return '';
  if (type === 0) return '个人版';
  if (type === 1) return '家庭版';
  return '';
}
export function getSalesNameByType(type: number | undefined): string {
  if (type === undefined) return '';
  if (type === 0) return '勾选版';
  if (type === 1) return '单售版';
  return '';
}
export const getListActiveVersion = {
  0: {
    text: '个人版',
  },
  1: {
    text: '家庭版',
  },
};
export const getLiatStatus = {
  1: {
    text: '未领用',
  },
  2: {
    text: '已领用',
  },
};
export const getListSaleType = {
  0: {
    text: '勾选版',
  },
  1: {
    text: '单售版',
  },
};

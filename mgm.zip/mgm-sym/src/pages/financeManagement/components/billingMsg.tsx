/* eslint-disable react-hooks/exhaustive-deps */

import { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { Spin, Form, Col, Row, Input, InputNumber, DatePicker } from 'antd';
import moment from 'moment';

import { EmailReg } from '@/utils/RegExp';
import { formatDate } from '@/utils/formatDate';
import { getFindInvoice } from '@/services/api';
import { showErrorMessage } from '@/mamagement/Notification';

interface modalPropType {
  logId?: string | undefined;
}
const BillingMsg = forwardRef((props: modalPropType, ref) => {
  const { logId } = props;
  const [form] = Form.useForm();
  const [Loading, setLoading] = useState<boolean>(false);
  const [openInvoiceTime, setOpenInvoiceTime] = useState<number | undefined>(undefined);
  const [createTime, setCreateTime] = useState<number | undefined>(undefined);
  const monthFormat = 'YYYY-MM-DD HH:mm:ss';

  useEffect(() => {
    if (logId) {
      setLoading(true);
      getFindInvoice(logId).then((res) => {
        if (res.status === 0) {
          setLoading(false);
          setCreateTime(res.result?.createTime);
          setOpenInvoiceTime(res.result?.openInvoiceTime);
          setData(res.result);
        }
      });
    }
  }, [logId]);

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 6 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 },
    },
  };
  const config = {
    rules: [{ type: 'object' as const, required: true, message: 'Please select time!' }],
  };
  function disabledDate(current: any) {
    return current && current > new Date();
  }
  // 时间转换
  const getMonment = (time: number | undefined) => {
    const day = formatDate(time);
    return time && time > 0 ? moment(day, monthFormat) : undefined;
  };
  useImperativeHandle(ref, () => ({
    takeData,
    setData,
    reset,
  }));

  return (
    <div>
      {!Loading ? (
        <Form form={form} {...formItemLayout} className="assitantModalMsg">
          <Row>
            <Col span={24}>
              <Form.Item label="录入时间">
                <span>{formatDate(Number(createTime))}</span>
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="名称"
                name="invoiceName"
                rules={[{ required: true, message: '请输入名称' }]}
              >
                <Input maxLength={50} placeholder="请输入名称" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="纳税人识别号"
                name="identifierNumber"
                rules={[{ required: true, message: '请输入纳税人识别号' }]}
              >
                <Input maxLength={50} placeholder="请输入纳税人识别号" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="地址"
                name="address"
                rules={[{ required: true, message: '请输入地址' }]}
              >
                <Input maxLength={50} placeholder="请输入地址" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="电话"
                name="mobile"
                rules={[{ required: true, message: '请输入电话' }]}
              >
                <Input maxLength={50} placeholder="请输入电话" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="开户行"
                name="openBank"
                rules={[{ required: true, message: '请输入开户行' }]}
              >
                <Input maxLength={50} placeholder="请输入开户行" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="账号"
                name="bankAccount"
                rules={[{ required: true, message: '请输入账号' }]}
              >
                <Input maxLength={50} placeholder="请输入账号" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="邮箱"
                name="email"
                rules={[{ required: true, message: '请输入邮箱' }]}
              >
                <Input maxLength={50} placeholder="请输入邮箱" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="发票号码"
                name="invoiceNumber"
                rules={[{ required: true, message: '请输入发票号码' }]}
              >
                <Input maxLength={50} placeholder="请输入发票号码" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="开票金额"
                name="invoiceAmount"
                rules={[{ required: true, message: '请输入开票金额' }]}
              >
                <InputNumber
                  min="0"
                  maxLength={20}
                  parser={(values?: string) => {
                    const reg = /^(-)*(\d+)\.(\d\d).*$/;
                    return values ? values.replace(/\s?|(,*)/g, '').replace(reg, '$1$2.$3') : '';
                  }}
                  step={0.01}
                  stringMode
                  style={{ width: '100%' }}
                  placeholder="请输入开票金额"
                />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="开票时间"
                name="openInvoiceTimeStr"
                initialValue={getMonment(openInvoiceTime)}
                {...config}
                rules={[{ required: true, message: '请输入开票时间' }]}
              >
                <DatePicker
                  showTime
                  disabledDate={disabledDate}
                  format="YYYY-MM-DD HH:mm:ss"
                  style={{ width: '100%' }}
                  placeholder="请选择开票时间"
                />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="发票代码"
                name="invoiceCode"
                rules={[{ required: true, message: '请输入发票代码' }]}
              >
                <Input maxLength={50} placeholder="请输入发票代码" />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      ) : (
        <Spin className="loadingContainer" size="large" />
      )}
    </div>
  );

  /** 父组件传递数据 */
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          const { openInvoiceTimeStr, invoiceAmount, ...data } = values;
          data.openInvoiceTime = openInvoiceTimeStr ? new Date(openInvoiceTimeStr).getTime() : '';
          data.invoiceAmount = invoiceAmount ? invoiceAmount * 100 : 0;
          if (!EmailReg(data.email)) {
            showErrorMessage('邮箱格式不对，请确认是否正确');
          } else {
            resolve(data);
          }
        })
        .catch((error) => {
          reject(error);
        });
    });
  }

  /** 设置数据 */
  function setData(data: any) {
    reset();
    if (data !== null && Object.keys(data).length) {
      data.invoiceAmount /= 100;

      form.setFieldsValue(data);
    }
  }
  // 重置数据
  function reset() {
    form.resetFields();
  }
});

export default BillingMsg;

import React from 'react';
import { Modal, Popconfirm, Button } from 'antd';
import type { ReactNode } from 'react';

import './SellMode.less';

interface modalPropType {
  title: string | undefined;
  SellVisible?: boolean;
  btnLoading?: boolean;
  visible?: boolean;
  onCancel: () => void;
  onCancelSave: () => void;
  onOk: () => void;
  onSaveData: () => void;
  children?: ReactNode;
}

const SellMode: React.FC<modalPropType> = (props) => {
  const {
    SellVisible,
    btnLoading,
    title,
    onCancel,
    onOk,
    children,
    visible,
    onSaveData,
    onCancelSave,
  } = props;
  return (
    <Modal
      className="standardModeModal"
      width={720}
      title={title}
      visible={SellVisible}
      centered
      onCancel={() => {
        onCancel();
      }}
      onOk={() => {
        onOk();
      }}
      footer={[
        <Button
          key="back"
          onClick={() => {
            onCancel();
          }}
        >
          关闭
        </Button>,
        <span key="submit">
          {' '}
          {title === '查看' ? null : (
            <Popconfirm
              key="submit"
              icon={''}
              title="是否录入信息?"
              visible={visible}
              onConfirm={onSaveData}
              okButtonProps={{ loading: btnLoading }}
              onCancel={() => {
                onCancelSave();
              }}
            >
              <Button type="primary" onClick={onOk}>
                确定
              </Button>
            </Popconfirm>
          )}{' '}
        </span>,
      ]}
    >
      {children}
    </Modal>
  );
};
export default SellMode;

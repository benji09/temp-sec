import { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import ProTable from '@ant-design/pro-table';
import { Col, Row, Spin, Button } from 'antd';
import type { ProColumns } from '@ant-design/pro-table';

import { timeStamp } from '@/utils/formatDate';
import { formatTime, TIME_FORMAT_DAY } from '@/utils/utils';
import { policySecrecyInfo, getPolicySecrecyInfo } from '@/services/api';

import { getCardNameByCardType, getActivationNameByType, getSalesNameByType } from '../utils/index';

import './viewDetails.less';

interface modalPropType {
  orderNo?: string;
  createdTime?: string;
  userId?: string;
}

const ViewDetails = forwardRef((props: modalPropType, ref) => {
  const { createdTime, userId } = props;
  const [loading, setLoading] = useState<boolean>(false);
  const [detail, setDetail] = useState<APIS.policySecrecyInfoType>();
  const [secrecyValue, setSecrecyValue] = useState<number | undefined>(undefined);
  const [payMobile, setPayMobile] = useState<string | undefined>(undefined);
  const [useMobile, setUseMobile] = useState<string | undefined>(undefined);
  const [cardNo, setCardNo] = useState<string | undefined>(undefined);

  const { orderNo } = props;
  useEffect(() => {
    setLoading(true);
    if (orderNo) {
      policySecrecyInfo({ orderNo, userId }).then((res) => {
        if (res.status === 0) {
          setLoading(false);
          setPayMobile(res.result.mwyPolicyInfo?.policyInfo?.payMobile);
          setUseMobile(res.result.mwyPolicyInfo?.policyInfo?.useMobile);
          setCardNo(res.result.mwyPolicyInfo?.policyInfo?.useIdCard);
          setDetail(res.result);
        }
      });
    }
  }, [orderNo, userId]);

  function getLookUpNode(content: string | undefined, secrecy: number) {
    if (!content || content.trim().length < 1 || content.indexOf('*') < 0) return null;
    return (
      <Button
        type={'link'}
        className="LookButton"
        disabled={secrecyValue !== undefined}
        loading={secrecyValue === secrecy}
        onClick={() => {
          setSecrecyValue(secrecy);
          getPolicySecrecyInfo(String(detail?.mwyPolicyInfo?.policyInfo?.policyId) || '', secrecy)
            .then((res) => {
              if (res.status === 0) {
                if (secrecy === 1) {
                  setPayMobile(res.result);
                } else if (secrecy === 2) {
                  setUseMobile(res.result);
                } else if (secrecy === 3) {
                  setCardNo(res.result);
                }
              }
            })
            .finally(() => setSecrecyValue(undefined));
        }}
      >
        查看
      </Button>
    );
  }

  const columns: ProColumns<APIS.RightsDetail>[] = [
    {
      title: '序号',
      align: 'center',
      render: (_text, _record, index) => <span>{index + 1}</span>,
    },
    {
      title: '权益',
      dataIndex: 'name',
      align: 'center',
    },
    {
      title: '剩余可使用',
      align: 'center',
      renderText: (_text, record) => (record.infinitely ? '无限次' : `${record.number}`),
    },
    {
      title: '生效日期',
      dataIndex: 'usableTime',
      align: 'center',
      renderText: (text) => formatTime(Number(text), TIME_FORMAT_DAY),
    },
    {
      title: '失效日期',
      dataIndex: 'overdueTime',
      align: 'center',
      renderText: (text) => formatTime(Number(text), TIME_FORMAT_DAY),
    },
    {
      title: '状态',
      dataIndex: 'usable',
      align: 'center',
      renderText: (text) => (text ? '可用' : '不可用'),
    },
  ];
  function rightsState() {
    return (
      <ProTable<APIS.RightsDetail>
        className={'rightsTable'}
        columns={columns}
        rowKey="rightsMasterId"
        dateFormatter="string"
        dataSource={detail?.rights}
        search={false}
        pagination={false}
        options={false}
        size={'small'}
        style={{ padding: '0px', marginTop: '16px' }}
        bordered={true}
      />
    );
  }
  useImperativeHandle(ref, () => ({
    takeData,
  }));

  return (
    <div className="ViewDetails">
      {!loading ? (
        <>
          <Row>
            <Col span={24}>接收日期：{timeStamp(Number(createdTime))}</Col>
          </Row>
          <h3 className="Title">销售信息</h3>
          <Row className={'spaceTop'}>
            <Col span={12}>订单号：{detail?.mwyPolicyInfo?.policyInfo?.orderId}</Col>
            <Col span={12}>投保单号/流水号：{detail?.mwyPolicyInfo?.policyInfo?.serialId}</Col>
            <Col span={12}>投保人/购买人姓名：{detail?.mwyPolicyInfo?.policyInfo?.payName}</Col>
            <Col span={12}>
              投保人/购买人电话：{payMobile}
              {getLookUpNode(payMobile, 1)}
            </Col>

            <Col span={12}>被保险人/使用人姓名：{detail?.mwyPolicyInfo?.policyInfo?.useName}</Col>
            <Col span={12}>
              被保险人/使用人电话：{useMobile}
              {getLookUpNode(useMobile, 2)}
            </Col>
            <Col span={12}>
              证件类型：{getCardNameByCardType(detail?.mwyPolicyInfo?.policyInfo?.useIdCardType)}
            </Col>
            <Col span={12}>
              证件号：{cardNo}
              {getLookUpNode(cardNo, 3)}
            </Col>
            <Col span={12}>
              激活版本：{getActivationNameByType(detail?.mwyPolicyInfo?.policyInfo?.activationType)}
            </Col>
          </Row>
          <Row className={'spaceTop'}>
            <Col span={12}>生效日期：{detail?.mwyPolicyInfo?.policyInfo?.effectDate}</Col>
            <Col span={12}>
              犹豫期：
              {(detail?.mwyPolicyInfo?.policyInfo?.hesitationPeriod || 0) > 0
                ? `${detail?.mwyPolicyInfo?.policyInfo?.hesitationPeriod} 天`
                : ''}
            </Col>
            <Col span={12}>
              销售方式：{getSalesNameByType(detail?.mwyPolicyInfo?.policyInfo?.salesType)}
            </Col>
          </Row>
          <Row className={'spaceTop'}>
            <Col span={12}>
              成交时间：{' '}
              {String(detail?.mwyPolicyInfo?.policyInfo?.dealTime || '').length > 0
                ? timeStamp(Number(detail?.mwyPolicyInfo?.policyInfo?.dealTime))
                : ''}
            </Col>
            <Col span={12}>
              成交金额：{' '}
              {String(detail?.mwyPolicyInfo?.policyInfo?.dealAmount || '').length > 0
                ? `￥${Number(detail?.mwyPolicyInfo?.policyInfo?.dealAmount) / 100}`
                : ''}
            </Col>
            <Col span={12}>业务员ID：{detail?.mwyPolicyInfo?.policyInfo?.businessId}</Col>
          </Row>
          <h3 className="Title">权益信息</h3>
          {userId !== '0' ? (
            <Row className={'spaceTop'}>
              <Col span={12}>UserID：{userId}</Col>
              <Col span={12}>领用时间：{formatTime(Number(detail?.card?.activeTime))}</Col>
              <Col span={12}>用户昵称：{detail?.card?.userName}</Col>
              <Col span={12}>权益卡名称：{detail?.card?.name}</Col>
              <Col span={12}>权益状态：</Col>
              {/* 权益状态table */}
              {rightsState()}
            </Row>
          ) : (
            <span style={{ color: 'red' }}>{detail?.payInfo?.message || '暂无权益信息'}</span>
          )}
          <h3 className="Title">微信支付信息</h3>
          {detail?.payInfo && detail.payInfo.code === 0 ? (
            <Row className={'spaceTop'}>
              <Col span={12}>商户单号：{detail.payInfo.outTradeNo}</Col>
              <Col span={12}>交易单号：{detail.payInfo.transactionId}</Col>
              <Col span={12}>交易时间：{timeStamp(detail.payInfo.timestamp)}</Col>
              <Col span={12}>交易状态：{detail.payInfo.message}</Col>
              <Col span={12}>
                交易金额：
                {detail.payInfo.amount ? `￥${Number(detail.payInfo.amount || 0) / 100}` : ''}
              </Col>
            </Row>
          ) : (
            <span style={{ color: 'red' }}>{detail?.payInfo?.message || '暂无微信支付信息'}</span>
          )}
        </>
      ) : (
        <Spin className="loadingContainer" size="large" />
      )}
    </div>
  );

  /** 父组件传递数据 */
  function takeData() {}
});

export default ViewDetails;

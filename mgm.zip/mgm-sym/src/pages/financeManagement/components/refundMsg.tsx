/* eslint-disable react-hooks/exhaustive-deps */

import { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { Spin, Form, Col, Row, Input, DatePicker, InputNumber } from 'antd';
import moment from 'moment';

import { getFindRefund } from '@/services/api';
import { formatDate } from '@/utils/formatDate';

interface modalPropType {
  logId?: string | undefined;
}
const RefundMsg = forwardRef((props: modalPropType, ref) => {
  const { logId } = props;
  const [form] = Form.useForm();
  const [refundTime, setRefundTime] = useState<number | undefined>(undefined);
  const [createTime, setCreateTime] = useState<number | undefined>(undefined);
  const [Loading, setLoading] = useState<boolean>(false);
  const monthFormat = 'YYYY-MM-DD HH:mm:ss';

  useEffect(() => {
    if (logId) {
      setLoading(true);
      getFindRefund(logId).then((res) => {
        if (res.status === 0) {
          setLoading(false);
          setRefundTime(res.result?.refundTime);
          setCreateTime(res.result?.createTime);
          setData(res.result);
        }
      });
    }
  }, [logId]);

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 6 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 16 },
    },
  };
  const config = {
    rules: [{ type: 'object' as const, required: true, message: 'Please select time!' }],
  };

  function disabledDate(current: any) {
    return current && current > new Date();
  }
  // 时间转换
  const getMonment = (time: number | undefined) => {
    const day = formatDate(Number(time));
    return time && time > 0 ? moment(day, monthFormat) : undefined;
  };
  useImperativeHandle(ref, () => ({
    takeData,
    setData,
    reset,
  }));

  return (
    <div>
      {!Loading ? (
        <Form form={form} {...formItemLayout} className="assitantModalMsg">
          <Row>
            <Col span={24}>
              <Form.Item label="录入时间">
                <span>{formatDate(Number(createTime))}</span>
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="户名"
                name="accountName"
                rules={[{ required: true, message: '请输入户名' }]}
              >
                <Input maxLength={50} placeholder="请输入户名" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="账户号"
                name="accountNumber"
                rules={[{ required: true, message: '请输入账户号' }]}
              >
                <Input maxLength={50} placeholder="请输入账户号" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="开户行"
                name="openBank"
                rules={[{ required: true, message: '请输入开户行' }]}
              >
                <Input maxLength={50} placeholder="请输入开户行" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="联行号"
                name="bankNumber"
                rules={[{ required: true, message: '请输入联行号' }]}
              >
                <Input maxLength={50} placeholder="请输入联行号" />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="退款金额"
                name="refundAmount"
                rules={[{ required: true, message: '请输入退款金额' }]}
              >
                <InputNumber
                  parser={(values?: string) => {
                    const reg = /^(-)*(\d+)\.(\d\d).*$/;
                    return values ? values.replace(/\s?|(,*)/g, '').replace(reg, '$1$2.$3') : '';
                  }}
                  min="0"
                  maxLength={20}
                  step={0.01}
                  style={{ width: '100%' }}
                  placeholder="请输入退款金额"
                />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item
                label="退款时间"
                name="refundTimeStr"
                initialValue={getMonment(refundTime)}
                {...config}
                rules={[{ required: true, message: '请输入退款时间' }]}
              >
                <DatePicker
                  showTime
                  disabledDate={disabledDate}
                  format="YYYY-MM-DD HH:mm:ss"
                  style={{ width: '100%' }}
                  placeholder="请选择退款时间"
                />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      ) : (
        <Spin className="loadingContainer" size="large" />
      )}
    </div>
  );

  /** 父组件传递数据 */
  function takeData() {
    return new Promise((resolve, reject) => {
      form
        .validateFields()
        .then((values) => {
          const { refundTimeStr, refundAmount, ...data } = values;
          data.refundTime = refundTimeStr ? new Date(refundTimeStr).getTime() : '';
          data.refundAmount = refundAmount ? refundAmount * 100 : 0;
          resolve(data);
        })
        .catch((error) => {
          reject(error);
        });
    });
  }
  function setData(data: any) {
    reset();
    if (data !== null && Object.keys(data).length) {
      data.refundAmount /= 100;
      form.setFieldsValue(data);
    }
  }

  // 重置数据
  function reset() {
    form.resetFields();
    setRefundTime(undefined);
  }
});

export default RefundMsg;

import type { RightsListType } from '../mallDrugsData/typings';
import type { TypeListType } from '../typing';

const transferListToObject = (
  list: APIS.DictionaryType[] | undefined,
  obj: TypeListType | undefined = undefined,
) => {
  const tempObj = { ...(obj ?? {}) };
  list?.map((item: APIS.DictionaryType) => {
    tempObj[item.key ?? ''] = item.value;
  });
  return tempObj;
};

const transferPlanCodeToObj = (list: RightsListType[]) => {
  const obj = {};
  list.map((item: RightsListType) => {
    obj[item.planCode ?? ''] = item.name;
  });
  return obj;
};

export { transferListToObject, transferPlanCodeToObj };

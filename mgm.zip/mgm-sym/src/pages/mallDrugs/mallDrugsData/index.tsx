/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useRef, useEffect } from 'react';
import _ from 'lodash';
import { Button, Select, Upload } from 'antd';
import { DownloadOutlined, ExportOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { ClickDownXlsx } from '@/utils/downXlsx';
import TableLocal from '@/components/TableLocal/TableLocal';
import { downloadExcelTemplate, listDictionary } from '@/services/api';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { hasFields, typeUploaded, UploadFailure, UploadResult, UploadSucceed } from '@/utils/utils';

import Modal from './components/Modal';
import Add from './components/Add';
import Edit from './components/Edit';
import OrderValue from './components/OrderValue';
import { transferListToObject, transferPlanCodeToObj } from '../utils';
import {
  addMallGoods,
  exportData,
  importMallGoods,
  importMallGoodsOrder,
  itemEquityDropDownbox,
  listFrontKind,
  MallDrugsDataList,
  modifyMallGoods,
  pullOffShelves,
  removeGoods,
} from './api';
import type {
  AddMallGoodsType,
  FrontKindItemType,
  FrontKindListType,
  MallDrugsDataListType,
  MallDrugsDataType,
  RightsListType,
} from './typings';
import type { TypeListType } from '../typing';

import './index.less';

const { Option } = Select;

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_EDIT = 2;
const MODAL_TYPE_ORDER = 3;

const MallDrugsData: React.ReactNode = () => {
  const actionRef = useRef<ActionType | undefined>();
  const addRef = useRef<any>();
  const editRef = useRef<any>();
  const orderValueRef = useRef<any>();
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);

  const [onOrOffLoading, setOnOrOffLoading] = useState<boolean>(false);

  const [category, setCategory] = useState<string | number>('1');

  const [ids, setIds] = useState<number[]>([]);

  // 分类数据
  const [classifyData, setClassifyData] = useState<TypeListType[]>([
    { id: '', name: '商城商品全数据' },
  ]);

  const [platStatus, setPlatStatus] = useState<TypeListType>({});
  const [mallStatus, setMallStatus] = useState<TypeListType>({});
  const [planCodeStatus, setPlanCodeStatus] = useState<TypeListType>({});
  const [medicineType, setMedicineType] = useState<TypeListType>({});
  const [itemTypeOpent, setItemTypeOpent] = useState<TypeListType>({});

  const [frontKindList, setFrontKindList] = useState<FrontKindListType[]>([]);
  const [rightsList, setRightsList] = useState<RightsListType[]>([]);

  const [details, setDetails] = useState<AddMallGoodsType[]>([]);
  const [editDetails, setEditDetails] = useState({});
  const [importLoading, setImportLoading] = useState<boolean>(false);
  const [exportLoading, setExportLoading] = useState<boolean>(false);
  const [importOrderLoading, setImportOrderLoading] = useState<boolean>(false);

  useEffect(() => {
    listDictionary().then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;

        setPlatStatus(transferListToObject(dictionary?.PLAT_STATUS));
        setMallStatus(transferListToObject(dictionary?.MALL_STATUS));
        setMedicineType(transferListToObject(dictionary?.MEDICINE_TYPE));
      }
    });
    listDictionary(['ITEM_TYPE']).then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;

        setItemTypeOpent(transferListToObject(dictionary?.ITEM_TYPE));
      }
    });

    listFrontKind().then((res) => {
      if (res.status === 0 && res.result) {
        setFrontKindList(res.result.list);

        const data = _.cloneDeep(classifyData);
        res.result.list.map((item: FrontKindItemType) => {
          data.push({ id: item.id, name: item.name });
        });
        setClassifyData(data);
      }
    });
    // 获取到有商城的权益卡列表
    itemEquityDropDownbox().then((res) => {
      if (res.status === 0 && res.result) {
        setRightsList(res.result);
        setPlanCodeStatus(transferPlanCodeToObj(res.result));
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '添加';
      case MODAL_TYPE_EDIT:
        return '编辑';
      case MODAL_TYPE_ORDER:
        return '编辑序值';
    }
    return '';
  }

  function onCancel() {
    setVisible(false);
    setBtnLoading(false);
    setTimeout(() => {
      addRef.current?.reset();
      editRef.current?.reset();
      orderValueRef.current?.reset();
      setModalType(undefined);
    });
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }
  function onOk() {
    if (modalType === 1) {
      addRef.current?.takeData().then((res: any) => {
        setDetails(res);
        setVisible(true);
      });
    } else if (modalType === 2) {
      editRef.current?.takeData().then((res: any) => {
        setEditDetails(res);
        setVisible(true);
      });
    } else if (modalType === 3) {
      orderValueRef.current?.takeData().then((res: any) => {
        setEditDetails(res);
        setVisible(true);
      });
    }
  }
  function onSaveData() {
    setBtnLoading(true);
    if (modalType === 1) {
      addMallGoods(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          addRef.current?.reset();
          setModalType(undefined);
          setDetails([]);
          actionRef.current?.reload();
        }
      });
    } else if (modalType === 2) {
      modifyMallGoods(editDetails).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          editRef.current?.reset();
          setModalType(undefined);
          setEditDetails({});
          actionRef.current?.reload();
        }
      });
    } else if (modalType === 3) {
      modifyMallGoods(editDetails).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          orderValueRef.current?.reset();
          setModalType(undefined);
          setEditDetails({});
          actionRef.current?.reload();
        }
      });
    } else {
      setTimeout(() => {
        setVisible(false);
        setBtnLoading(false);
        setModalType(undefined);
      });
    }
  }

  const rowSelection = {
    onChange: (selectedRowKeys: number[]) => {
      setIds(selectedRowKeys);
    },
  };
  function handleBeforeUpload(file: RcFile, fileList: RcFile[], suffix: string[] = ['xlsx']) {
    const fileName = file?.name ?? '';
    let isMatch = false;
    const _suffix = suffix ?? [];
    for (const item of _suffix) {
      if (fileName.endsWith(`.${item}`)) {
        isMatch = true;
        break;
      }
    }
    if (!isMatch) showErrorMessage(typeUploaded(_suffix.join(' 或 ')));
    return isMatch;
  }

  function customeUpload(options: any) {
    setImportLoading(true);
    importMallGoods(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef?.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setImportLoading(false));
  }

  function orderUpload(options: any) {
    setImportOrderLoading(true);
    importMallGoodsOrder(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef?.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setImportOrderLoading(false));
  }

  // 点击下架按钮
  function soldOutClick(record?: MallDrugsDataType) {
    setOnOrOffLoading(true);
    const tempIds = !!record ? [record.id ?? ''] : ids;
    pullOffShelves({ ids: tempIds, status: 1 }).then((res) => {
      setOnOrOffLoading(false);
      if (res.status === 0) {
        showSuccessMessage('下架成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      } else {
        showErrorMessage('下架失败');
      }
    });
  }
  // 点击上架按钮
  function putawayClick(record?: MallDrugsDataType) {
    setOnOrOffLoading(true);
    const tempIds = !!record ? [record.id ?? ''] : ids;
    pullOffShelves({ ids: tempIds, status: 2 }).then((res) => {
      setOnOrOffLoading(false);
      if (res.status === 0) {
        showSuccessMessage('上架成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      } else {
        showErrorMessage('上架失败');
      }
    });
  }
  // 点击 序值
  function orderValueClick(record: MallDrugsDataType) {
    setModalType(MODAL_TYPE_ORDER);
    setTimeout(() => {
      orderValueRef.current?.setData(record);
    });
  }
  function removeClick(record?: MallDrugsDataType) {
    const tempIds = !!record ? [record.id ?? ''] : ids ?? [];
    removeGoods(tempIds).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('移除成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      } else {
        showErrorMessage('移除失败');
      }
    });
  }
  // 点击编辑按钮
  function editClick(record: MallDrugsDataType) {
    setModalType(MODAL_TYPE_EDIT);
    setTimeout(() => {
      editRef.current?.setData(record);
    });
  }
  // 点击导出按钮
  function exportClick() {
    setExportLoading(true);
    exportData().then((res) => {
      setExportLoading(false);
      const { size } = res;
      if (size <= 500) {
        showErrorMessage('数据流异常，无法正常下载');
        return;
      }
      ClickDownXlsx(res, '前台商品管理');
      showSuccessMessage('导出成功');
    });
  }
  // 商城药品数据
  const columns: ProColumns<MallDrugsDataType>[] = [
    {
      title: '我方商品 ID',
      dataIndex: 'platGoodsId',
    },
    {
      title: '渠道商品编码',
      dataIndex: 'channelGoodsCode',
      hideInTable: true,
    },
    {
      title: '渠道商品编码',
      dataIndex: 'channelCode',
      hideInSearch: true,
    },
    {
      title: '前台分类',
      dataIndex: 'frontKindId',
      hideInTable: true,
      valueType: 'select',
      renderFormItem: () => {
        return (
          <Select placeholder="请选择前台分类" mode="multiple" allowClear showArrow>
            {frontKindList.map((item: FrontKindListType) => {
              return (
                <Option value={item.id} key={item.id}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        );
      },
    },
    {
      title: '前台分类',
      dataIndex: 'frontKind',
      hideInSearch: true,
      renderText: (text, record) => {
        return Object.values(record.frontKind ?? {}).join(' , ');
      },
    },
    {
      title: '所属权益',
      dataIndex: 'planCode',
      hideInTable: true,
      valueType: 'select',
      renderFormItem: () => {
        return (
          <Select placeholder="请选择所属权益" mode="multiple" allowClear showArrow>
            {rightsList.map((item: RightsListType) => {
              return (
                <Option value={item.planCode} key={item.planCode}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        );
      },
    },
    {
      title: '所属权益',
      dataIndex: 'planCode',
      valueType: 'select',
      valueEnum: planCodeStatus,
      hideInSearch: true,
    },
    {
      title: '商品属性',
      valueType: 'select',
      hideInTable: true,
      dataIndex: 'attribute',
      valueEnum: itemTypeOpent,
    },

    {
      title: '商品属性',
      valueType: 'select',
      hideInSearch: true,
      valueEnum: itemTypeOpent,
      dataIndex: 'goodsAttributes',
    },
    {
      title: '通用名',
      dataIndex: 'name',
      hideInTable: true,
    },
    {
      title: '通用名',
      dataIndex: 'commonName',
      hideInSearch: true,
    },
    {
      title: '品牌名',
      dataIndex: 'brandName',
      hideInSearch: true,
    },
    {
      title: '规格',
      dataIndex: 'spec',
      hideInSearch: true,
    },
    {
      title: '价格',
      dataIndex: 'price',
      hideInSearch: true,
      renderText: (value) => `￥${value / 100}`,
    },
    {
      title: '库存',
      dataIndex: 'stock',
      hideInSearch: true,
    },
    {
      title: '封面图',
      dataIndex: 'firstImg',
      render: (text, record) => [<img key={'image'} src={record.firstImg} alt="" width={'80'} />],
      hideInSearch: true,
    },
    {
      title: '详情轮播图',
      dataIndex: 'img',
      width: 200,
      render: (text, record) => [
        record?.img?.map((item: string, index: number) => {
          return (
            <img
              style={{ margin: '3px' }}
              key={item + String(index)}
              src={item}
              alt=""
              width={'80'}
            />
          );
        }),
      ],
      hideInSearch: true,
    },
    {
      title: '是否处方药',
      dataIndex: 'medicineType',
      valueType: 'select',
      valueEnum: medicineType,
    },
    {
      title: '平台上下架状态',
      dataIndex: 'platStatus',
      valueType: 'select',
      valueEnum: platStatus,
    },

    {
      title: '商城上下架状态',
      dataIndex: 'mallStatus',
      valueType: 'select',
      // hideInSearch: true,
      valueEnum: mallStatus,
    },

    {
      title: '添加时间',
      dataIndex: 'createTime',
      hideInSearch: true,
    },
    {
      title: '分类数据',
      dataIndex: 'backKindId',
      initialValue: '',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Select>
            {classifyData.map((item) => {
              return (
                <Option value={item.id} key={item.id}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        );
      },
    },

    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (_text, record) => [
        <Button
          className="mallDrugsButton"
          key={'edit'}
          onClick={() => {
            if (record.mallStatus === 1) {
              editClick(record);
            } else {
              showErrorMessage('上架状态商品不可编辑');
            }
          }}
          type="link"
        >
          编辑
        </Button>,
        record.mallStatus === 2 && (
          <Button
            disabled={onOrOffLoading}
            loading={onOrOffLoading}
            className="mallDrugsButton storeShelves"
            key={'storeShelves'}
            onClick={() => {
              setIds([]);
              actionRef.current?.clearSelected?.(); // 清空选中项
              soldOutClick(record);
            }}
            type="link"
          >
            下架
          </Button>
        ),
        record.mallStatus === 1 && (
          <Button
            disabled={onOrOffLoading}
            loading={onOrOffLoading}
            className="mallDrugsButton"
            key={'putaway'}
            onClick={() => {
              if (record.platStatus === 2) {
                setIds([]);
                actionRef.current?.clearSelected?.(); // 清空选中项
                putawayClick(record);
              } else {
                showErrorMessage('该商品平台已经下架，不可进行商城上架');
              }
            }}
            type="link"
          >
            上架
          </Button>
        ),
        <Button
          className="mallDrugsButton"
          key={'remove'}
          onClick={() => {
            setIds([]);
            actionRef.current?.clearSelected?.(); // 清空选中项
            removeClick(record);
          }}
          type="link"
        >
          移除
        </Button>,
      ],
    },
  ];
  // 前台分类药品数据
  const classifyColumns: ProColumns<MallDrugsDataType>[] = [
    {
      title: '序值',
      dataIndex: 'order',
      hideInSearch: true,
    },
    {
      title: '我方商品 ID',
      dataIndex: 'platGoodsId',
      // hideInSearch: true,
    },
    {
      title: '渠道商品编码',
      dataIndex: 'channelGoodsCode',
      hideInTable: true,
    },
    {
      title: '渠道商品编码',
      dataIndex: 'channelCode',
      hideInSearch: true,
    },
    {
      title: '前台分类',
      dataIndex: 'frontKindId',
      hideInTable: true,
      valueType: 'select',
      renderFormItem: () => {
        return (
          <Select placeholder="请选择前台分类" mode="multiple" allowClear showArrow>
            {frontKindList.map((item: FrontKindListType) => {
              return (
                <Option value={item.id} key={item.id}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        );
      },
    },
    {
      title: '前台分类',
      dataIndex: 'frontKind',
      renderText: (text, record) => {
        return Object.values(record.frontKind ?? {}).join(', ');
      },
      hideInSearch: true,
    },
    {
      title: '所属权益',
      dataIndex: 'planCode',
      hideInTable: true,
      valueType: 'select',
      renderFormItem: () => {
        return (
          <Select placeholder="请选择所属权益" mode="multiple" allowClear showArrow>
            {rightsList.map((item: RightsListType) => {
              return (
                <Option value={item.planCode} key={item.planCode}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        );
      },
    },
    {
      title: '商品属性',
      valueType: 'select',
      hideInTable: true,
      dataIndex: 'attribute',
      valueEnum: itemTypeOpent,
    },
    {
      title: '商品分类',
      dataIndex: 'categoryId',
      hideInSearch: true,
    },
    {
      title: '通用名',
      dataIndex: 'name',
      hideInTable: true,
    },
    {
      title: '通用名',
      dataIndex: 'commonName',
      hideInSearch: true,
    },
    {
      title: '是否处方药',
      dataIndex: 'medicineType',
      valueType: 'select',
      valueEnum: medicineType,
      hideInTable: true,
    },
    {
      title: '品牌名',
      dataIndex: 'brandName',
      hideInSearch: true,
    },
    {
      title: '规格',
      dataIndex: 'spec',
      hideInSearch: true,
    },
    {
      title: '平台上下架状态',
      dataIndex: 'platStatus',
      valueEnum: platStatus,
      valueType: 'select',
      // hideInSearch: true,
    },
    {
      title: '商城上下架状态',
      dataIndex: 'mallStatus',
      // hideInSearch: true,
      valueType: 'select',
      valueEnum: mallStatus,
    },

    {
      title: '添加时间',
      dataIndex: 'createTime',
      hideInSearch: true,
    },

    {
      title: '分类数据',
      dataIndex: 'backKindId',
      initialValue: '',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Select>
            {classifyData.map((item) => {
              return (
                <Option value={item.id} key={item.id}>
                  {item.name}
                </Option>
              );
            })}
          </Select>
        );
      },
    },
    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (_text, record) => [
        <Button
          className="mallDrugsButton"
          key={'orderValue'}
          onClick={() => {
            orderValueClick(record);
          }}
          type="link"
        >
          序值
        </Button>,
        <Button
          className="mallDrugsButton"
          key={'remove'}
          onClick={() => {
            setIds([]);
            actionRef.current?.clearSelected?.(); // 清空选中项
            removeClick(record);
          }}
          type="link"
        >
          移除
        </Button>,
      ],
    },
  ];

  const rowClassName = (record: MallDrugsDataType) => {
    if (category === '') {
      if (hasFields(record, ['img', 'firstImg'])) {
        return 'dataMissing';
      } else {
        return '';
      }
    } else {
      return '';
    }
  };
  const orderOptions = () => [
    <Button
      key="downloadOrderTemplate"
      onClick={() => {
        downloadExcelTemplate('DXZ');
      }}
      type="primary"
    >
      <ExportOutlined />
      下载序值模板
    </Button>,
    <Upload
      key="uploadOrderPatch"
      accept={'.xls, .xlsx'}
      maxCount={1}
      type={'select'}
      beforeUpload={(file, fileList) => handleBeforeUpload(file, fileList, ['xls', 'xlsx'])}
      customRequest={orderUpload}
      showUploadList={false}
    >
      <Button type="primary" loading={importOrderLoading}>
        <ImportOutlined />
        导入序值
      </Button>
    </Upload>,
  ];
  // 分类数据 是全数据时 table 上方操作
  const fullOperation = () => {
    return [
      <Button
        disabled={onOrOffLoading}
        loading={onOrOffLoading}
        key="BatchShelves"
        type="primary"
        onClick={() => {
          if (ids.length) {
            putawayClick();
          } else {
            showErrorMessage('请选择批量上架的数据');
          }
        }}
      >
        批量上架
      </Button>,
      <Button
        disabled={onOrOffLoading}
        loading={onOrOffLoading}
        key="BatchSoldOut "
        type="primary"
        onClick={() => {
          if (ids.length) {
            soldOutClick();
          } else {
            showErrorMessage('请选择批量下架的数据');
          }
        }}
      >
        批量下架
      </Button>,
      <Button
        key="BatchRemove "
        type="primary"
        onClick={() => {
          if (ids.length) {
            removeClick();
          } else {
            showErrorMessage('请选择批量下架的数据');
          }
        }}
      >
        批量移除
      </Button>,
      <Upload
        key="toLead"
        accept={'.xlsx'}
        maxCount={1}
        type={'select'}
        beforeUpload={handleBeforeUpload}
        customRequest={customeUpload}
        showUploadList={false}
      >
        <Button type="primary" loading={importLoading}>
          <ImportOutlined />
          导入
        </Button>
      </Upload>,
      <Button
        key="DownloadTemplate"
        onClick={() => {
          downloadExcelTemplate('SCYPSJ');
        }}
        type="primary"
      >
        <ExportOutlined />
        下载导入模板
      </Button>,
      <Button
        key="add"
        type="primary"
        onClick={() => {
          setModalType(MODAL_TYPE_ADD);
        }}
      >
        <PlusOutlined />
        添加
      </Button>,
      <Button loading={exportLoading} key="export" type="primary" onClick={exportClick}>
        <DownloadOutlined />
        导出
      </Button>,
    ];
  };
  // 分类数据 不是全数据时 table 上方操作
  const categoricalPperation = () => {
    return [
      ...orderOptions(),
      <Button
        key="BatchRemove "
        type="primary"
        onClick={() => {
          if (ids.length) {
            removeClick();
          } else {
            showErrorMessage('请选择批量下架的数据');
          }
        }}
      >
        批量移除
      </Button>,
      <Upload
        key="toLead"
        accept={'.xlsx'}
        maxCount={1}
        type={'select'}
        beforeUpload={handleBeforeUpload}
        customRequest={customeUpload}
        showUploadList={false}
      >
        <Button type="primary" loading={importLoading}>
          <ImportOutlined />
          导入
        </Button>
      </Upload>,
      <Button
        key="DownloadTemplate"
        onClick={() => {
          downloadExcelTemplate('SCYPSJ');
        }}
        type="primary"
      >
        下载导入模板
      </Button>,
      <Button
        key="add"
        type="primary"
        onClick={() => {
          setModalType(MODAL_TYPE_ADD);
        }}
      >
        <PlusOutlined />
        添加
      </Button>,
    ];
  };
  return (
    <TableLocal
      tableClassName="mallDrugsDataTable"
      rowClassName={(record: MallDrugsDataType) => rowClassName(record)}
      columns={category === '' ? columns : classifyColumns}
      request={MallDrugsDataList}
      rowKey="id"
      dateFormatter="string"
      beforeSearchSubmit={(params: Partial<MallDrugsDataListType>) => {
        setCategory(params.backKindId ?? '');
        return params;
      }}
      search={{
        labelWidth: 120,
        optionRender: (_searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      rowSelection={rowSelection}
      toolBarRender={() => (category === '' ? fullOperation() : categoricalPperation())}
      actionRef={actionRef}
    >
      <Modal
        title={getModalTitle()}
        modalType={modalType}
        onCancel={onCancel}
        onCancelSave={onCancelSave}
        onOk={onOk}
        onSaveData={onSaveData}
        ModalVisible={!!modalType}
        btnLoading={btnLoading}
        visible={visible}
      >
        {modalType === MODAL_TYPE_ADD && (
          <Add
            goodsClassify={frontKindList}
            category={category}
            rightsList={rightsList}
            ref={addRef}
          />
        )}
        {modalType === MODAL_TYPE_EDIT && (
          <Edit goodsClassify={frontKindList} rightsList={rightsList} ref={editRef} />
        )}
        {modalType === MODAL_TYPE_ORDER && <OrderValue ref={orderValueRef} />}
      </Modal>
    </TableLocal>
  );
};
export default MallDrugsData;

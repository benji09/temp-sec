import type { ReactNode } from 'react';

type ModalPropType = {
  modalType?: number;
  title?: string | undefined;
  ModalVisible?: boolean;
  btnLoading?: boolean;
  visible?: boolean;
  onOk: () => void;
  onCancel: () => void;
  onSaveData: () => void;
  onCancelSave: () => void;
  children?: ReactNode;
};

type FrontKindListType = {
  id: string;
  name: string;
};
type RightsListType = {
  planCode?: string;
  name?: string;
};
type MallDrugsDataListType = {
  backKindId?: string | number;
  name?: string;
  attribute?: string;
  mallStatus?: string;
  platStatus?: string;
  platGoodsId?: string;
  frontKindId?: string;
  channelGoodsCode?: string;
  current?: number;
  pageSize?: number;
};
type PullOffShelvesType = {
  ids: number[] | string[];
  itemOffReason?: string;
  status?: number;
};
type RemoveGoodsType = number[] | string[];
type ModifyMallGoodsType = {
  firstImg?: string;
  frontKindId?: number;
  id?: number;
  img?: string[];
  price?: number;
  status?: number;
  stock?: number;
};
type AddOrEditPropsType = {
  rightsList?: RightsListType[];
  category?: any;
  goodsClassify: FrontKindListType[];
};
type AddMallGoodsType = {
  brandName?: string;
  channelCode?: string;
  commonName?: string;
  frontKindId?: number;
  goodsId?: number;
  spec?: string;
};
type GetMyItemDataType = {
  channelSkuId?: string;
  id?: string;
};
type MallDrugsDataType = {
  order?: string | number;
  brandName?: string;
  channelCode?: string;
  commonName?: string;
  createTime?: string;
  firstImg?: string;
  frontKind?: Record<number | undefined, string | undefined>;
  goodsAttributes?: string;
  id?: string;
  img?: string[];
  mallStatus?: number;
  medicineType?: number;
  order?: null;
  planCode?: string[];
  platGoodsId?: string;
  platStatus?: number;
  price?: number;
  sellPrice?: string;
  spec?: string;
  stock?: number;
  thirdStock?: number;
};
type FrontKindItemType = {
  children?: null | string | number;
  id?: string;
  name?: string;
  order?: null | string | number;
  position?: null | string | number;
  status?: null | string | number;
};
export {
  ModalPropType,
  RightsListType,
  MallDrugsDataListType,
  FrontKindListType,
  PullOffShelvesType,
  RemoveGoodsType,
  ModifyMallGoodsType,
  AddOrEditPropsType,
  AddMallGoodsType,
  GetMyItemDataType,
  MallDrugsDataType,
  FrontKindItemType,
};

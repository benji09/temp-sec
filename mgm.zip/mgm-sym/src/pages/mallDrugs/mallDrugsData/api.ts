// @ts-ignore
import { request } from 'umi';

import { HOST_TYPE_POWER } from '@/utils/utils';
import { POWER_HOST } from '@/services/hosts';
import { getRequest, postRequest, TIMEOUT } from '@/services/api';

import type {
  AddMallGoodsType,
  GetMyItemDataType,
  MallDrugsDataListType,
  ModifyMallGoodsType,
  PullOffShelvesType,
  RemoveGoodsType,
} from './typings';

let searchBackKindId: string | number | undefined = undefined;
let searchData = {};

const MallDrugsDataList = async (params: MallDrugsDataListType) => {
  const { current, pageSize, frontKindId, backKindId, ...data } = params;

  searchBackKindId = backKindId || undefined;
  searchData = {
    isFrontView: backKindId === '' ? false : true,
    frontKindId: frontKindId || (backKindId !== '' ? [backKindId] : undefined),
    ...data,
  };
  const msg = (await postRequest(
    '/mall/list_mall_goods',
    {
      isFrontView: backKindId === '' ? false : true,
      frontKindId: frontKindId || (backKindId !== '' ? [backKindId] : undefined),
      ...data,
      pageSize,
      currentPage: current,
    },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;

  return {
    data: msg.result?.mallGoodsItems || [],
    total: msg.result?.total || 0,
  };
};
// 获取分类列表
const listFrontKind = async () => {
  return (await postRequest(
    '/mall/list-front-kind',
    {},
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 上下架
const pullOffShelves = async (data: PullOffShelvesType) => {
  return (await postRequest(
    '/mall/change_mall_goods_status',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 移除
const removeGoods = async (data?: RemoveGoodsType) => {
  return (await postRequest(
    '/mall/remove_mall_goods',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
//
const modifyMallGoods = async (data?: ModifyMallGoodsType) => {
  return (await postRequest(
    '/mall/modify_mall_goods',
    { frontKindId: [searchBackKindId], ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const addMallGoods = async (data: AddMallGoodsType[]) => {
  return (await postRequest(
    '/mall/add_mall_goods',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const getMyItemData = async (data: GetMyItemDataType) => {
  return (await postRequest(
    '/mall/get-my-item-Data',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

const importMallGoods = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/mall/import_mall_goods', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};
const importMallGoodsOrder = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/mall/import_sort', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};
const itemEquityDropDownbox = async () => {
  return (await getRequest(
    '/mall/item-equity-drop-downbox',
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const exportData = async () => {
  return (await postRequest(
    '/mall/export-item',
    { ...searchData },
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  )) as unknown as any;
};
export {
  MallDrugsDataList,
  listFrontKind,
  pullOffShelves,
  removeGoods,
  modifyMallGoods,
  addMallGoods,
  getMyItemData,
  importMallGoods,
  itemEquityDropDownbox,
  exportData,
  importMallGoodsOrder,
};

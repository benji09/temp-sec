type TypeListType = Record<string | undefined, string | undefined>;

export { TypeListType };

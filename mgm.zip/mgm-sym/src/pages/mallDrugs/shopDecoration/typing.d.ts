import type { ReactNode } from 'react';
type ShopDecorationListType = {
  pageSize: number;
  current: number;
};
type ShopDecorationModalType = {
  modalVisible?: boolean;
  visible?: boolean;
  title?: string;
  btnLoading?: boolean;
  onOk: () => void;
  onCancel: () => void;
  onSaveData: () => void;
  onCancelSave: () => void;
  children?: ReactNode;
};

type ShopDecorationType = {
  children?: ShopDecorationType[];
  id?: string | null;
  name?: string | null;
  order?: number | null;
  position?: string | null;
  status?: number | null;
};
export { ShopDecorationListType, ShopDecorationModalType, ShopDecorationType };

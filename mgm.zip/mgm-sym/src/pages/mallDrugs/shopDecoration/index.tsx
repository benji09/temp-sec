import React, { useEffect, useRef, useState } from 'react';
import { Button } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/index';
import { listDictionary, queryAllRights } from '@/services/api';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import Modal from './components/Modal';
import CreateOrEdit from './components/CreateOrEdit';
import { transferListToObject, transferPlanCodeToObj } from '../utils';
import { modifyFrontKind, shopDecorationList } from './aip';
import type { TypeListType } from '../typing';
import type { ShopDecorationType } from './typing';
import type { RightsListType } from '../mallDrugsData/typings';

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_EDIT = 2;
const ShopDecorationData: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const createOrEditRef = useRef<any>();

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [initiateMode, setInitiateMode] = useState<TypeListType>({});

  const [details, setDatails] = useState({});
  const [modifyStatusLoading, setModifyStatusLoading] = useState<boolean>(false);

  const [rightsList, setRightsList] = useState<RightsListType[]>([]);
  const [planCodeStatus, setPlanCodeStatus] = useState<TypeListType>({});

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_EDIT:
        return '编辑';
    }
    return '';
  }

  function onOk() {
    setVisible(true);
    createOrEditRef.current?.takeData().then((res: any) => {
      setDatails(res);
    });
  }
  function onCancel() {
    setBtnLoading(false);
    setVisible(false);
    createOrEditRef.current?.reset();
    setTimeout(() => {
      setModalType(undefined);
    });
  }
  function onSaveData() {
    setBtnLoading(true);

    modifyFrontKind(details).then((res) => {
      setBtnLoading(false);
      setVisible(false);
      if (res.status === 0) {
        actionRef.current?.reload();
        createOrEditRef.current?.reset();
        setModalType(undefined);
      }
    });
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }

  function enablingClick(record: ShopDecorationType) {
    setModifyStatusLoading(true);
    modifyFrontKind({ ...record, status: 1 }).then((res) => {
      setModifyStatusLoading(false);
      if (res.status === 0) {
        showSuccessMessage('启用成功');
        actionRef.current?.reload();
      } else {
        showErrorMessage('启用失败');
      }
    });
  }
  function disablingClick(record: ShopDecorationType) {
    setModifyStatusLoading(true);
    modifyFrontKind({ ...record, status: 2 }).then((res) => {
      setModifyStatusLoading(false);
      if (res.status === 0) {
        showSuccessMessage('禁用成功');
        actionRef.current?.reload();
      } else {
        showErrorMessage('禁用失败');
      }
    });
  }
  function editableClick(record: ShopDecorationType) {
    setModalType(MODAL_TYPE_EDIT);
    setTimeout(() => {
      createOrEditRef.current?.setData(record);
    });
  }

  function getPlanCodeDesc(data?: string[]) {
    const _list: string[] = [];
    (data ?? []).map((value: string) => {
      _list.push(planCodeStatus[value] ?? '');
      return value;
    });
    return _list.join('、');
  }

  useEffect(() => {
    listDictionary().then((res: any) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;
        setInitiateMode(transferListToObject(dictionary?.STATUS || []));
      }
    });
    queryAllRights().then((res) => {
      if (res && res.status === 0 && res.result) {
        setRightsList(res.result);
        setPlanCodeStatus(transferPlanCodeToObj(res.result));
      }
    });
  }, []);
  const columns: ProColumns<ShopDecorationType>[] = [
    {
      title: 'ID',
      dataIndex: 'id',
      hideInSearch: true,
    },
    {
      title: '前台一级分类名称',
      dataIndex: 'name',
      hideInSearch: true,
    },
    {
      title: '位置',
      dataIndex: 'position',
      hideInSearch: true,
    },
    {
      title: '所属权益',
      dataIndex: 'planCode',
      hideInSearch: true,
      renderText: (text) => getPlanCodeDesc(text),
    },
    {
      title: '序值',
      dataIndex: 'order',
      hideInSearch: true,
    },
    {
      title: '启用状态',
      dataIndex: 'status',
      valueType: 'select',
      valueEnum: initiateMode,
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (text, record) => [
        record.status === 2 && (
          <Button
            loading={modifyStatusLoading}
            disabled={modifyStatusLoading}
            key="enabling"
            type="link"
            onClick={() => {
              enablingClick(record);
            }}
          >
            启用
          </Button>
        ),
        record.status === 1 && (
          <Button
            loading={modifyStatusLoading}
            disabled={modifyStatusLoading}
            key="disabling"
            type="link"
            danger
            onClick={() => {
              disablingClick(record);
            }}
          >
            禁用
          </Button>
        ),
        <Button
          key="editable"
          type="link"
          onClick={() => {
            editableClick(record);
          }}
        >
          编辑
        </Button>,
      ],
    },
  ];

  return (
    <TableLocal
      columns={columns}
      request={shopDecorationList}
      rowKey="id"
      search={false}
      actionRef={actionRef}
      toolBarRender={() => [
        <Button
          key="import"
          type="primary"
          onClick={() => {
            setModalType(MODAL_TYPE_ADD);
          }}
        >
          <PlusOutlined /> 新增
        </Button>,
      ]}
    >
      <Modal
        modalVisible={!!modalType}
        visible={visible}
        btnLoading={btnLoading}
        title={getModalTitle()}
        onOk={onOk}
        onCancel={onCancel}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        <CreateOrEdit ref={createOrEditRef} rightsList={rightsList} />
      </Modal>
    </TableLocal>
  );
};
export default ShopDecorationData;

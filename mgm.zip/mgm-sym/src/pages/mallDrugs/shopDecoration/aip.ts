import { HOST_TYPE_POWER } from '@/utils/utils';
import { postRequest } from '@/services/api';

import type { ShopDecorationListType, ShopDecorationType } from './typing';

const shopDecorationList = async (params: ShopDecorationListType) => {
  const { current, ...data } = params;
  const msg = (await postRequest(
    '/mall/list-front',
    { currentPage: current, ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: (msg?.result && msg?.result.list) || [],
    total: (msg?.result && msg?.result.total) || 0,
  };
};
// 新增或编辑或修改状态
const modifyFrontKind = async (data: ShopDecorationType) => {
  return (await postRequest(
    '/mall/modify-front-kind',
    { ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

export { shopDecorationList, modifyFrontKind };

// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import { POWER_HOST } from '@/services/hosts';
import { checkIsNumberForSearch, HOST_TYPE_POWER } from '@/utils/utils';

import type {
  AssignDealPersonType,
  AssignDoctorType,
  ChcekAddressType,
  ChooseUserType,
  MedicalCareAddOrderType,
  MedicalCareCancelType,
  MedicalCareUpdateOrderType,
  MedicalCareVisitListType,
  UpDataDetailsType,
} from './typings';

// 获取医护上门列表
const medicalCareVisitList = async (data: MedicalCareVisitListType) => {
  const { current, pageSize, medicalNo, bookTime, patientId, ...params } = data;
  const bookTimeStart =
    bookTime && bookTime.length === 2
      ? dayjs(`${dayjs(bookTime[0]).format('YYYY-MM-DD')} 00:00:00`).valueOf()
      : undefined;
  const bookTimeEnd =
    bookTime && bookTime.length === 2
      ? dayjs(`${dayjs(bookTime[1]).format('YYYY-MM-DD')} 23:59:59`).valueOf()
      : undefined;

  const medicalNoResult = checkIsNumberForSearch(medicalNo, '订单号');
  if (medicalNoResult !== null) return medicalNoResult;
  const patientIdResult = checkIsNumberForSearch(patientId, 'UserID');
  if (patientIdResult !== null) return patientIdResult;

  const msg = await request('/medical-care/get-order-list', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      ...params,
      medicalNo: medicalNo || 0,
      patientId: patientId || 0,
      bookTimeStart,
      bookTimeEnd,
      page: {
        page: current || 1,
        size: pageSize,
      },
    },
  });
  return {
    data: (msg.result && msg.result.orderList) || [],
    total: (msg.result && msg.result.total) || 0,
  };
};
// 可指派医生列表
const getDoctorList = async (userName?: string) => {
  return await request('/user/list-doctor-301', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: {
      userName: userName || '',
    },
  });
};
// 可指派二线人员列表
const getDealPersonList = async (name?: string) => {
  return await request('/operator/list-operator-by-role', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { roleCode: 'mc-opt', keyword: name || '' },
  });
};
// 指派二线人员
const assignDealPerson = async (data: AssignDealPersonType) => {
  const { searchParam, medicalNo } = data;
  return await request('/medical-care/update-order-user', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      dealPersonId: searchParam,
      medicalNo,
    },
  });
};
// 指派医生
const assignDoctor = async (data: AssignDoctorType) => {
  const { searchParam, medicalNo } = data;
  return await request('/medical-care/update-order-user', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      providerId: searchParam,
      medicalNo: medicalNo,
    },
  });
};
// 保存详情信息
const upDataDetails = async (data: UpDataDetailsType) => {
  // 指派二线人员
  return await request('/medical-care/save-order', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 获取详情接口
const medicalCareOrderDetail = async (medicalNo?: string) => {
  return await request('/medical-care/detail', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      medicalNo,
    },
  });
};
// 取消医护上门
const medicalCareCancel = async (data?: MedicalCareCancelType) => {
  return await request('/medical-care/cancel', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 提交金牌
const medicalCareCommit = async (medicalNo?: string) => {
  return await request('/medical-care/commit', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      medicalNo,
    },
  });
};

// 获取用户信息和使用人信息   // 1001458801
const chooseUser = async (param: ChooseUserType) => {
  return await request('/medical-care/get-users', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { ...param },
  });
};
// 检测地址接口
const chcekAddress = async (data: ChcekAddressType) => {
  return await request('/medical-care/check-address', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { address: data },
  });
};
// 查询省份
const addressListProvince = async () => {
  return await request('/address/list-province', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
  });
};
// 通过省份代码获取城市
const addressListCity = async (code?: string) => {
  return await request('/address/list-city', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { code },
  });
};
// 通过城市代码获取区域
const addressListDistrict = async (code?: string) => {
  return await request('/address/list-district', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { code },
  });
};
// 新增上门订单
const medicalCareAddOrder = async (data?: MedicalCareAddOrderType) => {
  return await request('/medical-care/add-order', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 保存修改
const medicalCareUpdateOrder = async (data?: MedicalCareUpdateOrderType) => {
  return await request('/medical-care/update-order', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export {
  medicalCareVisitList,
  getDoctorList,
  getDealPersonList,
  assignDealPerson,
  assignDoctor,
  upDataDetails,
  medicalCareOrderDetail,
  medicalCareCancel,
  medicalCareCommit,
  chooseUser,
  chcekAddress,
  addressListProvince,
  addressListCity,
  addressListDistrict,
  medicalCareAddOrder,
  medicalCareUpdateOrder,
};

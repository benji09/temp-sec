import type { ReactNode } from 'react';
type MedicalCareListType = {
  medicalNo?: string;
  patientId?: string;
  patientMobile?: string;
  goldOrderId?: string;
  providerName?: string;
  dealPersonName?: string;
  dealPersonId?: string;
  sourceType?: number;
  bookTime?: string;
  orderStatus?: number;
  goldStatus?: number;
  currentPart?: number;
  remark?: string;
  userNames?: string;
  created?: string;
  providerDepartment?: string;
};
type MedicalCareVisitListType = {
  bookTime?: string[];
  current?: number;
  currentPart?: string;
  dealPersonId?: string;
  goldOrderId?: string;
  goldStatus?: string;
  orderStatus?: string;
  pageSize?: number;
  patientId?: string;
  patientMobile?: string;
  providerId?: string;
  sourceType?: string;
  medicalNo?: string;
};
type ModalPropType = {
  modalType?: number;
  title?: string | undefined;
  modalVisible?: boolean;
  btnLoading?: boolean;
  visible?: boolean;

  status?: number;
  // 取消医护上门
  cancelMedicalVisible?: boolean;
  onCancelMedicalOk: () => void;
  onCancelMedicalSaveData: () => void;

  // 提交金牌
  submitThirdVisible?: boolean;
  onSubmitThirdSaveData: () => void;
  onSubmitThirdOk: () => void;

  onCancel: () => void;
  onCancelSave: () => void;
  onOk: () => void;
  onSaveData: () => void;
  children?: ReactNode;
};

type PropsType = {
  modalType?: number;
  medicalNo?: number | string;
  addressList?: any[];
};
// 医生信息类型
type DoctorType = {
  department?: string;
  name?: string;
  providerId?: number;
};
// 护士上门信息
type NurseType = {
  age?: number;
  certificateNo?: string;
  endServeTime?: string;
  gender?: number;
  idCardNo?: string;
  mobile?: string;
  nurseName?: string;
  outDoorTime?: string;
  serveAddress?: string;
  serveTime?: string;
  startServeTime?: string;
};
// 预约信息
type ReserveType = {
  bookAddress?: string;
  bookMobile?: string;
  bookRemark?: string;
  bookTime?: string;
};
// 使用人信息
type UsersType = {
  userId?: string;
  age?: number;
  gender?: number;
  idCardNumber?: string;
  name?: string;
  sicknessCurrent?: string;
  uncomfortableBasic?: string;
  userHealthReportUrl: string[];
};
// 工单备注列表
type WorkOrderRemarkListType = {
  comment?: string;
  operateUser?: string;
  time?: string;
};
// 详情页面获取到详情数据的类型
type DetailsDataType = {
  bookConsultId?: string;
  consultOrderId?: number;
  currentPart?: number;
  dealPersonName?: string;
  dealTime?: string;
  doctor?: DoctorType;
  doctorDealStatus?: number;
  medicalNo?: number;
  nurse?: NurseType;
  orderStatus?: number;
  recordImgAddress?: string[];
  remark?: string;
  reserve?: ReserveType;
  serverConsultId?: string;
  thirdOrderNo?: string;
  thirdStatus?: number;
  users?: UsersType[];
  workOrderRemarkList?: WorkOrderRemarkListType[];
  patientId?: string;
  patientMobile?: string;
};
type AssignDealPersonType = {
  medicalNo?: number;
  searchParam?: number;
};
type AssignDoctorType = {
  medicalNo?: number;
  searchParam?: number;
};
type usersType = {
  age?: number;
  gender?: number;
  id?: number;
  idCardNumber?: string;
  sicknessCurrent?: string;
  uncomfortableBasic?: string;
};
type ChcekAddressType = {
  cityCode?: string;
  province?: string;
  city?: string;
  area?: string;
  detailAddress?: string;
};
type MedicalCareAddOrderType = {
  address?: ChcekAddressType;
  bookTime?: string;
  mobile?: string;
  patientId?: integer;
  patientMobile?: string;
  remark?: string;
  users?: usersType[];
};
type OptionItemType = {
  name?: string;
  id?: number;
  userId?: number;
  account?: string;
  name?: string;
  operatorId?: string;
  roles?: any[];
};
type ChooseUserType = {
  id?: number;
  mobile?: string;
};
type RoleType = {
  check?: boolean;
  age?: number;
  gender?: number;
  idCardNumber?: string;
  name?: string;
  sicknessCurrent?: string;
  uncomfortableBasic?: string;
  userId?: string;
};
type MedicalCareUpdateOrderType = {
  address?: ChcekAddressType;
  bookTime?: string;
  medicalNo?: string;
  mobile?: string;
  remark?: string;
};
type UpDataDetailsType = {
  medicalNo?: number;
  remark?: string;
  sourceType?: number;
  users?: UpDataDetailsUsersType[];
};
type UpDataDetailsUsersType = {
  id?: string;
  userHealthReports?: string[];
};
type MedicalCareCancelType = {
  medicalNo?: string;
  cancelReason?: string;
};
type UpFilesLoadingType = {
  key?: undefined | number;
  flag?: boolean;
};
export {
  MedicalCareListType,
  MedicalCareVisitListType,
  ModalPropType,
  PropsType,
  AssignDealPersonType,
  AssignDoctorType,
  ChcekAddressType,
  DetailsDataType,
  MedicalCareAddOrderType,
  OptionItemType,
  ChooseUserType,
  RoleType,
  MedicalCareUpdateOrderType,
  UpDataDetailsType,
  UpDataDetailsUsersType,
  MedicalCareCancelType,
  UpFilesLoadingType,
};

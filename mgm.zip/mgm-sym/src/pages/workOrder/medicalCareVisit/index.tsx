/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useRef, useEffect } from 'react';
import { Button, DatePicker, Select } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { formatTime, useDebounce } from '@/utils/utils';
import TableLocal from '@/components/TableLocal/TableLocal';

import {
  CurrentPartStatus,
  GoldStatusIdStatus,
  OrderStatusIdStatus,
  SourceTypeStatus,
} from './util';
import {
  addressListProvince,
  assignDealPerson,
  assignDoctor,
  getDealPersonList,
  getDoctorList,
  medicalCareOrderDetail,
  medicalCareVisitList,
  medicalCareCancel,
  medicalCareCommit,
  medicalCareAddOrder,
  medicalCareUpdateOrder,
  upDataDetails,
  addressListCity,
  addressListDistrict,
} from './api';
import Modal from './components/modal';
import CreateOrEdit from './components/CreateOrEdit';
import Details from './components/Details';
import DoctorOrOperator from './components/DoctorOrOperator';
import type { MedicalCareListType, OptionItemType } from './typings';

const MODAL_TYPE_ADD = 1; // 新增
const MODAL_TYPE_EDIT = 2; // 编辑
const MODAL_TYPE_DETAIL = 3; // 详情
const MODAL_TYPE_OPERATOR = 4; // 二线人员
const MODAL_TYPE_DOCTOR = 5; // 医生

const { RangePicker } = DatePicker;
const { Option } = Select;

const MedicalCareVisit: React.ReactNode = () => {
  const createOrEditRef = useRef<any>();
  const detailsRef = useRef<any>();
  const doctorOrOperatorRef = useRef<any>();
  const actionRef = useRef<ActionType | undefined>();

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [medicalNo, setMedicalNo] = useState<string | undefined>(undefined);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [cancelMedicalVisible, setCancelMedicalVisible] = useState<boolean>(false);
  const [submitThirdVisible, setSubmitThirdVisible] = useState<boolean>(false);
  const [status, setStatus] = useState<number | undefined>(undefined);

  const [addressList, setAddressList] = useState<any[]>([]);

  const [details, setDetails] = useState({});

  const [doctorSearch, setDoctorSearch] = useState<string | undefined>(undefined);
  const [doctorOption, setDoctorOption] = useState<OptionItemType[]>([]);

  const [dealPersonSearch, setDealPersonSearch] = useState<string | undefined>(undefined);
  const [dealPerson, setDealPerson] = useState<OptionItemType[]>([]);

  // 时间选择范围三个月
  const [dates, setDates] = useState<any>([]);
  const disabledDate = (current: any) => {
    if (!dates || dates.length === 0) {
      return false;
    }
    const tooLate = dates[0] && current.diff(dates[0], 'months') > 2;
    const tooEarly = dates[1] && dates[1]?.diff(current, 'months') > 2;
    return tooEarly || tooLate;
  };

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '医护上门';
      case MODAL_TYPE_EDIT:
        return '修改';
      case MODAL_TYPE_DETAIL:
        return '详情';
      case MODAL_TYPE_OPERATOR:
        return '二线人员';
      case MODAL_TYPE_DOCTOR:
        return '医生';
    }
    return '';
  }

  // 获取医生接口
  function searchDoctor(temp: string = '') {
    getDoctorList(temp).then((res) => {
      if (res.status === 0) {
        setDoctorOption(res?.result?.userList ?? []);
      } else {
        setDoctorOption([]);
      }
    });
  }
  // 获取二线人员接口
  function searchDealPerson(temp: string = '') {
    getDealPersonList(temp).then((res) => {
      if (res.status === 0) {
        setDealPerson(res.result || []);
      } else {
        setDealPerson([]);
      }
    });
  }
  useEffect(() => {
    addressListProvince().then((res) => {
      if (res.status === 0) {
        const data: any = [];
        res.result.map((item: any) => {
          item.isLeaf = false;
          data.push(item);
        });
        setAddressList(data);
      }
    });
    searchDoctor();
    searchDealPerson();
  }, []);
  // 搜索医生
  useEffect(() => {
    const temp = doctorSearch?.trim() || '';
    searchDoctor(temp);
  }, [useDebounce(doctorSearch, 400)]);

  // 二线人员筛选
  useEffect(() => {
    const temp = dealPersonSearch?.trim() || '';
    searchDealPerson(temp);
  }, [useDebounce(dealPersonSearch, 400)]);

  // 弹框取消
  function onCancel() {
    doctorOrOperatorRef.current?.reset();
    createOrEditRef.current?.reset();
    detailsRef.current?.reset();
    setMedicalNo(undefined);
    setBtnLoading(false);
    setCancelMedicalVisible(false);
    setSubmitThirdVisible(false);
    setVisible(false);
    setTimeout(() => {
      setModalType(undefined);
    });
  }

  // 取消保存
  function onCancelSave() {
    setBtnLoading(false);
    setCancelMedicalVisible(false);
    setSubmitThirdVisible(false);
    setVisible(false);
  }

  // 弹框保存 开启二次确认
  function onOk() {
    if (modalType === 1 || modalType === 2) {
      createOrEditRef.current.takeData().then((res: any) => {
        setDetails(res);
        setVisible(true);
      });
    } else if (modalType === 3) {
      detailsRef.current.takeData().then((res: any) => {
        setDetails(res);
        setVisible(true);
      });
    } else if (modalType === 4 || modalType === 5) {
      doctorOrOperatorRef.current.takeData().then((res: any) => {
        setDetails(res);
        setVisible(true);
      });
    }
  }

  // 二次确认后保存
  function onSaveData() {
    setBtnLoading(true);
    if (modalType === 1) {
      medicalCareAddOrder(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          createOrEditRef.current.reset();
          setMedicalNo(undefined);
          setDetails({});
          setModalType(undefined);
        }
      });
    } else if (modalType === 2) {
      medicalCareUpdateOrder({ ...details, medicalNo }).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          createOrEditRef.current.reset();
          setMedicalNo(undefined);
          setDetails({});
          setModalType(undefined);
        }
      });
    } else if (modalType === 3) {
      upDataDetails(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          detailsRef.current.reset();
          setMedicalNo(undefined);
          setDetails({});
          setModalType(undefined);
        }
      });
    } else if (modalType === 4) {
      // 指派二线人员
      assignDealPerson(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          doctorOrOperatorRef.current.reset();
          setMedicalNo(undefined);
          setDetails({});
          setModalType(undefined);
        }
      });
    } else if (modalType === 5) {
      // 指派医生
      assignDoctor(details).then((res) => {
        setVisible(false);
        setBtnLoading(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          doctorOrOperatorRef.current.reset();
          setMedicalNo(undefined);
          setDetails({});
          setModalType(undefined);
        }
      });
    }
  }

  //  关闭医护上门订单 开启二次确认
  function onCancelMedicalOk() {
    detailsRef.current.MedicalData().then((res: any) => {
      setDetails(res);
      setCancelMedicalVisible(true);
      setBtnLoading(false);
    });
  }

  // 关闭医护上门订单 二次确认后保存
  function onCancelMedicalSaveData() {
    setBtnLoading(true);
    medicalCareCancel({ medicalNo, ...details }).then((res) => {
      setBtnLoading(false);
      setCancelMedicalVisible(false);
      if (res.status === 0) {
        setMedicalNo(undefined);
        actionRef.current?.reload();
        detailsRef.current?.reset();
        setTimeout(() => setModalType(undefined));
      }
    });
  }

  //  关闭提交金牌弹框 开启二次确认
  function onSubmitThirdOk() {
    setSubmitThirdVisible(true);
    setBtnLoading(false);
  }

  // 关闭提交金牌弹框 二次确认后保存
  function onSubmitThirdSaveData() {
    setBtnLoading(true);
    medicalCareCommit(medicalNo).then((res) => {
      setBtnLoading(false);
      setSubmitThirdVisible(false);
      if (res.status === 0) {
        setMedicalNo(undefined);
        actionRef.current?.reload();
        detailsRef.current?.reset();
        setTimeout(() => setModalType(undefined));
      }
    });
  }

  // 点击编辑
  function detailClick(record: MedicalCareListType, type: number) {
    if (type === 2) {
      medicalCareOrderDetail(record.medicalNo).then((res) => {
        const { result } = res;
        if (res.status === 0) {
          const { area, cityCode, province } = result.reserve.address;
          const cityStr: string[] = [];

          addressList.map((provinceItem) => {
            if (
              provinceItem.name === province ||
              provinceItem.name.search(province) != -1 ||
              province.search(provinceItem.name) != -1
            ) {
              cityStr.push(provinceItem.code);
              addressListCity(provinceItem.code).then((CityRes) => {
                if (CityRes.status === 0) {
                  const data: any[] = [];
                  CityRes.result.map((CityItem: any) => {
                    CityItem.isLeaf = false;
                    data.push(CityItem);
                    provinceItem.children = data;
                    if (CityItem.code === cityCode) {
                      cityStr.push(cityCode);
                      addressListDistrict(cityCode).then((DistrictRes) => {
                        if (DistrictRes.status === 0) {
                          const DistrictData: any[] = [];
                          DistrictRes.result.map((DistrictItem: any) => {
                            if (DistrictItem.name === area) {
                              cityStr.push(DistrictItem.code);
                            }
                            DistrictItem.isLeaf = false;
                            DistrictData.push(DistrictItem);
                          });
                          CityItem.children = DistrictData;
                          createOrEditRef.current?.setData({ cityStr, ...result });
                        }
                      });
                    }
                  });
                }
              });
              createOrEditRef.current?.setData({ cityStr, ...result });
            }
          });
        }
      });
    } else if (type === 3) {
      medicalCareOrderDetail(record.medicalNo).then((res) => {
        if (res.status === 0) {
          detailsRef.current?.setData(res.result);
        }
      });
    } else if (type === 4) {
      getDealPersonList().then((res) => {
        if (res.status === 0) {
          doctorOrOperatorRef.current?.setData({
            optionItem: res.result,
            searchParam: record.dealPersonName,
          });
        }
      });
    } else if (type === 5) {
      getDoctorList().then((res) => {
        if (res.status === 0) {
          doctorOrOperatorRef.current?.setData({
            optionItem: res?.result?.userList ?? [],
            searchParam: record.providerName ?? '',
          });
        }
      });
    }
    setStatus(record.goldStatus);
    setModalType(type);
    setMedicalNo(record.medicalNo);
  }

  const columns: ProColumns<MedicalCareListType>[] = [
    {
      title: '订单号',
      dataIndex: 'medicalNo',
    },
    {
      title: '金牌护士订单号',
      dataIndex: 'goldOrderId',
      hideInSearch: true,
    },
    {
      title: '来源',
      dataIndex: 'sourceType',
      valueEnum: SourceTypeStatus,
      hideInSearch: true,
    },
    {
      title: 'UserID',
      dataIndex: 'patientId',
    },
    {
      title: '手机号',
      dataIndex: 'patientMobile',
    },
    {
      title: '金牌护士订单号',
      dataIndex: 'goldOrderId',
      hideInTable: true,
    },
    // 支持模糊搜索
    {
      title: '医生筛选',
      dataIndex: 'providerId',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Select
            style={{ width: '100%' }}
            showSearch
            placeholder="选择可指派的医生"
            showArrow={false}
            filterOption={false}
            allowClear={true}
            onSearch={setDoctorSearch}
            notFoundContent={null}
          >
            {doctorOption.length &&
              doctorOption.map((item) => {
                return (
                  <Option key={`${item.userId}`} value={item.userId || ''}>
                    {item.name}
                  </Option>
                );
              })}
          </Select>
        );
      },
    },
    // 支持模糊搜索
    {
      title: '二线人员筛选',
      dataIndex: 'dealPersonId',
      renderFormItem: () => {
        return (
          <Select
            style={{ width: '100%' }}
            showSearch
            placeholder="选择可指派的二线人员"
            showArrow={false}
            filterOption={false}
            allowClear={true}
            onSearch={setDealPersonSearch}
            notFoundContent={null}
          >
            {dealPerson.length &&
              dealPerson.map((item) => {
                return (
                  <Option value={item.operatorId || ''} key={item.operatorId}>
                    {item.name}
                  </Option>
                );
              })}
          </Select>
        );
      },
      hideInTable: true,
    },
    // 下拉选择
    {
      title: '来源筛选',
      dataIndex: 'sourceType',
      valueEnum: SourceTypeStatus,
      hideInTable: true,
    },
    {
      title: '创建日期',
      dataIndex: 'createdAt',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '预约上门日期',
      dataIndex: 'bookTime',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '预约上门日期',
      dataIndex: 'bookTime',
      renderFormItem: () => {
        return (
          <RangePicker
            disabledDate={disabledDate}
            onCalendarChange={(val) => setDates(val)}
            placeholder={['开始日期', '结束日期']}
          />
        );
      },
      hideInTable: true,
    },
    {
      title: '二线人员',
      align: 'center',
      dataIndex: 'dealPersonName',
      render: (_text, record) => [
        record.dealPersonId !== '0' ? (
          <span key={'providerName'}>{record.dealPersonName}</span>
        ) : (
          <Button
            style={{ padding: '0px' }}
            key={'detail'}
            onClick={() => detailClick(record, MODAL_TYPE_OPERATOR)}
            type="link"
          >
            未指派
          </Button>
        ),
      ],
      hideInSearch: true,
    },
    {
      title: '医生',
      align: 'center',
      dataIndex: 'providerName',
      render: (_text, record) => [
        <Button
          style={{ padding: '0px' }}
          key={'providerName'}
          onClick={() => detailClick(record, MODAL_TYPE_DOCTOR)}
          type="link"
        >
          {!record.providerName ? (
            '未指派'
          ) : (
            <span key={'providerName'}>
              {record.providerName}+{record.providerDepartment}
            </span>
          )}
        </Button>,
        // ),
      ],
      hideInSearch: true,
    },
    {
      title: '使用人',
      dataIndex: 'userNames',
      hideInSearch: true,
    },
    // 下拉选择
    {
      title: '订单状态',
      dataIndex: 'orderStatus',
      valueEnum: OrderStatusIdStatus,
    },
    // 下拉选择
    {
      title: '金牌状态',
      dataIndex: 'goldStatus',
      valueEnum: GoldStatusIdStatus,
    },
    // 下拉选择
    {
      title: '所处阶段',
      dataIndex: 'currentPart',
      valueEnum: CurrentPartStatus,
    },
    {
      title: '备注',
      dataIndex: 'remark',
      hideInSearch: true,
    },

    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (_text, record) => [
        <Button
          style={{ padding: '0px' }}
          key={'detail'}
          onClick={() => detailClick(record, MODAL_TYPE_DETAIL)}
          type="link"
        >
          详情
        </Button>,
        record.goldStatus === 1 && (
          <Button
            style={{ padding: '0px' }}
            key={'edit'}
            onClick={() => detailClick(record, MODAL_TYPE_EDIT)}
            type="link"
          >
            编辑
          </Button>
        ),
      ],
    },
  ];

  return (
    <TableLocal
      columns={columns}
      request={medicalCareVisitList}
      rowKey="medicalNo"
      search={{
        labelWidth: 110,
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      actionRef={actionRef}
      toolBarRender={() => [
        <Button
          key="primary"
          type="primary"
          onClick={() => {
            setModalType(MODAL_TYPE_ADD);
          }}
        >
          <PlusOutlined />
          新增
        </Button>,
      ]}
    >
      <Modal
        cancelMedicalVisible={cancelMedicalVisible}
        onCancelMedicalOk={onCancelMedicalOk}
        onCancelMedicalSaveData={onCancelMedicalSaveData}
        submitThirdVisible={submitThirdVisible}
        onSubmitThirdOk={onSubmitThirdOk}
        onSubmitThirdSaveData={onSubmitThirdSaveData}
        status={status}
        title={getModalTitle()}
        modalType={modalType}
        onCancel={onCancel}
        onCancelSave={onCancelSave}
        onOk={onOk}
        onSaveData={onSaveData}
        modalVisible={!!modalType}
        btnLoading={btnLoading}
        visible={visible}
      >
        {/* 新建 */}
        {modalType === MODAL_TYPE_ADD && (
          <CreateOrEdit addressList={addressList} modalType={modalType} ref={createOrEditRef} />
        )}
        {/* 修改 */}
        {modalType === MODAL_TYPE_EDIT && (
          <CreateOrEdit addressList={addressList} modalType={modalType} ref={createOrEditRef} />
        )}
        {/* 详情 */}
        {modalType === MODAL_TYPE_DETAIL && <Details modalType={modalType} ref={detailsRef} />}
        {/* 指派二线人员 */}
        {modalType === MODAL_TYPE_OPERATOR && (
          <DoctorOrOperator medicalNo={medicalNo} modalType={modalType} ref={doctorOrOperatorRef} />
        )}
        {/* 指派医生 */}
        {modalType === MODAL_TYPE_DOCTOR && (
          <DoctorOrOperator medicalNo={medicalNo} modalType={modalType} ref={doctorOrOperatorRef} />
        )}
      </Modal>
    </TableLocal>
  );
};
export default MedicalCareVisit;

import React from 'react';
import { Card } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import welcome from '@/assets/images/welcome.png';

import './index.less';

export default (): React.ReactNode => {
  return (
    <PageContainer pageHeaderRender={false}>
      <Card>
        <div className={'container'}>
          <img src={welcome} className={'image'} />
        </div>
      </Card>
    </PageContainer>
  );
};

/*
 * @Author: Walker Denial
 * @Date: 2021-08-31 19:10:13
 * @LastEditors: zyx
 * @LastEditTime: 2021-09-03 15:58:23
 * @Desc:
 */
const PRODUCT_STATUS = {
  1: {
    text: '上架',
  },
  2: {
    text: '下架',
  },
};
const MEDICINE_STATUS = {
  1: {
    text: '是',
  },
  2: {
    text: '否',
  },
  0: {
    text: '-',
  },
};
export { PRODUCT_STATUS, MEDICINE_STATUS };

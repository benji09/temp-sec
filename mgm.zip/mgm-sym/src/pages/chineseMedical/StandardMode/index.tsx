import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { getStandardModeList } from '@/services/api';

import AddModal from './components/Edit/addModal';
import { MEDICINE_STATUS } from '../utils';

type tableItem = {
  formulaName: string;
  herbName: string[];
  id: number;
  processingMethods: number;
  status: number;
  stockStatus: number;
};
const StandardMode: React.FC = () => {
  const [id, setId] = useState<string | number>('');
  const [editModalVisible, handleEditModalVisible] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');
  const actionRef = useRef<ActionType | undefined>();

  const columns: ProColumns<tableItem>[] = [
    {
      title: 'ID',
      dataIndex: 'id',
    },
    {
      title: '标准方名称',
      dataIndex: 'formulaName',
    },
    {
      title: '加工方式',
      dataIndex: 'processingMethods',
      hideInSearch: true,
      valueType: 'select',
      valueEnum: {
        1: {
          text: '颗粒状',
        },
      },
    },
    {
      title: '药材',
      dataIndex: 'herbName',
      render: (_text, record) => [<span key={'herbName'}> {record.herbName.join('、')}</span>],
    },
    {
      title: '是否缺货',
      dataIndex: 'stockStatus',
      hideInSearch: true,
      render: (text) => (text === 1 ? <span style={{ color: '#f00' }}>是</span> : <span>否</span>),
    },
    {
      title: '是否上架',
      dataIndex: 'status',
      hideInSearch: true,
      valueEnum: MEDICINE_STATUS,
    },
    {
      title: '操作',
      dataIndex: 'option',
      hideInSearch: true,
      valueType: 'option',
      render: (_text, record) => [
        <a
          key="config"
          onClick={() => {
            setId(record.id);
            setTitle('编辑');
            handleEditModalVisible(true);
          }}
        >
          编辑
        </a>,
      ],
    },
  ];
  const onSubmit = () => {
    handleEditModalVisible(false);
    actionRef.current?.reload();
    setId('');
  };
  const onCancel = () => {
    handleEditModalVisible(false);
    setId('');
  };

  return (
    <PageContainer>
      <ProTable<tableItem>
        columns={columns}
        actionRef={actionRef}
        request={getStandardModeList}
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        rowKey="id"
        dateFormatter="string"
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          <Button
            key="primary"
            type="primary"
            onClick={() => {
              setTitle('新增');
              handleEditModalVisible(true);
            }}
          >
            <PlusOutlined />
            新增
          </Button>,
        ]}
      />

      <AddModal
        editModalVisible={editModalVisible}
        title={title}
        id={id}
        onSubmit={onSubmit}
        onCancel={onCancel}
      />
    </PageContainer>
  );
};
export default StandardMode;

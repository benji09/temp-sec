import React, { useState, useRef } from 'react';
import { Button, Modal } from 'antd';

import { getSKUList, modifySkuStatus } from '@/services/api';
import { PageContainer } from '@ant-design/pro-layout';
import type { ActionType, ProColumns } from '@ant-design/pro-table';
import ProTable from '@ant-design/pro-table';
import { PRODUCT_STATUS } from '../utils/index';

import './index.less';

type HerbsItem = {
  herbId?: number;
  herbName?: string;
  referencePrice?: number;
  sellPrice?: number;
  settlementPrice?: number;
  skuId?: number;
  weight?: null;
  status?: number;
};
const ChineseMedicalSKU: React.FC = () => {
  const [loading, setLoading] = useState<any>({});
  const actionRef = useRef<ActionType | undefined>();
  const toggleStatus = (id: number, status: boolean) => {
    const newLoading = { ...loading };
    newLoading[id] = status;
    setLoading(newLoading);
  };
  const modifyStatus = (record: HerbsItem) => {
    Modal.confirm({
      title: '提示信息',
      content: `是否确认${record.status === 1 ? '下架' : '上架'}？`,
      okText: '是',
      onOk() {
        toggleStatus(record.herbId ?? 0, true);
        modifySkuStatus({ id: record.herbId ?? 0, status: record.status === 1 ? 2 : 1 })
          .then((res: any) => {
            if (res && res.status === 0) {
              actionRef?.current?.reload();
            }
          })
          .finally(() => {
            toggleStatus(record.herbId ?? 0, false);
          });
      },
      cancelText: '否',
    });
  };
  const columns: ProColumns<HerbsItem>[] = [
    {
      title: 'SKU',
      dataIndex: 'skuId',
      hideInSearch: false,
    },
    {
      title: '药品名称',
      dataIndex: 'herbName',
      hideInSearch: false,
    },
    {
      title: '结算价（每克）',
      dataIndex: 'settlementPrice',
      hideInSearch: true,
      renderText: (value) => `￥${value}`,
    },
    {
      title: '零售价（每克）',
      dataIndex: 'sellPrice',
      hideInSearch: true,
      renderText: (value) => `￥${value}`,
    },
    {
      title: '参考价',
      dataIndex: 'referencePrice',
      hideInSearch: true,
      hideInTable: true,
      renderText: (value) => `￥${value}`,
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueEnum: PRODUCT_STATUS,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => {
        return (
          <div className={`cmSkuBtn ${record.status === 1 ? 'down' : 'up'}`}>
            <Button
              type="link"
              onClick={() => modifyStatus(record)}
              loading={loading[record.skuId ?? 0]}
            >
              设置{record.status === 1 ? '下架' : '上架'}
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <PageContainer>
      <ProTable<HerbsItem>
        columns={columns}
        request={getSKUList}
        rowKey="skuId"
        dateFormatter="string"
        actionRef={actionRef}
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{
          defaultPageSize: 10,
        }}
      />
    </PageContainer>
  );
};
export default ChineseMedicalSKU;

import type { ReactNode } from 'react';

type DetailsType = {
  id?: number;
  idNo?: string; // 证件号码
  name?: string; // 投保人姓名
  idType?: number; // 证件类型
  userId?: number; // 账户id
  remark?: string[]; // 备注
  phone?: string; // 账户手机号
  status?: number; // 体检报告状态
  channel?: number; // 渠道
  cardCode?: string; // 卡号
  insureNo?: string; // 投保单号
  userName?: string; // 使用人姓名
  bindTime?: number; // 绑定时间
  userPhone?: string; // 使用人手机号
  checkPhone?: string; // 验证权益手机号
  auditResult?: string; // 审核结果
  receiveTime?: number; // 领取时间
  medicalReportPdf?: string[]; // 体检报告(pdf)
  medicalReportPic?: string[]; // 体检报告(pic)
  organizationName?: string; // 机构
  organizationCode?: string; // 标识编码
  salesmanName?: string; // 业务员
  salesmanPhone?: string; // 业务员电话
  age?: number; // 年龄
  gender?: number; // 性别
  historyReports?: HistoryItem[]; // 历史报告
};
type HistoryItem = {
  createdTime?: string;
  medicalReportPdf?: string[];
  medicalReportPic?: string[];
  reason?: string;
  status?: string;
};
type ModalPropType = {
  ModalVisible: boolean;
  title: string;
  loading: boolean;
  onCancel: () => void;
  onOk: () => void;
  children?: ReactNode;
};
export { DetailsType, ModalPropType, HistoryItem };

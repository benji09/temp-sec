/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useRef, useState } from 'react';
import _ from 'lodash';
import { history } from 'umi';
import { PageContainer } from '@ant-design/pro-layout';
import { Card, Space, Row, Col, Button, Image, List, Upload } from 'antd';
import { CloseCircleOutlined, FilePdfOutlined, UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';

import KEYS from '@/utils/storageKeys';
import { genderStatus } from '@/pages/workOrder/medicalCareVisit/util';
import { getCosDownladUrl, uploadFile } from '@/services/api';
import { checkFileSize, formatTime } from '@/utils/utils';
import { getItemUserInfo } from '@/utils/userInfoEncrypt';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import Modal from './components/Modal';
import Cause from './components/Cause';
import Remark from './components/Remark';
import { lifeBankDetail } from '../userManagement/api';
import { ChannelType, idType, StatusType } from '../utils';
import { addRemark, auditMedicalReport, lifeBankDownloadReport, uploadReport } from './api';
import type { DetailsType, HistoryItem } from './typings';

import './index.less';

const MODAL_TYPE_CAUSE = 1;
const MODAL_TYPE_REMARK = 2;
let filesList: string[] = [];
let filesListLength: number = 0;

const Details: React.ReactNode = () => {
  const id: string = String(history.location.query?.id) || '';
  const [loading, setLoading] = useState<boolean>(true);
  const [details, setDetails] = useState<DetailsType>({});

  const [filesLoading, setFilesLoading] = useState(false); // 上传的loading

  const [ModalVisible, setModalVisible] = useState<boolean>(false);
  const [ModalLoading, setModalLoading] = useState<boolean>(false);
  const [modalType, setModalType] = useState<number | undefined>(undefined);

  const causeRef = useRef<any>();
  const remarkRef = useRef<any>();

  function getDetaileData(dataId: string = id) {
    lifeBankDetail(dataId ?? '').then((res) => {
      setLoading(false);
      if (res.status === 0) {
        res.result = setDetails(res.result);
      }
    });
  }

  useEffect(() => {
    getDetaileData(id);
  }, [id]);

  function upDataMedicalReport(medicalReportList: any) {
    uploadReport(medicalReportList).then((res) => {
      if (res.status === 0) {
        history.push(`/cellula/userManagement/details?id=${res?.result ?? ''}`);
        // getDetaileData(res.result);
      }
    });
  }

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_CAUSE:
        return '不通过原因';
      case MODAL_TYPE_REMARK:
        return '备注';
    }
    return '';
  }

  function handleBeforeUpload(file: RcFile, FileList: RcFile[]) {
    const fileName =
      (file?.name || '').endsWith('.pdf') || (file.type && file.type?.indexOf('image') >= 0);
    if (!fileName) {
      showErrorMessage(`只能上传格式为 pdf或图片 的文件`);
      return fileName;
    }

    let pdfList: number = (details.medicalReportPdf ?? []).length;
    let imageList: number = 0;

    FileList.map((item) => {
      if ((item.type ?? []).indexOf('pdf') >= 0) {
        pdfList = pdfList + 1;
      }
      if ((item.type ?? []).indexOf('image') >= 0) {
        imageList = imageList + 1;
      }
    });
    if (pdfList > 3) {
      showErrorMessage(`pdf 文件最多三个，现在已超过三个`);
      return false;
    }
    if (imageList > 30) {
      showErrorMessage(`图片 文件最多 30 张，现在已超过 30 张`);
      return false;
    }
    if (!checkFileSize(file, 30, 4)) return false;
    filesListLength = FileList.length;

    return fileName;
  }
  function customeUpload(options: any) {
    setFilesLoading(true);
    uploadFile(options, (key) => {
      filesList.push(getCosDownladUrl(key) ?? '');
      if (filesList.length === filesListLength) {
        if (filesList.length > 0) {
          const medicalReportList: any = _.cloneDeep({
            id: id,
            medicalReportPic: details.medicalReportPic,
            medicalReportPdf: details.medicalReportPdf,
          });
          filesList.map((item) => {
            if (item.indexOf('pdf') >= 0) {
              medicalReportList.medicalReportPdf.push(item);
            } else {
              medicalReportList.medicalReportPic.push(item);
            }
          });
          uploadReport(medicalReportList)
            .then((res) => {
              if (res.status === 0) {
                // getDetaileData(res.result);
                history.push(`/cellula/userManagement/details?id=${res?.result ?? ''}`);
              }
            })
            .finally(() => {
              filesListLength = 0;
              filesList = [];

              setFilesLoading(false);
            });
        }
      }
    });
  }

  function DownloadClick() {
    lifeBankDownloadReport(id ?? '').then((res) => {
      const { result } = res;
      if (result && result.startsWith('https')) {
        window.open(result);
      }
    });
  }
  function onCancel() {
    setModalVisible(false);
    setModalLoading(false);
    setModalType(undefined);
    causeRef.current?.reset();
    remarkRef.current?.reset();
  }
  function onOk() {
    if (modalType === MODAL_TYPE_CAUSE) {
      causeRef.current?.takeData().then((data: any) => {
        setModalLoading(true);
        auditMedicalReport({ id: id, userId: details.userId, ...data }).then((res) => {
          setModalLoading(false);

          if (res.status === 0) {
            showSuccessMessage('操作成功');
            getDetaileData();
            setModalVisible(false);
            setModalType(undefined);
            causeRef.current?.reset();
          }
        });
      });
    }
    if (modalType === MODAL_TYPE_REMARK) {
      const user = getItemUserInfo(KEYS.KEY_USER_INFO);
      remarkRef.current?.takeData().then((data: any) => {
        setModalLoading(true);
        addRemark({ id: id, userName: user.name ?? '', ...data }).then((res) => {
          setModalLoading(false);

          if (res.status === 0) {
            showSuccessMessage('操作成功');
            getDetaileData();
            setModalVisible(false);
            setModalType(undefined);
            remarkRef.current?.reset();
          }
        });
      });
    }
  }
  return (
    <PageContainer className="cellulaUserDetails">
      <Card loading={loading}>
        <Space direction="vertical" style={{ width: '100%' }}>
          <Card title="关联信息" style={{ width: '100%' }}>
            <Row>
              <Col span={12}>UserID: {details?.userId ?? ''}</Col>
              <Col span={12}>账号手机号码: {details?.phone ?? ''}</Col>
              <Col span={12}>渠道: {ChannelType[details?.channel ?? '']?.text ?? ''}</Col>
              <Col span={12}>领取日期: {formatTime(details?.receiveTime) ?? ''}</Col>
              <Col span={12}>保单号: {details?.insureNo ?? ''}</Col>
              <Col span={12}>投保人姓名: {details?.name ?? ''}</Col>
              <Col span={12}>投保人电话: {details?.checkPhone ?? ''}</Col>
              <Col span={12}>卡号: {details?.cardCode ?? ''}</Col>
              <Col span={12}>验证权益手机号: {details?.checkPhone ?? ''}</Col>
              <Col span={12} />
              <Col span={12}>机构: {details?.organizationName ?? ''}</Col>
              <Col span={12}>业务员: {details?.salesmanName ?? ''}</Col>
              <Col span={12}>标识编码: {details?.organizationCode ?? ''}</Col>
              <Col span={12}>业务员电话: {details?.salesmanPhone ?? ''}</Col>
            </Row>
          </Card>
          <Card title="使用人基本信息" style={{ width: '100%' }}>
            <Row>
              <Col span={12}>使用人姓名: {details?.userName}</Col>
              <Col span={12}>联系电话: {details?.userPhone}</Col>
              <Col span={12}>使证件类型: {idType[details?.idType ?? '']?.text ?? ''}</Col>
              <Col span={12}>证件号码: {details?.idNo}</Col>
              <Col span={12}>年龄: {(details?.age ?? -1) > 0 ? details?.age : ''}</Col>
              <Col span={12}>性别: {genderStatus(details?.gender).replace('-', '')}</Col>
              <Col span={12}>绑定时间: {formatTime(details?.bindTime)}</Col>
            </Row>
          </Card>
          <Card
            title={
              <>
                体检报告信息
                <Button
                  type="link"
                  onClick={() => {
                    DownloadClick();
                  }}
                >
                  下载体检报告
                </Button>
                <Upload
                  accept={'image/*,.pdf'}
                  maxCount={20}
                  beforeUpload={handleBeforeUpload}
                  customRequest={customeUpload}
                  showUploadList={false}
                  multiple
                >
                  <Button key="primary" type="link" disabled={filesLoading} loading={filesLoading}>
                    {filesLoading ? null : <UploadOutlined />}
                    上传体检报告
                  </Button>
                </Upload>
              </>
            }
            style={{ width: '100%' }}
          >
            <Row>
              {/* 未处理完 */}
              <Col span={24}>
                体检报告状态: {(details?.status === 4 || details?.status === 5) && '不通过 - '}
                {StatusType[details?.status ?? '']?.text ?? ''}
                {details?.auditResult && ' + ' + details?.auditResult}
              </Col>
              {/* 体检报告 文件 */}
              <Col span={24} className="medicalReport">
                {(details?.medicalReportPdf ?? []).map((item, index) => {
                  return (
                    <span className="detailsImageItem" key={item + String(index)}>
                      <i
                        className="imageClose"
                        onClick={(e) => {
                          e.stopPropagation();
                          const tempMedicalReport = _.cloneDeep({
                            medicalReportPic: details.medicalReportPic,
                            id: id,
                            medicalReportPdf: details.medicalReportPdf,
                          });
                          (tempMedicalReport?.medicalReportPdf ?? []).splice(index, 1);
                          upDataMedicalReport(tempMedicalReport);
                        }}
                      >
                        <CloseCircleOutlined />
                      </i>
                      <a href={item} target="_blank">
                        <FilePdfOutlined />
                      </a>
                    </span>
                  );
                })}
              </Col>
              {/* 体检报告 图片 */}
              <Col span={24} className="medicalReport">
                <Image.PreviewGroup>
                  {(details?.medicalReportPic ?? []).map((item, index) => {
                    return (
                      <span className="detailsImageItem" key={item + String(index)}>
                        <i
                          className="imageClose"
                          onClick={(e) => {
                            e.stopPropagation();
                            const tempMedicalReport = _.cloneDeep({
                              medicalReportPic: details.medicalReportPic,
                              id: id,
                              medicalReportPdf: details.medicalReportPdf,
                            });
                            (tempMedicalReport?.medicalReportPic ?? []).splice(index, 1);
                            upDataMedicalReport(tempMedicalReport);
                          }}
                        >
                          <CloseCircleOutlined />
                        </i>
                        <Image src={item} />
                      </span>
                    );
                  })}
                </Image.PreviewGroup>
              </Col>

              {details?.status === 6 && (
                <Col span={24} className="resultButton">
                  <Button
                    className="itemButton"
                    type="primary"
                    onClick={() => {
                      auditMedicalReport({ id: id, status: 11, userId: details.userId }).then(
                        (res) => {
                          if (res.status === 0) {
                            showSuccessMessage('操作成功');
                            getDetaileData();
                          }
                        },
                      );
                    }}
                  >
                    通过
                  </Button>
                  <Button
                    className="itemButton"
                    type="primary"
                    onClick={() => {
                      setModalType(MODAL_TYPE_CAUSE);
                      setModalVisible(true);
                    }}
                  >
                    不通过
                  </Button>
                </Col>
              )}
            </Row>
            {details.historyReports &&
              details.historyReports.length > 0 &&
              details.historyReports.map((value: HistoryItem) => {
                const { createdTime, medicalReportPdf, medicalReportPic, reason, status } = value;
                return (
                  <Row key={value.createdTime}>
                    <Col span={24}>{`${createdTime} ${status} ${reason}`}</Col>
                    <Col span={24} className="medicalReport">
                      {(medicalReportPdf ?? []).map((item, index) => {
                        return (
                          <span className="detailsImageItem" key={item + String(index)}>
                            <a href={item} target="_blank">
                              <FilePdfOutlined />
                            </a>
                          </span>
                        );
                      })}
                    </Col>
                    {/* 体检报告 图片 */}
                    <Col span={24} className="medicalReport">
                      <Image.PreviewGroup>
                        {(medicalReportPic ?? []).map((item, index) => {
                          return (
                            <span className="detailsImageItem" key={item + String(index)}>
                              <Image src={item} />
                            </span>
                          );
                        })}
                      </Image.PreviewGroup>
                    </Col>
                  </Row>
                );
              })}
          </Card>
          <Card
            title={
              <>
                备注
                <Button
                  type="link"
                  onClick={() => {
                    setModalType(MODAL_TYPE_REMARK);
                    setModalVisible(true);
                  }}
                >
                  添加备注
                </Button>
              </>
            }
            style={{ width: '100%' }}
          >
            <List
              dataSource={details?.remark ?? []}
              renderItem={(item) => <List.Item>{item}</List.Item>}
            />
          </Card>
        </Space>
      </Card>
      <Modal
        ModalVisible={ModalVisible}
        title={getModalTitle()}
        loading={ModalLoading}
        onCancel={onCancel}
        onOk={onOk}
      >
        {modalType === MODAL_TYPE_CAUSE && <Cause ref={causeRef} />}
        {modalType === MODAL_TYPE_REMARK && <Remark ref={remarkRef} />}
      </Modal>
    </PageContainer>
  );
};
export default Details;

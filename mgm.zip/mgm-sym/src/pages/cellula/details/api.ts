import { getRequest, postRequest } from '@/services/api';
import { HOST_TYPE_POWER, RESULT_TYPE_TEXT } from '@/utils/utils';

// 下载接口
const lifeBankDownloadReport = async (id: string, options?: any) => {
  return (await getRequest(
    '/life-bank/download-report',
    { id: id || '' },
    { type: HOST_TYPE_POWER, resultType: RESULT_TYPE_TEXT, ...options },
  )) as unknown as APIS.BaseResponse<any>;
};
const uploadReport = async (options: any) => {
  return (await postRequest(
    '/life-bank/upload-report',
    { ...options },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

const auditMedicalReport = async (data: any) => {
  return (await postRequest(
    '/life-bank/audit-medical-report',
    { ...data },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
const addRemark = async (data: any) => {
  return (await postRequest(
    '/life-bank/add-remark',
    { ...data },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};

export { lifeBankDownloadReport, uploadReport, auditMedicalReport, addRemark };

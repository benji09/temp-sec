const StatusType = {
  1: { text: '待完善使用人' },
  2: { text: '待绑定使用人' },
  3: { text: '待上传体检报告' },
  4: { text: '更换使用人' },
  5: { text: '重新上传体检报告' },
  6: { text: '待审核体检报告' },
  11: { text: '体检报告审核通过' },
};
const idType = {
  0: { text: '身份证' },
  1: { text: '护照' },
  2: { text: '军官证' },
  3: { text: '驾照' },
  4: { text: '出生证明' },
  5: { text: '户口薄' },
  6: { text: '港澳台胞证' },
  8: { text: '其他' },
};
const ChannelType = {
  1: {
    text: '阳光',
  },
  2: {
    text: '非阳光',
  },
};
export { StatusType, idType, ChannelType };

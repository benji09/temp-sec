import React, { useRef, useState } from 'react';
import dayjs from 'dayjs';
import { Button, Popconfirm } from 'antd';
import { history, KeepAlive } from 'umi';
import { DownloadOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/index';
import { ClickDownXlsx } from '@/utils/downXlsx';
import { formatTime } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import { deleteRelatedUser, exportData, getCellulaUserList } from './api';
import { ChannelType, StatusType } from '../utils';

const CellulaUserList: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const [exportLoading, setExportLoading] = useState<boolean>(false);

  // 点击导出按钮
  function exportClick() {
    setExportLoading(true);
    exportData().then((res: any) => {
      setExportLoading(false);
      const { size } = res;
      if (size <= 500) {
        showErrorMessage('数据流异常，无法正常下载');
        return;
      }
      ClickDownXlsx(res, '用户管理');
      showSuccessMessage('导出成功');
    });
  }
  // 点击删除
  function deleteClick(id?: string) {
    deleteRelatedUser(id ?? '').then((res) => {
      if (res.status === 0) {
        actionRef.current?.reload();
        showSuccessMessage('删除成功');
      }
    });
  }
  const columns: ProColumns[] = [
    {
      title: 'UserID',
      dataIndex: 'userId',
      hideInSearch: true,
    },
    {
      title: '账号手机号码',
      dataIndex: 'phone',
      hideInSearch: true,
    },
    {
      title: '渠道',
      dataIndex: 'channel',
      valueEnum: ChannelType,
      hideInSearch: true,
    },
    {
      title: '保单号',
      dataIndex: 'insureNo',
      hideInSearch: true,
    },
    {
      title: '投保人姓名',
      dataIndex: 'name',
      hideInSearch: true,
    },
    {
      title: '验证权益手机号',
      dataIndex: 'checkPhone',
      hideInSearch: true,
    },
    {
      title: '卡号',
      dataIndex: 'cardCode',
      hideInSearch: true,
    },

    {
      title: '领取日期',
      dataIndex: 'receiveTime',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '使用人',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueEnum: StatusType,
      hideInSearch: true,
    },
    {
      title: '备注',
      dataIndex: 'remark',
      hideInSearch: true,
    },

    // 搜索数据
    {
      title: '投保人姓名',
      dataIndex: 'name',
      hideInTable: true,
    },
    {
      title: '使用人',
      dataIndex: 'userName',
      hideInTable: true,
    },
    {
      title: '卡号',
      dataIndex: 'cardCode',
      hideInTable: true,
    },
    {
      title: '渠道',
      dataIndex: 'channel',
      valueType: 'select',
      valueEnum: ChannelType,
      hideInTable: true,
    },
    {
      title: '领取日期',
      dataIndex: 'receiveTime',
      valueType: 'dateRange',
      hideInTable: true,
      search: {
        transform: (value) => {
          return {
            receiveTimeStart: dayjs(`${value[0]} 00:00:00`).valueOf(),
            receiveTimeEnd: dayjs(`${value[1]} 23:59:59`).valueOf(),
          };
        },
      },
    },
    {
      title: '账号手机号码',
      dataIndex: 'phone',
      hideInTable: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueType: 'select',
      valueEnum: StatusType,
      hideInTable: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        <Button
          key={'details'}
          type="link"
          onClick={() => {
            history.push(`/cellula/userManagement/details?id=${record.id}`);
          }}
        >
          详情
        </Button>,
        <Popconfirm
          key={'delete'}
          title="是否删除删除使用人"
          onConfirm={() => deleteClick(record.id)}
        >
          <Button type="link">删除</Button>
        </Popconfirm>,
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="CellulaUserList"
      columns={columns}
      request={getCellulaUserList}
      actionRef={actionRef}
      rowKey="id"
      search={{
        labelWidth: 120,
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      toolBarRender={() => [
        <Button loading={exportLoading} key="export" type="primary" onClick={exportClick}>
          <DownloadOutlined />
          导出
        </Button>,
      ]}
    />
  );
};
export default () => (
  <KeepAlive>
    <CellulaUserList />
  </KeepAlive>
);

import { getRequest, postRequest } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';
import _ from 'lodash';

let searchData = {};
// 生命银行用户列表
const getCellulaUserList = async (params: any) => {
  const { current, pageSize, status, channel, ...data } = params;
  data.currentPage = current;
  data.pageSize = pageSize;
  data.status = typeof status !== 'undefined' ? Number(status) : undefined;
  data.channel = typeof channel !== 'undefined' ? Number(channel) : undefined;

  searchData = _.cloneDeep(data);
  const msg = (await postRequest(
    '/life-bank/page',
    { ...data },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;

  return {
    data: msg?.result?.lifeBankInfoList ?? [],
    total: msg?.result?.totalCount ?? 0,
  };
};
// 删除接口
const deleteRelatedUser = async (id: string) => {
  return (await postRequest(
    '/life-bank/delete-related-user',
    { id },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
// 获取详情接口
const lifeBankDetail = async (id?: string) => {
  return (await getRequest(
    '/life-bank/detail',
    { id },
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
};
const exportData = async () => {
  return (await postRequest(
    '/life-bank/export',
    { ...searchData },
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  )) as unknown as APIS.BaseResponse<any>;
};
export { getCellulaUserList, deleteRelatedUser, lifeBankDetail, exportData };

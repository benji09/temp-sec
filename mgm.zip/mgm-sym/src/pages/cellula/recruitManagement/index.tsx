import React, { useRef, useState } from 'react';
import _ from 'lodash';
import dayjs from 'dayjs';
import moment from 'moment';
import { Button, DatePicker } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { ClickDownXlsx } from '@/utils/downXlsx';
import TableLocal from '@/components/TableLocal/index';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import { cellRecruitExport, cellRecruitFindPhone, cellRecruitModify, cellRecruitPage } from './api';
import RecruitModal from './components/RecruitModal';
import ModifyState from './components/ModifyState';
import Details from './components/Details';
import { REVISITSTATUSTYPE, SOURCE_TYPE } from './util';
import type { RecruitManagementType } from './typings';

const MODAL_TYPE_MODIFY = 1;
const MODAL_TYPE_DETAILS = 2;

const { RangePicker } = DatePicker;

const RecruitManagement: React.FC = () => {
  const [mobilesCache, setMobilesCache] = useState({});

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [ModalVisible, setModalVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const [exportLoading, setExportLoading] = useState<boolean>(false);

  const actionRef = useRef<ActionType | undefined>();
  const recruitModalRef = useRef<any>();
  const detailsRef = useRef<any>();

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_MODIFY:
        return '修改状态';
      case MODAL_TYPE_DETAILS:
        return '详情';
    }
    return '';
  }

  function disabledDate(current: any) {
    return current && current > moment();
  }

  const onModalOk = () => {
    if (modalType === 1) {
      recruitModalRef.current
        ?.takeData()
        .then((data: any) => {
          setLoading(true);
          cellRecruitModify(data).then((res) => {
            if (res.status === 0) {
              setModalType(undefined);
              setModalVisible(false);
              actionRef.current?.reload();
              showSuccessMessage('更改成功');
            }
          });
        })
        .finally(() => {
          setLoading(false);
        });
    }
  };
  const onModalCancel = () => {
    setLoading(false);
    setModalType(undefined);
    setModalVisible(false);
    recruitModalRef.current?.reset();
  };

  function exportClick() {
    setExportLoading(true);
    cellRecruitExport().then((res: any) => {
      setExportLoading(false);
      const { size } = res;
      if (size <= 500) {
        showErrorMessage('数据流异常，无法正常下载');
        return;
      }
      ClickDownXlsx(res, '招募管理');
      showSuccessMessage('导出成功');
    });
  }
  // 查看手机号
  const queryMobile = (record: RecruitManagementType) => {
    cellRecruitFindPhone(record.id ?? '')
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.id ?? ''] = res.result;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };
  const columns: ProColumns<RecruitManagementType>[] = [
    {
      title: '用户称号',
      dataIndex: 'nickName',
    },
    {
      title: '手机号',
      dataIndex: 'phone',
      render: (text, record: RecruitManagementType) => {
        return (
          <>
            {mobilesCache[record.id ?? ''] || text}
            {(record.phone ?? '').indexOf('*') < 0 ||
            mobilesCache[record.id ?? ''] ||
            (record.phone || '').trim().length < 1 ? null : (
              <Button type="link" key="lookMobile" onClick={() => queryMobile(record)}>
                查看
              </Button>
            )}
          </>
        );
      },
    },
    {
      title: '城市',
      dataIndex: 'address',
      hideInSearch: true,
    },
    {
      title: '提交日期',
      dataIndex: 'createdAt',
      hideInSearch: true,
    },
    {
      title: '回访状态',
      dataIndex: 'revisitStatus',
      valueType: 'select',
      valueEnum: REVISITSTATUSTYPE,
    },
    {
      title: '提交日期',
      dataIndex: 'id',
      valueType: 'dateRange',
      hideInTable: true,
      search: {
        transform: (value) => {
          return {
            submitTimeStart: dayjs(`${value[0]} 00:00:00`).valueOf(),
            submitTimeEnd: dayjs(`${value[1]} 23:59:59`).valueOf(),
          };
        },
      },
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '修改状态时间',
      dataIndex: 'updatedAt',
      hideInSearch: true,
    },
    {
      title: '来源',
      dataIndex: 'source',
      valueType: 'select',
      valueEnum: SOURCE_TYPE,
    },
    {
      title: '回访结果',
      dataIndex: 'revisitResult',
      hideInSearch: true,
      render: (text, record) => [
        <span key={'details'}>
          {(record?.revisitResult ?? [])[0]?.result ?? ''}
          <Button
            key="view"
            type="link"
            onClick={() => {
              setModalType(MODAL_TYPE_DETAILS);
              setModalVisible(true);
              setTimeout(() => {
                detailsRef.current?.setData(record);
              });
            }}
          >
            详情
          </Button>
        </span>,
      ],
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        Number(record?.revisitStatus ?? '') !== 2 && (
          <Button
            key="view"
            type="link"
            onClick={() => {
              setModalType(MODAL_TYPE_MODIFY);
              setModalVisible(true);
              setTimeout(() => {
                recruitModalRef.current?.setData(record);
              });
            }}
          >
            修改回访状态
          </Button>
        ),
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="RecruitTable"
      columns={columns}
      actionRef={actionRef}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={cellRecruitPage}
      rowKey="id"
      toolBarRender={() => [
        <Button
          loading={exportLoading}
          key="primary"
          type="primary"
          onClick={() => {
            exportClick();
          }}
        >
          导出
        </Button>,
      ]}
    >
      <RecruitModal
        title={getModalTitle()}
        modalType={modalType}
        loading={loading}
        ModalVisible={ModalVisible}
        onOk={onModalOk}
        onCancel={onModalCancel}
      >
        {modalType === 1 && <ModifyState ref={recruitModalRef} />}
        {modalType === 2 && <Details ref={detailsRef} />}
      </RecruitModal>
    </TableLocal>
  );
};
export default RecruitManagement;

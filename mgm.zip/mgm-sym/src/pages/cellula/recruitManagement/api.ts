import { HOST_TYPE_POWER } from '@/utils/utils';
import { getRequest, postRequest } from '@/services/api';

let search = {};
// 列表
const cellRecruitPage = async (params: any) => {
  const { current, pageSize, ...data } = params;

  search = data;
  const msg = (await postRequest(
    '/cell-recruit/page',
    { ...data, currentPage: current, pageSize },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: msg?.result?.cellRecruitInfoList ?? [],
    total: msg?.result?.totalCount ?? 0,
  };
};
// 导出
const cellRecruitExport = async () => {
  return await postRequest(
    '/cell-recruit/export',
    search,
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  );
};
// 修改状态
const cellRecruitModify = async (data: any) => {
  return (await postRequest(
    '/cell-recruit/modify',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 查看手机号
const cellRecruitFindPhone = async (id: number | string) => {
  return (await getRequest(
    '/cell-recruit/find-phone',
    { id },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
export { cellRecruitPage, cellRecruitExport, cellRecruitModify, cellRecruitFindPhone };

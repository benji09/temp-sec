import type { ReactNode } from 'react';
type RevisitResultType = {
  result?: string;
  createdTime?: string;
};
type RecruitManagementType = {
  address?: string;
  createdAt?: string;
  id?: number | string;
  nickName?: string;
  phone?: string;
  revisitResult?: RevisitResultType[];
  revisitStatus?: string;
  updatedAt?: string;
};
interface ModalPropType {
  modalType?: number | undefined;
  ModalVisible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children: ReactNode;
}

export { RecruitManagementType, ModalPropType, RevisitResultType };

import { request } from 'umi';

import { HOST_TYPE_POWER } from '@/utils/utils';
import { getRequest, postRequest, TIMEOUT } from '@/services/api';

import type { DetailsType, PullOffShelvesType, RemoveGsoodsType } from './typing';
import { POWER_HOST } from '@/services/hosts';

let searchData = {};
const platformDrugList = async (params: any) => {
  const { current, pageSize, ...data } = params;
  const pageable = { page: current, size: pageSize };

  searchData = data;
  const msg = (await postRequest(
    '/mall/my-goods-data-list',
    {
      ...data,
      pageable,
    },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: (msg?.result && msg?.result.myItemData) || [],
    total: (msg?.result && msg?.result.totalCount) || 0,
  };
};
// 上下架
const pullOffShelves = async (data: PullOffShelvesType) => {
  return (await postRequest(
    '/mall/change-mall-my-goods-status',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 移除
const removeGsoods = async (data: RemoveGsoodsType) => {
  return (await postRequest(
    '/mall/remove-my-goods',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 加入商场
const joinTheMall = async (data: RemoveGsoodsType) => {
  return (await postRequest(
    '/mall/join-the-mall',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 详情接口
const getOurGoodsDataDetails = async (id?: number) => {
  return (await getRequest(
    '/mall/get-our-goods-data-details',
    { id },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 修改接口
const editFullDataOfOurGoods = async (data: DetailsType) => {
  return (await postRequest(
    '/mall/edit-full-data-of-our-goods',
    { ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

// 商品分类
const goodsClassification = async () => {
  return (await postRequest(
    '/mall/my-tree-category',
    {},
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const listDiagnostic = async () => {
  return (await postRequest(
    '/mall/list-diagnostic',
    {},
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};

const listDictByIds = async (dictType?: string, ids?: number[]) => {
  return (await postRequest(
    '/mall/list-dict-by-ids',
    { dictType, ids: ids || [] },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const listDiagnosisByKey = async (keyWord: string) => {
  return (await getRequest(
    '/mall/list-diagnosis-by-key',
    { keyWord: keyWord || '' },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 导入
const importExcel = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/mall/batch-insert-full-data-of-our-goods', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};

const exportData = async () => {
  return (await postRequest(
    '/mall/export-my-item-data',
    { ...searchData },
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  )) as unknown as any;
};
export {
  platformDrugList,
  pullOffShelves,
  removeGsoods,
  joinTheMall,
  getOurGoodsDataDetails,
  editFullDataOfOurGoods,
  goodsClassification,
  listDiagnostic,
  listDictByIds,
  listDiagnosisByKey,
  importExcel,
  exportData,
};

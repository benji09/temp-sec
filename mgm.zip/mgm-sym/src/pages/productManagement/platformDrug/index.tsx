import React, { useEffect, useRef, useState } from 'react';
import { Button, TreeSelect, Upload } from 'antd';
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { ClickDownXlsx } from '@/utils/downXlsx';
import TableLocal from '@/components/TableLocal/TableLocal';
import { downloadExcelTemplate, listDictionary } from '@/services/api';
import { typeUploaded, UploadFailure, UploadResult, UploadSucceed } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import {
  editFullDataOfOurGoods,
  exportData,
  getOurGoodsDataDetails,
  goodsClassification,
  importExcel,
  joinTheMall,
  listDictByIds,
  platformDrugList,
  pullOffShelves,
  removeGsoods,
} from './api';
import {
  ChildrenMedicationSearchType,
  ChildrenMedicationType,
  CommodityImagesType,
  PlaguePreventionDrugType,
  transferListToObject,
} from '../utils';
import Modal from './components/Modal';
import Details from './components/Details';
import Edit from './components/Edit';
import OnOrOff from './components/OnOrOff';
import type { PlatformDrugListType, TypeListType } from './typing';

const MODAL_TYPE_DETAIL = 1;
const MODAL_TYPE_EDIT = 2;
const MODAL_TYPE_OFF = 4;

const PlatformDrug: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const detailsRef = useRef<any>();
  const editRef = useRef<any>();
  const onOrOffRef = useRef<any>();

  const [goodsCategoryOptions, setGoodsCategoryOptions] = useState([]);

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [detailsData, setDetailsData] = useState({});

  const [ids, setIds] = useState<number[]>([]);
  const [selectedItem, setSelectedItem] = useState<any[]>([]);

  const [platStatus, setPlatStatus] = useState<TypeListType>({});
  const [thirdStatus, setThirdStatus] = useState<TypeListType>({});
  const [medicineType, setMedicineType] = useState<TypeListType>({});
  const [supplierType, setSetsupplierType] = useState<TypeListType>({});
  const [platformChannelType, setPlatformChannelType] = useState<TypeListType>({});
  const [itemTypeOpent, setItemTypeOpent] = useState<TypeListType>({});
  const [ageUnitType, setAgeUnitType] = useState<TypeListType>({});

  const [scheduleLoading, setScheduleLoading] = useState(false);

  const [department, setDepartment] = useState<APIS.DictionaryType[]>([]);

  const [pregnantWoman, setPregnantWoman] = useState<APIS.DictionaryType[]>([]);
  const [pregnantMan, setPregnantMan] = useState<APIS.DictionaryType[]>([]);
  const [allergies, setAllergies] = useState<APIS.DictionaryType[]>([]);
  const [diseaseHistory, setDiseaseHistory] = useState<APIS.DictionaryType[]>([]);
  const [applicableSex, setApplicableSex] = useState<APIS.DictionaryType[]>([]);
  const [itemType, setItemType] = useState<APIS.DictionaryType[]>([]);
  const [usage, setUsage] = useState<APIS.DictionaryType[]>([]);
  const [usageUnit, setUsageUnit] = useState<APIS.DictionaryType[]>([]);
  const [useTime, setUseTime] = useState<APIS.DictionaryType[]>([]);
  const [medicineTypeOption, setMedicineTypeOption] = useState<APIS.DictionaryType[]>([]);

  const [exportLoading, setExportLoading] = useState<boolean>(false);

  useEffect(() => {
    listDictionary([
      'PREGNANT_WOMAN',
      'PREGNANT_MAN',
      'ALLERGIES',
      'DISEASE_HISTORY',
      'ITEM_TYPE',
    ]).then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;

        setPregnantWoman(dictionary?.PREGNANT_WOMAN);
        setPregnantMan(dictionary?.PREGNANT_MAN);
        setAllergies(dictionary?.ALLERGIES);
        setDiseaseHistory(dictionary?.DISEASE_HISTORY);
      }
    });
    listDictByIds('DEPARTMENT').then((res) => {
      if (res.status === 0 && res.result) {
        setDepartment(res.result.dictDataInfos);
      }
    });

    listDictionary().then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;

        setPlatStatus(transferListToObject(dictionary?.PLAT_STATUS));
        setThirdStatus(transferListToObject(dictionary?.THIRD_STATUS));
        setMedicineType(transferListToObject(dictionary?.MEDICINE_TYPE));
        setSetsupplierType(transferListToObject(dictionary?.SUPPLIER));
        setPlatformChannelType(transferListToObject(dictionary?.PLATFORM_CHANNEL));
        setAgeUnitType(transferListToObject(dictionary?.AGE_UNIT));
        setItemTypeOpent(transferListToObject(dictionary?.ITEM_TYPE));

        setApplicableSex(dictionary?.APPLICABLE_SEX);
        setUsage(dictionary?.usage);
        setUsageUnit(dictionary?.usage_unit);
        setUseTime(dictionary?.use_time);
        setMedicineTypeOption(dictionary?.MEDICINE_TYPE);
        setItemType(dictionary?.ITEM_TYPE);
      }
    });
    goodsClassification().then((res) => {
      if (res.status === 0 && res.result) {
        const treeCategoryInfo = JSON.parse(res.result.treeCategoryInfo[2]);
        setGoodsCategoryOptions(treeCategoryInfo);
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_DETAIL:
        return '详情';
      case MODAL_TYPE_EDIT:
        return '编辑';
      case MODAL_TYPE_OFF:
        return '下架';
    }
    return '';
  }

  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name ?? '').endsWith('.xls') || (file?.name ?? '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(typeUploaded('xls 或 xlsx'));
    return isXlsx;
  }
  function customeUpload(options: any) {
    setScheduleLoading(true);

    importExcel(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setScheduleLoading(false));
  }

  const rowSelection = {
    onChange: (selectedRowKeys: number[], selectedRows: any[]) => {
      setSelectedItem(selectedRows);
      setIds(selectedRowKeys);
    },
  };

  function onOk() {
    if (modalType === 2) {
      editRef.current
        ?.takeData()
        .then((editRefRes: any) => {
          setDetailsData(editRefRes);
          setVisible(true);
        })
        .catch((error: Error) => {
          showErrorMessage(error.message);
        });
    } else {
      setVisible(true);
    }
  }
  function onCancel() {
    setBtnLoading(false);
    setVisible(false);

    setTimeout(() => {
      editRef.current?.reset();
      detailsRef.current?.reset();
      onOrOffRef.current?.reset();
      setModalType(undefined);
    });
  }
  function onSaveData() {
    setBtnLoading(true);
    if (modalType === 4) {
      onOrOffRef.current?.takeData().then((onOrOffRefRes: any) => {
        const { itemOffReason } = onOrOffRefRes;

        const selectedIds: number[] = [];
        selectedItem.map((item) => {
          if (item.mySidestatus !== 1) {
            selectedIds.push(item.id);
          }
        });
        pullOffShelves({ ids: selectedIds, itemOffReason: itemOffReason ?? '', status: 1 }).then(
          (res) => {
            setBtnLoading(false);
            setVisible(false);
            if (res.status === 0) {
              onOrOffRef.current?.reset();
              actionRef.current?.reload();
              actionRef.current?.clearSelected?.();
              setModalType(undefined);
            }
          },
        );
      });
    } else if (modalType === 2) {
      editFullDataOfOurGoods(detailsData).then((res) => {
        setBtnLoading(false);
        setVisible(false);
        if (res.status === 0) {
          editRef.current?.reset();
          actionRef.current?.reload();
          actionRef.current?.clearSelected?.();
          setDetailsData({});
          setModalType(undefined);
        }
      });
    }
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }
  function putawayClick(id?: number[]) {
    const selectedIds: number[] = [];
    selectedItem.map((item) => {
      if (item.mySidestatus !== 2) {
        selectedIds.push(item.id);
      }
    });
    pullOffShelves({ ids: id || selectedIds, status: 2 }).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('操作成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      } else {
        showErrorMessage('上架失败');
      }
    });
  }
  function removeClick(id?: number[]) {
    removeGsoods({ ids: id || ids }).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('操作成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      } else {
        showErrorMessage('移除失败');
      }
    });
  }
  function joinTheMallClick() {
    joinTheMall({ ids: ids }).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('操作成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      } else {
        showErrorMessage('移加入商城失败');
      }
    });
  }
  // 点击详情按钮
  function detailsClick(record: PlatformDrugListType) {
    setModalType(MODAL_TYPE_DETAIL);
    getOurGoodsDataDetails(record.id).then((res) => {
      if (res.status === 0) {
        detailsRef.current?.setData(res.result);
      }
    });
  }
  // 点击编辑按钮
  function editClick(record: PlatformDrugListType) {
    setModalType(MODAL_TYPE_EDIT);
    getOurGoodsDataDetails(record.id).then((res) => {
      if (res.status === 0) {
        editRef.current?.setData(res.result);
      }
    });
  }

  const searchRender = () => {
    return (
      <TreeSelect
        showSearch
        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
        fieldNames={{ label: 'name', value: 'id', children: 'children' }}
        placeholder="请选择"
        allowClear
        multiple
        treeData={goodsCategoryOptions}
      />
    );
  };

  // 点击导出按钮
  function exportClick() {
    setExportLoading(true);
    exportData().then((res) => {
      setExportLoading(false);
      const { size } = res;
      if (size <= 500) {
        showErrorMessage('数据流异常，无法正常下载');
        return;
      }
      ClickDownXlsx(res, '我方商品全数据');
      showSuccessMessage('导出成功');
    });
  }
  const columns: ProColumns<PlatformDrugListType>[] = [
    {
      title: '通用名 ID',
      dataIndex: 'commonId',
    },
    {
      title: '标准库 ID',
      dataIndex: 'standardId',
    },
    {
      title: '我方商品 ID',
      dataIndex: 'skuId',
    },
    {
      title: '渠道商品编码',
      dataIndex: 'channelGoodsSkuId',
    },
    {
      title: '商品属性',
      dataIndex: 'itemType',
      valueEnum: itemTypeOpent,
      valueType: 'select',
    },
    {
      title: '平台渠道',
      dataIndex: 'channel',
      valueType: 'select',
      valueEnum: platformChannelType,
      hideInSearch: true,
    },
    {
      title: '渠道',
      dataIndex: 'channelId',
      valueType: 'select',
      valueEnum: supplierType,
      hideInTable: true,
    },
    {
      title: '渠道',
      dataIndex: 'channelType',
      valueType: 'select',
      valueEnum: supplierType,
      hideInSearch: true,
    },
    {
      title: '通用名',
      dataIndex: 'commonName',
    },
    {
      title: '品牌名',
      dataIndex: 'brandName',
      hideInSearch: true,
    },
    {
      title: '规格',
      dataIndex: 'specification',
      hideInSearch: true,
    },
    {
      title: '是否处方',
      dataIndex: 'medicineType',
      valueType: 'select',
      valueEnum: medicineType,
    },
    {
      title: '疫情防控药品',
      dataIndex: 'plaguePreventionDrug',
      valueType: 'select',
      valueEnum: PlaguePreventionDrugType,
      hideInSearch: true,
    },
    {
      title: '是否儿童用药',
      dataIndex: 'childrenDrug',
      valueType: 'select',
      valueEnum: ChildrenMedicationType,

      hideInSearch: true,
    },
    {
      title: '单次添加数量限制',
      dataIndex: 'singleAddNum',
      hideInSearch: true,
    },
    {
      title: '第三方库存',
      dataIndex: 'thirdPartystock',
      hideInSearch: true,
    },
    {
      title: '我方上下架状态',
      dataIndex: 'mySidestatus',
      valueType: 'select',
      valueEnum: platStatus,
    },
    {
      title: '我方下架原因',
      dataIndex: 'itemOffReason',
      hideInSearch: true,
      ellipsis: true,
    },
    {
      title: '第三方上下架状态',
      dataIndex: 'thirdPartyStatus',
      valueType: 'select',
      valueEnum: thirdStatus,
    },
    {
      title: '商品分类',
      dataIndex: 'categoryId',
      renderFormItem: searchRender,
      hideInTable: true,
    },
    {
      title: '是否儿童用药',
      dataIndex: 'childrenDrug',
      valueType: 'select',
      valueEnum: ChildrenMedicationSearchType,

      hideInTable: true,
    },
    {
      title: '是否有商品图片',
      dataIndex: 'isItemPic',
      valueType: 'select',
      valueEnum: CommodityImagesType,

      hideInTable: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      fixed: 'right',
      width: 150,
      render: (text, record) => [
        <Button
          type="link"
          key="details"
          onClick={() => {
            detailsClick(record);
          }}
        >
          详情
        </Button>,
        record.mySidestatus === 1 && (
          <Button
            disabled={!record.listingStatus}
            type="link"
            key="putaway"
            onClick={() => {
              if (record.thirdPartyStatus === 1) {
                showErrorMessage('药商已下架该商品，不可上架');
              } else {
                setIds([]);
                putawayClick([record.id]);
              }
            }}
          >
            上架
          </Button>
        ),
        record.mySidestatus === 2 && (
          <Button
            type="link"
            key="SoldOut"
            style={{ color: '#f00' }}
            onClick={() => {
              setModalType(MODAL_TYPE_OFF);
              setSelectedItem([record]);
              setIds([record.id]);
            }}
          >
            下架
          </Button>
        ),
        <Button
          type="link"
          key="edit"
          onClick={() => {
            editClick(record);
          }}
        >
          编辑
        </Button>,
        <Button
          type="link"
          key="remove"
          onClick={() => {
            if (record.mySidestatus === 2) {
              showErrorMessage('平台上架状态不可移除');
            } else {
              setIds([]);
              removeClick([record.id]);
            }
          }}
        >
          移除
        </Button>,
      ],
    },
  ];
  return (
    <TableLocal
      rowSelection={rowSelection}
      search={{
        labelWidth: 120,
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      rowKey="id"
      request={platformDrugList}
      columns={columns}
      actionRef={actionRef}
      scroll={{ x: 2000 }}
      toolBarRender={() => [
        <Button
          key="batchSoldOut"
          type="primary"
          onClick={() => {
            if (ids.length) {
              setModalType(MODAL_TYPE_OFF);
            } else {
              showErrorMessage('请选择批量下架的数据');
            }
          }}
        >
          批量下架
        </Button>,
        <Button
          key="batchShelves"
          type="primary"
          onClick={() => {
            if (ids.length) {
              putawayClick();
            } else {
              showErrorMessage('请选择批量上架的数据');
            }
          }}
        >
          批量上架
        </Button>,
        <Upload
          accept={'.xlsx,.xls'}
          maxCount={1}
          type={'select'}
          beforeUpload={handleBeforeUpload}
          customRequest={customeUpload}
          showUploadList={false}
        >
          <Button key="primary" type="primary" loading={scheduleLoading}>
            {scheduleLoading ? null : <UploadOutlined />}
            导入
          </Button>
        </Upload>,
        <Button
          key="batchRemove"
          type="primary"
          onClick={() => {
            if (ids.length) {
              removeClick();
            } else {
              showErrorMessage('请选择批量移除的数据');
            }
          }}
        >
          批量移除
        </Button>,
        <Button
          key="download"
          type="primary"
          onClick={() => {
            downloadExcelTemplate('WFYPQSJ');
          }}
        >
          下载导入模板
        </Button>,
        <Button
          key="joinMall"
          type="primary"
          onClick={() => {
            if (ids.length) {
              joinTheMallClick();
            } else {
              showErrorMessage('请选择加入商城的数据');
            }
          }}
        >
          加入商城
        </Button>,
        <Button loading={exportLoading} key="export" type="primary" onClick={exportClick}>
          <DownloadOutlined />
          导出
        </Button>,
      ]}
    >
      <Modal
        title={getModalTitle()}
        modalVisible={!!modalType}
        modalType={modalType}
        visible={visible}
        btnLoading={btnLoading}
        onOk={onOk}
        onCancel={onCancel}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        {modalType === 1 && (
          <Details
            department={department}
            pregnantWoman={pregnantWoman}
            pregnantMan={pregnantMan}
            allergies={allergies}
            diseaseHistory={diseaseHistory}
            applicableSex={applicableSex}
            itemType={itemType}
            usage={usage}
            usageUnit={usageUnit}
            useTime={useTime}
            medicineType={medicineTypeOption}
            ageUnitType={ageUnitType}
            ref={detailsRef}
          />
        )}
        {modalType === 2 && (
          <Edit
            department={department}
            pregnantWoman={pregnantWoman}
            pregnantMan={pregnantMan}
            allergies={allergies}
            diseaseHistory={diseaseHistory}
            applicableSex={applicableSex}
            itemType={itemType}
            usage={usage}
            usageUnit={usageUnit}
            useTime={useTime}
            medicineType={medicineTypeOption}
            ageUnitType={ageUnitType}
            ref={editRef}
          />
        )}
        {modalType === 4 && <OnOrOff ref={onOrOffRef} />}
      </Modal>
    </TableLocal>
  );
};
export default PlatformDrug;

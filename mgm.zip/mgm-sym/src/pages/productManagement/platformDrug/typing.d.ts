type PlatformDrugListType = {
  id: number;
  price?: number;
  spec?: string;
  stock?: number;
  itemPic?: string[];
  order?: number;
  firstImg?: string;
  brandName?: string;
  commonName?: string;
  channelCode?: string;
  createTime?: string;
  mallStatus?: number;
  platStatus?: number;
  platGoodsId?: number;
  frontKindName?: string;
  medicineType?: number;
  goodsAttributes?: string;
  mySidestatus?: number;
  thirdPartyStatus?: number;
  listingStatus?: boolean;
};
type PlatformDrugType = {
  modalVisible?: boolean;
  modalType?: number;
  visible?: boolean;
  title?: string;
  btnLoading?: boolean;
  onOk: () => void;
  onCancel: () => void;
  onSaveData: () => void;
  onCancelSave: () => void;
  children?: ReactNode;
};

type TypeListType = Record<string | boolean | undefined, string | undefined>;

type PullOffShelvesType = {
  ids?: number[];
  itemOffReason?: string;
  status?: number;
};
type RemoveGsoodsType = {
  ids?: number[];
};
type DetailsType = {
  allergiesId?: number[];
  applyGender?: number;
  approvalNum?: string;
  attentionMatter?: string;
  barCode?: string;
  brandName?: string;
  categoryId?: string[];
  commonId?: string;
  commonName?: string;
  dept?: { id?: string; name?: string }[];
  deptId?: (string | undefined)[];
  diagnosisResult?: { id?: string; name?: string }[];
  diagnosis?: (string | undefined)[];
  diseaseHistory?: number[];
  dosage?: number;
  dosageUnit?: number;
  frequency?: string;
  id?: string;
  indication?: string;
  ingredient?: string;
  itemPic?: string[];
  itemType?: number;
  manufacturer?: string;
  maxAge?: number;
  medicineInteraction?: string;
  medicineType?: number;
  minAge?: number;
  pregnantMan?: number;
  pregnantWoman?: number[];
  sideEffect?: string;
  singleAddNum?: number;
  skuId?: string;
  smallestUseUnit?: string;
  specification?: string;
  standardId?: string;
  storage?: string;
  taboo?: string;
  trait?: string;
  usage?: number;
  usageInstructions?: string;
  validityPeriod?: string;
  thirdPartyUsage?: string;
};
type GoodsClassificationType = {
  id?: number;
  parentId?: number;
  weight?: number;
  name?: string;
  level?: number;
  type?: number;
  children?: GoodsClassificationType[];
};
type DepartmentType = {
  id?: number;
  parentId?: number;
  weight?: number;
  name?: string;
  level?: number;
  type?: number;
  children?: GoodsClassificationType[];
};
type DiagnosisResultOptionType = {
  departmentIds?: string[];
  id?: string;
  name?: string;
};
type PropsType = {
  department?: APIS.DictionaryType[];
  pregnantWoman?: APIS.DictionaryType[];
  pregnantMan?: APIS.DictionaryType[];
  allergies?: APIS.DictionaryType[];
  diseaseHistory?: APIS.DictionaryType[];
  applicableSex?: APIS.DictionaryType[];
  itemType?: APIS.DictionaryType[];
  usage?: APIS.DictionaryType[];
  usageUnit?: APIS.DictionaryType[];
  useTime?: APIS.DictionaryType[];
  medicineType?: APIS.DictionaryType[];
  searchParam?: APIS.DictionaryType[];
  ageUnitType?: TypeListType;
};
export {
  PlatformDrugListType,
  PlatformDrugType,
  TypeListType,
  PullOffShelvesType,
  RemoveGsoodsType,
  DetailsType,
  GoodsClassificationType,
  DepartmentType,
  DiagnosisResultOptionType,
  PropsType,
};

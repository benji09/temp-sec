type ModalPropType = {
  modalVisible?: boolean;
  title?: string;
  modalType?: number;
  visible?: boolean;
  btnLoading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  onSaveData: () => void;
  onCancelSave: () => void;
  children?: ReactNode;
};
type TypeListType = Record<string | undefined, string | undefined>;
type ThirdPartyDrugsDataType = {
  brandName?: string;
  createdTime?: string;
  genericName?: string;
  isSync?: string;
  medicineProperty?: string;
  status?: string;
  supplierSkuId?: string;
  supplierType?: string;
  current?: number;
  pageSize?: number;
};

export { ModalPropType, TypeListType, ThirdPartyDrugsDataType };

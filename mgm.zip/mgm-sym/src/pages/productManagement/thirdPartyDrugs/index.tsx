import React, { useState, useRef, useEffect } from 'react';
import { Button, DatePicker, Upload } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { hasFields, typeUploaded, UploadFailure, UploadResult, UploadSucceed } from '@/utils/utils';
import { downloadExcelTemplate, listDictionary } from '@/services/api';
import { ClickDownXlsx } from '@/utils/downXlsx';
import TableLocal from '@/components/TableLocal/TableLocal';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import Modal from './components/Modal';
import { convertTime, THIRD_STATUS } from '../utils';
import Details from './components/Details';
import CreateOrEdit from './components/createOrEdit';
import {
  addThirdGoods,
  channelGoodsDetails,
  exportThirdGoods,
  importExcel,
  joinThirdGoods,
  listWarehouse,
  ThirdPartyDrugsData,
} from './aip';
import type { TypeListType } from './typings';

import './index.less';

const { RangePicker } = DatePicker;

const MODAL_TYPE_DETAIL = 1;
const MODAL_TYPE_CREATE = 2;
const MODAL_TYPE_EDIT = 3;

const ThirdPartyDrugs: React.ReactNode = () => {
  const actionRef = useRef<ActionType | undefined>();
  const detailsRef = useRef<any>();
  const createOrEditRef = useRef<any>();
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [detailsData, setDetailsData] = useState({});

  const [supplierType, setSetsupplierType] = useState<TypeListType>({});
  const [medicineType, setMedicineType] = useState<TypeListType>({});
  const [itemTypeOpent, setItemTypeOpent] = useState<TypeListType>({});
  const [syncStatus, setSyncStatus] = useState<TypeListType>({});
  const [scheduleLoading, setScheduleLoading] = useState(false);

  const [ids, setIds] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const [warehouse, setWarehouse] = useState();

  useEffect(() => {
    listDictionary().then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;
        const SUPPLIER_TYPE = {};
        const MEDICINE_TYPE = {};
        const SYNC_STATUS = {};
        const ITEM_TYPE = {};

        dictionary?.MEDICINE_TYPE?.map((item: APIS.DictionaryType) => {
          MEDICINE_TYPE[item.key ?? ''] = item.value;
        });
        dictionary?.SUPPLIER?.map((item: APIS.DictionaryType) => {
          SUPPLIER_TYPE[item.key ?? ''] = item.value;
        });
        dictionary?.SYNC_STATUS?.map((item: APIS.DictionaryType) => {
          SYNC_STATUS[item.key ?? ''] = item.value;
        });
        dictionary?.ITEM_TYPE?.map((item: APIS.DictionaryType) => {
          ITEM_TYPE[item.key ?? ''] = item.value;
        });
        setSetsupplierType(SUPPLIER_TYPE);
        setMedicineType(MEDICINE_TYPE);
        setSyncStatus(SYNC_STATUS);
        setItemTypeOpent(ITEM_TYPE);
      }
    });
    listWarehouse().then((res) => {
      if (res.status === 0) {
        setWarehouse(res.result);
      }
    });
  }, []);
  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_DETAIL:
        return '详情';
      case MODAL_TYPE_CREATE:
        return '新增';
      case MODAL_TYPE_EDIT:
        return '编辑';
    }
    return '';
  }

  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name ?? '').endsWith('.xls') || (file?.name ?? '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(typeUploaded('xls 或 xlsx'));
    return isXlsx;
  }
  function customeUpload(options: any) {
    setScheduleLoading(true);

    importExcel(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setScheduleLoading(false));
  }

  function onCancel() {
    setTimeout(() => {
      setVisible(false);
      setBtnLoading(false);
      setDetailsData({});
      setModalType(undefined);
    });
  }
  function onOk() {
    createOrEditRef.current?.takeData().then((data: any) => {
      setDetailsData(data);
      setVisible(true);
    });
  }
  function onSaveData() {
    setBtnLoading(true);
    if (modalType === MODAL_TYPE_CREATE) {
      addThirdGoods({ ...detailsData, pattern: 'ADD' }).then((res) => {
        setBtnLoading(false);
        setVisible(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          createOrEditRef.current?.reset();
          setDetailsData({});
          setModalType(undefined);
        }
      });
    } else if (modalType === MODAL_TYPE_EDIT) {
      addThirdGoods({ ...detailsData, pattern: 'UPDATE' }).then((res) => {
        setBtnLoading(false);
        setVisible(false);
        if (res.status === 0) {
          actionRef.current?.reload();
          createOrEditRef.current?.reset();
          setDetailsData({});
          setModalType(undefined);
        }
      });
    }
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }
  const rowSelection = {
    onChange: (selectedRowKeys: string[]) => {
      setIds(selectedRowKeys);
    },
  };
  function joinClick(record?: any) {
    joinThirdGoods(record ? [record.id] : ids).then((res) => {
      if (res.status === 0) {
        setIds([]);
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.();
        showSuccessMessage('操作成功');
      }
    });
  }
  function detailsClick(record?: any) {
    setModalType(MODAL_TYPE_DETAIL);
    channelGoodsDetails({ id: record.id, skuId: record.skuId }).then((res) => {
      if (res.status === 0 && res.result) {
        detailsRef.current?.setData(res.result);
      }
    });
  }
  function editClick(record?: any) {
    setModalType(MODAL_TYPE_EDIT);
    channelGoodsDetails({ id: record.id, skuId: record.skuId }).then((res) => {
      if (res.status === 0 && res.result) {
        createOrEditRef.current?.setData(res.result);
      }
    });
  }
  const columns: ProColumns[] = [
    {
      title: '是否加入我方库',
      dataIndex: 'isSync',
      valueType: 'select',
      valueEnum: syncStatus,
      hideInTable: true,
    },
    {
      title: '是否加入我方库',
      dataIndex: 'syncStatus',
      valueType: 'select',
      valueEnum: syncStatus,
      hideInSearch: true,
    },
    {
      title: '药品属性',
      dataIndex: 'medicineProperty',
      valueEnum: itemTypeOpent,
      valueType: 'select',
      hideInTable: true,
    },
    {
      title: '渠道',
      dataIndex: 'supplierType',
      valueType: 'select',
      valueEnum: supplierType,
    },
    {
      title: '仓 ID',
      dataIndex: 'repositoryId',
      hideInSearch: true,
    },
    {
      title: '仓名',
      hideInSearch: true,
      dataIndex: 'repositoryName',
    },
    {
      title: '渠道商品编码',
      dataIndex: 'supplierSkuId',
    },
    {
      title: '商品属性',
      dataIndex: 'medicineProperty',
      hideInSearch: true,
      valueEnum: itemTypeOpent,
      valueType: 'select',
    },
    {
      title: '第三方商品分类',
      dataIndex: 'itemType',
      hideInSearch: true,
    },
    {
      title: '第三方库存',
      hideInSearch: true,
      dataIndex: 'stockCount',
    },
    {
      title: '第三方上下架状态',
      dataIndex: 'status',

      valueType: 'select',
      valueEnum: THIRD_STATUS, // Boolean 类型
    },
    {
      title: '第三方售价',
      dataIndex: 'price',
      hideInSearch: true,
      renderText: (value) => (value ? Number(value) / 100 : 0),
    },
    {
      title: '第三方成本价',
      dataIndex: 'costPrice',
      hideInSearch: true,
      renderText: (value) => (value ? Number(value) / 100 : 0),
    },
    {
      title: '条形码',
      dataIndex: 'barCode',
      hideInSearch: true,
    },
    {
      title: '商品图片',
      dataIndex: 'pics',
      hideInSearch: true,
      render: (text, record) => [
        record?.pics?.map((item: string, index: number) => {
          return <img key={item + String(index)} src={item} alt="" height="80" />;
        }),
      ],
    },
    {
      title: '通用名',
      dataIndex: 'genericName',
    },
    {
      title: '品牌名',
      dataIndex: 'brandName',
    },
    {
      title: '规格',
      dataIndex: 'spec',
      hideInSearch: true,
    },
    {
      title: '是否处方',
      dataIndex: 'prescriptionType',
      hideInSearch: true,

      valueType: 'select',
      valueEnum: medicineType,
    },
    {
      title: '同步时间',
      dataIndex: 'updatedTime',
      hideInSearch: true,
      renderText: (value: string | undefined) => convertTime(value),
    },
    {
      title: '新增商品时间区间',
      dataIndex: 'createdTime',
      renderFormItem: () => {
        return <RangePicker placeholder={['开始日期', '结束日期']} />;
      },
      hideInTable: true,
    },
    {
      hideInSearch: true,
      title: '操作',
      fixed: 'right',
      align: 'center',
      render: (_text, record) => [
        <Button
          key={'details'}
          onClick={() => {
            detailsClick(record);
          }}
          type="link"
        >
          详情
        </Button>,
        record.supplierType !== 1 && (
          <Button
            key={'edit'}
            onClick={() => {
              editClick(record);
            }}
            type="link"
          >
            编辑
          </Button>
        ),
        <Button
          key={'join'}
          onClick={() => {
            setIds([]);
            joinClick(record);
          }}
          type="link"
        >
          加入
        </Button>,
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="ThirdPartyDrugsTable"
      scroll={{ x: 2000 }}
      rowClassName={(record: any) => {
        if (
          hasFields(record, [
            'supplierSkuId',
            'stockCount',
            'status',
            'price',
            'genericName',
            'brandName',
            'spec',
          ])
        ) {
          return 'dataMissing';
        } else {
          return '';
        }
      }}
      columns={columns}
      request={ThirdPartyDrugsData}
      rowKey="id"
      dateFormatter="string"
      search={{
        labelWidth: 120,
        optionRender: (_searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      rowSelection={rowSelection}
      pagination={{ defaultPageSize: 10 }}
      toolBarRender={() => [
        <Button
          key="batchJoin"
          type="primary"
          onClick={() => {
            if (ids.length) {
              joinClick();
            } else {
              showErrorMessage('请选择批量上架的数据');
            }
          }}
        >
          批量加入
        </Button>,
        <Button
          key="export"
          type="primary"
          loading={loading}
          onClick={() => {
            setLoading(true);
            exportThirdGoods().then((res) => {
              setLoading(false);
              const { size } = res;
              if (size <= 500) {
                showErrorMessage('数据流异常，无法正常下载');
                return;
              }
              ClickDownXlsx(res, '第三方药品数据');
              showSuccessMessage('导出成功');
            });
          }}
        >
          导出
        </Button>,

        // 新增
        <Button
          key="create"
          type="primary"
          onClick={() => {
            setModalType(MODAL_TYPE_CREATE);
          }}
        >
          新增
        </Button>,
        <Upload
          accept={'.xlsx,.xls'}
          maxCount={1}
          type={'select'}
          beforeUpload={handleBeforeUpload}
          customRequest={customeUpload}
          showUploadList={false}
        >
          <Button key="primary" type="primary" loading={scheduleLoading}>
            {scheduleLoading ? null : <UploadOutlined />}
            导入
          </Button>
        </Upload>,
        <Button
          key="download"
          type="primary"
          onClick={() => {
            downloadExcelTemplate('DSFK');
          }}
        >
          下载导入模板
        </Button>,
      ]}
      actionRef={actionRef}
    >
      <Modal
        visible={visible}
        btnLoading={btnLoading}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
        onOk={onOk}
        modalType={modalType}
        modalVisible={!!modalType}
        title={getModalTitle()}
        onCancel={onCancel}
      >
        {modalType === MODAL_TYPE_DETAIL && (
          <Details
            syncStatus={syncStatus}
            medicineType={medicineType}
            itemType={itemTypeOpent}
            warehouse={warehouse}
            supplierType={supplierType}
            ref={detailsRef}
          />
        )}
        {modalType === MODAL_TYPE_CREATE && (
          <CreateOrEdit
            medicineType={medicineType}
            itemType={itemTypeOpent}
            warehouse={warehouse}
            supplierType={supplierType}
            ref={createOrEditRef}
          />
        )}
        {modalType === MODAL_TYPE_EDIT && (
          <CreateOrEdit
            medicineType={medicineType}
            itemType={itemTypeOpent}
            warehouse={warehouse}
            supplierType={supplierType}
            ref={createOrEditRef}
          />
        )}
      </Modal>
    </TableLocal>
  );
};
export default ThirdPartyDrugs;

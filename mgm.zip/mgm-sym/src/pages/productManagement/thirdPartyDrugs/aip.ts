import dayjs from 'dayjs';
import { HOST_TYPE_POWER } from '@/utils/utils';
import { getRequest, postRequest, TIMEOUT } from '@/services/api';

import { removerObjectWhitespace } from '../api';
import type { ThirdPartyDrugsDataType } from './typings';
import { request } from 'umi';
import { POWER_HOST } from '@/services/hosts';

let searchData = {};

const ThirdPartyDrugsData = async (params: ThirdPartyDrugsDataType) => {
  const { pageSize, current, createdTime, ...data } = params;
  const createdStartTime =
    createdTime && createdTime.length === 2
      ? `${dayjs(createdTime[0]).format('YYYY-MM-DD')} 00:00:00`
      : undefined;
  const createdEndTime =
    createdTime && createdTime.length === 2
      ? `${dayjs(createdTime[1]).format('YYYY-MM-DD')} 23:59:59`
      : undefined;

  searchData = { ...data, createdStartTime, createdEndTime };

  const newData = removerObjectWhitespace<ThirdPartyDrugsDataType>(data);

  const msg = (await postRequest(
    '/mall/list-third-goods',
    {
      createdStartTime,
      createdEndTime,
      currentPage: current,
      pageSize,
      ...newData,
    },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: (msg.result && msg.result.items) || [],
    total: (msg.result && msg.result.totalCount) || 0,
  };
};
const joinThirdGoods = async (ids: string[]) => {
  return (await postRequest(
    '/mall/join-third-goods',
    {},
    { ids },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
//
const channelGoodsDetails = async (data: { id: string; skuId: string }) => {
  return (await postRequest(
    '/mall/channel-goods-details',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const exportThirdGoods = async () => {
  return (await postRequest(
    '/mall/export-third-goods',
    { ...searchData },
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  )) as unknown as any;
};
// 导入
const importExcel = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/mall/import_third_goods', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};
const listWarehouse = async () => {
  return (await getRequest(
    '/mall/list-warehouse',
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const addThirdGoods = async (data: any) => {
  return (await postRequest(
    '/mall/add-or-update-third-goods',
    data,
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
export {
  ThirdPartyDrugsData,
  joinThirdGoods,
  channelGoodsDetails,
  exportThirdGoods,
  importExcel,
  listWarehouse,
  addThirdGoods,
};

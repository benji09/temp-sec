import { getRequest, post } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';
import { importExcel } from '../api';
import type { DiagnosricParams, DiagnosricResult } from './typing';

// 诊断结果列表
async function queryDiagnosticList(data: DiagnosricParams) {
  const { current, ...rest } = data;
  const response = (await post('/mall/list-diagnostic', {
    data: { ...rest, currentPage: current },
    hostType: HOST_TYPE_POWER,
  })) as unknown as APIS.BaseResponse<DiagnosricResult>;
  const { result } = response;
  return {
    data: result?.diagnosticItemList ?? [],
    total: result?.total ?? 0,
  };
}

// 查询所有已启用的科室列表
async function queryDepartment() {
  return await post('/mall/list-department-data', { hostType: HOST_TYPE_POWER });
}

// 字典查询
async function queryDictionaryList(dicType: string) {
  const res: any = await getRequest(
    '/mall/list-dictionary',
    { dicType: '' },
    { type: HOST_TYPE_POWER },
  );
  const { result } = res;
  return result?.dictionary[dicType] ?? [];
}

// 批量启用禁用诊断结果
async function modifyDiagnosticStatus(id: string | number, status: number) {
  return await post('/mall/change-diagnostic-status', {
    data: { ids: [id], status },
    hostType: HOST_TYPE_POWER,
  });
}

// 诊断结果科室列表
async function queryClassroomById(id: string) {
  return await getRequest('/mall/list-diagnostic-classroom', { id }, { type: HOST_TYPE_POWER });
}

// 修改诊断结果科室
async function modifyDiagnosticClassroom(data) {
  return await post('/mall/modify-diagnostic-classroom', {
    data,
    hostType: HOST_TYPE_POWER,
  });
}

// 上传 EXCEL 文件接口
async function uploadInquiry(options: any) {
  return importExcel('/mall/import_diagnosis', options);
}

export {
  queryDiagnosticList,
  queryDepartment,
  queryDictionaryList,
  modifyDiagnosticStatus,
  queryClassroomById,
  modifyDiagnosticClassroom,
  uploadInquiry,
};

/*
 * @Author: Walker Denial
 * @Date: 2022-01-06 19:01:44
 * @LastEditors: zyx
 * @LastEditTime: 2022-02-24 14:48:40
 * @Desc:
 */
import { useRef, useState, useEffect } from 'react';
import { Button, Modal, Select, Upload } from 'antd';
import { ExportOutlined, ImportOutlined, PlusOutlined } from '@ant-design/icons';
import type { ActionType } from '@ant-design/pro-table';
import type { RcFile } from 'antd/lib/upload';

import { downloadExcelTemplate } from '@/services/api';
import TableLocal from '@/components/TableLocal/TableLocal';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { typeUploaded, UploadFailure, UploadResult, UploadSucceed } from '@/utils/utils';
import AddOrModifyModal from './editModal';
import {
  modifyDiagnosticStatus,
  queryDepartment,
  queryDiagnosticList,
  queryDictionaryList,
  uploadInquiry,
} from './api';
import { convertDepartmentToString } from './utils';
import type {
  DiagnosricClassRoomItem,
  DiagnosricItem,
  DictItem,
  ModalType,
  ModalRefType,
} from './typing';

import './index.less';

const InquiryManagement = () => {
  const actionRef = useRef<ActionType | undefined>();
  const modalRef = useRef<ModalRefType>();

  const [modalType, setModalType] = useState<ModalType>();
  const [diagnosric, setDiagnosric] = useState<DiagnosricItem | undefined>();
  const [departments, setDepartments] = useState<DiagnosricClassRoomItem[]>([]);
  const [statusDict, setStatusDict] = useState<DictItem[]>([]);
  const [statusEnum, setStatusEnum] = useState({});
  const [operateData, setOperateData] = useState({});
  const [confirming, setConfirming] = useState<boolean>();
  const [scheduleLoading, setScheduleLoading] = useState(false);

  const queryAllDepartment = () => {
    queryDepartment().then((res: any) => {
      const { result } = res;
      setDepartments(result?.departmentInfos ?? []);
    });
  };

  const queryStatus = () => {
    queryDictionaryList('STATUS').then((res: any) => {
      setStatusDict(res);
      const temp = {};
      (res ?? []).map((value: any) => {
        const { key } = value;
        temp[key] = value.value;
      });
      setStatusEnum(temp);
    });
  };

  const getOppsiteStatus = (status: number, defaultCode: number = -999) => {
    const tempList = statusDict.filter((value) => value.key !== status) ?? [];
    if (tempList.length < 1) return defaultCode;
    return +(tempList[0].key ?? defaultCode);
  };

  const onCreate = () => {
    setModalType('add');
  };

  const onEdit = (record: DiagnosricItem) => {
    setDiagnosric(record);
    setModalType('modify');
  };

  const modifyStatus = (id: string, status: boolean) => {
    const temp = { ...operateData };
    temp[id] = status;
    setOperateData(temp);
  };

  const onModifyStatus = (record: DiagnosricItem) => {
    const { id, status } = record;
    const tempId = `${id ?? ''}`;
    const tmepStatus = status ?? -1;
    modifyStatus(tempId, true);
    modifyDiagnosticStatus(tempId, getOppsiteStatus(tmepStatus))
      .then((res: any) => {
        modifyStatus(tempId, false);
        if (res?.status === 0) {
          showSuccessMessage('操作成功');
          actionRef?.current?.reload();
        }
      })
      .catch(() => modifyStatus(tempId, false));
  };

  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name || '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(typeUploaded('xlsx'));
    return isXlsx;
  }

  function customeUpload(options: any) {
    setScheduleLoading(true);
    uploadInquiry(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef?.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setScheduleLoading(false));
  }

  const downloadTemplate = () => {
    downloadExcelTemplate('ZDGL');
  };

  useEffect(() => {
    if (typeof modalType === 'undefined' && typeof diagnosric !== 'undefined') {
      setDiagnosric(undefined);
    }
  }, [diagnosric, modalType]);

  useEffect(() => {
    queryAllDepartment();
    queryStatus();
  }, []);

  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '诊断结果',
      dataIndex: 'name',
      align: 'center',
    },
    {
      title: '用户所见名称',
      dataIndex: 'alias',
      align: 'center',
    },
    {
      title: '科室',
      dataIndex: 'classRoomItems',
      align: 'center',
      renderText: (value: DiagnosricClassRoomItem[]) => convertDepartmentToString(value),
      hideInSearch: true,
    },
    {
      title: '科室',
      dataIndex: 'classRoomId',
      align: 'center',
      hideInTable: true,
      renderFormItem: () => {
        return (
          <Select>
            {(departments ?? []).map((item) => {
              return (
                <Select.Option value={item.id} key={item.id}>
                  {item.name}
                </Select.Option>
              );
            })}
          </Select>
        );
      },
    },
    {
      title: '药品数量',
      dataIndex: 'drugCount',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      align: 'center',
      hideInSearch: true,
      renderText: (value: number) => statusEnum[value],
    },
    {
      title: '操作',
      valueType: 'option',
      align: 'center',
      render: (text: any, record: DiagnosricItem) => {
        const { drugCount, classRoomItems, status, id } = record;
        const btnText = statusEnum[getOppsiteStatus(status!)];
        const isDisableStatus = `${btnText ?? ''}`.includes('禁用');
        return (
          <>
            <Button type="link" onClick={() => onEdit(record)}>
              编辑
            </Button>
            <Button
              type="link"
              onClick={() => onModifyStatus(record)}
              loading={operateData[id!]}
              disabled={isDisableStatus ? (drugCount ?? 0) > 0 : (classRoomItems ?? []).length < 1}
            >
              {btnText}
            </Button>
          </>
        );
      },
    },
  ];

  const toolbarRender = () => {
    return [
      <Upload
        accept={'.xlsx'}
        maxCount={1}
        type={'select'}
        beforeUpload={handleBeforeUpload}
        customRequest={customeUpload}
        showUploadList={false}
      >
        <Button type="primary" loading={scheduleLoading}>
          <ImportOutlined />
          导入
        </Button>
      </Upload>,
      <Button type="primary" onClick={downloadTemplate}>
        <ExportOutlined />
        下载导入模板
      </Button>,
      <Button type="primary" onClick={onCreate}>
        <PlusOutlined />
        新增
      </Button>,
    ];
  };

  const getTitleByModalType = () => {
    if (modalType === 'add') return '新增';
    if (modalType === 'modify') return '编辑';
    return '';
  };

  const onReload = () => {
    setModalType(undefined);
    actionRef?.current?.reload();
  };

  return (
    <>
      <TableLocal
        columns={columns}
        request={queryDiagnosticList}
        rowKey="id"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
        }}
        actionRef={actionRef}
        toolBarRender={toolbarRender}
      />
      <Modal
        width="60%"
        title={getTitleByModalType()}
        visible={!!modalType}
        onCancel={() => setModalType(undefined)}
        destroyOnClose={true}
        okText="保存"
        onOk={() => modalRef?.current?.onSave(onReload)}
        confirmLoading={confirming}
      >
        {(modalType === 'add' || modalType === 'modify') && (
          <AddOrModifyModal
            diagnosric={diagnosric}
            departments={departments}
            ref={modalRef}
            setConfirmLoading={setConfirming}
            statusDict={statusDict}
          />
        )}
      </Modal>
    </>
  );
};

export default InquiryManagement;

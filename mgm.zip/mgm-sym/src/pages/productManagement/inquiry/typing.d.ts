/*
 * @Author: Walker Denial
 * @Date: 2022-01-07 14:33:12
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-02-10 10:40:47
 * @Desc:
 */
type ModalType = 'add' | 'modify' | undefined | null;

type AddOrModifyProps = {
  diagnosric?: DiagnosricItem;
  departments?: DiagnosricClassRoomItem[];
  statusDict?: DictItem[];
  setConfirmLoading?: (loading: boolean) => void;
};

type DiagnosricParams = {
  classRoomName?: string; // 科室名称
  currentPage?: number; // 当前页
  current?: number; // 当前页
  name?: string; // 名字
  pageSize?: number; // 每页条数
};

type DiagnosricClassRoomItem = {
  id?: number | string | null | undefined;
  name?: string | null | undefined;
};

type DiagnosricItem = {
  classRoomItems?: DiagnosricClassRoomItem[]; // 科室姓名
  drugCount?: number; // 药品数量
  id?: number | string;
  name?: string; // 名称
  status?: number; // 状态
};

type DiagnosricResult = {
  currentPage?: number; // 当前页
  pageSize?: number; // 每页条数
  total?: number; // 全部条数
  totalPage?: number; // 全部页
  diagnosticItemList?: DiagnosricItem[];
};

type ClassRoomItem = {
  classroomName?: string; // 科室名
  id?: number | string; // 科室 id
  order?: number | string; // 排序
  mask?: number;
};

type ClassRoomResult = {
  classroomList?: ClassRoomItem[];
  diagnosticId?: string | number; // 诊断 id
  name?: string;
};

type DictItem = {
  key: number | string;
  value: string | number | boolean;
};

type ModalRefType = {
  onSave: (nextStep: () => void | undefined) => void;
};

export {
  AddOrModifyProps,
  ModalType,
  DiagnosricParams,
  DiagnosricResult,
  DiagnosricItem,
  ClassRoomItem,
  ClassRoomResult,
  DiagnosricClassRoomItem,
  DictItem,
  ModalRefType,
};

/*
 * @Author: Walker Denial
 * @Date: 2022-01-13 17:20:21
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-13 18:06:23
 * @Desc:
 */
type OfficeAttributeItem = {
  count?: number;
  department?: string;
  id?: string | number;
};

type OfficeDiagnosisResult = {
  createdAt?: string;
  diagnosisResult?: string;
  id?: string | number;
};

export { OfficeAttributeItem, OfficeDiagnosisResult };

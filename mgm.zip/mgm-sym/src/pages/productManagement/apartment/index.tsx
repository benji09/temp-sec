/*
 * @Author: Walker Denial
 * @Date: 2022-01-06 19:01:44
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-13 17:55:51
 * @Desc:
 */
import { useState } from 'react';
import { Button, Modal } from 'antd';

import TableLocal from '@/components/TableLocal/TableLocal';
import InquiryResult from './result';
import { queryOfficeAttrList } from './api';
import type { OfficeAttributeItem } from './typing';

import './index.less';

const Apartment = () => {
  const [id, setId] = useState<string | number | undefined>();

  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '一级科室',
      dataIndex: 'department',
      align: 'center',
    },
    {
      title: '对应诊断结果',
      dataIndex: 'count',
      align: 'center',
      render: (text: string | number, record: OfficeAttributeItem) => {
        return (
          <>
            <Button type="link" onClick={() => setId(record.id)}>
              {text}
            </Button>
          </>
        );
      },
    },
  ];

  return (
    <>
      <TableLocal columns={columns} request={queryOfficeAttrList} rowKey="id" search={false} />
      <Modal
        footer={false}
        width="60%"
        title="对应诊断结果"
        visible={typeof id !== 'undefined'}
        onCancel={() => setId(undefined)}
        destroyOnClose={true}
      >
        <InquiryResult id={id} />
      </Modal>
    </>
  );
};

export default Apartment;

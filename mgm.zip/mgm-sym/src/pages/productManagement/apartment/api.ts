import { getRequest, post } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';
import type { OfficeAttributeItem } from './typing';

// 科室属性列表
async function queryOfficeAttrList() {
  const response = (await post('/mall/section-office-attributes-list', {
    hostType: HOST_TYPE_POWER,
  })) as unknown as APIS.BaseResponse<OfficeAttributeItem[]>;
  const { result } = response;
  return { data: result ?? [] };
}
// 科室属性对应诊断结果
async function queryDiagnosticResult(data: any) {
  const response: any = await getRequest('/mall/section-office-diagnostic-result', data, {
    type: HOST_TYPE_POWER,
  });
  return response?.result?.diagnosisInfos ?? [];
}

export { queryOfficeAttrList, queryDiagnosticResult };

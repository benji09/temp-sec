/*
 * @Author: Walker Denial
 * @Date: 2022-01-07 14:33:12
 * @LastEditors: zyx
 * @LastEditTime: 2022-02-08 14:04:52
 * @Desc:
 */
type ModalType = 'add' | 'modify' | undefined | null;

type DictItem = {
  createAt?: string;
  dictType?: string;
  id?: string;
  name?: string;
  sort?: number;
  status?: boolean;
  updatedAt?: string;
};
type TypeListType = Record<string | undefined, string | undefined>;

type FieldNamesType = {
  value: string;
  key: string;
  lable: string;
};
type ArrayToSelectModeType = 'multiple' | 'tags' | undefined;

export { ModalType, DictItem, TypeListType, FieldNamesType, ArrayToSelectModeType };

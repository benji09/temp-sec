/*
 * @Author: Walker Denial
 * @Date: 2022-01-06 19:01:44
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-19 17:47:39
 * @Desc:
 */
import DictManagement from '../components/dictList';

const IllnessManagement = () => (
  <DictManagement dictLabel="过往疾病史" dictType="DISEASE_HISTORY" excelTemplate="GWJBS" />
);

export default IllnessManagement;

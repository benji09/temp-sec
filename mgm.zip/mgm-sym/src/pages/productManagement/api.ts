import { request } from 'umi';

import { post } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';

// mall字典列表
async function queryDictList(data: { keyWord?: string }, dictType: string) {
  const response: any = await post('/mall/mall-list-of-dictionaries', {
    data: { ...(data ?? {}), dictType },
    hostType: HOST_TYPE_POWER,
  });
  return { data: response?.result?.dictInfos ?? [] };
}

async function addDictItem(data: { name: string; sort: number }, dictType: string) {
  return await post('/mall/add-mall-dictionary', {
    data: { dictInfoList: [data], dictType },
    hostType: HOST_TYPE_POWER,
  });
}

async function modifyDictItem(data: { id: number; status: boolean; name: string; sort: number }) {
  return await post('/mall/update-mall-dictionary', {
    data: data,
    hostType: HOST_TYPE_POWER,
  });
}

// 上传 EXCEL
async function importExcel(url: string, options: any) {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request(url, {
    method: 'POST',
    body: formData,
    timeout: 60 * 1000,
    type: HOST_TYPE_POWER,
  });
}

// 上传 EXCEL 文件接口
async function uploadMallDictionary(options: any) {
  return importExcel('/mall/import-mall-dictionary', options);
}

// 去除数据中的空对象和前后空格
function removerObjectWhitespace<T>(obj: T) {
  if (!obj || Object.keys(obj).length <= 0) return {};
  const newObj = {};
  Object.keys(obj).map((item) => {
    if (obj[item].trim() === '') {
      newObj[item] = undefined;
    } else {
      newObj[item] = obj[item].trim();
    }
  });
  return newObj;
}
// 是否儿童用药
const ChildrenMedicationType = {
  true: {
    text: '是',
  },
  false: {
    text: '否',
  },
};
// 搜索是否儿童用药
const ChildrenMedicationSearchType = {
  1: {
    text: '是',
  },
  2: {
    text: '否',
  },
};

export {
  queryDictList,
  addDictItem,
  modifyDictItem,
  uploadMallDictionary,
  importExcel,
  removerObjectWhitespace,
  ChildrenMedicationType,
  ChildrenMedicationSearchType,
};

import type { TypeListType } from '../typing';

const convertTime = (time: string | undefined, defaultValue: string | undefined = '') => {
  if (!time) return defaultValue;
  if (time.includes('T') && time.includes('.')) {
    return time.substring(0, time.indexOf('.')).replace('T', ' ');
  }
  return time;
};

const THIRD_STATUS = {
  true: {
    text: '上架',
  },
  false: {
    text: '下架',
  },
};
const PlaguePreventionDrugType = {
  true: {
    text: '是',
  },
  false: {
    text: '否',
  },
};
const PlaguePreventionDrugSearchType = {
  1: {
    text: '否',
  },
  2: {
    text: '是',
  },
};
// 是否儿童用药
const ChildrenMedicationType = {
  true: {
    text: '是',
  },
  false: {
    text: '否',
  },
};
// 搜索是否儿童用药
const ChildrenMedicationSearchType = {
  1: {
    text: '是',
  },
  2: {
    text: '否',
  },
};
// 下拉选择是否儿童用药
const ChildrenMedication = {
  1: '是',
  2: '否',
};
// 下拉选择是否儿童用药
const ChildrenMedicationBoolean = {
  true: '是',
  false: '否',
};
// 是否有商品图片
const CommodityImagesType = {
  1: {
    text: '是',
  },
  2: {
    text: '否',
  },
};

const transferListToObject = (
  list: APIS.DictionaryType[] | undefined,
  obj: TypeListType | undefined = undefined,
) => {
  const tempObj = { ...(obj ?? {}) };
  list?.map((item: APIS.DictionaryType) => {
    tempObj[item.key ?? ''] = item.value;
  });
  return tempObj;
};

export {
  convertTime,
  transferListToObject,
  THIRD_STATUS,
  PlaguePreventionDrugType,
  PlaguePreventionDrugSearchType,
  ChildrenMedicationType,
  ChildrenMedicationSearchType,
  ChildrenMedication,
  ChildrenMedicationBoolean,
  CommodityImagesType,
};

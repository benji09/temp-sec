/*
 * @Author: Walker Denial
 * @Date: 2022-01-06 19:01:44
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-19 17:46:37
 * @Desc:
 */
import DictManagement from '../components/dictList';

const AllergyManagement = () => (
  <DictManagement dictLabel="药物过敏史" dictType="ALLERGIES" excelTemplate="YWGMS" />
);

export default AllergyManagement;

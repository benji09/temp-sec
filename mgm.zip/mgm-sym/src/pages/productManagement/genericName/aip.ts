import { getRequest, postRequest, TIMEOUT } from '@/services/api';
import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';
import { request } from 'umi';

import type { GenericNameParamsType } from './typing';

const genericNameList = async (params: GenericNameParamsType) => {
  const { current, ...data } = params;
  const msg = (await postRequest(
    '/mall/common-goods-list',
    {
      ...data,
      currentPage: current,
    },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: (msg?.result && msg?.result.approvedDrugInfos) || [],
    total: (msg?.result && msg?.result.totalCount) || 0,
  };
};
const commonGoodsDetail = async (id: string) => {
  return (await getRequest(
    '/mall/common-goods-detail',
    { id },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const listDictByIds = async (dictType?: string, ids?: number[]) => {
  return (await postRequest(
    '/mall/list-dict-by-ids',
    { dictType, ids: ids || [] },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const listDiagnosisByKey = async (keyWord: string) => {
  return (await getRequest(
    '/mall/list-diagnosis-by-key',
    { keyWord: keyWord || '' },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const commonGoodsUpdate = async (data: any) => {
  return (await postRequest(
    '/mall/common-goods-update',
    { ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const commonGoodsSync = async (ids: string[]) => {
  return (await postRequest(
    '/mall/common-goods-sync',
    {},
    { ids },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 导入
const importExcel = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/mall/import_common_goods', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};
export {
  genericNameList,
  commonGoodsDetail,
  listDictByIds,
  listDiagnosisByKey,
  commonGoodsUpdate,
  commonGoodsSync,
  importExcel,
};

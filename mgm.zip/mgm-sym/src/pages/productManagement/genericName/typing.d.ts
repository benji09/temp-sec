import type { ReactNode } from 'react';

type GenericNameParamsType = {
  commonId?: string;
  commonName?: string;
  itemType?: number;
  oneFlowKindId?: number;
  standardId?: number;
  threeFlowKindId?: number;
  twoFlowKindId?: number;
  current: number;
  pageSize: number;
};
type DrugUsageType = {
  dosage?: string;
  dosageUnit?: number;
  frequency?: number;
  usage?: number;
};
type RiskInfoType = {
  allergiesId?: number[];
  diseaseHistory?: number[];
  maxAge?: number;
  minAge?: number;
  pregnantMan?: number;
  pregnantWoman?: number[];
};
type GenericNameType = {
  allergiesId?: number[];
  applyGender?: number;
  attentionMatter?: string;
  categoryId?: number[];
  commonId?: string;
  commonName?: string;
  deptId?: number[];
  diagnosticResult?: Record<string | undefined, string | undefined>;
  diagnosticResultId?: number[];
  diseaseHistory?: number[];
  drugUsage?: DrugUsageType;
  id?: number;
  indication?: string;
  itemType?: number;
  maxAge?: number;
  medicineInteraction?: string;
  minAge?: number;
  pregnantMan?: number;
  pregnantWoman?: number[];
  riskInfo?: RiskInfoType;
  sideEffect?: string;
  taboo?: string;
  usageMessage?: string;
  userId?: number;
  minAgeUnit?: number;
  maxAgeUnit?: number;
};
type GoodsCategoryOptionsType = {
  value?: string;
  label?: string;
  children?: GoodsCategoryOptionsType[];
};
type GenericNameModalType = {
  modalVisible?: boolean;
  visible?: boolean;
  title?: string;
  btnLoading?: boolean;
  onOk: () => void;
  onCancel: () => void;
  onSaveData: () => void;
  onCancelSave: () => void;
  children?: ReactNode;
};
type TypeListType = Record<string | undefined, string | undefined>;
type DiagnosisResultOptionType = {
  id?: string;
  name?: string;
  departmentIds?: string[];
};
type FieldNamesType = {
  value: string;
  key: string;
  lable: string;
};
type CreateOrEditPropsType = {
  usage?: APIS.DictionaryType[];
  usageUnit?: APIS.DictionaryType[];
  useTime?: APIS.DictionaryType[];
  itemType?: APIS.DictionaryType[];
  department?: APIS.DictionaryType[];
  pregnantWoman?: APIS.DictionaryType[];
  pregnantMan?: APIS.DictionaryType[];
  allergies?: APIS.DictionaryType[];
  diseaseHistory?: APIS.DictionaryType[];
  applicableSex?: APIS.DictionaryType[];
  ageUnitType?: TypeListType;
};
type DetailsType = {
  userId?: string;
  id?: string;
};
type ArrayToSelectModeType = 'multiple' | 'tags' | undefined;
export {
  GenericNameParamsType,
  GenericNameType,
  GoodsCategoryOptionsType,
  TypeListType,
  GenericNameModalType,
  DiagnosisResultOptionType,
  CreateOrEditPropsType,
  DetailsType,
  FieldNamesType,
  ArrayToSelectModeType,
};

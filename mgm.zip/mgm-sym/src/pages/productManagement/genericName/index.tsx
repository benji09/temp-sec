import React, { useEffect, useRef, useState } from 'react';
import { Button, Upload } from 'antd';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/TableLocal';
import { downloadExcelTemplate, listDictionary } from '@/services/api';
import { hasFields, typeUploaded, UploadFailure, UploadResult, UploadSucceed } from '@/utils/utils';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import {
  commonGoodsDetail,
  commonGoodsSync,
  commonGoodsUpdate,
  genericNameList,
  importExcel,
  listDictByIds,
} from './aip';
import {
  ChildrenMedicationSearchType,
  PlaguePreventionDrugSearchType,
  PlaguePreventionDrugType,
  transferListToObject,
} from '../utils';
import Modal from './components/Modal';
import CreateOrEdit from './components/CreateOrEdit';
import type { GenericNameType, TypeListType } from './typing';

import './index.less';

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_EDIT = 2;
const GenericName: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const createOrEditRef = useRef<any>();

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [details, setDetails] = useState<any>({});
  const [ids, setIds] = useState<string[]>([]);

  const [pregnantWoman, setPregnantWoman] = useState<TypeListType>({});
  const [pregnantMan, setPregnantMan] = useState<TypeListType>({});
  const [allergies, setAllergies] = useState<TypeListType>({});
  const [diseaseHistory, setDiseaseHistory] = useState<TypeListType>({});
  const [applyGender, setApplyGender] = useState<TypeListType>({});
  const [itemType, setItemType] = useState<TypeListType>({});
  const [ageUnitType, setAgeUnitType] = useState<TypeListType>({});
  const [department, setDepartment] = useState<TypeListType>({});

  const [usageUnitOption, setUsageUnitOption] = useState<APIS.DictionaryType[]>([]);
  const [usageOption, setUsageOption] = useState<APIS.DictionaryType[]>([]);
  const [useTimeOption, setUseTimeOption] = useState<APIS.DictionaryType[]>([]);
  const [itemTypeOption, setItemTypeOption] = useState<APIS.DictionaryType[]>([]);
  const [departmentOption, setDepartmentOption] = useState<APIS.DictionaryType[]>([]);
  const [pregnantWomanOption, setPregnantWomanOption] = useState<APIS.DictionaryType[]>([]);
  const [pregnantManOption, setPregnantManOption] = useState<APIS.DictionaryType[]>([]);
  const [allergiesOption, setAllergiesOption] = useState<APIS.DictionaryType[]>([]);
  const [diseaseHistoryOption, setDiseaseHistoryOption] = useState<APIS.DictionaryType[]>([]);
  const [applicableSexOption, setApplicableSexOption] = useState<APIS.DictionaryType[]>([]);

  const [scheduleLoading, setScheduleLoading] = useState(false);

  useEffect(() => {
    listDictionary([
      'PREGNANT_WOMAN',
      'PREGNANT_MAN',
      'ALLERGIES',
      'DISEASE_HISTORY',
      'ITEM_TYPE',
    ]).then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;

        setPregnantWoman(transferListToObject(dictionary?.PREGNANT_WOMAN));
        setPregnantMan(transferListToObject(dictionary?.PREGNANT_MAN));
        setAllergies(transferListToObject(dictionary?.ALLERGIES));
        setDiseaseHistory(transferListToObject(dictionary?.DISEASE_HISTORY));

        setPregnantWomanOption(dictionary.PREGNANT_WOMAN);
        setPregnantManOption(dictionary.PREGNANT_MAN);
        setAllergiesOption(dictionary.ALLERGIES);
        setDiseaseHistoryOption(dictionary.DISEASE_HISTORY);
      }
    });
    listDictionary().then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;
        setApplyGender(transferListToObject(dictionary?.APPLICABLE_SEX));
        setApplicableSexOption(dictionary?.APPLICABLE_SEX);
        setUsageOption(dictionary?.usage);
        setUsageUnitOption(dictionary?.usage_unit);
        setUseTimeOption(dictionary?.use_time);
        setAgeUnitType(transferListToObject(dictionary?.AGE_UNIT));
        setItemType(transferListToObject(dictionary?.ITEM_TYPE));
        setItemTypeOption(dictionary?.ITEM_TYPE);
      }
    });
    listDictByIds('DEPARTMENT').then((res) => {
      if (res.status === 0 && res.result) {
        const DICDATAINFOS = {};
        res.result.dictDataInfos?.map((item: APIS.DictionaryType) => {
          DICDATAINFOS[item.id ?? ''] = item.name;
        });

        setDepartment(DICDATAINFOS);
        setDepartmentOption(res.result.dictDataInfos);
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_EDIT:
        return '编辑';
    }
    return '';
  }

  function onOk() {
    createOrEditRef.current
      ?.takeData()
      .then((res: any) => {
        setDetails(res);
        setVisible(true);
      })
      .catch((error: Error) => {
        showErrorMessage(error.message);
      });
  }
  function onCancel() {
    setBtnLoading(false);
    setVisible(false);

    setTimeout(() => {
      createOrEditRef.current?.reset();
      setModalType(undefined);
    });
  }
  function onSaveData() {
    setBtnLoading(true);
    commonGoodsUpdate(details).then((res) => {
      setBtnLoading(false);
      setVisible(false);
      if (res.status === 0) {
        setModalType(undefined);
        createOrEditRef.current?.reset();
        actionRef.current?.reload();
      }
    });
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }

  function editClick(record: any) {
    setModalType(MODAL_TYPE_EDIT);
    commonGoodsDetail(record.id).then((res) => {
      if (res.status === 0 && !!res.result) {
        createOrEditRef.current?.setData(res.result);
      }
    });
  }
  function synchroScaleClick(record?: any) {
    commonGoodsSync(record ? record.id : ids).then((res) => {
      if (res.status === 0) {
        setIds([]);
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.();
        showSuccessMessage('操作成功');
      }
    });
  }
  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name ?? '').endsWith('.xls') || (file?.name ?? '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(typeUploaded('xls 或 xlsx'));
    return isXlsx;
  }
  function customeUpload(options: any) {
    setScheduleLoading(true);

    importExcel(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setScheduleLoading(false));
  }
  // 年龄风控
  const riskInfoAge = (record: GenericNameType) => {
    const { minAge, minAgeUnit, maxAge, maxAgeUnit } = record;
    return (
      <span key={'riskInfo'}>
        {minAge ?? ''} {ageUnitType?.[`${minAgeUnit ?? ''}`]}
        {!hasFields(record, ['maxAge', 'minAge']) && '~'}
        {maxAge ?? ''}
        {ageUnitType?.[`${maxAgeUnit ?? ''}`]}
      </span>
    );
  };
  const deptList = (text: (string | number)[]) => {
    const tempDept: (string | undefined)[] = [];
    text.map((item: string | number) => {
      tempDept.push(department[item]);
    });
    return tempDept.join(', ');
  };

  const columns: ProColumns<GenericNameType>[] = [
    {
      title: '通用名 ID',
      dataIndex: 'commonId',
    },
    {
      title: '标准库 ID',
      dataIndex: 'standardId',
      hideInTable: true,
    },
    {
      title: '通用名',
      dataIndex: 'commonName',
    },
    {
      title: '商品属性',
      dataIndex: 'itemType',
      valueType: 'select',
      valueEnum: itemType,
    },
    {
      title: '商品分类',
      dataIndex: 'categoryId',
      hideInForm: true,
    },
    {
      title: '用法用量',
      dataIndex: 'usageMessage',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '是否儿童用药',
      dataIndex: 'childrenDrug',
      valueType: 'select',
      valueEnum: ChildrenMedicationSearchType,
      hideInSearch: true,
    },
    {
      title: '年龄风控',
      dataIndex: 'riskInfo',
      hideInSearch: true,
      renderText: (text: any, record: any) => riskInfoAge(record),
    },
    {
      title: '对应诊断结果',
      dataIndex: 'diagnosticResultId',
      hideInSearch: true,
      renderText: (text: any, record: any) => Object.values(record.diagnosticResult).join(','),
    },
    {
      title: '科室',
      dataIndex: 'deptId',
      ellipsis: true,
      hideInSearch: true,
      renderText: (text: any) => deptList(text),
    },
    {
      title: '女性孕哺风控',
      dataIndex: 'pregnantWoman',
      valueType: 'select',
      valueEnum: pregnantWoman,
      hideInSearch: true,
    },
    {
      title: '男性备孕风控',
      dataIndex: 'pregnantMan',
      valueType: 'select',
      valueEnum: pregnantMan,
      hideInSearch: true,
    },
    {
      title: '药物过敏史风控',
      dataIndex: 'allergiesId',
      valueType: 'select',
      valueEnum: allergies,
      hideInSearch: true,
    },
    {
      title: '过往病史风控',
      dataIndex: 'diseaseHistory',
      valueType: 'select',
      valueEnum: diseaseHistory,
      hideInSearch: true,
    },
    {
      title: '适用性别',
      valueType: 'select',
      dataIndex: 'applyGender',
      valueEnum: applyGender,
      hideInSearch: true,
    },
    {
      title: '是否疫情防控药品',
      valueType: 'select',
      dataIndex: 'plaguePreventionDrug',
      valueEnum: PlaguePreventionDrugSearchType,
      hideInTable: true,
    },
    {
      title: '疫情防控药品',
      valueType: 'select',
      dataIndex: 'plaguePreventionDrug',
      valueEnum: PlaguePreventionDrugType,
      hideInSearch: true,
    },
    {
      title: '适应症',
      dataIndex: 'indication',
      hideInSearch: true,
      ellipsis: true,
    },
    {
      title: '不良反应',
      dataIndex: 'sideEffect',
      hideInSearch: true,
      ellipsis: true,
    },
    {
      title: '禁忌',
      dataIndex: 'taboo',
      hideInSearch: true,
      ellipsis: true,
    },
    {
      title: '注意事项',
      dataIndex: 'attentionMatter',
      hideInSearch: true,
      ellipsis: true,
    },
    {
      title: '药物相互作用',
      width: 100,
      dataIndex: 'medicineInteraction',
      hideInSearch: true,
      ellipsis: true,
    },
    {
      title: '是否儿童用药',
      dataIndex: 'childrenDrug',
      valueType: 'select',
      valueEnum: ChildrenMedicationSearchType,
      hideInTable: true,
    },
    {
      title: '操作',
      fixed: 'right',
      width: 130,
      hideInSearch: true,
      render: (text, record) => [
        <Button
          type="link"
          key="synchroScale"
          onClick={() => {
            synchroScaleClick(record);
          }}
        >
          同步全量表
        </Button>,
        <Button
          type="link"
          key="editable"
          onClick={() => {
            editClick(record);
          }}
        >
          编辑
        </Button>,
      ],
    },
  ];

  const rowSelection = {
    onChange: (selectedRowKeys: string[]) => {
      setIds(selectedRowKeys);
    },
  };
  return (
    <TableLocal
      tableClassName="genericName"
      rowSelection={rowSelection}
      scroll={{ x: 2000 }}
      columns={columns}
      request={genericNameList}
      rowKey="id"
      search={{
        labelWidth: 120,
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      actionRef={actionRef}
      rowClassName={(record: any) => {
        // 存在商品分类、对应诊断结果、科室、药物过敏史风控、年龄风控、女性孕哺风控、男性备孕风控、适用性别其中一项为空时。
        if (
          hasFields(record, [
            'diagnosticResultId',
            'deptId',
            'allergiesId',
            'applyGender',
            'pregnantMan',
            'pregnantWoman',
          ]) ||
          (hasFields(record, ['minAge']) && hasFields(record, ['maxAge']))
        ) {
          return 'dataMissing';
        } else {
          return '';
        }
      }}
      toolBarRender={() => [
        <Upload
          maxCount={1}
          type={'select'}
          beforeUpload={handleBeforeUpload}
          customRequest={customeUpload}
          showUploadList={false}
        >
          <Button key="primary" type="primary" loading={scheduleLoading}>
            {scheduleLoading ? null : <UploadOutlined />}
            导入
          </Button>
        </Upload>,
        <Button
          key="download"
          type="primary"
          onClick={() => {
            downloadExcelTemplate('TYMK');
          }}
        >
          下载导入模板
        </Button>,
        <Button
          key="synchroScale"
          type="primary"
          onClick={() => {
            if (ids.length) {
              synchroScaleClick();
            } else {
              showErrorMessage('请选择要同步的数据');
            }
          }}
        >
          批量同步全量表
        </Button>,
        <Button
          key="add"
          type="primary"
          onClick={() => {
            setModalType(MODAL_TYPE_ADD);
          }}
        >
          <PlusOutlined />
          新增
        </Button>,
      ]}
    >
      <Modal
        modalVisible={!!modalType}
        visible={visible}
        btnLoading={btnLoading}
        title={getModalTitle()}
        onOk={onOk}
        onCancel={onCancel}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        <CreateOrEdit
          ref={createOrEditRef}
          usageUnit={usageUnitOption}
          usage={usageOption}
          useTime={useTimeOption}
          itemType={itemTypeOption}
          department={departmentOption}
          pregnantWoman={pregnantWomanOption}
          pregnantMan={pregnantManOption}
          allergies={allergiesOption}
          diseaseHistory={diseaseHistoryOption}
          applicableSex={applicableSexOption}
          ageUnitType={ageUnitType}
        />
      </Modal>
    </TableLocal>
  );
};
export default GenericName;

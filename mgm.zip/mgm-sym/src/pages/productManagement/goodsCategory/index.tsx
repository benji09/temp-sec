/*
 * @Author: Walker Denial
 * @Date: 2022-01-06 19:01:44
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-10 16:26:12
 * @Desc:
 */
import { useRef, useState, useEffect } from 'react';
import { Button, Modal, Cascader } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/TableLocal';
import AddOrModifyModal from './editModal';
import type { ModalType } from './typing';
import { queryGoodsClassification } from './api';

import './index.less';

const GoodsCategory = () => {
  const actionRef = useRef<ActionType | undefined>();
  const [modalType, setModalType] = useState<ModalType>();

  const queryClassification = () => {
    queryGoodsClassification().then((res: any) => {
      console.log(res);
    });
  };

  useEffect(() => {
    queryClassification();
  }, []);

  type NodeType = { value: string; label: string; disabled?: boolean; children?: NodeType[] };

  const searchData: NodeType[] = [
    {
      value: 'zhejiang',
      label: 'Zhejiang',
      children: [
        {
          value: 'hangzhou',
          label: 'Hangzhou',
          children: [
            {
              value: 'xihu',
              label: 'West Lake',
            },
            {
              value: 'xiasha',
              label: 'Xia Sha',
              disabled: true,
            },
          ],
        },
      ],
    },
    {
      value: 'jiangsu',
      label: 'Jiangsu',
      children: [
        {
          value: 'nanjing',
          label: 'Nanjing',
          children: [
            {
              value: 'zhonghuamen',
              label: 'Zhong Hua men',
            },
          ],
        },
      ],
    },
  ];

  const searchRender = () => {
    return (
      <Cascader
        options={searchData}
        // showSearch={{ filter }}
        multiple={true}
        // changeOnSelect
      />
    );
  };

  const columns = [
    {
      title: '分类',
      dataIndex: '',
      align: 'center',
      hideInTable: true,
      renderFormItem: searchRender,
    },
    {
      title: 'ID',
      dataIndex: '',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '一级商品类管理',
      dataIndex: '',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '商品数量',
      dataIndex: '',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '添加时间',
      dataIndex: '',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '状态',
      dataIndex: '',
      align: 'center',
      hideInSearch: true,
    },
    {
      title: '操作',
      valueType: 'option',
      align: 'center',
      render: (_text, record) => {
        return (
          <>
            <Button type="link">编辑</Button>
            <Button type="link">新增下一级</Button>
            <Button type="link">启用/禁用</Button>
          </>
        );
      },
    },
  ];

  const toolbarRender = () => {
    return [
      <Button
        type="primary"
        onClick={() => {
          setModalType('add');
        }}
      >
        <PlusOutlined />
        新增
      </Button>,
    ];
  };

  const getTitleByModalType = () => {
    if (modalType === 'add') return '新增';
    if (modalType === 'modify') return '编辑';
    return '';
  };

  return (
    <>
      <TableLocal
        columns={columns}
        // request={evaluationDoctorPage}
        rowKey="id"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
        }}
        actionRef={actionRef}
        toolBarRender={toolbarRender}
      />
      <Modal
        width="60%"
        title={getTitleByModalType()}
        visible={!!modalType}
        onCancel={() => setModalType(undefined)}
        destroyOnClose={true}
        okText="保存"
      >
        {(modalType === 'add' || modalType === 'modify') && <AddOrModifyModal />}
      </Modal>
    </>
  );
};

export default GoodsCategory;

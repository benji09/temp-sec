import { post } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';
import type { GoodsClassificationParams } from './typing';

// 商品分类
async function queryGoodsClassification(data: GoodsClassificationParams = {}) {
  return await post('/mall/goods-classification', { data: data, hostType: HOST_TYPE_POWER });
}

export { queryGoodsClassification };

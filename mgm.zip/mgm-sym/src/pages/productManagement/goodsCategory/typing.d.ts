/*
 * @Author: Walker Denial
 * @Date: 2022-01-07 14:33:12
 * @LastEditors: Walker Denial
 * @LastEditTime: 2022-01-10 16:22:37
 * @Desc:
 */
type ModalType = 'add' | 'modify' | undefined | null;

type GoodsClassificationParams = {
  page?: number;
  parentId?: number;
  size?: number;
};

export { ModalType, GoodsClassificationParams };

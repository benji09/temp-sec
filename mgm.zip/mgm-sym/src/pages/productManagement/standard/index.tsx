import React, { useEffect, useRef, useState } from 'react';
import { Button, Upload } from 'antd';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';
import type { RcFile } from 'antd/lib/upload';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/TableLocal';
import { downloadExcelTemplate, listDictionary } from '@/services/api';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { typeUploaded, UploadFailure, UploadResult, UploadSucceed } from '@/utils/utils';

import {
  importExcel,
  standardGoodsDetail,
  standardGoodsSync,
  standardGoodsUpdate,
  standardList,
} from './api';
import Modal from './components/Modal';
import CreateOrEdit from './components/CreateOrEdit';
import type { TypeListType } from './typing';

import './index.less';

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_EDIT = 2;
const Standard: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const createOrEditRef = useRef<any>();

  const [details, setDetails] = useState();

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [visible, setVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);

  const [scheduleLoading, setScheduleLoading] = useState(false);

  const [medicineTypeOption, setMedicineTypeOption] = useState<APIS.DictionaryType[]>([]);
  const [medicineType, setMedicineType] = useState<TypeListType>({});

  const [ids, setIds] = useState<string[]>([]);

  useEffect(() => {
    listDictionary().then((res) => {
      if (res.status === 0 && !!res.result) {
        const { dictionary } = res.result;
        const MEDICINE_TYPE = {};
        dictionary?.MEDICINE_TYPE?.map((item: APIS.DictionaryType) => {
          MEDICINE_TYPE[item.key ?? ''] = item.value;
        });
        setMedicineType(MEDICINE_TYPE);
        setMedicineTypeOption(dictionary?.MEDICINE_TYPE);
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_EDIT:
        return '编辑';
    }
    return '';
  }

  function onOk() {
    createOrEditRef.current.takeData().then((res: any) => {
      setDetails(res);
      setVisible(true);
    });
  }
  function onCancel() {
    setBtnLoading(false);
    setVisible(false);

    setTimeout(() => {
      setModalType(undefined);
      createOrEditRef.current?.reset();
    });
  }
  function onSaveData() {
    setBtnLoading(true);

    standardGoodsUpdate(details).then((res) => {
      setBtnLoading(false);
      setVisible(false);
      if (res.status === 0) {
        actionRef.current?.reload();
        createOrEditRef.current?.reset();
        setModalType(undefined);
      }
    });
  }
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }
  function editClick(record: { id: string }) {
    setModalType(MODAL_TYPE_EDIT);

    standardGoodsDetail(record.id).then((res) => {
      if (res.status === 0 && res.result) {
        createOrEditRef.current?.setData(res.result);
      }
    });
  }
  // 同步全量表
  function synchroScaleClick(record?: { id: string }) {
    standardGoodsSync({ ids: (!!record && [record.id]) || ids }).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('操作成功');
        actionRef.current?.reload();
        actionRef.current?.clearSelected?.(); // 清空选中项
        setIds([]);
      }
    });
  }
  function handleBeforeUpload(file: RcFile) {
    const isXlsx = (file?.name ?? '').endsWith('.xls') || (file?.name ?? '').endsWith('.xlsx');
    if (!isXlsx) showErrorMessage(typeUploaded('xls 或 xlsx'));
    return isXlsx;
  }
  function customeUpload(options: any) {
    setScheduleLoading(true);

    importExcel(options)
      .then((res) => {
        if (res.status === 0) {
          showSuccessMessage(UploadResult(UploadSucceed));
          actionRef.current?.reload();
        } else {
          showErrorMessage(res.message ? res.message : UploadResult(UploadFailure));
        }
      })
      .finally(() => setScheduleLoading(false));
  }
  const columns: ProColumns[] = [
    {
      title: '标准库 ID',
      dataIndex: 'id',
    },
    {
      title: '69 码',
      dataIndex: 'barCode',
    },
    {
      title: '通用名 ID',
      dataIndex: 'commonId',
    },
    {
      title: '通用名',
      dataIndex: 'commonName',
    },
    {
      title: '品牌',
      dataIndex: 'brandName',
      hideInSearch: true,
    },
    {
      title: '规格',
      dataIndex: 'spec',
      hideInSearch: true,
    },
    {
      title: '生产厂家',
      dataIndex: 'manufacturer',
      hideInSearch: true,
    },
    {
      title: '成份',
      dataIndex: 'contain',
      hideInSearch: true,
      ellipsis: true,
      width: 130,
    },
    {
      title: '性状',
      dataIndex: 'characteristic',
      hideInSearch: true,
    },
    {
      title: '贮藏',
      dataIndex: 'storage',
      hideInSearch: true,
    },
    {
      title: '有效期',
      dataIndex: 'validTime',
      hideInSearch: true,
    },
    {
      title: '批准文号',
      dataIndex: 'approvalNo',
      hideInSearch: true,
    },
    {
      title: '最小使用单位',
      dataIndex: 'miniUnit',
      hideInSearch: true,
    },
    {
      title: '包装单位',
      dataIndex: 'packUnit',
      hideInSearch: true,
    },
    {
      title: '用法用量说明书',
      dataIndex: 'usageDescription',
      hideInSearch: true,
      ellipsis: true,
      width: 120,
    },
    {
      title: '是否处方',
      dataIndex: 'medicineType',
      hideInSearch: true,
      valueType: 'select',
      valueEnum: medicineType,
    },
    {
      title: '操作',
      hideInSearch: true,
      fixed: 'right',
      render: (text, record) => [
        <Button
          key="editable"
          type="link"
          onClick={() => {
            editClick(record);
          }}
        >
          编辑
        </Button>,
        // 同步全量表
        <Button
          key="synchroScale"
          type="link"
          onClick={() => {
            setIds([]);
            synchroScaleClick(record);
          }}
        >
          同步全量表
        </Button>,
      ],
    },
  ];

  const rowSelection = {
    onChange: (selectedRowKeys: string[]) => {
      setIds(selectedRowKeys);
    },
  };
  return (
    <TableLocal
      rowSelection={rowSelection}
      columns={columns}
      request={standardList}
      rowKey="id"
      search={{
        labelWidth: 110,
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      scroll={{ x: 1850 }}
      actionRef={actionRef}
      toolBarRender={() => [
        <Upload
          accept={'.xlsx,.xls'}
          maxCount={1}
          type={'select'}
          beforeUpload={handleBeforeUpload}
          customRequest={customeUpload}
          showUploadList={false}
        >
          <Button key="primary" type="primary" loading={scheduleLoading}>
            {scheduleLoading ? null : <UploadOutlined />}
            导入
          </Button>
        </Upload>,
        <Button
          key="download"
          type="primary"
          onClick={() => {
            downloadExcelTemplate('BZKSJ');
          }}
        >
          下载导入模板
        </Button>,
        <Button
          key="synchroScale"
          type="primary"
          onClick={() => {
            if (ids.length) {
              synchroScaleClick();
            } else {
              showErrorMessage('请选择批量同步全量表数据');
            }
          }}
        >
          批量同步全量表
        </Button>,
        <Button
          key="add"
          type="primary"
          onClick={() => {
            setModalType(MODAL_TYPE_ADD);
          }}
        >
          <PlusOutlined />
          新增
        </Button>,
      ]}
    >
      <Modal
        modalVisible={!!modalType}
        visible={visible}
        btnLoading={btnLoading}
        title={getModalTitle()}
        onOk={onOk}
        onCancel={onCancel}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        <CreateOrEdit
          medicineType={medicineTypeOption}
          modalType={modalType}
          ref={createOrEditRef}
        />
      </Modal>
    </TableLocal>
  );
};
export default Standard;

import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';
import { getRequest, postRequest, TIMEOUT } from '@/services/api';

import type { StandardParamsType, StandardGoodsUpdateType } from './typing';

// 标准库管理
const standardList = async (params: StandardParamsType) => {
  const { current, ...data } = params;
  const msg = (await postRequest(
    '/mall/standard-goods-list',
    { ...data, currentPage: current },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: (msg?.result && msg?.result.standardGoodsVOItems) || [],
    total: (msg?.result && msg?.result.total) || 0,
  };
};

// 标准库修改/新增
const standardGoodsUpdate = async (data?: StandardGoodsUpdateType) => {
  return (await postRequest(
    '/mall/standard-goods-update',
    { ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 标准库获取详情
const standardGoodsDetail = async (id: string) => {
  return (await getRequest(
    '/mall/standard-goods-detail',
    { id },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 同步标准库
const standardGoodsSync = async (data: { ids: string[] }) => {
  return (await postRequest(
    '/mall/standard-goods-sync',
    {},
    { ...data },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
const searchCommonGoods = async (name: string) => {
  return (await getRequest(
    '/mall/search_common_goods',
    { name },
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 导入
const importExcel = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/mall/import_standard_goods', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};
export {
  standardList,
  standardGoodsUpdate,
  standardGoodsDetail,
  standardGoodsSync,
  searchCommonGoods,
  importExcel,
};

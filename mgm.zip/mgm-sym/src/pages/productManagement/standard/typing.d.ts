import type { ReactNode } from 'react';

type StandardParamsType = {
  id?: string;
  barCode?: string;
  commonId?: string;
  commonName?: string;
  current: number;
  pageSize: number;
};

type StandardModalType = {
  modalVisible?: boolean;
  visible?: boolean;
  title?: string;
  btnLoading?: boolean;
  onOk: () => void;
  onCancel: () => void;
  onSaveData: () => void;
  onCancelSave: () => void;
  children?: ReactNode;
};
type CreateOrEditPropsType = {
  medicineType: APIS.DictionaryType[];
  modalType?: number;
};
type StandardGoodsUpdateType = {
  approvalNo?: string;
  barCode?: string;
  brandName?: string;
  characteristic?: string;
  commonId?: number;
  contain?: string;
  id?: number;
  medicineType?: number;
  miniUnit?: string;
  spec?: string;
  storage?: string;
  usageDescription?: string;
  validTime?: string;
};
type TypeListType = Record<string | undefined, string | undefined>;
export {
  StandardParamsType,
  StandardModalType,
  CreateOrEditPropsType,
  StandardGoodsUpdateType,
  TypeListType,
};

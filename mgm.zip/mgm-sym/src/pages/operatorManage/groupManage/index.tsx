import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { showSuccessMessage } from '@/mamagement/Notification';
import { checkPermission, CREATE_GROUP } from '@/utils/power';

import Modal from './components/Modal';
import AddorEdit from './components/AddorEdit';
import { searchGroup, createGroup } from './api';
import type { GroupManageType } from './typings.d';

const permissionGroups = [CREATE_GROUP];

const GroupManage: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const addOrEdit = useRef<any>();

  const [addorEditVisible, setAddorEditVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [title, setTitle] = useState<string>('');

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  // 取消
  const onModalCancel = () => {
    addOrEdit.current?.reset();
    setLoading(false);
    setAddorEditVisible(false);
  };
  // 保存
  const onModalOk = () => {
    addOrEdit.current?.takeData().then((value: any) => {
      setLoading(true);
      createGroup(value).then((res) => {
        setLoading(false);
        if (res.status === 0) {
          showSuccessMessage('保存成功');
          addOrEdit.current?.reset();
          actionRef.current?.reload();
          setAddorEditVisible(false);
        }
      });
    });
  };

  const columns: ProColumns<GroupManageType>[] = [
    {
      dataIndex: 'keyword',
      align: 'center',
      hideInTable: true,
    },
    {
      title: 'code',
      align: 'center',
      dataIndex: 'code',
      hideInSearch: true,
    },
    {
      title: 'name',
      align: 'center',
      dataIndex: 'name',
      hideInSearch: true,
    },
    {
      title: 'type',
      align: 'center',
      dataIndex: 'type',
      hideInSearch: true,
    },
  ];

  return (
    <PageContainer>
      <ProTable<GroupManageType>
        tableClassName="GroupManage"
        headerTitle="分组列表"
        columns={columns}
        actionRef={actionRef}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        request={searchGroup}
        rowKey="code"
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          powers[`${CREATE_GROUP}`] && (
            <Button
              key="parent"
              type="primary"
              onClick={() => {
                setAddorEditVisible(true);
                setTitle('新建');
              }}
            >
              <PlusOutlined />
              新建
            </Button>
          ),
        ]}
      />
      <Modal
        title={title}
        loading={loading}
        addorEditVisible={addorEditVisible}
        onOk={onModalOk}
        onCancel={onModalCancel}
      >
        <AddorEdit ref={addOrEdit} />
      </Modal>
    </PageContainer>
  );
};
export default GroupManage;

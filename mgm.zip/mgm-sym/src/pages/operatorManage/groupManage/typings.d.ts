import type { ReactNode } from 'react';

interface GroupManageType {
  code?: string;
  name?: string;
  operations?: any[];
  type?: string;
}
interface AddorEditPropsType {
  addorEditVisible?: boolean;
}
interface ModalPropType {
  addorEditVisible?: boolean;
  loading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children?: ReactNode;
  title?: string;
}
interface CreateGroupDataType {
  code?: string;
  name?: string;
  type?: string;
}
interface SearchGroupDataType {
  keyword?: string;
  current?: number;
  pageSize?: number;
}
export {
  AddorEditPropsType,
  GroupManageType,
  ModalPropType,
  CreateGroupDataType,
  SearchGroupDataType,
};

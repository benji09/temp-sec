// @ts-ignore
import { request } from 'umi';

import { HOST_TYPE_POWER } from '@/utils/utils';
import { POWER_HOST } from '@/services/hosts';
import type { CreateGroupDataType, SearchGroupDataType } from './typings';

// 列表
const searchGroup = async (data: SearchGroupDataType) => {
  const { keyword } = data;
  const msg = await request('/manage/search-group', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: keyword || '',
      withOperation: false,
    },
  });
  return {
    data: msg.result || [],
    total: msg.result.length || 0,
  };
};
// 新建
const createGroup = async (data: CreateGroupDataType) => {
  return request(`/manage/create-group`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export { searchGroup, createGroup };

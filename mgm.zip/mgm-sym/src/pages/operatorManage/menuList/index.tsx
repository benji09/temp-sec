/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useRef } from 'react';
import { Row, Col, Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { showSuccessMessage } from '@/mamagement/Notification';
import { getMenuListList, setMenuListShow, setMenuList } from '@/services/api';

import SetRole from './components/setRole';
import MenuModal from './components/MenuModal';
import AddOrEditMenu from './components/addOrEditmenu';

const MenuList: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const AddOrEdit = useRef<any>();
  const [menuId, setMenuId] = useState<number | undefined>(undefined);
  const [RoleVisible, setRoleVisible] = useState<boolean>(false);
  const [addorEditVisible, setAddorEditVisible] = useState<boolean>(false);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [detailsData, setDetailsData] = useState({});
  const [title, setTitle] = useState<string>('');

  const onRoleSubmit = () => {
    setRoleVisible(false);
    setMenuId(undefined);
    actionRef.current?.reload();
  };
  const onRoleCancel = () => {
    setRoleVisible(false);
    setMenuId(undefined);
  };

  const onMenuCancel = () => {
    setAddorEditVisible(false);
    setMenuId(undefined);
    setDetailsData({});
    AddOrEdit.current?.reset();
  };
  const onMenuOk = () => {
    setBtnLoading(true);

    AddOrEdit.current?.takeData().then((value: any) => {
      if (title === '编辑') {
        value.menuId = menuId;
        setMenuList(value, 'PUT').then((res) => {
          if (res.status === 0) {
            showSuccessMessage('保存成功');
            setBtnLoading(false);
            setAddorEditVisible(false);
            setMenuId(undefined);
            setDetailsData({});
            AddOrEdit.current?.reset();
            actionRef.current?.reload();
          }
        });
      } else {
        setMenuList(value, 'POST').then((res) => {
          if (res.status === 0) {
            showSuccessMessage('保存成功');
            setBtnLoading(false);
            setAddorEditVisible(false);
            setMenuId(undefined);
            setDetailsData({});
            AddOrEdit.current?.reset();
            actionRef.current?.reload();
          }
        });
      }
    });
  };

  useEffect(() => {
    if (!addorEditVisible) {
      AddOrEdit.current?.reset();
    } else {
      AddOrEdit.current?.setData(detailsData);
    }
  }, [addorEditVisible]);

  const columns: ProColumns<APIS.menuListSons>[] = [
    {
      title: '菜单id',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: '菜单名',
      dataIndex: 'menuName',
      key: 'menuName',
    },
    {
      title: '菜单url',
      dataIndex: 'url',
      key: 'url',
    },
    {
      title: '描述',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: '操作',
      width: '250px',
      align: 'center',
      dataIndex: 'display',
      hideInSearch: true,
      render: (text, record) => [
        <Row key="text">
          <Col
            span={8}
            style={{ color: '#0486FE' }}
            key="edit"
            onClick={() => {
              setDetailsData(record);
              setAddorEditVisible(true);
              setMenuId(record.id);
              setTitle('编辑');
            }}
          >
            编辑
          </Col>
          <Col
            span={8}
            style={{ color: '#0486FE' }}
            key="cole"
            onClick={() => {
              setRoleVisible(true);
              setMenuId(record.id);
            }}
          >
            所属角色
          </Col>
          <Col
            span={8}
            style={{ color: '#0486FE' }}
            key="show"
            onClick={() => {
              setMenuListShow(record.id).then((res) => {
                if (res.status === 0) {
                  actionRef.current?.reload();
                }
              });
            }}
          >
            {text ? '隐藏' : '显示'}
          </Col>
        </Row>,
      ],
    },
  ];

  return (
    <PageContainer>
      <ProTable<APIS.menuListSons>
        tableClassName="MenuList"
        columns={columns}
        actionRef={actionRef}
        request={getMenuListList}
        search={false}
        rowKey="id"
        childrenColumnName="sons"
        indentSize={35}
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          <Button
            key="parent"
            type="primary"
            onClick={() => {
              setAddorEditVisible(true);
              setTitle('新建父节点');
            }}
          >
            <PlusOutlined />
            新建父节点
          </Button>,
          <Button
            key="chilren"
            type="primary"
            onClick={() => {
              setAddorEditVisible(true);
              setTitle('新建子节点');
            }}
          >
            <PlusOutlined />
            新建子节点
          </Button>,
        ]}
      />
      <SetRole
        RoleVisible={RoleVisible}
        menuId={menuId}
        onRoleSubmit={onRoleSubmit}
        onRoleCancel={onRoleCancel}
      />
      <MenuModal
        title={title}
        btnLoading={btnLoading}
        addorEditVisible={addorEditVisible}
        onOk={onMenuOk}
        onCancel={onMenuCancel}
      >
        <AddOrEditMenu ref={AddOrEdit} title={title} menuId={menuId} />
      </MenuModal>
    </PageContainer>
  );
};
export default MenuList;

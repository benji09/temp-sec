// @ts-ignore
import { request } from 'umi';

import { HOST_TYPE_POWER } from '@/utils/utils';
import { POWER_HOST } from '@/services/hosts';

import type { CreateOperationDataType, RelateOperationType, SearchRoleDataType } from './typings';
// 获取列表
const searchRole = async (data: SearchRoleDataType) => {
  const { keyword } = data;
  const msg = await request('/manage/search-role', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: keyword || '',
    },
  });
  return {
    data: msg.result || [],
    total: msg.result.length || 0,
  };
};
// 新增
const createOperation = async (data: CreateOperationDataType) => {
  return request(`/manage/create-role`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 获取操作列表
const searchOperationList = async () => {
  return await request('/manage/search-operation', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: '',
    },
  });
};
const searchFindRoleList = async (roleCode?: string) => {
  return await request('/manage/find-role', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { roleCode },
  });
};
const relateOperation = async (data: RelateOperationType) => {
  return await request('/manage/relate-operation', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export { searchRole, createOperation, searchOperationList, searchFindRoleList, relateOperation };

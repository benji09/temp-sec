import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { showSuccessMessage } from '@/mamagement/Notification';
import { checkPermission, SEARCH_ROLE, RELATE_OPERATION } from '@/utils/power';

import Binds from './components/Binds';
import RoleModal from './components/RoleModal';
import AddOrEdit from './components/AddOrEdit';
import { searchRole, createOperation, relateOperation } from './api';
import type { RoleManageType } from './typings.d';

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_BINDS = 2;

const permissionGroups = [SEARCH_ROLE, RELATE_OPERATION];
const RoleManage: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const AddOrEditRef = useRef<any>();
  const BindsRef = useRef<any>();
  const [loading, setLoading] = useState<boolean>(false);
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [bindsCode, setBindsCode] = useState<string | undefined>(undefined);

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_BINDS:
        return '关联操作';
    }
    return '';
  }
  const onMenuCancel = () => {
    if (modalType === 1) {
      AddOrEditRef.current?.reset();
      setLoading(false);
    }
    if (modalType === 2) {
      BindsRef.current?.reset();
      setBindsCode(undefined);
    }

    setTimeout(() => {
      setModalVisible(false);
    });
  };
  const onMenuOk = () => {
    if (modalType === 1) {
      AddOrEditRef.current?.takeData().then((value: any) => {
        setLoading(true);
        createOperation(value)
          .then((res) => {
            if (!res.message) {
              showSuccessMessage('保存成功');
              AddOrEditRef.current?.reset();
              actionRef.current?.reload();
              setModalVisible(false);
            }
          })
          .finally(() => {
            setLoading(false);
          });
      });
    }
    if (modalType === 2) {
      BindsRef.current?.takeData().then((value: any) => {
        setLoading(true);
        relateOperation(value)
          .then((res) => {
            if (!res.message) {
              showSuccessMessage('保存成功');
              BindsRef.current?.reset();
              actionRef.current?.reload();
              setBindsCode(undefined);
              setModalVisible(false);
            }
          })
          .finally(() => {
            setLoading(false);
          });
      });
    }
  };

  const columns: ProColumns<RoleManageType>[] = [
    {
      dataIndex: 'keyword',
      align: 'center',
      hideInTable: true,
    },
    {
      title: 'code',
      align: 'center',
      dataIndex: 'code',
      hideInSearch: true,
    },
    {
      title: 'name',
      align: 'center',
      dataIndex: 'name',
      hideInSearch: true,
    },
    {
      align: 'center',
      title: '操作',
      hideInSearch: true,
      render: (text, record) => [
        powers[`${RELATE_OPERATION}`] && record.unrestricted === false && (
          <Button
            key="binds"
            type="link"
            onClick={() => {
              setModalVisible(true);
              setModalType(MODAL_TYPE_BINDS);
              setBindsCode(record.code);
            }}
          >
            关联操作
          </Button>
        ),
      ],
    },
  ];

  return (
    <PageContainer>
      <ProTable<RoleManageType>
        tableClassName="operationManage"
        headerTitle="角色列表"
        columns={columns}
        actionRef={actionRef}
        expandRowByClick={true}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        request={searchRole}
        rowKey="code"
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          powers[`${SEARCH_ROLE}`] && (
            <Button
              key="parent"
              type="primary"
              onClick={() => {
                setModalVisible(true);
                setModalType(MODAL_TYPE_ADD);
              }}
            >
              <PlusOutlined />
              新建
            </Button>
          ),
        ]}
      />
      <RoleModal
        title={getModalTitle()}
        loading={loading}
        modalVisible={modalVisible}
        modalType={modalType}
        onOk={onMenuOk}
        onCancel={onMenuCancel}
      >
        {modalType === 1 && <AddOrEdit ref={AddOrEditRef} />}
        {modalType === 2 && <Binds ref={BindsRef} bindsCode={bindsCode} />}
      </RoleModal>
    </PageContainer>
  );
};
export default RoleManage;

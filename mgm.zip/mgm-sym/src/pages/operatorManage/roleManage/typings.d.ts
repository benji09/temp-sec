import type { ReactNode } from 'react';

interface OperatorsType {
  groupCode?: string;
  name?: string;
  operationCode?: string;
}
interface RoleManageType {
  code?: string;
  name?: string;
  unrestricted?: boolean;
  operators?: OperatorsType[];
}
interface GroupManageType {
  code?: string;
  name?: string;
  operations?: any[];
  type?: string;
}

interface ModalPropType {
  modalVisible?: boolean;
  loading?: boolean;
  title?: string;
  modalType?: number | undefined;
  onCancel: () => void;
  onOk: () => void;
  children?: ReactNode;
}
interface SearchRoleDataType {
  keyword?: string;
  current?: number;
  pageSize?: number;
}
interface CreateOperationDataType {
  groupCode?: string;
  name?: string;
  operationCode?: string;
}
interface OperationListType {
  groupCode?: string;
  name?: string;
  operationCode?: string;
  key?: string;
}
interface RelateOperationType {
  groupCode?: string;
  operationCode?: string;
  roleCode?: string;
  type?: string;
}
export {
  RoleManageType,
  OperatorsType,
  GroupManageType,
  ModalPropType,
  SearchRoleDataType,
  CreateOperationDataType,
  OperationListType,
  RelateOperationType,
};

import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { checkPermission, RELATE_OPERATOR } from '@/utils/power';

import RoleSet from './components/RoleSet';
import { searchOperator } from './api';
import type { RoleManageType } from './typings.d';

const permissionGroups = [RELATE_OPERATOR];
const OperatorManage: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const roleSetRef = useRef<any>();

  const [roleSetVisible, setRoleSetVisible] = useState<boolean>(false);
  const [roleSetOperatorId, setRoleSetOperatorId] = useState<number | undefined>(undefined);

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  const onCancel = () => {
    setRoleSetOperatorId(undefined);
    setRoleSetVisible(false);
  };
  const columns: ProColumns<RoleManageType>[] = [
    {
      dataIndex: 'keyword',
      align: 'center',
      hideInTable: true,
    },
    {
      title: 'operatorId',
      align: 'center',
      dataIndex: 'operatorId',
      hideInSearch: true,
    },
    {
      title: 'account',
      align: 'center',
      dataIndex: 'account',
      hideInSearch: true,
    },
    {
      title: 'name',
      align: 'center',
      dataIndex: 'name',
      hideInSearch: true,
    },
    {
      title: 'company',
      align: 'center',
      dataIndex: 'companyName',
      hideInSearch: true,
    },
    {
      title: '操作',
      align: 'center',
      hideInSearch: true,
      render: (text, record) => [
        powers[RELATE_OPERATOR] && (
          <Button
            key="binds"
            type="link"
            onClick={() => {
              setRoleSetVisible(true);
              setRoleSetOperatorId(record.operatorId);
            }}
          >
            角色设置
          </Button>
        ),
      ],
    },
  ];

  return (
    <PageContainer className="operatorManage">
      <ProTable<RoleManageType>
        headerTitle="操作员列表"
        columns={columns}
        actionRef={actionRef}
        expandRowByClick={true}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        request={searchOperator}
        rowKey="operatorId"
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => []}
      />

      <RoleSet
        ref={roleSetRef}
        roleSetVisible={roleSetVisible}
        roleSetOperatorId={roleSetOperatorId}
        onCancel={onCancel}
      />
    </PageContainer>
  );
};
export default OperatorManage;

interface OperatorsType {
  groupCode?: string;
  name?: string;
  operationCode?: string;
}
interface RolesType {
  code?: string;
  name?: string;
  operators?: OperatorsType[];
}

interface RoleManageType {
  account?: string;
  name?: string;
  operatorId?: number;
  roles?: RolesType[];
}

interface SearchOperatorDataType {
  keyword?: string;
  current?: number;
  pageSize?: number;
}
interface RoleSetPropsType {
  roleSetOperatorId?: number;
  roleSetVisible?: boolean;
  loading?: boolean;
  onCancel: () => void;
}
interface relateOperatorDataType {
  code?: string;
  operatorId?: number;
  type?: string;
}
export {
  RoleManageType,
  SearchOperatorDataType,
  RoleSetPropsType,
  RolesType,
  relateOperatorDataType,
};

// @ts-ignore
import { request } from 'umi';

import { HOST_TYPE_POWER } from '@/utils/utils';
import { POWER_HOST } from '@/services/hosts';

import type { relateOperatorDataType, SearchOperatorDataType } from './typings';
// 获取列表
const searchOperator = async (data: SearchOperatorDataType) => {
  const { keyword } = data;
  const msg = await request('/manage/search-operator', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: keyword || '',
    },
  });
  return {
    data: msg.result || [],
    total: msg.result.length || 0,
  };
};
// 查找操作员的角色 入参 用户operatorId
const listOperatorRole = async (operatorId?: number) => {
  return await request('/manage/list-operator-role', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      operatorId: operatorId || '',
    },
  });
};
// 搜索角色 入参 keyword作用根据 role code 或者 name 搜索 role
const findRole = async () => {
  return await request('/manage/search-role', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: '',
    },
  });
};
// 绑定或解绑角色 入参 角色code 用户operatorId 解绑或绑定type
const relateOperator = async (data: relateOperatorDataType) => {
  return await request('/manage/relate-operator', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export { searchOperator, listOperatorRole, findRole, relateOperator };

// @ts-ignore
import { request } from 'umi';

import { HOST_TYPE_POWER } from '@/utils/utils';
import { POWER_HOST } from '@/services/hosts';

import type { CreateOperationDataType, SearchOperationDataType } from './typings';

// 获取列表
const searchOperation = async (data: SearchOperationDataType) => {
  const { keyword } = data;
  const msg = await request('/manage/search-operation', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: keyword || '',
    },
  });
  return {
    data: msg.result || [],
    total: msg.result.length || 0,
  };
};

// 新增
const createOperation = async (data: CreateOperationDataType) => {
  return request(`/manage/create-operation`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};

// 获取分组的数据
const searchGroup = async () => {
  return await request('/manage/search-group', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      keyword: '',
    },
  });
};
export { searchOperation, createOperation, searchGroup };

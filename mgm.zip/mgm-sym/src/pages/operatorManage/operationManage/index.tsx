import React, { useState, useRef } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { showSuccessMessage } from '@/mamagement/Notification';
import { checkPermission, CREATE_OPERATION } from '@/utils/power';

import Modal from './components/Modal';
import AddOrEdit from './components/addOrEdit';
import { searchOperation, createOperation } from './api';
import type { OperationManageType } from './typings.d';

const permissionGroups = [CREATE_OPERATION];
const OperationManage: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const AddOrEditRef = useRef<any>();
  const [title, setTitle] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [addorEditVisible, setAddorEditVisible] = useState<boolean>(false);

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  const onCancel = () => {
    AddOrEditRef.current?.reset();
    setLoading(false);
    setAddorEditVisible(false);
  };
  const onOk = () => {
    AddOrEditRef.current?.takeData().then((value: any) => {
      setLoading(true);
      createOperation(value)
        .then((res) => {
          if (!res.message) {
            showSuccessMessage('保存成功');
            AddOrEditRef.current?.reset();
            actionRef.current?.reload();
            setAddorEditVisible(false);
          }
        })
        .finally(() => {
          setLoading(false);
        });
    });
  };

  const columns: ProColumns<OperationManageType>[] = [
    {
      dataIndex: 'keyword',
      align: 'center',
      hideInTable: true,
    },
    {
      title: 'groupCode',
      align: 'center',
      dataIndex: 'groupCode',
      hideInSearch: true,
    },
    {
      title: 'operationCode',
      align: 'center',
      dataIndex: 'operationCode',
      hideInSearch: true,
    },
    {
      title: 'name',
      align: 'center',
      dataIndex: 'name',
      hideInSearch: true,
    },
  ];

  return (
    <PageContainer>
      <ProTable<OperationManageType>
        tableClassName="operationManage"
        headerTitle="操作列表"
        columns={columns}
        actionRef={actionRef}
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        request={searchOperation}
        rowKey={(record) => {
          return `${record.groupCode}${record.operationCode}`;
        }}
        pagination={{
          defaultPageSize: 10,
        }}
        toolBarRender={() => [
          powers[`${CREATE_OPERATION}`] && (
            <Button
              key="parent"
              type="primary"
              onClick={() => {
                setAddorEditVisible(true);
                setTitle('新建');
              }}
            >
              <PlusOutlined />
              新建
            </Button>
          ),
        ]}
      />
      <Modal
        title={title}
        loading={loading}
        addorEditVisible={addorEditVisible}
        onOk={onOk}
        onCancel={onCancel}
      >
        <AddOrEdit ref={AddOrEditRef} />
      </Modal>
    </PageContainer>
  );
};
export default OperationManage;

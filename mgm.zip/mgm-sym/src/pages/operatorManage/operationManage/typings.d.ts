import type { ReactNode } from 'react';

interface OperationManageType {
  groupCode?: string;
  name?: string;
  operationCode?: string;
}
interface GroupManageType {
  code?: string;
  name?: string;
  operations?: any[];
  type?: string;
}

interface ModalPropType {
  addorEditVisible?: boolean;
  loading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children?: ReactNode;
  title?: string;
}
interface SearchOperationDataType {
  keyword?: string;
  current?: number;
  pageSize?: number;
}
interface CreateOperationDataType {
  groupCode?: string;
  name?: string;
  operationCode?: string;
}
export {
  OperationManageType,
  GroupManageType,
  ModalPropType,
  SearchOperationDataType,
  CreateOperationDataType,
};

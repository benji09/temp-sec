import React, { useState, useRef } from 'react';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { getRoleSetList } from '@/services/api';

import RoleList from './components/index';

type RoleSetItem = {
  mobile: string;
  name: string;
  operatorId: number;
  wechatUserId: string;
};

const RoleSet: React.FC = () => {
  const actionRef = useRef<ActionType | undefined>();
  const [visible, setVisible] = useState<boolean>(false);
  const [operatorId, setOperatorId] = useState<number | string>('');

  const columns: ProColumns<RoleSetItem>[] = [
    {
      title: 'operatorId',
      dataIndex: 'operatorId',
      hideInSearch: true,
    },
    {
      title: 'wechatUserId',
      dataIndex: 'wechatUserId',
      hideInSearch: true,
    },
    {
      title: '姓名',
      dataIndex: 'name',
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        <a
          key="config"
          onClick={() => {
            setVisible(true);
            setOperatorId(record.operatorId);
          }}
        >
          角色设置
        </a>,
      ],
    },
  ];
  return (
    <PageContainer>
      <ProTable<RoleSetItem>
        actionRef={actionRef}
        columns={columns}
        request={getRoleSetList}
        rowKey="operatorId"
        dateFormatter="string"
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{
          defaultPageSize: 10,
        }}
      />
      <RoleList
        visible={visible}
        operatorId={operatorId}
        onSubmit={() => {
          setOperatorId('');
          setVisible(false);
        }}
        onCancel={() => {
          setOperatorId('');
          setVisible(false);
        }}
      />
    </PageContainer>
  );
};
export default RoleSet;

// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type { GetRelieveDoctorListType } from './typings';

export const TIMEOUT = 30 * 1000;

// 用户列表
const getRelieveDoctorList = async (params: GetRelieveDoctorListType) => {
  const { current, pageSize, providerId, userId } = params;
  const msg = await request('/unbind/page', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: {
      providerId,
      userId,
      pageNo: current || 1,
      pageSize,
    },
  });
  return {
    data: msg.result?.doctorInfos || [],
    total: msg.result?.totalCount || 0,
  };
};
// 解绑接口
const unbindUpdate = async (id?: number[]) => {
  return await request<APIS.BaseResponse<null>>(`/unbind/update`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: id,
  });
};
export { getRelieveDoctorList, unbindUpdate };

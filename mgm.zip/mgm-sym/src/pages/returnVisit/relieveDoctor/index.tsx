import React, { useRef, useState } from 'react';
import _ from 'lodash';
import { Button, Popconfirm } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { timeStamp } from '@/utils/formatDate';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { OrderDetailsMobile } from '@/services/api';
import TableLocal from '@/components/TableLocal/TableLocal';

import { getRelieveDoctorList, unbindUpdate } from './api';
import type { ReturnVisitnListType } from './typings';

import './index.less';

const ReturnVisitnList: React.FC = () => {
  const [mobilesCache, setMobilesCache] = useState({});
  const actionRef = useRef<ActionType | undefined>();

  // 查看手机号
  const queryMobile = (record: ReturnVisitnListType) => {
    OrderDetailsMobile(record.userId)
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.id] = res.result;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };
  // 解绑事件
  const confirmUntie = (record: ReturnVisitnListType) => {
    unbindUpdate([Number(record.id)]).then((res) => {
      if (res?.status === 0) {
        showSuccessMessage('解绑成功');
        actionRef.current?.reload();
      }
    });
  };
  const columns: ProColumns[] = [
    {
      title: '医生名字',
      dataIndex: 'doctorName',
      hideInSearch: true,
    },
    {
      title: 'providerId',
      dataIndex: 'providerId',
    },
    {
      title: '用户姓名',
      dataIndex: 'userName',
      hideInSearch: true,
    },

    {
      title: 'userId',
      dataIndex: 'userId',
    },
    {
      title: '电话',
      hideInSearch: true,
      dataIndex: 'mobile',
      render: (text, record) => {
        return (
          <>
            {mobilesCache[record.id] || text}
            {mobilesCache[record.id] || (record.mobile || '').trim().length < 1 ? null : (
              <Button type="link" onClick={() => queryMobile(record)}>
                查看
              </Button>
            )}
          </>
        );
      },
    },
    {
      title: '创建时间',
      render: (_text, record) => {
        return <span>{timeStamp(record.createdTime)}</span>;
      },
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        <Popconfirm
          key={'untie'}
          title="确定是否解绑"
          onConfirm={() => {
            confirmUntie(record);
          }}
          okText="是"
          cancelText="否"
        >
          <Button type="link">解绑</Button>
        </Popconfirm>,
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="returnVisitnList"
      columns={columns}
      request={getRelieveDoctorList}
      search={false}
      rowKey="id"
      dateFormatter="string"
      pagination={true}
      actionRef={actionRef}
    />
  );
};
export default ReturnVisitnList;

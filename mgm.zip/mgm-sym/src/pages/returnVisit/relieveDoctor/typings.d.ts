interface GetRelieveDoctorListType {
  providerId?: string;
  userId?: string;
  pageSize?: number;
  current?: number;
}
interface ReturnVisitnListType {
  createdTime: string;
  doctorName: string;
  id: string;
  mobile: string;
  providerId: string;
  userId: string;
  userName: string;
}

export { GetRelieveDoctorListType, ReturnVisitnListType };

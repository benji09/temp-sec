import React, { useRef, useState } from 'react';
import _ from 'lodash';
import { Button, Popconfirm } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { timeStamp } from '@/utils/formatDate';
import { showErrorMessage } from '@/mamagement/Notification';
import { getReturnVisitnList, ReturnVisitnseeMobile } from '@/services/api';
import { checkPermission, ROUTER_VIEW, ROUTER_CONSULT } from '@/utils/power';
import TableLocal from '@/components/TableLocal/TableLocal';

import { ApplyGenderStutas, ProcessStutas } from './utils/utils';
import { consultMessageReturn } from './api';

import './index.less';

const permissionGroups = [ROUTER_VIEW, ROUTER_CONSULT];
const ReturnVisitnList: React.FC = () => {
  const [mobilesCache, setMobilesCache] = useState({});
  const actionRef = useRef<ActionType | undefined>();

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  const queryMobile = (record: APIS.ReturnVisitnItem) => {
    ReturnVisitnseeMobile(record.applyId)
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.id] = res.result;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };
  const confirmReturnVisit = (record: APIS.ReturnVisitnItem) => {
    consultMessageReturn(record.id).then((res: { status: number }) => {
      if (res.status === 0) {
        actionRef.current?.reload();
      }
    });
  };
  const columns: ProColumns<APIS.ReturnVisitnItem>[] = [
    {
      title: 'UserID',
      dataIndex: 'userId',
      hideInTable: true,
    },
    {
      title: 'ID',
      dataIndex: 'id',
      hideInSearch: true,
    },
    {
      title: '请求日期',
      hideInSearch: true,
      render: (_text, record) => {
        return <span>{timeStamp(record.receiveTime)}</span>;
      },
    },
    {
      title: '用户姓名',
      dataIndex: 'applyName',
      hideInSearch: true,
    },
    {
      title: '性别',
      hideInSearch: true,
      dataIndex: 'applyGender',
      valueEnum: ApplyGenderStutas,
    },
    {
      title: '年龄',
      dataIndex: 'age',
      hideInSearch: true,
    },
    {
      title: '电话',
      dataIndex: 'applyMobile',
      render: (text, record) => {
        return (
          <>
            {mobilesCache[record.id] || text}
            {powers[`${ROUTER_VIEW}`] &&
              (mobilesCache[record.id] || (record.applyMobile || '').trim().length < 1 ? null : (
                <Button type="link" onClick={() => queryMobile(record)}>
                  查看
                </Button>
              ))}
          </>
        );
      },
    },
    {
      title: '指定医生',
      dataIndex: 'receiveName',
      hideInSearch: true,
    },
    {
      title: '问题描述',
      width: 300,
      hideInSearch: true,
      render: (_text, record) => {
        return <span>{record.message}</span>;
      },
    },
    {
      title: '回访状态',
      hideInSearch: true,
      dataIndex: 'process',
      valueEnum: ProcessStutas,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => {
        return (
          powers[`${ROUTER_CONSULT}`] && (
            <Popconfirm
              disabled={record.process}
              key={'retry'}
              icon=""
              title={'是否确认已回访'}
              onConfirm={() => {
                confirmReturnVisit(record);
              }}
              okText="确认"
              cancelText="取消"
            >
              <Button disabled={record.process} type="link">
                标记为已回访
              </Button>
            </Popconfirm>
          )
        );
      },
    },
  ];

  return (
    <TableLocal
      tableClassName="returnVisitnList"
      columns={columns}
      request={getReturnVisitnList}
      actionRef={actionRef}
      expandable={{
        expandedRowRender: (record: any) => <p style={{ margin: 0 }}>{record.message}</p>,
      }}
      postData={(data: any) => {
        return data;
      }}
      search={false}
      rowKey="id"
      dateFormatter="string"
      pagination={true}
    />
  );
};
export default ReturnVisitnList;

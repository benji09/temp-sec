// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

export const TIMEOUT = 30 * 1000;

// 解绑接口
const consultMessageReturn = async (messageId?: number | string) => {
  return await request<APIS.BaseResponse<null>>(`/consult/consult-message-return`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { messageId },
  });
};
export { consultMessageReturn };

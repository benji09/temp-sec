// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import { checkIsNumberForSearch } from '@/utils/utils';
import { getRequest, getUpLoadRequest, postRequest } from '@/services/api';

import type { CouponNoteProvideType, sendDetailsTypes } from './typings';

export const TIMEOUT = 30 * 1000;

// 医生账号管理列表
const couponNoteProvideList = async (params: APIS.getProviderListType) => {
  const { current, pageSize, TimeDate, orderNo, mobile, msgType } = params;
  const checkorderNoResult = checkIsNumberForSearch(orderNo, '订单号');
  if (checkorderNoResult !== null) return checkorderNoResult;
  const checkmobileResult = checkIsNumberForSearch(mobile, '手机号');
  if (checkmobileResult !== null) return checkmobileResult;

  const startTime =
    TimeDate && TimeDate.length === 2 ? dayjs(`${TimeDate[0]} 00:00:00`).valueOf() : undefined;
  const endTime =
    TimeDate && TimeDate.length === 2 ? dayjs(`${TimeDate[1]} 23:59:59`).valueOf() : undefined;
  const msg = (await getRequest('/cain/card/msg/page', {
    msgType,
    orderNo,
    mobile,
    startTime,
    endTime,
    pageNo: current || 1,
    pageSize,
  })) as unknown as APIS.BaseResponse<CouponNoteProvideType>;
  return {
    data: (msg?.result && msg?.result.gainCardMsgInfos) || [],
    total: (msg?.result && msg?.result.totalCount) || 0,
  };
};

const bulkImportExcel = async (options: any) => {
  return await request('/cain/card/msg/excel', {
    method: 'POST',
    body: options,
    timeout: TIMEOUT,
  });
};
const CodeDownload = async (batchNo: string) => {
  return (await getUpLoadRequest(
    '/gen/activation/code/download',
    { batchNo },
    'blob',
  )) as unknown as CouponNoteProvideType;
};
const cainCardMsgAdd = async (data: sendDetailsTypes) => {
  return (await postRequest('/cain/card/msg/add', data)) as unknown as APIS.BaseResponse<any>;
};
const cainCardMsgDetail = async (data: { id: string }) => {
  return (await getRequest('/cain/card/msg/detail', data)) as unknown as APIS.BaseResponse<any>;
};
const cainCardMsgResend = async (data: { id: number }) => {
  return (await postRequest(
    '/cain/card/msg/resend',
    {},
    data,
  )) as unknown as APIS.BaseResponse<any>;
};
const cainCardMsgConfig = async () => {
  return (await getRequest('/cain/card/msg/config')) as unknown as APIS.BaseResponse<any>;
};
export {
  couponNoteProvideList,
  CodeDownload,
  bulkImportExcel,
  cainCardMsgAdd,
  cainCardMsgDetail,
  cainCardMsgResend,
  cainCardMsgConfig,
};

import React, { useState, useRef } from 'react';
import ProTable from '@ant-design/pro-table';
import { Button, DatePicker, Popconfirm } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import { upLoadExcel } from '@/utils/uploadOrDownload';
import { showSuccessMessage } from '@/mamagement/Notification';

import {
  couponNoteProvideList,
  cainCardMsgAdd,
  cainCardMsgDetail,
  cainCardMsgResend,
  bulkImportExcel,
} from './api';
import type { GainCardMsgInfosType, sendDetailsTypes } from './typings.d';
import Modal from './components/modal';
import CreateOrDetails from './components/createOrDetails';
import GuideTable from './components/guideTable';
import { sendStatusEnum, msgTypeEnum } from './utils/utils';

const { RangePicker } = DatePicker;

const MODAL_TYPE_ADD = 1;
const MODAL_TYPE_DETAIL = 2;
const MODAL_TYPE_EXCEL = 3;

const CouponNoteProvide: React.ReactNode = () => {
  const CreateOrDetailsRef = useRef<any>();
  const GuideTableRef = useRef<any>();
  const actionRef = useRef<ActionType | undefined>();
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [sendDetails, setSendDetails] = useState<sendDetailsTypes>({});
  const [xlsxFile, setXlsxFile] = useState<sendDetailsTypes>({});
  const [bulkImport] = useState('');

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
      case MODAL_TYPE_DETAIL:
        return '详情';
      case MODAL_TYPE_EXCEL:
        return '导入表格';
    }
    return '';
  }

  function onCancel() {
    if (modalType === 1 || modalType === 2) {
      CreateOrDetailsRef.current?.reset();
    }
    if (modalType === 3) {
      GuideTableRef.current?.reset();
    }
    setVisible(false);
    setTimeout(() => {
      setModalType(undefined);
    });
  }
  function onCancelSave() {
    setVisible(false);
  }
  function onOk() {
    if (modalType === 1) {
      CreateOrDetailsRef.current?.takeData().then((res: any) => {
        setSendDetails(res);
        setVisible(true);
      });
    } else if (modalType === 3) {
      GuideTableRef.current?.takeData().then((res: any) => {
        setSendDetails(res);
        setVisible(true);
      });
    }
  }
  function onSaveData() {
    setBtnLoading(true);
    if (modalType === 1) {
      cainCardMsgAdd(sendDetails)
        .then((res) => {
          if (res.status === 0) {
            CreateOrDetailsRef.current?.reset();
            actionRef.current?.reload();
            setTimeout(() => {
              setModalType(undefined);
            });
          }
        })
        .finally(() => {
          setVisible(false);
          setBtnLoading(false);
        });
    } else if (modalType === 3) {
      bulkImportExcel(xlsxFile)
        .then((res) => {
          if (res.status === 0) {
            GuideTableRef.current?.reset();
            actionRef.current?.reload();
            setTimeout(() => {
              setModalType(undefined);
            });
          }
        })
        .finally(() => {
          setVisible(false);
          setBtnLoading(false);
        });
    }
  }
  function disabledDate(current: any) {
    return current && current > new Date();
  }
  // 重发信息
  function retryMessage(record: GainCardMsgInfosType) {
    cainCardMsgResend({ id: Number(record.id) }).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('发送成功');
        actionRef.current?.reload();
      }
    });
  }
  function detailClick(record: GainCardMsgInfosType) {
    setModalType(MODAL_TYPE_DETAIL);
    cainCardMsgDetail({ id: record.id }).then((res) => {
      if (res.status === 0) {
        CreateOrDetailsRef.current?.setData(res.result);
      }
    });
  }
  const columns: ProColumns<GainCardMsgInfosType>[] = [
    {
      title: '序号',
      renderText: (_text, record, index) => index + 1,
      hideInSearch: true,
    },
    {
      title: '订单号',
      dataIndex: 'orderNo',
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
      hideInTable: true,
    },
    {
      title: '用户手机号',
      dataIndex: 'mobile',
      hideInSearch: true,
    },
    {
      title: '消息类型',
      dataIndex: 'msgType',
      valueEnum: msgTypeEnum,
    },
    {
      title: '批次号',
      dataIndex: 'batchNo',
      hideInSearch: true,
    },
    {
      title: '创建时间',
      dataIndex: 'TimeDate',
      valueType: 'dateRange',
      hideInTable: true,
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
    },
    {
      title: '创建日期',
      dataIndex: 'createdAt',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '发送状态',
      dataIndex: 'sendStatus',
      hideInSearch: true,
      valueEnum: sendStatusEnum,
    },
    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (_text, record: GainCardMsgInfosType) => [
        <Button key={'detail'} onClick={() => detailClick(record)} type="link">
          详情
        </Button>,
        <Popconfirm
          key={'retry'}
          icon=""
          title={
            <div className="popconfirmTitle">
              <span>是否确认重发短信？</span>
              <span>(订单号：{record.orderNo})</span>
            </div>
          }
          onConfirm={() => {
            retryMessage(record);
          }}
          okText="确认"
          cancelText="取消"
        >
          <Button type="link">重发</Button>
        </Popconfirm>,
      ],
    },
  ];

  function upLoadExcelChange(e: any) {
    upLoadExcel(e).then((res: any) => {
      const xlsxData = res?.resultJson[0] || [];
      const repetitionId: number[] = [];
      const listId =
        xlsxData &&
        xlsxData.map((item: any, index: number) => {
          if (
            Object.keys(item).indexOf('关联订单号') < 0 ||
            Object.keys(item).indexOf('流水号') < 0 ||
            Object.keys(item).indexOf('消息类型') < 0 ||
            Object.keys(item).indexOf('渠道') < 0 ||
            Object.keys(item).indexOf('用户手机号') < 0 ||
            Object.keys(item).indexOf('销售日期') < 0
          ) {
            repetitionId.push(index);
          }
          return `${item.关联订单号}${item.流水号}`;
        });
      listId?.forEach((item: any, index: number) => {
        if (listId.indexOf(item) !== index && repetitionId.indexOf(index) === -1) {
          repetitionId.push(index);
        }
      });
      setModalType(MODAL_TYPE_EXCEL);
      setXlsxFile(res.params);
      GuideTableRef.current?.setData({ repetitionId, xlsxData });
    });
  }
  return (
    <PageContainer>
      <ProTable<GainCardMsgInfosType>
        columns={columns}
        request={couponNoteProvideList}
        rowKey="id"
        dateFormatter="string"
        search={{
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
        pagination={{ defaultPageSize: 10 }}
        toolBarRender={() => [
          <Button key="primary" type="primary">
            <a href="/downTemplate/领用券短信发放导入模板.xlsx" download target="_blank">
              下载模板
            </a>
          </Button>,
          <Button className="CouponNoteProvideUpload" key="primary" type="primary">
            <input
              value={bulkImport}
              accept={'.xlsx'}
              type="file"
              onChange={(e) => upLoadExcelChange(e)}
            />
            批量导入
          </Button>,
          <Button
            key="primary"
            type="primary"
            onClick={() => {
              setModalType(MODAL_TYPE_ADD);
            }}
          >
            <PlusOutlined />
            新增
          </Button>,
        ]}
        actionRef={actionRef}
      />
      <Modal
        sendDetails={sendDetails}
        title={getModalTitle()}
        modalType={modalType}
        onCancel={onCancel}
        onCancelSave={onCancelSave}
        onOk={onOk}
        onSaveData={onSaveData}
        ModalVisible={!!modalType}
        btnLoading={btnLoading}
        visible={visible}
      >
        {(modalType === 1 || modalType === 2) && (
          <CreateOrDetails modalType={modalType} ref={CreateOrDetailsRef} />
        )}
        {modalType === 3 && <GuideTable ref={GuideTableRef} />}
      </Modal>
    </PageContainer>
  );
};
export default CouponNoteProvide;

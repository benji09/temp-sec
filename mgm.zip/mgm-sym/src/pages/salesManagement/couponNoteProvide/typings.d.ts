import type { ReactNode } from 'react';

interface GainCardMsgInfosType {
  createdAt: string;
  id: string;
  mobile: string;
  msgType: number;
  orderNo: string;
  sendStatus: number;
  transNo: string;
}
interface CouponNoteProvideType {
  gainCardMsgInfos: GainCardMsgInfosType[];
  totalCount: number;
  totalPage: number;
}
interface sendDetailsTypes {
  channel?: string;
  mobile?: string;
  msgType?: number;
  orderNo?: string;
  saleDate?: string;
  transNo?: string;
  // skuNo?: number;
}
interface ModalPropType {
  modalType?: number;
  sendDetails: sendDetailsTypes;
  title?: string | undefined;
  ModalVisible?: boolean;
  btnLoading?: boolean;
  visible?: boolean;
  onCancel: () => void;
  onCancelSave: () => void;
  onOk: () => void;
  onSaveData: () => void;
  children?: ReactNode;
}

interface PropsType {
  modalType?: number;
}
interface cardMsgConfigType {
  code: number;
  msg: string;
  skuName: string;
}

type CardDetail = {
  cardSecret?: string;
  createdAt?: string;
  id?: string;
  logInfos?: {
    dateTime?: string;
    operation?: string;
    operator?: string;
  }[];
  mobile?: string;
  msgType?: number;
  orderNo?: string;
  saleDate?: string;
  sendStatus?: number;
  transNo?: string;
  batchNo?: string;
  channel?: string;
};
export {
  GainCardMsgInfosType,
  CouponNoteProvideType,
  ModalPropType,
  PropsType,
  sendDetailsTypes,
  CardDetail,
  cardMsgConfigType,
};

export function getCardNameByCardType(type: number | undefined): string {
  if (type === undefined) return '';
  switch (type) {
    case 0:
      return '身份证';
    case 1:
      return '护照';
    case 2:
      return '军官证';
    case 3:
      return '驾照';
    case 4:
      return '出生证明';
    case 5:
      return '户口薄';
    case 6:
      return '港澳台胞证';
    case 8:
      return '其他';
    default:
      return '';
  }
}

export function getActivationNameByType(type: number | undefined): string {
  if (type === undefined) return '';
  if (type === 0) return '个人版';
  if (type === 1) return '家庭版';
  return '';
}

export function getSalesNameByType(type: number | undefined): string {
  if (type === undefined) return '';
  if (type === 0) return '勾选版';
  if (type === 1) return '单售版';
  return '';
}

export const getOrderStatusType = {
  1: '已创建',
  2: '已支付',
  3: '配送中',
  4: '妥投',
  6: '取消',
  7: '退款',
  8: '药店配货中',
};
export const rightLockState = {
  0: {
    text: '无',
  },
  1: {
    text: '系统锁定',
  },
  5: {
    text: '人工锁定',
  },

  10: {
    text: '永久锁定',
  },
};
export function rightState(type: number | undefined): string {
  if (type === undefined) return '';
  if (type === 0) return '无';
  if (type === 1) return '系统锁定';
  if (type === 5) return '人工锁定';
  if (type === 10) return '永久锁定';
  return '';
}
export const PrescriptionsFlagStatus = {
  0: {
    text: '-',
  },
  1: {
    text: 'PASS过审',
  },
  2: {
    text: '时间段过审',
  },
  3: {
    text: '手动签发',
  },
  4: {
    text: '商城自动签发',
  },
  5: {
    text: '商城手动签发',
  },
};
export const ThirdBusinessStatus = {
  1: {
    text: '叮当购药',
  },
  2: {
    text: '中药',
  },
  3: {
    text: '小药药购药',
  },
  4: {
    text: '自主购药',
  },
  5: {
    text: '新药无忧问诊开药',
  },
  6: {
    text: '老药无忧仓',
  },
};
export const nameActivityStatus = {};

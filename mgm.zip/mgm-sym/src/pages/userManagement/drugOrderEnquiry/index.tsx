/* eslint-disable react-hooks/exhaustive-deps */

import React, { useEffect, useRef, useState } from 'react';
import { Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import { QueryFilter, ProFormText, ProFormSelect } from '@ant-design/pro-form';

import { formatTime, getSafeMoney } from '@/utils/utils';
import {
  getDdOrderEnquiry,
  getXyyOrderEnquiry,
  getBztOrderEnquiry,
  getMallOrderEnquiry,
} from '@/services/api';
import { PrescriptionsFlagStatus, ThirdBusinessStatus } from '../util';
import type { SearchParams } from './typing';

import Details from './components/details';
import SellMode from './components/sellMode';

import './index.less';

const ChineseMedicalSKU: React.FC = () => {
  const ORDER_GROUP_INQUIRY = 'inquiry';
  const ORDER_GROUP_MALL = 'mall';

  const DEFAULT_PAGE_SIZE = 5;
  const DEFAULT_MALL_PAGE_SIZE = 10;

  const [search, setSearch] = useState<SearchParams>({});
  const [title, setTitle] = useState<number | undefined>(undefined);
  const [SellVisible, setSellVisible] = useState<boolean>(false);
  const [orderId, setOrderId] = useState<string | undefined>(undefined);

  const [ddOrderTotal, setDdOrderTotal] = useState<number>(0);
  const [xyyTotal, setXyyTotal] = useState<number>(0);
  const [bztTotal, setBztTotal] = useState<number>(0);
  const [mallTotal, setMallTotal] = useState<number>(0);
  const [ddOrderData, setDdOrderData] = useState([]);
  const [xyyData, setXyyData] = useState([]);
  const [bztData, setBztData] = useState([]);
  const [mallData, setMallData] = useState([]);
  const [group, setGroup] = useState<string | undefined>(ORDER_GROUP_INQUIRY);
  const [ddOrderCurrent, setDdOrderCurrent] = useState<number | undefined>(1);
  const [xyyOrderCurrent, setXyyOrderCurrent] = useState<number | undefined>(1);
  const [bztOrderCurrent, setBztOrderCurrent] = useState<number | undefined>(1);
  const [mallOrderCurrent, setMallOrderCurrent] = useState<number | undefined>(1);
  const [mallPageSize, setMallPageSize] = useState<number>(DEFAULT_MALL_PAGE_SIZE);

  const DetailsRef = useRef<any>();

  const ORDER_TYPE_DD = 1;
  const ORDER_TYPE_BZT = 2;
  const ORDER_TYPE_XYY = 3;
  const ORDER_TYPE_MALL = 4;
  const ORDER_TYPE_WORKMALL = 5;

  const ORDER_GROUP = {
    inquiry: {
      text: '问诊购药订单',
    },
    mall: {
      text: '商城购药订单',
    },
  };

  // 弹框标题
  function getOrderType(name?: number) {
    if (name === undefined) return '';
    switch (name) {
      case ORDER_TYPE_DD:
        return '叮当订单';
      case ORDER_TYPE_XYY:
        return '小药药订单';
      case ORDER_TYPE_BZT:
        return '宝中堂订单';
      case ORDER_TYPE_MALL:
        return ORDER_GROUP[ORDER_GROUP_MALL].text;
      case ORDER_TYPE_WORKMALL:
        return ORDER_GROUP[ORDER_GROUP_MALL].text;
      default:
        return '';
    }
  }

  const onCancel = () => {
    setOrderId(undefined);
    setTimeout(() => {
      setSellVisible(false);
    }, 0);
  };

  const searchFilter = (values: {
    userId?: string;
    mobile?: string;
    orderNo?: string;
    orderGroup?: string;
    deliveryNo?: string;
  }) => {
    const { orderGroup, ...rest } = values;
    if (orderGroup === ORDER_GROUP_INQUIRY) {
      setDdOrderCurrent(1);
      setXyyOrderCurrent(1);
      setBztOrderCurrent(1);
    } else if (orderGroup === ORDER_GROUP_MALL) {
      setMallOrderCurrent(1);
    }
    setGroup(orderGroup);
    setSearch(rest);
  };

  const ddOrderEnquiry = (searchData: SearchParams) => {
    getDdOrderEnquiry(searchData).then(async (res) => {
      if (res?.status === 0) {
        setDdOrderData(res.result.data);
        setDdOrderTotal(res?.result?.total);
      }
    });
  };
  const xyyOrderEnquiry = (searchData: SearchParams) => {
    getXyyOrderEnquiry(searchData).then(async (res) => {
      if (res?.status === 0) {
        setXyyData(res.result.data);
        setXyyTotal(res.result.total);
      }
    });
  };
  const bztOrderEnquiry = (searchData: SearchParams) => {
    getBztOrderEnquiry(searchData).then(async (res) => {
      if (res?.status === 0) {
        setBztData(res.result.data);
        setBztTotal(res.result.total);
      }
    });
  };

  const mallOrderEnquiry = (searchData: SearchParams) => {
    getMallOrderEnquiry(searchData).then(async (res) => {
      if (res?.status === 0) {
        setMallData(res.result.data);
        setMallTotal(res.result.total);
      } else {
        setMallData([]);
        setMallTotal(0);
      }
    });
  };

  const getPageInfo = (page: number = 1, pageSize: number = DEFAULT_PAGE_SIZE) => {
    return { page, pageSize };
  };
  useEffect(() => {
    const tempGroup = group ?? '';
    const queryParams = { ...search, ...getPageInfo() };

    if (tempGroup === ORDER_GROUP_INQUIRY) {
      ddOrderEnquiry(queryParams);
      xyyOrderEnquiry(queryParams);
      bztOrderEnquiry(queryParams);
    } else if (tempGroup === ORDER_GROUP_MALL) {
      mallOrderEnquiry({ ...search, ...getPageInfo(1, mallPageSize) });
    }
  }, [search]);

  useEffect(() => {
    if (group !== ORDER_GROUP_INQUIRY) return;
    ddOrderEnquiry({ ...search, ...getPageInfo(ddOrderCurrent) });
  }, [ddOrderCurrent]);
  useEffect(() => {
    if (group !== ORDER_GROUP_INQUIRY) return;
    xyyOrderEnquiry({ ...search, ...getPageInfo(xyyOrderCurrent) });
  }, [xyyOrderCurrent]);
  useEffect(() => {
    if (group !== ORDER_GROUP_INQUIRY) return;
    bztOrderEnquiry({ ...search, ...getPageInfo(bztOrderCurrent) });
  }, [bztOrderCurrent]);
  useEffect(() => {
    if (group !== ORDER_GROUP_MALL) return;
    mallOrderEnquiry({ ...search, ...getPageInfo(mallOrderCurrent, mallPageSize) });
  }, [mallOrderCurrent]);

  const columnsItem = (name: number) => {
    return [
      {
        title: 'UserID',
        dataIndex: 'userId',
      },
      {
        title: '手机号',
        dataIndex: 'mobile',
      },
      {
        title: '用户昵称',
        dataIndex: 'nickname',
      },
      {
        title: '问诊单号',
        dataIndex: 'consultOrderId',
      },
      {
        title: '开药时间',
        dataIndex: 'openMedicineTime',
        renderText: (text: number) => formatTime(text),
      },
      {
        title: '支付时间',
        dataIndex: 'payTime',
        renderText: (text: number) => formatTime(text),
      },
      {
        title: '订单号',
        dataIndex: 'orderNo',
      },
      {
        title: '订单状态',
        dataIndex: 'orderStatus',
      },
      {
        title: '订单来源',
        dataIndex: 'thirdBusiness',
        valueEnum: ThirdBusinessStatus,
        hideInTable: name === ORDER_TYPE_MALL ? false : true,
      },
      {
        title: '药无忧标志',
        dataIndex: 'medicineFlag',
        renderText: (text?: boolean | null) =>
          typeof text === 'boolean' ? (text ? '已使用' : '未使用') : undefined,
        hideInSearch: true,
      },
      {
        title: '优惠金额',
        dataIndex: 'discountAmount',
        renderText: (text: any) => getSafeMoney(text / 100),
        hideInSearch: true,
      },
      {
        title: '支付金额',
        dataIndex: 'payMoney',
        renderText: (text: any) => getSafeMoney(text / 100),
        hideInSearch: true,
      },
      // 审方标识
      {
        title: '审方标识',
        dataIndex: 'prescriptionsFlag',
        valueEnum: PrescriptionsFlagStatus,
        hideInSearch: true,
      },
      {
        title: '操作',
        valueType: 'option',
        render: (text: any, record: any) => [
          <Button
            key="details"
            type="link"
            onClick={() => {
              setOrderId(record.orderId);
              setTitle(record.thirdBusiness);
              setSellVisible(true);
            }}
          >
            详情
          </Button>,
        ],
      },
    ];
  };
  const table = (
    list: any[],
    current: number | undefined,
    total: number,
    name: number,
    pageSize: number = DEFAULT_PAGE_SIZE,
  ) => {
    const paginationParams = {
      showSizeChanger: false,
      pageSize,
      total,
      current,
    };
    return (
      <ProTable
        key={name}
        className="Table"
        columns={columnsItem(name)}
        dataSource={list}
        rowKey="orderId"
        pagination={paginationParams}
        onChange={(pagination) => {
          const curr = pagination.current;
          if (name === ORDER_TYPE_DD) {
            setDdOrderCurrent(curr);
          } else if (name === ORDER_TYPE_XYY) {
            setXyyOrderCurrent(curr);
          } else if (name === ORDER_TYPE_BZT) {
            setBztOrderCurrent(curr);
          } else if (name === ORDER_TYPE_MALL) {
            setMallPageSize(pagination.pageSize ?? DEFAULT_MALL_PAGE_SIZE);
            setMallOrderCurrent(curr);
          }
        }}
        options={false}
        search={false}
        headerTitle={getOrderType(name)}
      />
    );
  };
  return (
    <PageContainer className="drugOrderEnquiry">
      <QueryFilter
        onFinish={async (values) => {
          searchFilter(values);
        }}
        onReset={() => {
          setSearch({});
        }}
        labelAlign="right"
        labelWidth={120}
        className="searchFilter"
        optionRender={(searchConfig, formProps, dom) => [...dom.reverse()]}
      >
        <ProFormText name="userId" label="UserID" />
        <ProFormText name="mobile" label="手机号" />
        <ProFormText name="orderNo" label="订单号" />
        <ProFormSelect
          name="orderGroup"
          label="订单类型"
          valueEnum={ORDER_GROUP}
          initialValue={group}
        />
        <ProFormText name="deliveryNo" label="物流单号" />
      </QueryFilter>

      {group === ORDER_GROUP_INQUIRY && (
        <>
          {/* 叮当订单 */}
          {table(ddOrderData, ddOrderCurrent, ddOrderTotal, ORDER_TYPE_DD)}
          {/* 小药药订单 */}
          {table(xyyData, xyyOrderCurrent, xyyTotal, ORDER_TYPE_XYY)}
          {/* 宝中堂订单 */}
          {table(bztData, bztOrderCurrent, bztTotal, ORDER_TYPE_BZT)}
        </>
      )}

      {group === ORDER_GROUP_MALL && (
        <>
          {/* 我要购药订单 */}
          {table(mallData, mallOrderCurrent, mallTotal, ORDER_TYPE_MALL, DEFAULT_MALL_PAGE_SIZE)}
        </>
      )}

      <SellMode title={getOrderType(title)} SellVisible={SellVisible} onCancel={onCancel}>
        <Details ref={DetailsRef} orderId={orderId} title={title} />
      </SellMode>
    </PageContainer>
  );
};
export default ChineseMedicalSKU;

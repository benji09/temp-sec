/*
 * @Author: Walker Denial
 * @Date: 2022-01-04 17:50:20
 * @LastEditors: zyx
 * @LastEditTime: 2022-03-23 13:02:08
 * @Desc:
 */
import type { ReactNode } from 'react';

type SearchParams = {
  userId?: string | undefined;
  mobile?: string | undefined;
  orderNo?: string;
  deliveryNo?: string;
  page?: number;
  pageSize?: number;
};

type DetailsPropType = {
  orderId?: string;
  title?: number;
};
type MedicineItemsType = {
  itemName?: string;
  weight?: string;
};
type WtMedicineInfosType = {
  medicineName: string;
  medicinePicUrl: string;
  medicinePrice: number;
  number: number;
  spec: string;
  useIntro: string;
};
type LogisticsInfosType = {
  context: string;
  ftime: string;
};
type cnMedicineDetail = {
  medicineItems?: MedicineItemsType[];
  processType?: string;
  useIntro?: string;
  useSuggest?: string;
  name: string;
};
type DetailType = {
  cnMedicineDetail?: cnMedicineDetail;
  consultOrderId?: number;
  consultTime?: number;
  createdTime?: number;
  deliverPay?: number;
  discountAmount?: number;
  logisticsCompany?: string;
  logisticsInfos?: LogisticsInfosType[];
  logisticsNo?: string;
  nickname?: string;
  orderNo?: string;
  orderStatus?: string;
  payMoney?: number;
  payTime?: number;
  rights?: boolean;
  totalPrice?: number;
  wtMedicineInfos?: WtMedicineInfosType[];
  medicineName?: string;
  medicinePicUrl?: string;
  medicinePrice?: number;
  number?: number;
  spec?: string;
  useIntro?: string;
  prescriptionBase64?: string;
  prescriptionInvalid?: boolean;
  prescription?: PrescriptionType[];
  orderVersion?: number;
  prescriptionNewUrl?: string;
};
type PrescriptionType = {
  prescriptionUrl?: string;
  status?: number;
  signId?: string;
};
type SelModalPropType = {
  title: string | undefined;
  SellVisible?: boolean;
  onCancel: () => void;
  children?: ReactNode;
};

export {
  SearchParams,
  DetailsPropType,
  MedicineItemsType,
  WtMedicineInfosType,
  LogisticsInfosType,
  cnMedicineDetail,
  DetailType,
  SelModalPropType,
  PrescriptionType,
};

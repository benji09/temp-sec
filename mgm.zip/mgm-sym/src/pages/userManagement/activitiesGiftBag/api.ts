// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import { POWER_HOST } from '@/services/hosts';
import { checkIsNumberForSearch, HOST_TYPE_POWER } from '@/utils/utils';

const TIMEOUT = 30 * 1000;
let searchData = {};

// 列表
const activitiesGiftBagList = async (params: any) => {
  const { current, receiveTimes, pageSize, userId, ...data } = params;
  const startTime =
    receiveTimes && receiveTimes.length === 2
      ? dayjs(`${dayjs(receiveTimes[0]).format('YYYY-MM-DD')} 00:00:00`).valueOf()
      : undefined;
  const endTime =
    receiveTimes && receiveTimes.length === 2
      ? dayjs(`${dayjs(receiveTimes[1]).format('YYYY-MM-DD')} 23:59:59`).valueOf()
      : undefined;
  const checkUserIdResult = checkIsNumberForSearch(userId, '手机号');
  if (checkUserIdResult !== null) return checkUserIdResult;

  searchData = {
    ...data,
    userId,
    startTime,
    endTime,
  };

  const msg = await request('/self-check/list-active-log', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: {
      ...data,
      // activeType: null,
      startTime,
      userId,
      endTime,
      currentPage: current || 1,
      pageSize,
    },
  });
  return {
    data: (msg?.result && msg?.result.list) || [],
    total: (msg?.result && msg?.result.total) || 0,
  };
};
const importActiveLog = async (options: any) => {
  return await request('/self-check/import-active-log', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    body: options,
    timeout: TIMEOUT,
  });
};
// 导出接口
const exportActiveLog = async () => {
  return await request('/self-check/export-active-log', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: searchData,
    responseType: 'blob',
  });
};
const getActiveDetail = async (id: string) => {
  return await request('/self-check/get-active-detail', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { id },
  });
};
export { activitiesGiftBagList, getActiveDetail, importActiveLog, exportActiveLog };

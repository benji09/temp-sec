import React, { useEffect, useRef, useState } from 'react';
import { Button, DatePicker } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { listDictionary } from '@/services/api';
import { upLoadExcel } from '@/utils/uploadOrDownload';
import TableLocal from '@/components/TableLocal/TableLocal';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import Modal from './components/Modal';
import Details from './components/Details';
import BulkImport from './components/BulkImport';
import { activitiesGiftBagList, exportActiveLog, getActiveDetail, importActiveLog } from './api';

import './index.less';
import type { ActiveTypeListType } from './typings';
import { ClickDownXlsx } from '@/utils/downXlsx';

const { RangePicker } = DatePicker;

const MODAL_TYPE_DETAIL = 1; // 详情
const MODAL_TYPE_IMPORT = 2; // 批量导入

const ActivitiesGiftBag: React.ReactNode = () => {
  const actionRef = useRef<ActionType | undefined>();
  const detailsRef = useRef<any>();
  const bulkImportRef = useRef<any>();

  const [loading, setLoading] = useState<boolean>(false);

  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);

  const [xlsxFile, setXlsxFile] = useState<any>({});
  const [bulkImportValue] = useState('');

  const [activeTypeList, setActiveTypeList] = useState<ActiveTypeListType>({});

  useEffect(() => {
    listDictionary().then((res) => {
      if (res.status === 0 && !!res.result) {
        const activeType = {};
        res.result.dictionary?.ACTIVE_TYPE.map((item: APIS.DictionaryType) => {
          activeType[item.key] = item.value;
        });
        setActiveTypeList(activeType || {});
      }
    });
  }, []);

  // 时间禁用
  const disabledDate = (current: any) => {
    return current && current > new Date();
  };

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_DETAIL:
        return '领取详情';
      case MODAL_TYPE_IMPORT:
        return '导入表格';
    }
    return '';
  }

  // 弹框关闭
  function onCancel() {
    setBtnLoading(false);
    setVisible(false);
    setXlsxFile({});
    setTimeout(() => {
      setModalType(undefined);
    }, 0);
  }
  // 弹框确定 开启二次确认
  function onOk() {
    setVisible(true);
  }

  // 二次确认
  function onSaveData() {
    setBtnLoading(true);
    importActiveLog(xlsxFile).then((res) => {
      setBtnLoading(false);
      setVisible(false);
      setXlsxFile({});
      if (res.status === 0) {
        setModalType(undefined);
        actionRef.current?.reload();
      }
    });
  }

  // 关闭二次确认的弹框
  function onCancelSave() {
    setBtnLoading(false);
    setVisible(false);
  }
  // 批量导出
  function batchExport() {
    setLoading(true);

    exportActiveLog().then((res) => {
      const { size } = res;
      if (size <= 500) {
        showErrorMessage('数据流异常，无法正常下载');
        return;
      }
      setLoading(false);
      showSuccessMessage('导出成功');

      ClickDownXlsx(res, '礼包订单');
    });
  }

  // 批量导入
  function bulkImport(e: any) {
    upLoadExcel(e).then((res: any) => {
      const xlsxData = res?.resultJson[0] || [];
      const repetitionId: number[] = [];
      setModalType(MODAL_TYPE_IMPORT);
      setXlsxFile(res.params);
      bulkImportRef.current?.setData({ repetitionId, xlsxData });
    });
  }

  // 点击详情按钮
  function detailsClick(record: any) {
    setModalType(MODAL_TYPE_DETAIL);

    getActiveDetail(record.id).then((res) => {
      if (res.status === 0 && !!res.result) {
        detailsRef.current?.setData(res.result);
      }
    });
  }
  const columns: ProColumns[] = [
    {
      title: 'userID',
      dataIndex: 'userId',
    },
    {
      title: '用户昵称',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: '活动名称',
      dataIndex: 'activeType',
      valueType: 'select',
      initialValue: '1002',
      valueEnum: activeTypeList,
    },
    {
      title: '商品',
      dataIndex: 'packageContext',
      hideInSearch: true,
    },
    {
      title: '领取时间',
      dataIndex: 'receiveTime',
      hideInSearch: true,
    },
    {
      title: '领取时间',
      dataIndex: 'receiveTimes',
      renderFormItem: () => {
        return <RangePicker disabledDate={disabledDate} placeholder={['开始日期', '结束日期']} />;
      },
      hideInTable: true,
    },
    {
      title: '订单编号',
      dataIndex: 'orderNo',
    },
    {
      title: '物流单号',
      dataIndex: 'deliverNo',
      hideInSearch: true,
    },
    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (_text, record) => [
        <Button
          key="details"
          type="link"
          onClick={() => {
            detailsClick(record);
          }}
        >
          详情
        </Button>,
      ],
    },
  ];
  return (
    <TableLocal
      tableClassName="activitiesGiftBagTable"
      rowKey="id"
      columns={columns}
      actionRef={actionRef}
      dateFormatter="string"
      request={activitiesGiftBagList}
      pagination={{ defaultPageSize: 10 }}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      toolBarRender={() => [
        <Button className="activitiesbulkImport" key="bulkImport" type="primary">
          <input
            value={bulkImportValue}
            accept={'.xlsx'}
            type="file"
            onChange={(e) => bulkImport(e)}
          />
          批量导入
        </Button>,
        <Button
          key="batchExport"
          type="primary"
          disabled={loading}
          loading={loading}
          onClick={batchExport}
        >
          导出
        </Button>,
      ]}
    >
      <Modal
        modalType={modalType}
        title={getModalTitle()}
        modalVisible={!!modalType}
        btnLoading={btnLoading}
        visible={visible}
        onCancel={onCancel}
        onOk={onOk}
        onSaveData={onSaveData}
        onCancelSave={onCancelSave}
      >
        {modalType === 1 && <Details ref={detailsRef} />}
        {modalType === 2 && <BulkImport ref={bulkImportRef} />}
      </Modal>
    </TableLocal>
  );
};
export default ActivitiesGiftBag;

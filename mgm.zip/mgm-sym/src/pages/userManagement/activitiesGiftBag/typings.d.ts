import type { ReactNode } from 'react';

type ModalPropType = {
  modalType?: number;
  modalVisible?: boolean;
  btnLoading?: boolean;
  title?: string;
  onCancel: () => void;
  onOk: () => void;
  children?: ReactNode;
  visible?: boolean;
  onSaveData: () => void;
  onCancelSave: () => void;
};

type XlsxDataType = {
  订单编号?: string;
  物流单号?: string;
};

type DeliverFlowsType = {
  time?: string;
  context?: string;
};

type DetailsType = {
  id?: number;
  cardDetail?: {
    cardId?: string;
    cardName?: string;
    cardPlanCode?: string;
  }[];
  receiveName?: string;
  receiveMobile?: string;
  detailAddress?: string;
  deliverStatus?: string;
  deliverFlows?: DeliverFlowsType[];
};
type ActiveTypeListType = Record<string | undefined, string | undefined>;
export { ModalPropType, DetailsType, XlsxDataType, ActiveTypeListType };

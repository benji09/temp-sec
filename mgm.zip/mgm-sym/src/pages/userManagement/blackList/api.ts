// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type { AddBlacklistType, CouponNoteProvideListType, DelBlacklistType } from './typings';

// 列表
const pageBlacklist = async (params: CouponNoteProvideListType) => {
  const { userId, userName, userPhone, current, pageSize } = params;
  const msg = await request('/blacklist/page', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: {
      userId,
      userName,
      userPhone,
      pageNo: current || 1,
      pageSize,
    },
  });
  return {
    data: (msg?.result && msg?.result.pageBlacklistInfos) || [],
    total: (msg?.result && msg?.result.totalCount) || 0,
  };
};
// 删除
const delBlacklist = async (data: DelBlacklistType) => {
  return await request(`/blacklist/del?userId=${data.userId}`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
  });
};

// 添加
const addBlacklist = async (data: AddBlacklistType) => {
  const { userId, ...params } = data;
  return await request('/blacklist/add', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { userId: Number(userId), ...params },
  });
};

// 获取用户信息
const getUserInfo = async (data: DelBlacklistType) => {
  return await request('/blacklist/user-info', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: data,
  });
};
export { pageBlacklist, delBlacklist, addBlacklist, getUserInfo };

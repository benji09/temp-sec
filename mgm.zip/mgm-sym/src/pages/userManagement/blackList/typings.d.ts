import type { ReactNode } from 'react';
type CouponNoteProvideListType = {
  userId?: string;
  userName?: string;
  userPhone?: string;
  current?: number;
  pageSize?: number;
};
type DelBlacklistType = {
  userId?: number;
};
type AddBlacklistType = {
  userId?: number;
  userPhone?: string;
  userName?: string;
  remark?: string;
};

type ModalPropType = {
  title?: string | undefined;
  ModalVisible?: boolean;
  btnLoading?: boolean;
  visible?: boolean;
  onCancel: () => void;
  onCancelSave: () => void;
  onOk: () => void;
  onSaveData: () => void;
  children?: ReactNode;
};

type PropsType = {
  modalType?: number;
};
type UserMsgType = {
  userName?: string;
  userPhone?: string;
};
export {
  CouponNoteProvideListType,
  DelBlacklistType,
  AddBlacklistType,
  ModalPropType,
  PropsType,
  UserMsgType,
};

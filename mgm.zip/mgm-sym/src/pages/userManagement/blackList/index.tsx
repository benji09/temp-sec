import React, { useState, useRef } from 'react';
import _ from 'lodash';
import { Button, Popconfirm } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import { checkPermission, BLACKLIST_PAGE, BLACKLIST_DEL, BLACKLIST_ADD } from '@/utils/power';
import { OrderDetailsMobile } from '@/services/api';
import TableLocal from '@/components/TableLocal/TableLocal';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import Modal from './components/modal';
import Create from './components/create';
import { pageBlacklist, delBlacklist, addBlacklist } from './api';

const MODAL_TYPE_ADD = 1;
// 权限
const permissionGroups = [BLACKLIST_PAGE, BLACKLIST_DEL, BLACKLIST_ADD];
const BlackList: React.ReactNode = () => {
  const CreateRef = useRef<any>();
  const actionRef = useRef<ActionType | undefined>();
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [visible, setVisible] = useState<boolean>(false);
  const [details, setDetails] = useState({});

  const [mobilesCache, setMobilesCache] = useState({});

  const [powers, setPowers] = useState({});
  if (Object.keys(powers).length < 1) checkPermission(permissionGroups, setPowers);

  // 查看手机号
  const queryMobile = (record: any) => {
    OrderDetailsMobile(record.userId)
      .then((res) => {
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.userId] = res.result;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };
  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_ADD:
        return '新增';
    }
    return '';
  }

  function onCancel() {
    CreateRef.current?.reset();
    setVisible(false);
    setTimeout(() => {
      setModalType(undefined);
    });
  }
  function onCancelSave() {
    setVisible(false);
  }
  function onOk() {
    CreateRef.current?.takeData().then((res: any) => {
      setDetails(res);
      setVisible(true);
    });
  }
  function onSaveData() {
    setBtnLoading(true);
    addBlacklist(details)
      .then((res) => {
        if (res.status === 0) {
          CreateRef.current?.reset();
          actionRef.current?.reload();
          setTimeout(() => {
            setModalType(undefined);
          });
        }
      })
      .finally(() => {
        setBtnLoading(false);
        setVisible(false);
      });
  }

  // 删除黑名单
  function detailsBlackList(record: any) {
    delBlacklist({ userId: Number(record.userId) }).then((res) => {
      if (res.status === 0) {
        showSuccessMessage('删除成功');
        actionRef.current?.reload();
      }
    });
  }

  const columns: ProColumns[] = [
    {
      title: 'UserID',
      dataIndex: 'userId',
    },
    {
      title: '手机号',
      dataIndex: 'userPhone',
      render: (text, record) => {
        return (
          <>
            {mobilesCache[record.userId] || text}
            {(record.userPhone || '').indexOf('*') < 0 ||
            mobilesCache[record.userId] ||
            (record.userPhone || '').trim().length < 1 ? null : (
              <Button type="link" key="lookMobile" onClick={() => queryMobile(record)}>
                查看
              </Button>
            )}
          </>
        );
      },
    },
    {
      title: '用户姓名',
      dataIndex: 'userName',
    },
    {
      title: '新增时间',
      dataIndex: 'createTime',
      hideInSearch: true,
    },
    {
      title: '备注',
      dataIndex: 'remark',
      hideInSearch: true,
    },
    {
      hideInSearch: true,
      title: '操作',
      valueType: 'option',
      render: (text, record) => [
        powers[`${BLACKLIST_DEL}`] && (
          <Popconfirm
            key={'retry'}
            icon=""
            title={'是否确认删除'}
            onConfirm={() => {
              detailsBlackList(record);
            }}
            okText="确认"
            cancelText="取消"
          >
            <Button type="link">删除</Button>
          </Popconfirm>
        ),
      ],
    },
  ];
  return (
    <TableLocal
      columns={columns}
      request={powers[`${BLACKLIST_PAGE}`] && pageBlacklist}
      rowKey="userId"
      dateFormatter="string"
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      pagination={{ defaultPageSize: 10 }}
      toolBarRender={() => [
        powers[`${BLACKLIST_ADD}`] && (
          <Button
            key="primary"
            type="primary"
            onClick={() => {
              setModalType(MODAL_TYPE_ADD);
            }}
          >
            <PlusOutlined />
            新增
          </Button>
        ),
      ]}
      actionRef={actionRef}
    >
      <Modal
        title={getModalTitle()}
        onCancel={onCancel}
        onCancelSave={onCancelSave}
        onOk={onOk}
        onSaveData={onSaveData}
        ModalVisible={!!modalType}
        btnLoading={btnLoading}
        visible={visible}
      >
        {modalType === 1 && <Create modalType={modalType} ref={CreateRef} />}
      </Modal>
    </TableLocal>
  );
};
export default BlackList;

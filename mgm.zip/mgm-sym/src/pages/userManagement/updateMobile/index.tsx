import React, { useState } from 'react';
import { Card, Col, Row, Form, Input, Button, Popconfirm } from 'antd';
import { PageContainer } from '@ant-design/pro-layout';

import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';
import { cardSingleMobilePhoneReg } from '@/utils/RegExp';

import { changeMobile } from './api';
import type { ChangeMobileType } from './typings';

import './index.less';

const UpdataMobile: React.FC = () => {
  const [mobileLoading, setMobileLoading] = useState<boolean>(false);
  const [visible, setVisible] = React.useState(false);
  const [details, setDetails] = useState<ChangeMobileType>({});
  const [form] = Form.useForm();

  const handleOk = () => {
    setVisible(true);
    setMobileLoading(true);
    if (cardSingleMobilePhoneReg(details.mobile || '')) {
      changeMobile(details).then((res) => {
        if (res.status === 0) {
          showSuccessMessage('修改成功');
        }
        setVisible(false);
        setMobileLoading(false);
      });
    } else {
      showErrorMessage('请检查手机号格式是否正确');
    }
  };
  const onClickButton = () => {
    form.validateFields().then((res) => {
      setVisible(true);
      setDetails(res);
    });
  };

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 24 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 24 },
    },
  };

  return (
    <PageContainer>
      <Card className="updateMobile">
        <Row className="updateMobileMsg">
          <h3>手机号登录为用户唯一登录方式，请勿擅自更改，否则将追究各种责任</h3>
        </Row>
        <Form form={form} {...formItemLayout}>
          <Row>
            <Col span={7}>
              <Form.Item
                label="请输入 userId"
                labelAlign="left"
                name="userId"
                rules={[{ required: true, message: '请输入 userId' }]}
              >
                <Input placeholder="请输入 userId" />
              </Form.Item>
            </Col>
          </Row>
          <Row>
            <Col span={7}>
              <Form.Item
                label="请输入手机号码"
                labelAlign="left"
                name="mobile"
                rules={[{ required: true, message: '请输入手机号码' }]}
              >
                <Input maxLength={11} placeholder="请输入手机号码" />
              </Form.Item>
            </Col>
            <Col span={5}>
              <Form.Item className="updateMobileMsgButton">
                <Popconfirm
                  title="确认修改，修改后无法撤销"
                  visible={visible}
                  onConfirm={handleOk}
                  okButtonProps={{ loading: mobileLoading }}
                  onCancel={() => {
                    setVisible(false);
                  }}
                >
                  <Button onClick={onClickButton} type="primary">
                    确认
                  </Button>
                </Popconfirm>
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Card>
    </PageContainer>
  );
};
export default UpdataMobile;

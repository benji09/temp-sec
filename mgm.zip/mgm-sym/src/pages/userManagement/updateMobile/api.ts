import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type { ChangeMobileType } from './typings';

// 更改手机号接口
const changeMobile = async (params?: ChangeMobileType) => {
  return await request('/update-mobile', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params,
  });
};
export { changeMobile };

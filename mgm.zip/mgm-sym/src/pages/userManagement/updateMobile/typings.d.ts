type ChangeMobileType = {
  userId?: string;
  mobile?: string;
};

export { ChangeMobileType };

import type { ReactNode } from 'react';

interface SeriousIllnessType {
  admissionDate: string;
  dischargeDate: string;
  id: string;
  applyTime: string;
  userName: string;
  userId: string;
  applyStatus: number;
  visitingHospital: string;
}
interface StatusList {
  code: string;
  name: string;
}
interface ModalPropType {
  showModalOk?: boolean;
  ModalVisible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel: () => void;
  onOk: () => void;
  children: ReactNode;
}
interface ViewType {
  id?: number;
  applyTime?: string;
  userId?: number;
  userName?: string;
  userPhone?: string;
  applyPhone?: string; // 申请时联系电话
  applyStatus?: number; // 申请状态
  allowanceAmount?: number; // 津贴金额
  visitingHospital?: string; // 就诊医院
  admissionDate?: string; // 入院日期
  dischargeDate?: string; // 出院日期
  referralHospital?: string; // 转诊医院
  referralDate?: string; // 转诊日期
  diseaseDesc?: string; // 疾病描述
  receiptImg?: string; // 收据信息
  receiptImgNum?: number; // 收据信息数量
  supplementImg?: string; // 补充材料信息
  supplementTime?: string; // 补充材料提交时间
  rightsInfos?: any;
}
interface ViewPropsType {
  applyForStatus?: StatusList[];
  viewLoading?: boolean;
}
interface RightsAndAmountInfosType {
  balanceAmount?: string;
  code?: string;
  name?: string;
  rightsId?: string;
}
interface RightsInfosType {
  name?: string;
  planCode?: string;
  rightsAndAmountInfos: RightsAndAmountInfosType[];
}
interface DetailsType {
  code?: string;
  admissionDate?: string;
  allowanceAmount?: string;
  applyPhone?: string;
  applyStatus?: number;
  applyTime?: string;
  dischargeDate?: string;
  diseaseDesc?: string;
  id?: string;
  receiptImg?: string[];
  receiptImgNum?: number;
  referralDate?: string;
  referralHospital?: string;
  rightsId?: string;
  rightsInfos?: RightsInfosType[];
  supplementImg?: string[];
  supplementTime?: string;
  userId?: string;
  userName?: string;
  userPhone?: string;
  visitingHospital?: string;
}
interface SicknessAllowanceUpdateType {
  allowanceAmount: string;
  applyStatus: string;
  id: string;
  rightsId: string;
}
export {
  SeriousIllnessType,
  StatusList,
  ModalPropType,
  ViewType,
  ViewPropsType,
  RightsAndAmountInfosType,
  RightsInfosType,
  DetailsType,
  SicknessAllowanceUpdateType,
};

/*
 * @Author: zyx
 * @Date: 2021-09-16 14:22:42
 * @LastEditors: zyx
 * @LastEditTime: 2021-11-03 17:59:15
 * @Desc:
 */
// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import { POWER_HOST } from '@/services/hosts';
import { checkIsNumberForSearch, HOST_TYPE_POWER } from '@/utils/utils';

import type { SicknessAllowanceUpdateType } from './typings';

// 重疾津贴列表
const seriousIllnessList = async (params: any) => {
  const { current, pageSize, admissionDate, applyTime, dischargeDate, ...data } = params;
  data.admissionDate = admissionDate ? dayjs(admissionDate).format('YYYY-MM-DD') : '';
  data.applyTime = applyTime ? dayjs(applyTime).format('YYYY-MM-DD') : '';
  data.dischargeDate = dischargeDate ? dayjs(dischargeDate).format('YYYY-MM-DD') : '';
  data.pageNo = current;
  data.pageSize = Number(pageSize);

  const UserIdResult = checkIsNumberForSearch(params.userId, 'UserId');
  if (UserIdResult !== null) return UserIdResult;

  const msg = await request('/sickness-allowance/page', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: data,
  });

  return {
    data: msg.result.sicknessAllowanceInfos || [],
    total: msg.result.totalCount || 0,
  };
};
// 重疾津贴状态列表
const mgrStatus = async () => {
  return await request('/sickness-allowance/status', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
  });
};
// 重疾津贴详情信息
const mgrDetail = async (id?: number | string) => {
  return await request('/sickness-allowance/detail', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { id },
  });
};
const sicknessAllowanceUpdate = async (data: SicknessAllowanceUpdateType) => {
  return await request('/sickness-allowance/update', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
const sicknessAllowancePhone = async (id?: number | string) => {
  return await request('/sickness-allowance/phone', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { id },
  });
};
export {
  seriousIllnessList,
  mgrStatus,
  mgrDetail,
  sicknessAllowanceUpdate,
  sicknessAllowancePhone,
};

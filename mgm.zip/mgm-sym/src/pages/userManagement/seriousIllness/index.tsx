import React, { useEffect, useRef, useState } from 'react';
import { Button, DatePicker } from 'antd';
import type { ActionType, ProColumns } from '@ant-design/pro-table';

import TableLocal from '@/components/TableLocal/TableLocal';

import Modal from './components/Modal';
import View from './components/View';
import { mgrDetail, mgrStatus, seriousIllnessList, sicknessAllowanceUpdate } from './api';
import type { SeriousIllnessType, StatusList } from './typings';

function disabledDate(current: any) {
  return current && current > new Date();
}

const MODAL_TYPE_VIEW = 1;

const SeriousIllness: React.FC = () => {
  const [modalType, setModalType] = useState<number | undefined>(undefined);
  const [ModalVisible, setModalVisible] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [viewLoading, setViewLoading] = useState<boolean>(false);
  const [statusList, setStatusList] = useState<StatusList[]>([]);

  const [showModalOk, setShowModalOk] = useState<boolean>(false);

  const actionRef = useRef<ActionType | undefined>();
  const ViewRef = useRef<any>();

  useEffect(() => {
    mgrStatus().then((res: any) => {
      if (res.status === 0) {
        setStatusList(res.result.codeAndNames || []);
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_VIEW:
        return '查看';
    }
    return '';
  }

  const onModalOk = () => {
    if (modalType === 1) {
      ViewRef.current?.takeData().then((data: any) => {
        setLoading(true);
        sicknessAllowanceUpdate(data)
          .then((res) => {
            if (res.status === 0) {
              setModalType(undefined);
              ViewRef.current?.reset();
              setModalVisible(false);
              actionRef.current?.reload();
            }
          })
          .finally(() => {
            setLoading(false);
          });
      });
    }
  };
  const onModalCancel = () => {
    setLoading(false);
    setModalType(undefined);
    ViewRef.current?.reset();
    setModalVisible(false);
  };

  const columns: ProColumns<SeriousIllnessType>[] = [
    {
      title: 'UserID',
      dataIndex: 'userId',
      hideInTable: true,
    },
    {
      title: '用户姓名',
      dataIndex: 'userName',
      hideInTable: true,
    },
    {
      title: '申请时间',
      dataIndex: 'applyTime',
      renderFormItem: () => (
        <DatePicker disabledDate={disabledDate} placeholder={'请选择申请时间'} />
      ),
      hideInTable: true,
    },
    {
      title: '状态',
      dataIndex: 'applyStatus',
      valueEnum: () => {
        const cateData = {};
        statusList?.forEach((item: any) => {
          cateData[item.code] = { text: item.name };
        });
        return cateData;
      },
      hideInTable: true,
    },

    {
      title: '入院日期',
      dataIndex: 'admissionDate',
      renderFormItem: () => {
        return <DatePicker placeholder={'请选择入院时间'} />;
      },
      hideInTable: true,
    },
    {
      title: '出院日期',
      dataIndex: 'dischargeDate',
      renderFormItem: () => {
        return <DatePicker placeholder={'请选择出院时间'} />;
      },
      hideInTable: true,
    },

    {
      title: '申请时间',
      dataIndex: 'applyTime',
      hideInSearch: true,
    },
    {
      title: '用户昵称',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: 'UserID',
      dataIndex: 'userId',
      hideInSearch: true,
    },
    {
      title: '就诊医院',
      dataIndex: 'visitingHospital',
      hideInSearch: true,
    },
    {
      title: '入院日期',
      dataIndex: 'admissionDate',
      hideInSearch: true,
    },
    {
      title: '出院日期',
      dataIndex: 'dischargeDate',
      hideInSearch: true,
    },
    {
      title: '状态',
      dataIndex: 'applyStatus',
      valueEnum: () => {
        const cateData = {};
        statusList?.forEach((item: any) => {
          cateData[item.code] = { text: item.name };
        });
        return cateData;
      },
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      render: (_text, record) => [
        <Button
          key="view"
          type="link"
          onClick={() => {
            mgrDetail(record.id)
              .then((res) => {
                const { status, result } = res;
                if (status === 0) {
                  setModalType(MODAL_TYPE_VIEW);
                  setModalVisible(true);
                  setViewLoading(true);
                  if (result.applyStatus === 4 || result.applyStatus === 5) {
                    setShowModalOk(true);
                  } else {
                    setShowModalOk(false);
                  }
                  ViewRef.current?.setData(result);
                }
              })
              .finally(() => {
                setViewLoading(false);
              });
          }}
        >
          查看
        </Button>,
      ],
    },
  ];

  return (
    <TableLocal
      tableClassName="SeriousIllness"
      columns={columns}
      actionRef={actionRef}
      search={{
        optionRender: (searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      request={seriousIllnessList}
      rowKey="id"
    >
      <Modal
        showModalOk={showModalOk}
        title={getModalTitle()}
        loading={loading}
        ModalVisible={ModalVisible}
        onOk={onModalOk}
        onCancel={onModalCancel}
      >
        {modalType === 1 && (
          <View ref={ViewRef} viewLoading={viewLoading} applyForStatus={statusList} />
        )}
      </Modal>
    </TableLocal>
  );
};
export default SeriousIllness;

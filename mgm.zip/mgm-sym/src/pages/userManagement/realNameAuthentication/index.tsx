import { useEffect, useRef, useState } from 'react';
import dayjs from 'dayjs';
import { Button, Popconfirm, Select, Switch } from 'antd';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import TableLocal from '@/components/TableLocal/index';

import Modal from './components/Modal';
import Details from './components/Details';
import {
  getConfigState,
  realNameAuthenticationList,
  reviewCertificationAuth,
  updateConfigState,
} from './api';
import { AuditResultType, AuditStatusType, CardPlanCodeType, CertificateType } from './utils/utils';
import type { CommonRefType, RealNameAuthenticationType } from './typings';
import { showErrorMessage } from '@/mamagement/Notification';
import { OrderDetailsMobile } from '@/services/api';
import _ from 'lodash';

const { Option } = Select;
const MODAL_TYPE_DETAILS = 1;
export default (): React.ReactNode => {
  const actionRef = useRef<ActionType | undefined>();
  const detailsRef = useRef<CommonRefType<RealNameAuthenticationType>>();

  const [ModalVisible, setModalVisible] = useState<boolean>(false);
  const [modalType, setModalType] = useState<number | undefined>(undefined);

  const [verifiedLoading, setVerifiedLoading] = useState<boolean>(false);
  const [auditFailedLoading, setAuditFailedLoading] = useState<boolean>(false);
  const [id, setId] = useState<string | number | undefined>(undefined);

  // 是否开关
  const [configStateLoading, setConfigStateLoading] = useState<boolean>(false);
  const [configState, setConfigState] = useState<boolean>(false);
  const [visible, setVisible] = useState(false);
  const [tempFlag, setTempFlag] = useState<boolean>(false);

  const [mobilesCache, setMobilesCache] = useState({});
  const [mobileLoading, setMobileLoading] = useState<boolean>(false);

  useEffect(() => {
    getConfigState().then((res) => {
      if (res.status === 0) {
        setConfigState(res.result?.state);
        setTempFlag(res.result?.state);
      }
    });
  }, []);

  // 弹框标题
  function getModalTitle() {
    if (modalType === undefined) return '';
    switch (modalType) {
      case MODAL_TYPE_DETAILS:
        return '用户证件上传详情';
    }
    return '';
  }

  // 关闭弹框
  function onCancel() {
    setModalType(undefined);
    setModalVisible(false);
  }
  // 证件类型
  const idCardTypeSelect = () => {
    return (
      <Select mode="multiple" placeholder="请选择证件类型" allowClear showArrow>
        {(Object.keys(CertificateType) ?? []).map((item) => {
          return (
            <Option value={item ?? ''} key={item ?? ''}>
              {CertificateType[item].text ?? ''}
            </Option>
          );
        })}
      </Select>
    );
  };
  // 审核通过
  function verified() {
    setVerifiedLoading(true);
    reviewCertificationAuth({ auditResult: 1, id: id ?? '' }).then((res) => {
      setVerifiedLoading(false);
      if (res.status === 0) {
        detailsRef.current?.reset();
        actionRef.current?.reload();
        setId(undefined);
        setModalType(undefined);
        setModalVisible(false);
      }
    });
  }
  // 审核不通过
  function auditFailed() {
    detailsRef.current
      ?.takeData()
      .then((data) => {
        setAuditFailedLoading(true);
        reviewCertificationAuth({
          auditResult: 2,
          id: id ?? '',
          failureReason: data.failureReasonValue,
        }).then((res) => {
          setAuditFailedLoading(false);
          if (res.status === 0) {
            detailsRef.current?.reset();
            actionRef.current?.reload();
            setId(undefined);
            setModalType(undefined);
            setModalVisible(false);
          }
        });
      })
      .catch((err) => {
        showErrorMessage(err.message);
      });
  }

  // 更改是否开启的状态
  function switchChange(checked: boolean) {
    setTempFlag(checked);
    setVisible(true);
  }

  const handleOk = () => {
    setVisible(false);
    setConfigStateLoading(true);

    updateConfigState(tempFlag).then((res) => {
      setConfigStateLoading(false);
      if (res.status === 0) {
        setConfigState(tempFlag);
      }
    });
  };

  const handleCancel = () => {
    setVisible(false);
    setTempFlag(configState);
  };

  // 开关
  const configSwitch = () => {
    return (
      <Popconfirm
        key={'switch'}
        title={tempFlag ? '是否开启实名认证服务？' : '是否关闭实名认证服务？'}
        visible={visible}
        onConfirm={handleOk}
        onCancel={handleCancel}
      >
        <Switch loading={configStateLoading} checked={configState} onChange={switchChange} />
      </Popconfirm>
    );
  };

  const queryMobile = (record: RealNameAuthenticationType) => {
    setMobileLoading(true);
    OrderDetailsMobile(record.userId)
      .then((res) => {
        setMobileLoading(false);
        if (res.status === 0) {
          const temp = _.cloneDeep(mobilesCache);
          temp[record.userId ?? ''] = res.result;
          setMobilesCache(temp);
        }
      })
      .catch(() => showErrorMessage('获取失败，请重试'));
  };

  const columns: ProColumns<RealNameAuthenticationType>[] = [
    {
      title: '',
      dataIndex: 'id',
      hideInSearch: true,
    },
    {
      title: '选择搜索日期',
      dataIndex: 'time',
      valueType: 'dateRange',
      hideInTable: true,
      search: {
        transform: (value) => {
          return {
            startTime: dayjs(`${value[0]} 00:00:00`).valueOf(),
            endTime: dayjs(`${value[1]} 23:59:59`).valueOf(),
          };
        },
      },
    },
    {
      title: 'UserID',
      dataIndex: 'userId',
    },
    {
      title: '证件上传时间',
      dataIndex: 'uploadTime',
      renderText: (text) => formatTime(text),
      hideInSearch: true,
    },
    {
      title: '保单号',
      dataIndex: 'policyNo',
      hideInSearch: true,
    },
    {
      title: '证件类型',
      hideInTable: true,
      dataIndex: 'idCardType',
      renderFormItem: idCardTypeSelect,
    },
    {
      title: '证件类型',
      dataIndex: 'idCardType',
      valueType: 'select',
      valueEnum: CertificateType,
      hideInSearch: true,
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
      render: (text, record) => {
        return (
          <>
            {mobilesCache[record.userId ?? ''] || text}
            {mobilesCache[record.userId ?? ''] || (record.mobile || '').trim().length < 1 ? null : (
              <Button
                loading={mobileLoading}
                type="link"
                key="lookMobile"
                onClick={() => queryMobile(record)}
              >
                查看
              </Button>
            )}
          </>
        );
      },
    },
    {
      title: '权益卡',
      dataIndex: 'cardId',
      valueType: 'select',
      valueEnum: CardPlanCodeType,
      hideInTable: true,
    },
    {
      title: '权益卡名称',
      dataIndex: 'cardName',
      hideInSearch: true,
    },
    {
      title: 'CardID',
      dataIndex: 'cardId',
      hideInSearch: true,
    },
    {
      title: '审核状态',
      dataIndex: 'auditStatus',
      valueType: 'select',
      valueEnum: AuditStatusType,
    },
    {
      title: '审核结果',
      dataIndex: 'auditResult',
      valueType: 'select',
      valueEnum: AuditResultType,
    },
    {
      title: '管理',
      hideInSearch: true,
      render: (_text, record) => [
        <Button
          key="details"
          type="link"
          onClick={() => {
            setModalType(MODAL_TYPE_DETAILS);
            setModalVisible(true);
            setId(record.id ?? undefined);
            setTimeout(() => {
              detailsRef.current?.setData(record);
            });
          }}
        >
          详情
        </Button>,
      ],
    },
  ];
  return (
    <TableLocal
      columns={columns}
      request={realNameAuthenticationList}
      actionRef={actionRef}
      rowKey="id"
      search={{
        labelWidth: 100,
        optionRender: (_searchConfig: any, formProps: any, dom: any[]) => [...dom.reverse()],
      }}
      toolBarRender={() => [configSwitch()]}
    >
      <Modal ModalVisible={ModalVisible} title={getModalTitle()} onCancel={onCancel}>
        <Details
          ref={detailsRef}
          verifiedLoading={verifiedLoading}
          auditFailedLoading={auditFailedLoading}
          verified={verified}
          auditFailed={auditFailed}
        />
      </Modal>
    </TableLocal>
  );
};

import { getRequest, postRequest } from '@/services/api';
import { HOST_TYPE_POWER } from '@/utils/utils';

// 实名认证列表
const realNameAuthenticationList = async (params: any) => {
  const { current, pageSize, mobile, userId, ...data } = params;

  const msg = (await postRequest(
    '/certification-auth/list-certification-auth',
    {
      mobile: (mobile && mobile.trim()) || undefined,
      userId: (userId && userId.trim()) || undefined,
      size: pageSize,
      page: current,
      ...data,
    },
    {},
    {
      type: HOST_TYPE_POWER,
    },
  )) as unknown as APIS.BaseResponse<any>;
  return {
    data: msg.result?.list || [],
    total: msg.result?.total || 0,
  };
};
// 重新审核
const reviewCertificationAuth = async (data: any) => {
  return (await postRequest(
    '/certification-auth/review-certification-auth',
    { ...data },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 获取实名认证服务开关状态
const getConfigState = async () => {
  return (await getRequest(
    '/certification-auth/get-config-state',
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
// 获取实名认证服务开关状态
const updateConfigState = async (checked: boolean) => {
  return (await postRequest(
    '/certification-auth/update-config-state',
    { state: checked },
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
};
export { realNameAuthenticationList, reviewCertificationAuth, getConfigState, updateConfigState };

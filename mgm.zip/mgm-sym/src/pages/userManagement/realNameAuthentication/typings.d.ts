type RealNameAuthenticationType = {
  auditResult?: number; // 审核结果: 1 通过   | 2 不通过
  auditStatus?: number; // 审核状态：1 未审核 | 2 已审核
  auditType?: number; // 审核状态：1 自动审 | 2 人工审
  cardId?: number; // 卡 ID
  cardName?: string; // 卡名称
  failureReason?: string; //失败原因
  id?: number;
  idCardNo?: string; // 证件号
  idCardType?: number; // 证件类型：身份证0 | 护照1 | 军官证2 | 驾照3 | 出生证明4 | 户口薄5 | 港澳台胞证6 | 其他8
  imageUrl1?: string; // 影像图片1
  imageUrl2?: string; // 影像图片1
  mobile?: string; // 手机号
  name?: string; // 用户名称
  policyNo?: string; // 保单号
  uploadTime?: number; // 上传时间
  userId?: number; // 用户 ID
};
type ModalPropType = {
  ModalVisible?: boolean;
  title?: string;
  loading?: boolean;
  onCancel: () => void;
  children?: ReactNode;
};
type CommonRefType<T> = {
  setData: (data: T) => void;
  reset: () => void;
  takeData: () => Promise<void | any>;
};
type DetailsPropsType = {
  verifiedLoading?: boolean;
  auditFailedLoading?: boolean;
  verified?: () => void;
  auditFailed?: () => void;
};
export { RealNameAuthenticationType, ModalPropType, CommonRefType, DetailsPropsType };

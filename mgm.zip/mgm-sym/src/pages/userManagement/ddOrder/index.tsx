import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns } from '@ant-design/pro-table';
import ProTable from '@ant-design/pro-table';

import { ddOrderList } from '@/services/api';

import './index.less';

export default (): React.ReactNode => {
  const columns: ProColumns<APIS.DDOrderItem>[] = [
    {
      title: 'UserID',
      dataIndex: 'userId',
    },
    {
      title: '手机号',
      dataIndex: 'mobile',
    },
    {
      title: '用户昵称',
      dataIndex: 'nick',
      hideInSearch: true,
    },
    {
      title: '订单创建时间',
      dataIndex: 'createdDate',
      renderText: (text) =>
        text && text.length > 0 ? text.substring(0, text.lastIndexOf('.')).replace('T', ' ') : text,
      hideInSearch: true,
    },
    {
      title: '订单号',
      dataIndex: 'ddOrderNo',
      hideInSearch: true,
    },
    {
      title: '订单状态',
      dataIndex: 'orderStatusCn',
      hideInSearch: true,
    },
    {
      title: '药无忧标志',
      dataIndex: 'rights',
      renderText: (text) => (text ? '已使用' : '未使用'),
      hideInSearch: true,
    },
    {
      title: '优惠金额',
      dataIndex: 'deductionAmount',
      renderText: (text) => `￥${text / 100}`,
      hideInSearch: true,
    },
    {
      title: '支付金额',
      dataIndex: 'price',
      renderText: (text) => `￥${text / 100}`,
      hideInSearch: true,
    },
  ];
  return (
    <PageContainer>
      <ProTable<APIS.DDOrderItem>
        columns={columns}
        request={(params) => ddOrderList({ ...params, tag: 1 })}
        rowKey="createdDate"
        dateFormatter="string"
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
      />
    </PageContainer>
  );
};

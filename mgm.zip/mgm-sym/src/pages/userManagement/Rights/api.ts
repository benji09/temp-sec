/*
 * @Author: zyx
 * @Date: 2021-09-16 14:22:42
 * @LastEditors: zyx
 * @LastEditTime: 2021-11-09 10:32:42
 * @Desc:
 */
// @ts-ignore
import { request } from 'umi';

import { POWER_HOST } from '@/services/hosts';
import { HOST_TYPE_POWER } from '@/utils/utils';

import type { DeleteCardRelatedPersonType, LockCardType } from './typings';

// 删除卡中的使用人
const deleteCardRelatedPerson = async (data: DeleteCardRelatedPersonType) => {
  return await request('/rights/delete-card-related-person', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 锁定卡
const lockCard = async (data: LockCardType) => {
  return await request('/rights/lock-card', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 解锁卡
const unlockCard = async (data: LockCardType) => {
  return await request('/rights/unlock-card', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
// 扣除权益
const rightsDecrease = async (data: LockCardType) => {
  return await request('/rights/decrease', {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data,
  });
};
export { deleteCardRelatedPerson, lockCard, unlockCard, rightsDecrease };

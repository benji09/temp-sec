type CardRelationalDetail = {
  idCardNumber?: string;
  idCardType?: number;
  name?: string;
  primary?: boolean;
  relatedPersonId?: string;
};
type DeleteCardRelatedPersonType = {
  relatedPersonId?: string;
  userId?: string | number;
};
type LockCardType = {
  cardId: string;
};
type DeductRightsType = {
  rightsId?: string;
  serviceType?: number;
};

export { CardRelationalDetail, DeleteCardRelatedPersonType, LockCardType, DeductRightsType };

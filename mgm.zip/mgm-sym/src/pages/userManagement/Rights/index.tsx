import React, { useRef, useState } from 'react';
import { Button, Popconfirm } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageContainer } from '@ant-design/pro-layout';
import type { ProColumns, ActionType } from '@ant-design/pro-table';

import { formatTime } from '@/utils/utils';
import { getRightsList } from '@/services/api';
import { showSuccessMessage } from '@/mamagement/Notification';

import CardDetailModal from './components';
import { rightLockState } from '../util';
import { lockCard, unlockCard } from './api';

import './index.less';

export default (): React.ReactNode => {
  const actionRef = useRef<ActionType | undefined>();

  const [visible, setVisible] = useState(false);
  const [cardItem, setCardItem] = useState<APIS.RightCardItem | null>(null);
  const [confirmLoading, setConfirmLoading] = useState<boolean>(false);

  function confirm(record: APIS.RightCardItem) {
    setConfirmLoading(true);
    if (record.lockState === 1 || record.lockState === 5) {
      unlockCard({ cardId: record.cardId || '' })
        .then((res) => {
          if (res.status === 0) {
            showSuccessMessage('解锁成功');
            actionRef.current?.reload();
          }
        })
        .finally(() => setConfirmLoading(false));
    } else if (record.lockState === 0) {
      lockCard({ cardId: record.cardId || '' })
        .then((res) => {
          if (res.status === 0) {
            showSuccessMessage('锁定成功');
            actionRef.current?.reload();
          }
        })
        .finally(() => setConfirmLoading(false));
    }
  }

  const columns: ProColumns<APIS.RightCardItem>[] = [
    {
      title: 'UserID',
      dataIndex: 'userId',
    },
    {
      title: '用户昵称',
      dataIndex: 'userName',
      hideInSearch: true,
    },
    {
      title: '权益卡名称',
      dataIndex: 'cardName',
      hideInSearch: true,
    },
    {
      title: '领用日期',
      dataIndex: 'activeTime',
      renderText: (text) => formatTime(Number(text)),
      hideInSearch: true,
    },
    {
      title: '锁定状态',
      dataIndex: 'lockState',
      valueType: 'select',
      valueEnum: rightLockState,
      hideInSearch: true,
    },
    {
      title: '是否待绑定使用人',
      dataIndex: 'broken',
      renderText: (text) => (text ? '是' : '否'),
      hideInSearch: true,
    },
    {
      title: '操作',
      hideInSearch: true,
      valueType: 'option',
      render: (_text, record) => [
        <Button
          type="link"
          key="view"
          onClick={() => {
            setCardItem(record);
            setVisible(true);
          }}
        >
          查看
        </Button>,

        <Popconfirm
          key="display"
          icon=""
          title={record.lockState === 0 ? '是否锁定?' : '是否解锁?'}
          onConfirm={() => {
            confirm(record);
          }}
          okText="确定"
          cancelText="取消"
          okButtonProps={{ loading: confirmLoading }}
        >
          {(record.lockState === 1 || record.lockState === 5 || record.lockState === 10) && (
            <Button type="link" disabled={record.lockState === 10}>
              解锁
            </Button>
          )}
          {record.lockState === 0 && (
            <Button type="link" danger>
              锁定
            </Button>
          )}
        </Popconfirm>,
      ],
    },
  ];
  return (
    <PageContainer>
      <ProTable<APIS.RightCardItem>
        columns={columns}
        request={getRightsList}
        rowKey="cardId"
        dateFormatter="string"
        actionRef={actionRef}
        search={{
          labelWidth: 120,
          optionRender: (searchConfig, formProps, dom) => [...dom.reverse()],
        }}
      />
      <CardDetailModal
        visible={visible}
        onCancel={() => {
          setVisible(false);
          setCardItem(null);
          actionRef.current?.reload();
        }}
        cardItem={cardItem}
      />
    </PageContainer>
  );
};

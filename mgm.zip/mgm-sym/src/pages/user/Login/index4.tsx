import React, { useState } from 'react';
import { history, FormattedMessage, useModel } from 'umi';
import { Alert, Card } from 'antd';
import ProForm, { ProFormText } from '@ant-design/pro-form';
import { LockOutlined, UserOutlined } from '@ant-design/icons';

import { login } from '@/services/api';
import KEYS from '@/utils/storageKeys';
import { setItemUserInfo } from '@/utils/userInfoEncrypt';
import { showErrorMessage, showSuccessMessage } from '@/mamagement/Notification';

import './index.less';

const LoginMessage: React.FC<{
  content: string;
}> = ({ content }) => (
  <Alert
    style={{
      marginBottom: 24,
    }}
    message={content}
    type="error"
    showIcon
  />
);

/** 此方法会跳转到 redirect 参数所在的位置 */
const goto = () => {
  if (!history) return;
  setTimeout(() => {
    const { query } = history.location;
    const { redirect } = query as { redirect: string };
    history.push(redirect || '/');
  }, 10);
};

const Login: React.FC = () => {
  const [submitting, setSubmitting] = useState(false);
  const [userLoginState, setUserLoginState] = useState<APIS.LoginResult>({});
  const [type] = useState<string>('account');
  const { refresh } = useModel('@@initialState');
  const handleSubmit = async (values: APIS.LoginParams) => {
    setSubmitting(true);
    const msg = await login(values);
    try {
      // 登录
      const { status, result } = msg;
      if (status === 0) {
        if (result.result === 'ERROR_ACCOUNT' || result.result === 'ERROR_PASSWORD') {
          const defaultloginSuccessMessage = `登录失败,请检查${
            result.result === 'ERROR_ACCOUNT' ? '账号' : '密码'
          }是否正确！`;
          showErrorMessage(defaultloginSuccessMessage);
          setSubmitting(false);
          return;
        }
        const defaultloginSuccessMessage = '登录成功！';
        showSuccessMessage(defaultloginSuccessMessage);
        // await fetchUserInfo();
        setItemUserInfo(KEYS.KEY_USER_INFO, JSON.stringify(result));
        refresh();
        goto();
        return;
      }
      // 如果失败去设置用户错误信息
      setUserLoginState(msg);
    } catch (error) {}
    setSubmitting(false);

    // 登录
    // const defaultloginSuccessMessage = '登录成功！';
    // showSuccessMessage(defaultloginSuccessMessage);
    // setItemUserInfo(KEYS.KEY_USER_INFO, JSON.stringify(msg));
    // refresh();
    // goto();
    // return;
  };
  const { status, type: loginType } = userLoginState;

  return (
    <div className={'login'}>
      <div className={'content'}>
        <Card className={'card'}>
          <h2>登录</h2>
          <ProForm
            initialValues={{
              autoLogin: true,
            }}
            submitter={{
              searchConfig: {
                submitText: '登录',
              },
              render: (_, dom) => dom.pop(),
              submitButtonProps: {
                loading: submitting,
                size: 'large',
                style: {
                  width: '100%',
                },
              },
            }}
            onFinish={async (values) => {
              handleSubmit(values as APIS.LoginParams);
            }}
          >
            {status === 'error' && loginType === 'account' && (
              <LoginMessage content="账户或密码错误" />
            )}
            {type === 'account' && (
              <>
                <div className={'main'}>
                  <ProFormText
                    name="name"
                    fieldProps={{
                      size: 'large',
                      prefix: <UserOutlined className={'prefixIcon'} />,
                    }}
                    placeholder="用户名"
                    rules={[
                      {
                        required: true,
                        message: (
                          <FormattedMessage
                            id="pages.login.username.required"
                            defaultMessage="请输入用户名!"
                          />
                        ),
                      },
                    ]}
                  />
                  <ProFormText.Password
                    name="password"
                    fieldProps={{
                      size: 'large',
                      prefix: <LockOutlined className={'prefixIcon'} />,
                    }}
                    placeholder="密码"
                    rules={[
                      {
                        required: true,
                        message: (
                          <FormattedMessage
                            id="pages.login.password.required"
                            defaultMessage="请输入密码！"
                          />
                        ),
                      },
                    ]}
                  />
                </div>
              </>
            )}
          </ProForm>
        </Card>
      </div>
    </div>
  );
};

export default Login;

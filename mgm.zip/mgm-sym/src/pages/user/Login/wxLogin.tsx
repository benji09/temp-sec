import { AGENT_ID, APP_ID, WX_REDIRECT_URL } from '@/services/hosts';

interface LoginConfig {
  id: string;
  appid: string;
  agentid: number;
  redirect_uri: string;
  state: string;
  href: string;
  style: string;
}

export const getLoginConfig = (groupId: string): LoginConfig => {
  return {
    id: 'wx_reg', // 登录页面显示二维码的容器id
    appid: APP_ID[groupId], // 企业微信的CroupID，在企业微信管理端查看
    agentid: AGENT_ID[groupId], // 授权方的网页应用id，在具体的网页应用中查看
    redirect_uri: encodeURIComponent(WX_REDIRECT_URL), // 重定向的地址，需要进行encode
    state: 'YVJI',
    style: 'black',
    href: 'data:text/css;base64,LndycF9jb2RlIHttYXJnaW4tdG9wOiAwICFpbXBvcnRhbnQ7fQ0KLndycF9jb2RlX3JsX2luZm8ge30NCi5pbXBvd2VyQm94IHt3aWR0aDogMjM5cHh9DQoucmVzdWx0X3RleHQge21heC13aWR0aDogMjM5cHh9DQouaW1wb3dlckJveCAucXJjb2RlIHt3aWR0aDogMjM5cHh9DQouaW1wb3dlckJveCAudGl0bGUge2Rpc3BsYXk6IG5vbmU7fQ0KLmltcG93ZXJCb3ggLmluZm8ge2Rpc3BsYXk6IG5vbmU7fQ0KLnN0YXR1c19pY29uIHtkaXNwbGF5OiBub25lfQ0KLmltcG93ZXJCb3ggLnN0YXR1cyB7fQ0KLmltcG93ZXJCb3ggLnN0YXR1cy5zdGF0dXNfYnJvd3NlciB7ZGlzcGxheTogbm9uZTt9',
  };
};

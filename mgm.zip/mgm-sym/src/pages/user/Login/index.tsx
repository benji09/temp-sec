/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import qs from 'qs';
import { Select } from 'antd';
import { history, useModel } from 'umi';

import KEYS from '@/utils/storageKeys';
import { queryCompany, wxLogin } from '@/services/api';
import { setItemUserInfo } from '@/utils/userInfoEncrypt';
import { showSuccessMessage } from '@/mamagement/Notification';
import { getItem, setItem } from '@/services/localStorage';
import { getLoginConfig } from './wxLogin';

import IconCompany from '@/assets/images/icon_company.svg';
import IconArrowUp from '@/assets/images/icon_arrow_up.svg';
import IconArrowDown from '@/assets/images/icon_arrow_down.svg';

import './index.less';

declare global {
  interface Window {
    WwLogin: any;
  }
}

type CompanyProps = {
  id?: number;
  groupId?: string;
  name?: string;
};

const Login: React.FC = () => {
  const { setInitialState } = useModel('@@initialState');
  const [open, setOpen] = useState(false);
  const [company, setCompany] = useState<CompanyProps[] | undefined>();
  const [groupId, setGroupId] = useState<string | undefined>();

  const KEY_GROUP_ID = 'company_group_id';

  useEffect(() => {
    const { search } = window.location;
    if (search.includes('code')) {
      const params = qs.parse(search.slice(1));
      login(params);
    }
    if (!company) {
      queryCompany().then((res: any) => {
        const { result } = res;
        if (res && result) {
          modifyGroupId(result[0]?.groupId);
          setCompany(result);
        }
      });
    }
  }, []);

  useEffect(() => {
    showCodeImg();
  }, [groupId]);
  return (
    <div className={'login'}>
      <div className="wx-code-container">
        <div className="title">欢迎登录</div>
        <div className="company">
          <img src={IconCompany} className="logo" />
          <div className="selector-container">
            <div className="arrow">
              <img src={open ? IconArrowUp : IconArrowDown} />
            </div>
            {company && (
              <Select
                className="selector"
                defaultValue={groupId}
                bordered={false}
                showArrow={false}
                onDropdownVisibleChange={setOpen}
                onChange={(value) => modifyGroupId(value)}
              >
                {(company ?? []).map((value) => {
                  const { name } = value;
                  return (
                    <Select.Option key={value.groupId} value={value.groupId}>
                      {name}
                    </Select.Option>
                  );
                })}
              </Select>
            )}
          </div>
        </div>
        <div className="code-container">
          <div id="wx_reg" />
        </div>
        <div className="warn">※使用企业微信扫码登录</div>
      </div>
    </div>
  );

  function modifyGroupId(id: string) {
    setGroupId(id);
    setItem(KEY_GROUP_ID, id);
  }

  function showCodeImg() {
    window.WwLogin(getLoginConfig(getItem(KEY_GROUP_ID)));
  }

  //  登录
  function login(params: { code?: string; state?: string; appid?: string }) {
    wxLogin({ ...params, groupId: getItem(KEY_GROUP_ID) }).then((res: any) => {
      if (res.status === 0) {
        showSuccessMessage('登录成功');
        setItemUserInfo(KEYS.KEY_USER_INFO, JSON.stringify(res.result));
        setInitialState({ currentUser: res.result });
        history.push('/');
      }
    });
  }
};

export default Login;

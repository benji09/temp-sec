const env = REACT_APP_ENV === 'prod' ? '' : `${REACT_APP_ENV}.`;

export const HOST = `http://platform-admin.${env}yesdream.cn`;

export const COS_HOST = `https://cos-gateway.${env}yesdream.cn`;
export const COS_FILE_HOST = `https://file-${REACT_APP_ENV}-1304455996.cos.ap-shanghai.myqcloud.com`;
export const WX_REDIRECT_URL = `http://platforms.${env}yesdream.cn/user/login`;

export const POWER_HOST = `https://platforms-api.${env}yesdream.cn`;

export const BI_URL = (token?: string, device?: string) => {
  return env === 'poc.'
    ? ``
    : `http://bi.${env}yesdream.cn/login?device=${device}&token=${token}&link=http://bi.${env}yesdream.cn/superset/welcome/`;
};
export const FINANCE_BI_URL = (token?: string, device?: string) => {
  return env === 'poc.'
    ? ``
    : `http://fi-bi.${env}yesdream.cn/login?device=${device}&token=${token}&link=http://fi-bi.${env}yesdream.cn/superset/welcome/`;
};

const isProd = REACT_APP_ENV === 'prod';
export const AGENT_ID = {
  YJKJ: isProd ? 1000009 : 1000008,
  YJXB: isProd ? 1000003 : 1000002,
};

export const APP_ID = {
  YJKJ: 'wwfe7291fee5f0d04f',
  YJXB: 'ww7701f4f557789895',
};

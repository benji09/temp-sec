// @ts-ignore
import { request } from 'umi';
import dayjs from 'dayjs';

import KEYS from '@/utils/storageKeys';
import { mobilePhoneReg } from '@/utils/RegExp';
import { getItemUserInfo } from '@/utils/userInfoEncrypt';
import { showErrorMessage } from '@/mamagement/Notification';
import {
  checkIsNumberForSearch,
  cleanObject,
  HOST_TYPE_NORMAL,
  HOST_TYPE_OTHER,
  HOST_TYPE_POWER,
  RESULT_TYPE_TEXT,
} from '@/utils/utils';

import { COS_UPLOAD, COS_DOWN } from './consts';
import { COS_FILE_HOST, COS_HOST, POWER_HOST } from './hosts';

export const TIMEOUT = 30 * 1000;
export const DEFAULT_PAGE_SIZE = 20;

// POST 请求封装
export const postRequest = <T = any>(
  url: string,
  data: any = undefined,
  params: any = undefined,
  options: any = undefined,
) => {
  return request<T>(url, {
    method: 'POST',
    data,
    params,
    ...(options || {}),
  });
};

export const post = <T = any>(
  url: string,
  config: {
    data?: any;
    params?: any;
    options?: any;
    hostType?: number;
  },
) => {
  const { data, params, options, hostType = HOST_TYPE_NORMAL } = config;
  const _options = options ?? {};
  return postRequest<T>(url, data, params, { ..._options, type: hostType });
};

export const postFileRequest = <T = any>(
  url: string,
  data: any = undefined,
  timeout: number = TIMEOUT,
  options: any = undefined,
) => {
  return request<T>(url, {
    method: 'POST',
    data,
    timeout,
    ...(options || {}),
  });
};
// PUT 请求封装
export const putRequest = <T = any>(
  url: string,
  data: any = undefined,
  params: any = undefined,
  options: any = undefined,
) => {
  return request<T>(url, {
    method: 'PUT',
    data,
    params,
    ...(options || {}),
  });
};
// GET 请求封装
export const getRequest = <T = any>(
  url: string,
  params: any = undefined,
  options: any = undefined,
) => {
  return request<T>(url, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};
// GET 下载请求封装
export const getUpLoadRequest = <T = any>(
  url: string,
  params: any = undefined,
  responseType: string | undefined = undefined,
  options: any = undefined,
) => {
  return request<T>(url, {
    method: 'GET',
    params,
    ...(options || {}),
    responseType,
  });
};

/** 删除规则 DELETE /api/rule */
export async function removeRule(options?: Record<string, any>) {
  return request<Record<string, any>>('/api/rule', {
    method: 'DELETE',
    ...(options || {}),
  });
}

export async function uploadFile(
  options: any,
  onSuccess: (code: string) => any,
  onError?: (error: Error | null) => void | any,
) {
  const formData = new FormData();
  formData.append('file', options.file);

  request<APIS.CosResult>(COS_UPLOAD, {
    host: COS_HOST,
    type: HOST_TYPE_OTHER,
    method: 'POST',
    body: formData,
    timeout: 10 * 60 * 1000,
  })
    .then((res: any) => {
      if (res.code === 0) onSuccess(res.key || '');
      else onError?.(null);
    })
    .catch((err: Error | null) => {
      onError?.(err);
    });
}
// 上传PDF文件接口
export async function uploadPdfFile(
  options: any,
  onSuccess: (code: string) => any,
  onError?: (error: Error | null) => any,
) {
  const formData = new FormData();
  formData.append('file', options.file);
  request<APIS.CosResult>('/uploadFile/uploadPermanent', {
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  })
    .then((res: any) => {
      if (res.status === 0) onSuccess(res.result || '');
      else onError?.(null);
    })
    .catch((err: Error | null) => {
      onError?.(err);
    });
}
// 上传 EXCEL 文件接口
export const uploadExcel = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/anon/assistant/importScheduling', {
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};

export function getCosDownladUrl(key: string): string {
  if (key === undefined) return '';
  if (key === '' || key.startsWith('http')) return key;
  return `${COS_FILE_HOST}/${key}`;
}

// 登录
// export async function login(body: APIS.LoginParams, options: any = {}) {
//   return request<APIS.BaseResponse<APIS.UserInfo>>(`/login`, {
//     method: 'POST',
//     data: body,
//     ...(options || {}),
//   });
// }

// 登录
export async function login(body: APIS.LoginParams) {
  const { name, password } = body;
  return request<APIS.BaseResponse<APIS.UserInfo>>(`/operator/password-login`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'POST',
    data: { username: name, password },
  });
}

// 内容管理列表
export const contentList = async (params: APIS.listParams, options?: Record<string, any>) => {
  const { current, createdTime, id } = params;
  // const plate = ownedPlate?.join(',') || ''
  const checkIdResult = checkIsNumberForSearch(id, 'ID');
  if (checkIdResult !== null) return checkIdResult;
  params.createdTime = createdTime ? dayjs(createdTime).format('YYYY-MM-DD') : '';

  const msg = await request('/cms/content/list', {
    method: 'GET',
    params: {
      pageNo: current,
      ...params,
      // ownedPlate: plate
    },
    ...(options || {}),
  });
  return {
    data: msg.result.contents || [],
    total: msg.result.totalCount || 0,
  };
};

// 内容详情
export const contentDetail = async (params: APIS.detailParams, options: any = {}) => {
  return await request(`/cms/content/detail`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

// cms 外链配置列表
export const cmsLinkConfigList = async (params: APIS.detailParams, options: any = {}) => {
  return await request(`/cms/content/link/config/list`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

// cms 外链配置保存
export const cmsLinkConfigSave = async (params: APIS.SaveLinkConfig, options: any = {}) => {
  const formData = new FormData();
  formData.append('id', `${params.id}`);
  formData.append('params', `${params.params}`);
  return await request(`/cms/content/link/config/save`, {
    method: 'POST',
    data: formData,
    ...(options || {}),
  });
};

// 所属板块
export const contentOwnedPlate = async (options: any = {}) => {
  return await request(`/cms/content/listContentOwnedPlate`, {
    method: 'GET',
    params: {},
    ...(options || {}),
  });
};

// 推荐标签
export const recommendTag = async (options: any) => {
  return await request(`/cms/content/listRecommendTag`, {
    method: 'GET',
    params: {},
    ...(options || {}),
  });
};

// 更新推荐
export const updateRecommend = async (body: APIS.updateCommendParams, options: any = {}) => {
  return await request(`/cms/content/updateRecommendConfig`, {
    method: 'POST',
    data: body,
    ...(options || {}),
  });
};

/** 获取二维码信息 */
export const getQRCode = async (params: { id: number }, options: any = {}) => {
  return await request(`/cms/content/QRCode`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

/** 保存二维码信息 */
export const saveQRCode = async (body: APIS.saveCodeParams, options: any = {}) => {
  return await request(`/cms/content/saveContentQRCode`, {
    method: 'POST',
    data: body,
    ...(options || {}),
  });
};

// 获取用户权限信息和左边菜单栏
/** 初始化权限 */
export const initPower = async (options: any = {}) => {
  return await request(`/operator/list-user-operation`, {
    method: 'POST',
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    ...(options || {}),
  });
};

// 更新推荐
export const cmsAddOrUpdate = async (body: APIS.CmsAddOrUpdate, options: any = {}) => {
  return await request(`/cms/content/addOrUpdate`, {
    method: 'POST',
    data: body,
    ...(options || {}),
  });
};

// 问卷列表
export async function getAppraisalManageList(
  params: APIS.AppraisalManageList,
  options?: Record<string, any>,
) {
  const { current, pageSize, ...data } = params;
  let { assessmentId, userId } = params;
  // const checkUserId = !(userId && !userId.match(/\d+/));
  // if ((assessmentId && !assessmentId.match(/\d+/)) || !checkUserId) {
  //   return {
  //     data: [],
  //     total: 0,
  //   };
  // }
  userId = userId?.trim();
  assessmentId = assessmentId?.trim();
  const checkUserId = checkIsNumberForSearch(userId, '用户 ID');
  if (checkUserId !== null) return checkUserId;
  const checkAssessmentId = checkIsNumberForSearch(assessmentId, 'ID');
  if (checkAssessmentId !== null) return checkAssessmentId;

  const msg = await request(`/question/questionnaireList`, {
    method: 'GET',
    params: {
      page: current,
      size: pageSize,
      ...data,
      id: assessmentId,
      // && assessmentId.trim().length > 0 ? assessmentId : undefined
      userId: userId,
      //  && userId.trim().length > 0 ? userId : undefined
    },
    ...(options || {}),
  });
  if (msg.status === 0) {
    return {
      data: msg.result.content,
      total: msg.result.totalElements,
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
}
// 问卷列表详情
export async function questionnaireDetails(
  assessmentId?: number | string,
  options?: Record<string, any>,
) {
  return request('/question/questionnaire', {
    method: 'GET',
    params: { assessmentId },
    ...(options || {}),
  });
}

// 获取标准方列表
export async function getStandardModeList(
  params: APIS.StandardModeList,
  options?: Record<string, any>,
) {
  const { current, id, ...data } = params;
  const checkIdResult = checkIsNumberForSearch(id, 'ID');
  if (checkIdResult !== null) return checkIdResult;

  const msg = await request(`/medicine/list`, {
    method: 'GET',
    params: {
      pageNo: params.current,
      formulaId: params.id,
      ...data,
    },
    ...(options || {}),
  });
  return {
    data: msg.result.herbFormulaListInfos,
    total: msg.result.totalCount,
  };
}
// 标准方详情
export async function getStandardModeDetail(id?: number | string, options?: Record<string, any>) {
  return request(`/medicine/detail`, {
    method: 'GET',

    params: { id },
    ...(options || {}),
  });
}

// 通过药材名字查询药材（模糊搜索）
export async function getHerbName(herbName?: string, options?: Record<string, any>) {
  return request(`/medicine/herbName`, {
    method: 'GET',

    params: { herbName },
    ...(options || {}),
  });
}
// 通过药材Id查询药材
export async function getHerbId(id?: number, options?: Record<string, any>) {
  return request(`/medicine/herb/detail`, {
    method: 'GET',

    params: { id },
    ...(options || {}),
  });
}
// 标准方修改或新建的保存
export async function StandardModeSaveOrUpdate(
  data?: APIS.StandardModeSaveOrUpdate,
  options?: Record<string, any>,
) {
  return await request(`/medicine/saveOrUpdate`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
// 中药SKU列表
export const getSKUList = async (params: APIS.medicalParams, options?: Record<string, any>) => {
  const { current, pageSize, skuId, herbName, status } = params;
  const checkIdResult = checkIsNumberForSearch(skuId, 'SKU');
  if (checkIdResult !== null) return checkIdResult;

  const msg = await request(`/medicine/herbs`, {
    method: 'GET',

    params: {
      pageNo: current,
      pageSize,
      skuId,
      herbName,
      status,
    },
    ...(options || {}),
  });
  return {
    data: msg.result.herbs,
    total: msg.result.totalCount,
  };
};
// 中药 SKU 上下架
export async function modifySkuStatus(
  data?: { id: number; status: number },
  options?: Record<string, any>,
) {
  return await request(`/medicine/status`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
/** 测评列表 */
export const templateList = async (params: APIS.listParams, options?: Record<string, any>) => {
  const { pageSize, current, id } = params;
  let questionId = undefined;

  const checkIdResult = checkIsNumberForSearch(id, 'ID');
  if (checkIdResult !== null) return checkIdResult;

  if (id && id.toString().trim().length > 0) {
    questionId = id;
  }
  const page = current;
  const size = pageSize;
  let name = undefined;

  if (params.name && params.name.trim().length > 0) name = params.name;

  delete params.name;
  delete params.id;
  delete params.current;
  delete params.pageSize;

  const msg = await request(`/question/templateList`, {
    method: 'GET',
    params: {
      page,
      size,
      questionId,
      name,
      ...params,
    },
    ...(options || {}),
  });
  return {
    data: msg?.result?.content || [],
    total: msg?.result?.totalElements || 0,
  };
};
// 运动计划和饮食计划列表
export async function planList(cat?: string, options?: Record<string, any>) {
  return await request(`/plan/pageList`, {
    method: 'GET',
    params: {
      page: 1,
      size: 999,
      cat: cat,
    },
    ...(options || {}),
  });
}

// 保存修改评估
export async function ProcessAssessment(
  data?: APIS.processAssessment,
  options?: Record<string, any>,
) {
  return await request(`/question/processAssessment`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 修改评估备注
export function AssessmentRemark(
  data: { assessmentId?: string; remark?: string },
  options?: Record<string, any>,
) {
  return request<APIS.BaseResponse<string>>(`/question/assessmentRemark`, {
    method: 'PUT',
    data,
    ...(options || {}),
  });
}
// 获取文件信息（img pdf）
export async function fileDetail(key: string, type: number, options?: Record<string, any>) {
  return await request(`/question/fileDetail`, {
    method: 'GET',
    params: { key, type },
    ...(options || {}),
  });
}
// 拼接用户文件的链接
export function getCosDownlad(key: string): string {
  if (key === undefined) return '';
  if (key === '' || key.startsWith('http')) return key;
  return `${COS_HOST}${COS_DOWN}${key}`;
}

/** 获取标签组 */
export const labelGroups = async (params: any = {}, options: any = {}) => {
  return await request(`/question/labelGroups`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

/** 添加标签 */
export const addLabels = async (params: any, options = {}) => {
  return await request<APIS.BaseResponse<any>>(`/question/labels`, {
    method: 'POST',
    data: params,
    ...(options || {}),
  });
};

/** 获取标签 */
export const labelLists = async (params: any = {}, options = {}) => {
  return await request(`/question/labelList`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

/** 添加标签 */
export const searchLabels = async (params: any = {}, options = {}) => {
  return await request(`/question/labels`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

export const createQuestion = async (params: any = {}, options = {}) => {
  return await request(`/question`, {
    method: 'POST',
    data: params,
    ...(options || {}),
  });
};

/** 搜索问题 */
export const searchQuestion = async (params: any = {}, options = {}) => {
  return await request(`/question`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

// 获取食品分类列表
export const getCategoryList = () =>
  request('/pantry/categoryList', {
    method: 'GET',
  });

// 添加或修改计划
export const postPlan = (data: { planId: any }) =>
  request('/plan', {
    method: data.planId ? 'PUT' : 'POST',
    data,
  });

// 获取计划列表
export const getPlans = (params: { planId: any; cat: number; page: number; size: number }) =>
  request('/plan/pageList', {
    method: 'GET',
    params,
  });

// 添加计划阶段
export const addPlanStage = (data: {
  cat?: number;
  sort?: any;
  planId?: any;
  followStageId?: string | number;
}) =>
  request('/plan/stage', {
    method: 'POST',
    data,
  });

// 删除计划阶段
export const delPlanStage = (data: {
  stageId: any;
  planId: any;
  cat: number;
  followStageId: any;
}) =>
  request('/plan/stage', {
    method: 'DELETE',
    data,
  });

// 获取计划阶段列表
export const getPlanStages = (planId: any) =>
  request('/plan/planStageList', {
    method: 'GET',
    params: { planId },
  });

// 获取计划阶段详情
export const getPlanStage = (stageId: any) =>
  request('/plan/listPlanFood', {
    method: 'GET',
    params: { stageId },
  });

// 获取运动计划阶段详情
export const getSportPlanStage = (stageId: any) =>
  request('/plan/listExercisePlanStageDetail', {
    method: 'GET',
    params: { stageId },
  });

// 添加或修改计划
export const addOrModifyPlan = async (params: any = {}, options = {}) => {
  const { planId } = params;
  let method = 'POST';
  if (planId) method = 'PUT';
  return await request(`/plan`, {
    method,
    data: params,
    ...(options || {}),
  });
};

// 食品库
export const getFoodList = async (params: any = {}, options = {}) => {
  const { pantryId } = params;
  const checkPantryIdResult = checkIsNumberForSearch(pantryId, 'ID');
  if (checkPantryIdResult !== null) return checkPantryIdResult;

  const msg = await request('/pantry/foodList', {
    method: 'GET',
    params,
    ...(options || {}),
  });
  if (msg.status === 0) {
    return {
      data: msg.result.content,
      total: msg.result.totalElements,
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
};
// 同上一个阶段处理
export const followPlanStage = (data: { cat: number; stages: never[] }) =>
  request('/plan/followPlanStage', {
    method: 'POST',
    data,
  });

// CMS ID  或 内容标题模糊搜索
export async function getSimpleCMSInfo(
  title?: string,
  type?: number,
  options?: Record<string, any>,
) {
  return request(`/cms/content/plan/search`, {
    method: 'GET',

    params: { title, type },
    ...(options || {}),
  });
}

// 修改阶段详情
export const modifyPlanStage = (data: any) =>
  request('/plan/batchPlanStage', {
    method: 'PUT',
    data,
  });

// 新增食品库
export const addFoodList = async (params: any = {}, options = {}) => {
  return await request('/pantry', {
    method: 'POST',
    data: params,
    ...(options || {}),
  });
};

// 新增修改
export const changeFoodList = async (params: any = {}) => {
  return request('/pantry', {
    method: 'PUT',
    data: params,
  });
};

/** 获取食品分类列表 */
export const categoryList = async (params: any = {}, options = {}) => {
  return await request(`/pantry/categoryList`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

export const searchTagList = async (params: any = {}, options = {}) => {
  return await request(`/cms/content/three/tag`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

export const queryDrugOrder = async (params: any = {}, options = {}) => {
  const {
    pageSize,
    current,
    applicantMobile,
    insuredCode: insuredCode1,
    policyCode: policyCode1,
    policyStatus: policyStatus1,
    refundStatus: refundStatus1,
    timeRange,
  } = params;
  const mobile = applicantMobile && applicantMobile.trim().length > 0 ? applicantMobile : undefined;
  const insuredCode = insuredCode1 && insuredCode1.trim().length > 0 ? insuredCode1 : undefined;
  const policyCode = policyCode1 && policyCode1.trim().length > 0 ? policyCode1 : undefined;
  const policyStatus = policyStatus1 && policyStatus1.trim().length > 0 ? policyStatus1 : undefined;
  const refundApplyStatus =
    refundStatus1 && refundStatus1.trim().length > 0 ? refundStatus1 : undefined;
  const dealStartAt =
    timeRange && timeRange.length === 2 ? dayjs(`${timeRange[0]} 00:00:00`).valueOf() : undefined;
  const dealEndIn =
    timeRange && timeRange.length === 2 ? dayjs(`${timeRange[1]} 23:59:59`).valueOf() : undefined;
  const msg = await request(`/drugOrder/list`, {
    method: 'GET',
    params: {
      page: current - 1,
      size: pageSize,
      mobile,
      insuredCode,
      policyCode,
      policyStatus,
      refundApplyStatus,
      dealStartAt,
      dealEndIn,
    },
    ...(options || {}),
  });
  return {
    data: msg.content || [],
    total: msg.totalElements || 0,
  };
};

// 查询真实信息
export const queryRealInfo = async (params: any = {}, options = {}) => {
  return await request(`/drugOrder/getPolicySecrecyInfo`, {
    method: 'POST',
    data: {
      secrecy: 1,
      source: 0,
      ...params,
    },
    ...(options || {}),
  });
};

// 回访列表
export const getReturnVisitnList = async (
  params: {
    pageSize?: number | undefined;
    current?: number | undefined;
    userId?: string;
    applyMobile?: string;
  },
  options?: Record<string, any>,
) => {
  const { current, pageSize, userId, applyMobile } = params;
  const checkuserIdResult = checkIsNumberForSearch(userId, 'ID');
  if (checkuserIdResult !== null) return checkuserIdResult;

  const msg = await request(`/doctor/list`, {
    method: 'GET',
    params: {
      userId,
      applyMobile,
      page: (current || 1) - 1,
      size: pageSize,
    },
    ...(options || {}),
  });
  return {
    data: msg.result.data || [],
    total: msg.result.total || 0,
  };
};
// 回访列表中的查看手机号
export const ReturnVisitnseeMobile = async (applyId: number, options?: Record<string, any>) => {
  return request(`/provider/seeMobile`, {
    method: 'GET',
    params: {
      token: getItemUserInfo(KEYS.KEY_USER_INFO)?.token,
      userId: applyId,
    },
    ...(options || {}),
  });
};
// 医疗服务订单列表
export const getMedicalOrders = async (
  params: {
    orderId?: number;
    doctorName?: string;
    orderType?: number;
    providerId?: number;
    userId?: number;
    TimeDate?: string[];
    pageSize?: number;
    current?: number;
    assistantName?: string;
  },
  options?: Record<string, any>,
) => {
  const { current, pageSize, TimeDate, orderId, orderType, userId, providerId } = params;
  const orderIdResult = checkIsNumberForSearch(orderId, '订单ID');
  const userIdResult = checkIsNumberForSearch(userId, 'userId');
  const providerIdResult = checkIsNumberForSearch(providerId, 'providerId');

  const doctorName =
    params.doctorName && params.doctorName.trim().length > 0 ? params.doctorName : undefined;
  const assistantName =
    params.assistantName && params.assistantName.trim().length > 0
      ? params.assistantName
      : undefined;

  if (userIdResult !== null) return userIdResult;
  if (orderIdResult !== null) return orderIdResult;
  if (providerIdResult !== null) return providerIdResult;

  const startTime =
    TimeDate && TimeDate.length === 2 ? dayjs(`${TimeDate[0]} 00:00:00`).valueOf() : undefined;
  const endTime =
    TimeDate && TimeDate.length === 2 ? dayjs(`${TimeDate[1]} 23:59:59`).valueOf() : undefined;

  if (
    startTime ||
    endTime ||
    orderId ||
    orderType ||
    doctorName ||
    userId ||
    providerId ||
    assistantName
  ) {
    const msg = await request(`/order/list`, {
      method: 'GET',
      params: {
        page: (current || 1) - 1,
        size: pageSize,
        startTime: startTime,
        endTime: endTime,
        orderId,
        orderType,
        doctorName,
        assistantName,
        userId: userId,
        providerId,
      },
      ...(options || {}),
    });
    return {
      data: msg.content || [],
      total: msg.totalElements || 0,
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
};
// 获取订单详情
export const OrderDetailsData = async (orderId?: number, options?: Record<string, any>) => {
  return request(`/order/detail`, {
    method: 'GET',
    params: {
      orderId,
    },
    ...(options || {}),
  });
};

// 添加订单备注
export const orderNotes = async (
  data: { orderId?: number | string; remark?: string },
  options?: Record<string, any>,
) => {
  return request(`/order/orderNotes`, {
    method: 'PUT',
    data,
    ...(options || {}),
  });
};
// 获取用户手机号
export const OrderDetailsMobile = async (
  userId?: number | string,
  options?: Record<string, any>,
) => {
  return request(`/order/seeMobile`, {
    method: 'GET',
    params: { userId },
    ...(options || {}),
  });
};

// 获取订单中聊天记录
export const getChitchatList = async (
  params: {
    orderId?: number | string;
    size?: number;
    page?: number;
  },
  options?: Record<string, any>,
) => {
  return request(`/order/chatRecord`, {
    method: 'GET',
    params: params,
    ...(options || {}),
  });
};

// 获取订单中开药详情
export const getPrescribeList = async (orderId?: string, options?: Record<string, any>) => {
  return request(`/order/prescription`, {
    method: 'GET',
    params: { orderId },
    ...(options || {}),
  });
};

// 客服聊天记录数据列表
export const getServiceChat = async (
  params: APIS.getServiceChatType,
  options?: Record<string, any>,
) => {
  const { current, pageSize, TimeDate, orderId, userId, assistantId } = params;
  const orderIdResult = checkIsNumberForSearch(orderId, '订单ID');
  const userIdResult = checkIsNumberForSearch(userId, 'userId');
  const assistantIdResult = checkIsNumberForSearch(assistantId, '客服ID');

  const assistantName =
    params.assistantName && params.assistantName.trim().length > 0
      ? params.assistantName
      : undefined;

  if (userIdResult !== null) return userIdResult;
  if (orderIdResult !== null) return orderIdResult;
  if (assistantIdResult !== null) return assistantIdResult;

  const startTime =
    TimeDate && TimeDate.length === 2 ? dayjs(`${TimeDate[0]} 00:00:00`).valueOf() : undefined;
  const endTime =
    TimeDate && TimeDate.length === 2 ? dayjs(`${TimeDate[1]} 23:59:59`).valueOf() : undefined;

  if (startTime || endTime || orderId || assistantName || userId || assistantId) {
    const msg = await request(`/consult-order/list-cs-order`, {
      method: 'POST',
      data: {
        page: current,
        size: pageSize,
        startTime,
        endTime,
        orderId,
        assistantName,
        assistantId,
        userId,
      },
      ...(options || {}),
    });
    return {
      data: msg.content || [],
      total: msg.totalElements || 0,
    };
  } else {
    return {
      // orderId: 19648
      data: [],
      total: 0,
    };
  }
};
// 客服聊天记录数据列表
export const ServiceChatDetails = async (orderId: number, options?: Record<string, any>) => {
  const data = await request(`/consult-order/list-cs-order`, {
    method: 'POST',
    data: { orderId, page: 1, size: 1 },
    ...(options || {}),
  });
  const remark = await request(`/consult-order/find-cs-detailed-order`, {
    method: 'POST',
    data: { orderId },
    ...(options || {}),
  });
  return { ...data.content[0], remark };
};

// 查询药无忧订单详情
export const queryDrugOrderDetail = async (params: any = {}, options = {}) => {
  return await request(`/drugOrder/policyDetail`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

// 权限检查
export const hasPower = async (powerId: number, params: any = {}, options = {}) => {
  return await request(`/menu/isPower`, {
    method: 'GET',
    params: {
      powerId,
      ...params,
    },
    ...(options || {}),
  });
};

// 药无忧订单，申请退款
export const applyDrugOrderRefund = async (
  policyPhaseId: number,
  params: any = {},
  options = {},
) => {
  return await request(`/drugOrder/submitRefundApply`, {
    method: 'POST',
    data: {
      policyPhaseId,
      ...params,
    },
    ...(options || {}),
  });
};

// 药无忧订单，处置退款申请订单
export const handleDrugOrderRefund = async (
  refundApplyId: string,
  applyStatus: number,
  refundAmount: number,
  refundReason: string,
  params: any = {},
  options = {},
) => {
  return await request(`/drugOrder/processRefundApply`, {
    method: 'POST',
    data: {
      refundApplyId,
      applyStatus,
      refundAmount,
      refundReason,
      ...params,
    },
    ...(options || {}),
  });
};
// 企业微信扫码登录
export const wxLogin = async (formData: any) => {
  const { code, groupId } = formData;
  const msg = await request(`/operator/corp-wechat-login`, {
    method: 'POST',
    type: HOST_TYPE_POWER,
    data: { code, groupId },
  });
  return msg;
};

// 医生账号管理列表
export const getProviderList = async (
  params: APIS.getProviderListType,
  options?: Record<string, any>,
) => {
  const { current, pageSize, providerId, name, tags } = params;
  const checkproviderIdResult = checkIsNumberForSearch(providerId, 'Provider_ID');
  if (checkproviderIdResult !== null) return checkproviderIdResult;

  const msg = await request(`/provider/list`, {
    method: 'GET',
    params: {
      providerId,
      name,
      tags: tags || [],
      page: (current || 1) - 1,
      size: pageSize,
    },
    ...(options || {}),
  });
  return {
    data: msg.content || [],
    total: msg.totalElements || 0,
  };
};

// 查询详情
export const getProviderDetail = async (providerId: number, params: any = {}, options = {}) => {
  return await request(`/provider/basic`, {
    method: 'GET',
    params: {
      providerId,
      ...params,
    },
    ...(options || {}),
  });
};

// 增加 Provider
export const addProvider = async (params: any = {}, options = {}) => {
  return await request(`/provider`, {
    method: 'POST',
    data: { ...params },
    ...(options || {}),
  });
};

// 修改 Provider
export const modifyProvider = async (params: any = {}, options = {}) => {
  return await request(`/provider/basic`, {
    method: 'PUT',
    data: { ...params },
    ...(options || {}),
  });
};

// 判断是否能选择（保健团/工作组）选项
export const getProviderCheckable = async (
  providerId: number,
  type: number,
  params: any = {},
  options = {},
) => {
  return await request(`/provider/isCancelCheck`, {
    method: 'GET',
    params: {
      providerId,
      type,
      ...params,
    },
    ...(options || {}),
  });
};

// 检测 CA 签章
export const verifyCaOpenId = async (
  providerId: number,
  caOpenId: string,
  params: any = {},
  options = {},
) => {
  return await request(`/provider/checkCaOpenId`, {
    method: 'PUT',
    data: {
      providerId,
      caOpenId,
      ...params,
    },
    ...(options || {}),
  });
};

// 修改 Provider
export const modifyProviderSettings = async (params: any = {}, options = {}) => {
  return await request(`/provider/settings`, {
    method: 'PUT',
    data: {
      ...params,
    },
    ...(options || {}),
  });
};

// 查询助手信息
export const getAssistantList = async (params: any = {}, options = {}) => {
  return await request(`/assistant/list`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

// 绑定助手信息
export const bindAssistants = async (data: APIS.BindAssistantItem[], options = {}) => {
  return await request(`/provider/bind`, {
    method: 'PUT',
    data,
    ...(options || {}),
  });
};

// 查询部门信息
export const getDepartmentList = async (params: any = {}, options = {}) => {
  return await request(`/provider/departmentList`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};

// 查询擅长标签信息
export const getProviderTags = async (params: any = {}, options = {}) => {
  return await request(`/provider/tags`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
};
// 查询绑定信息
export const getBindSize = async (providerId: number, params: any = {}, options = {}) => {
  return await request(`/provider/bindSize`, {
    method: 'GET',
    params: {
      providerId,
      ...params,
    },
    ...(options || {}),
  });
};

// 权益管理列表
export const getRightsList = async (
  params: APIS.RightsRequestParam,
  options?: Record<string, any>,
) => {
  const checkUserId = checkIsNumberForSearch(params.userId, 'UserID');
  if (checkUserId !== null) return checkUserId;

  if (!params.userId) {
    return {
      data: [],
      total: 0,
    };
  }

  const { pageSize, current, ...data } = params;

  const msg = await request(`/rights/list-user-card`, {
    method: 'POST',
    data: {
      ...cleanObject(data),
    },
    ...(options || {}),
  });

  let responseData: any[] = [];
  const responseTotal = (msg?.result || []).length;
  if (responseTotal > 0) {
    const startIndex = ((current || 1) - 1) * (pageSize || DEFAULT_PAGE_SIZE);
    const endIndex = startIndex + (pageSize || DEFAULT_PAGE_SIZE);
    responseData = msg.result.slice(startIndex, Math.min(responseTotal, endIndex));
  }

  return {
    data: responseData,
    total: responseTotal,
  };
};

// 权益详情
export const getRightsDetail = async (cardId: string, options?: Record<string, any>) => {
  const msg = await request(`/rights/find-detailed-card`, {
    method: 'POST',
    data: { cardId },
    ...(options || {}),
  });
  return msg;
};

// 禁用权益
export const disableRights = async (rightsId: string, options?: Record<string, any>) => {
  const msg = await request(`/rights/disable-rights`, {
    method: 'POST',
    data: { rightsId },
    ...(options || {}),
  });
  return msg;
};
// 解除禁用权益
export const openRights = async (rightsId: string, options?: Record<string, any>) => {
  const msg = await request(`/rights/cancel-rights-disable`, {
    method: 'POST',
    data: { rightsId },
    ...(options || {}),
  });
  return msg;
};

/**
 * 查看保单隐私信息
 * @param policyId 保单记录Id
 * @param secrecy 1：投保人/购买人电话 2：被保险人/使用人电话 3：证件号
 */
export const getPolicySecrecyInfo = async (
  policyId: string,
  secrecy: number,
  params: any = {},
  options = {},
) => {
  return await request(`/yg/center/policy-secrecy-info`, {
    method: 'GET',
    params: {
      policyId,
      secrecy,
      ...params,
    },
    ...(options || {}),
  });
};

// 获取操作员列表
export const getRoleSetList = async (
  params: APIS.RoleSetListType,
  options?: Record<string, any>,
) => {
  const { pageSize, current, mobile } = params;
  const name = params.name && params.name.trim().length > 0 ? params.name : undefined;

  const mobileResult = checkIsNumberForSearch(mobile, '手机号');
  if (mobileResult !== null) return mobileResult;

  const msg = await request(`/operator/list`, {
    method: 'GET',
    params: {
      page: (current || 1) - 1,
      size: pageSize,
      name,
      mobile,
    },
    ...(options || {}),
  });
  return {
    data: msg.content || [],
    total: msg.totalElements || 0,
  };
};

// 获取角色列表
export const getRoleList = async (operatorId: number | string, options = {}) => {
  return await request(`/operator/roleList`, {
    method: 'GET',
    params: {
      operatorId,
    },
    ...(options || {}),
  });
};
// 修改用户角色
export const EditRoleList = async (
  data: { operatorId: number | string; roleIds: number[] },
  options?: Record<string, any>,
) => {
  return request<APIS.BaseResponse<string>>(`/operator/role`, {
    method: 'PUT',
    data,
    ...(options || {}),
  });
};

// work列表
export async function getWorkList(options?: Record<string, any>) {
  const msg = await request<APIS.BaseResponse<APIS.getWorkListType>>(`/work/get/room/open/info`, {
    method: 'GET',
    ...(options || {}),
  });
  if (msg.status === 0) {
    return {
      data: msg.result || [],
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
}

// 菜单列表
export async function getMenuListList(options?: Record<string, any>) {
  const msg = await request<APIS.BaseResponse<APIS.menuListSons[]>>(`/menu/list`, {
    method: 'GET',
    ...(options || {}),
  });
  if (msg.status === 0) {
    return {
      data: msg.result || [],
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
}
// 点击菜单显示隐藏
export async function setMenuListShow(menuId?: number, options?: Record<string, any>) {
  return request(`/trigger?menuId=${menuId}`, {
    method: 'PUT',
    ...(options || {}),
  });
}
// 菜单中获取每个菜单的角色分布
export async function RoleList(menuId?: number, options?: Record<string, any>) {
  return request<APIS.BaseResponse<APIS.roleListType[]>>(`/menu/roleList`, {
    method: 'GET',
    params: { menuId },
    ...(options || {}),
  });
}
// 编辑 新增菜单列表
export async function setMenuList(
  data: { description: string; menuName: string; parentId: string; url: string },
  method: string,
  options?: Record<string, any>,
) {
  return request(`/menu`, {
    method: method,
    data,
    ...(options || {}),
  });
}

export async function RelationRoleAndMenu(
  data: { menuId?: number; roleIdList?: number[] },
  options?: Record<string, any>,
) {
  return request<APIS.BaseResponse<APIS.roleListType[]>>(`/menu/relationRoleAndMenu`, {
    method: 'PUT',
    data,
    ...(options || {}),
  });
}

export async function assistantList(
  params: {
    pageSize?: number;
    current?: number;
    assistantId?: string | number;
    name?: string;
    login?: string;
    mobile?: string | number;
  },
  options?: Record<string, any>,
) {
  const { pageSize, current, assistantId, name, login: loginData, mobile } = params;

  const assistantIdResult = checkIsNumberForSearch(assistantId, 'ID');
  if (assistantIdResult !== null) return assistantIdResult;

  const mobileResult = checkIsNumberForSearch(mobile, '手机号');
  if (mobileResult !== null) return mobileResult;

  const msg = await request(`/assistant/list`, {
    method: 'GET',
    params: {
      page: (current || 1) - 1,
      size: pageSize,
      assistantId,
      name,
      login: loginData,
      mobile,
    },
    ...(options || {}),
  });
  return {
    data: msg.content || [],
    total: msg.totalElements || 0,
  };
}
// 新增助手
export async function EditorAddAssistant(data: any, method: string, options?: Record<string, any>) {
  return await request(`/assistant`, {
    method,
    data,
    ...(options || {}),
  });
}
// 查看助手手机号
export async function LookAssistantMobile(assistantId?: number, options?: Record<string, any>) {
  return await request(`/assistant/seeMobile`, {
    method: 'GET',
    params: {
      assistantId,
      token: getItemUserInfo(KEYS.KEY_USER_INFO).token,
    },
    ...(options || {}),
  });
}

// 获取康无忧保健团信息
export async function getHealthcareGroup(providerId?: number, options?: Record<string, any>) {
  return await request(`/provider/kwyHealthcareGroup`, {
    method: 'GET',
    params: {
      providerId,
    },
    ...(options || {}),
  });
}
// 保存康无忧保健团信息
export async function kwyHealthcareGroup(
  data?: APIS.kwyHealthcareGroupType,
  options?: Record<string, any>,
) {
  return await request(`/provider/kwyHealthcareGroup`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
// 获取儿科工作组信息
export async function getChildrenWorkGroup(providerId?: number, options?: Record<string, any>) {
  return await request(`/provider/childrenWorkGroup`, {
    method: 'GET',
    params: {
      providerId,
    },
    ...(options || {}),
  });
}
// 保存儿科工作组信息
export async function childrenWorkGroup(
  data?: APIS.kwyHealthcareGroupType,
  options?: Record<string, any>,
) {
  return await request(`/provider/childrenWorkGroup`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 清空保健团
export async function cleanKwyHealthcareGroup(providerId?: number, options?: Record<string, any>) {
  return await request(`/provider/cleanKwyHealthcareGroup`, {
    method: 'PUT',
    params: { providerId },
    ...(options || {}),
  });
}
// 清空工作组
export async function cleanChildrenWorkGroup(providerId?: number, options?: Record<string, any>) {
  return await request(`/provider/cleanChildrenWorkGroup`, {
    method: 'PUT',
    params: { providerId },
    ...(options || {}),
  });
}
// 校验助手账号名是否唯一值
export async function isExistLogin(loginData?: string, options?: Record<string, any>) {
  return await request(`/login/isExistLogin`, {
    method: 'post',
    data: {
      device: getItemUserInfo(KEYS.KEY_USER_INFO).device,
      login: loginData,
    },
    ...(options || {}),
  });
}

// 叮当订单查询
export const ddOrderList = async (
  params: APIS.DDOrderRequestParam,
  options?: Record<string, any>,
) => {
  if (!params.userId && !params.mobile)
    return {
      data: [],
      total: 0,
    };

  const checkUserId = checkIsNumberForSearch(params.userId, 'UserID');
  if (checkUserId !== null) return checkUserId;
  const checkMobile = checkIsNumberForSearch(params.mobile, '手机号');
  if (checkMobile !== null) return checkMobile;

  if ((params.mobile || '').trim().length > 0 && !mobilePhoneReg(params.mobile || '')) {
    showErrorMessage('请输入正确的手机号');
    return {
      data: [],
      total: 0,
    };
  }

  const { pageSize, current, ...data } = params;

  const msg = await request(`/dd/order/listByUserId`, {
    method: 'GET',
    params: {
      ...cleanObject(data),
    },
    ...(options || {}),
  });

  let responseData: any[] = [];
  const responseTotal = (msg?.result || []).length;
  if (responseTotal > 0) {
    const startIndex = ((current || 1) - 1) * (pageSize || DEFAULT_PAGE_SIZE);
    const endIndex = startIndex + (pageSize || DEFAULT_PAGE_SIZE);
    responseData = msg.result.slice(startIndex, Math.min(responseTotal, endIndex));
  }

  return {
    data: responseData,
    total: responseTotal,
  };
};

// 药无忧销售记录列表
export async function getDrugOrderSellList(
  params: APIS.getDrugOrderSellType,
  options?: Record<string, any>,
) {
  const { current, pageSize, ...data } = params;

  if (data.orderNo) {
    const msg = await request<APIS.BaseResponse<APIS.getDrugOrderSellListType>>(
      `/yg/center/sale-log`,
      {
        method: 'POST',
        data,
        ...(options || {}),
      },
    );
    return {
      data: msg.result !== null ? [msg.result] : [],
      total: msg.result !== null ? [msg.result].length : 0,
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
}
// 药无忧销售记录查看详情
export async function policySecrecyInfo(
  data: { orderNo?: string; userId?: string },
  options?: Record<string, any>,
) {
  return await request<APIS.BaseResponse<APIS.policySecrecyInfoType>>(
    `/yg/center/find-sale-detail`,
    {
      method: 'POST',
      data,
      ...(options || {}),
    },
  );
}
// 开票信息回显
export async function getFindInvoice(logId: string, options?: Record<string, any>) {
  return await request(`/yg/center/find-invoice`, {
    method: 'POST',
    data: { logId },
    ...(options || {}),
  });
}

// 保存开票信息
export async function saleOpenInvoice(
  data: APIS.saleOpenInvoiceDataType,
  options?: Record<string, any>,
) {
  return await request(`/yg/center/sale-open-invoice`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
// 退款信息回显
export async function getFindRefund(logId: string, options?: Record<string, any>) {
  return await request(`/yg/center/find-refund`, {
    method: 'POST',
    data: { logId },
    ...(options || {}),
  });
}
// 保存退款信息
export async function saleRefund(data: APIS.saleRefundDataType, options?: Record<string, any>) {
  return await request(`/yg/center/sale-refund`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 药品订单查询列表
async function queryOrderEnquiry(
  apiName: string,
  params: APIS.OrderListParams,
  options?: Record<string, any>,
) {
  const UserIdResult = checkIsNumberForSearch(params.userId, 'ID');
  if (UserIdResult !== null) return UserIdResult;

  if (params.mobile || params.userId || params.orderNo || params.deliveryNo) {
    return await request(apiName, {
      method: 'GET',
      params,
      ...(options || {}),
    });
  } else {
    return {
      message: '',
      result: { data: [], total: 0 },
      status: 0,
    };
  }
}
// 叮当
export async function getDdOrderEnquiry(
  params: APIS.OrderListParams,
  options?: Record<string, any>,
) {
  return await queryOrderEnquiry(`/medicine/orderList/dingdang`, params, options);
}
// 小药药
export async function getXyyOrderEnquiry(
  params: APIS.OrderListParams,
  options?: Record<string, any>,
) {
  return await queryOrderEnquiry(`/medicine/orderList/xiaoyaoyao`, params, options);
}
// 宝中堂
export async function getBztOrderEnquiry(
  params: APIS.OrderListParams,
  options?: Record<string, any>,
) {
  return await queryOrderEnquiry(`/medicine/orderList/baozhongtang`, params, options);
}
// 商城购药订单
export async function getMallOrderEnquiry(
  params: APIS.OrderListParams,
  options?: Record<string, any>,
) {
  return await queryOrderEnquiry(`/medicine/orderList/mall`, params, options);
}
// 药品订单查询详情
export async function getOrderDetail(
  params: { orderId?: string; thirdBusiness?: number },
  options?: Record<string, any>,
) {
  return await request(`/medicine/order/detail`, {
    method: 'GET',
    params,
    ...(options || {}),
  });
}
// 处方作废
export async function medicineInvalid(
  data: { orderId?: string; thirdBusiness?: number; signId?: string },
  options?: Record<string, any>,
) {
  return await request(`/medicine/invalid`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 发放权益卡管理列表
export async function customerCardPalletList(
  params: { current?: number; pageSize?: number; mobile?: string; userId?: string },
  options?: Record<string, any>,
) {
  const { current, pageSize, mobile, userId } = params;

  const UserIdResult = checkIsNumberForSearch(userId, 'userId');
  if (UserIdResult !== null) return UserIdResult;
  const MobileResult = checkIsNumberForSearch(mobile, '手机号');
  if (MobileResult !== null) return MobileResult;

  if (mobile || userId) {
    const msg = await request<APIS.BaseResponse<APIS.CustomerCardPalletListType>>(
      `/customer-list-customer-card-pallet`,
      {
        method: 'POST',
        data: { userId: userId || '', mobile: mobile || '', page: current, size: pageSize },
        ...(options || {}),
      },
    );
    return {
      data: msg.result !== null && msg.status === 0 ? msg.result.content : [],
      total: msg.result !== null && msg.status === 0 ? msg.result.totalElements : 0,
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
}
// 权益卡关闭
export async function customerCloseCard(cardId?: string, options?: Record<string, any>) {
  return await request(`/customer-close-card`, {
    method: 'POST',
    data: { cardId },
    ...(options || {}),
  });
}

// 发卡权益卡详情
export async function CustomerFindDetailed(
  data: {
    cardId: string;
    gainWay: string;
    relationshipNumber: string;
    skuNo: string;
  },
  options?: Record<string, any>,
) {
  return await request(`/customer-find-customer-detailed`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
// 批量导入时上传 EXCEL 文件接口
export const bulkImportExcel = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/issue/card/uploadExcel', {
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
  });
};
// 搜索权益卡名称
export async function rightsCardName(goodsName?: string, options?: Record<string, any>) {
  return request(`/issue/card/goods/search`, {
    method: 'GET',

    params: { goodsName },
    ...(options || {}),
  });
}
// 通过权益卡号查询权益信息
export async function rightsCardDetails(skuNo?: number, options?: Record<string, any>) {
  return request(`/issue/card/goods/detail`, {
    method: 'GET',

    params: { skuNo },
    ...(options || {}),
  });
}
// 权益卡单个导入
export async function AddCardSingle(
  data: { allowTransfer: boolean; certify: string },
  options?: Record<string, any>,
) {
  return await request(`/issue/card/single`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
// 权益卡批量导入
export async function AddCardBatch(
  data: { batchNo: string | undefined; certify: string },
  options?: Record<string, any>,
) {
  return await request(`/issue/card/batch`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 获取激活码列表
export async function generateActivateCodeList(
  params: { current?: number; pageSize?: number; skuNo?: string },
  options?: Record<string, any>,
) {
  const { current, ...data } = params;

  const SkuNoResult = checkIsNumberForSearch(params.skuNo, 'skuNo');
  if (SkuNoResult !== null) return SkuNoResult;

  const msg = await request(`/gen/activation/code/pageInfo`, {
    method: 'GET',
    params: { ...data, pageNo: current },
    ...(options || {}),
  });
  return {
    data: msg.result !== null && msg.status === 0 ? msg.result.activationCodeList : [],
    total: msg.result !== null && msg.status === 0 ? msg.result.totalCount : 0,
  };
}

// 下载激活码
export async function activationCodeDownload(batchNo: string, options?: Record<string, any>) {
  return await request(`/gen/activation/code/download`, {
    method: 'GET',
    params: { batchNo },
    ...(options || {}),
    responseType: 'blob',
  });
}

// 生成激活码
export async function ActivationCodeInsert(
  data: APIS.ActivationCodeInsertData,
  options?: Record<string, any>,
) {
  return await request(`/gen/activation/code/insert`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}
// 查看激活码详情
// 通过权益卡号查询权益信息
export async function activationCodeDetail(id?: number, options?: Record<string, any>) {
  return request(`/gen/activation/code/detail`, {
    method: 'GET',
    params: { id },
    ...(options || {}),
  });
}
//
export async function PushOrderCallback(
  data: { operating: string; orderId?: string; mobile?: string },
  options?: Record<string, any>,
) {
  return await request(`/tool/push-order-callback`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 商品卡列表
export const queryCardSellingList = async (
  params: APIS.CardSellingRequest,
  options?: Record<string, any>,
) => {
  const { current, skuNo } = params;

  const checkSku = checkIsNumberForSearch(skuNo, 'SKU');
  if (checkSku !== null) return checkSku;

  const msg = await request('/goods/page', {
    method: 'POST',
    data: cleanObject({
      pageNo: current,
      pageSize: params.pageSize,
      skuNo: params.skuNo,
      goodsName: params.goodsName,
      planCode: params.planCode,
    }),
    ...(options || {}),
  });
  const { status, result } = msg;
  return {
    data: status === 0 ? result.listGoodsInfo || [] : [],
    total: status === 0 ? result.totalCount || 0 : 0,
  };
};

// 商品卡详情
export async function queryCardSellingDetails(id?: string, options?: any) {
  return request(`/goods/detail`, {
    method: 'GET',
    params: { id },
    ...(options || {}),
  });
}

// 权益卡列表
export async function queryCardByName(name?: string, options?: any) {
  return request(`/rights/card-name-code`, {
    method: 'GET',
    params: { name },
    ...(options || {}),
  });
}

// 权益卡详情
export async function queryCardDetailByMasterId(masterId?: string, options?: any) {
  return request(`/rights/preview_card`, {
    method: 'GET',
    params: { masterId },
    ...(options || {}),
  });
}

// 商品卡添加或更新
export async function addOrUpdateSellCard(data: APIS.AddOrUpdateCardSellReques, options?: any) {
  return request(`/goods/addOrUpdate`, {
    method: 'POST',
    data: data,
    ...(options || {}),
  });
}

// 信息重发列表
export async function orderManagementList(
  params: {
    pageSize?: number;
    current?: number;
    mobile?: string;
  },
  options?: Record<string, any>,
) {
  const { pageSize, current, mobile } = params;
  const mobileResult = checkIsNumberForSearch(mobile, '手机号');
  if (mobileResult !== null) return mobileResult;
  if (mobile) {
    const msg = await request(`/drug/drugOrderMessage`, {
      method: 'POST',
      params: {
        page_num: current,
        page_size: pageSize,
      },
      data: {
        customerPhone: mobile,
      },
      ...(options || {}),
    });
    return {
      data: msg?.data || [],
      total: msg?.total || 0,
    };
  } else {
    return {
      data: [],
      total: 0,
    };
  }
}
export async function sendDrugOrderMessage(data: { orderId?: string }, options?: any) {
  return request(`/drug/sendDrugOrderMessage`, {
    method: 'POST',
    data,
    ...(options || {}),
  });
}

// 商场字典
export async function listDictionary(dicType?: string[], options?: any) {
  return request(`/mall/list-dictionary`, {
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    method: 'GET',
    params: { dicType: dicType || '' },
    ...(options || {}),
  }) as unknown as APIS.BaseResponse<any>;
}

// 商场的下载导入模板
export async function downloadExcelTemplate(type?: APIS.ExcelTemplateType, options?: any) {
  const res: { result?: string } = await getRequest(
    `/excel/template`,
    { type: type || '' },
    { type: HOST_TYPE_POWER, resultType: RESULT_TYPE_TEXT, ...options },
  );
  const { result } = res;
  if (result && result.startsWith('http')) {
    window.open(result);
  }
}

// 查看所有权益
export async function queryAllRights() {
  return (await postRequest(
    '/rights/list-card-master',
    {},
    {},
    { type: HOST_TYPE_POWER },
  )) as unknown as APIS.BaseResponse<any>;
}

// 获取公司
export async function queryCompany() {
  return getRequest(
    '/operator/list-company',
    {},
    {
      type: HOST_TYPE_POWER,
    },
  );
}

// 订单中心 - 自营订单 - POST 封装
const POST_selfOperatedOrders = async (url: string, params: any, options?: any) => {
  const res: any = await request(url, {
    method: 'POST',
    data: params,
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
    ...(options || {}),
  });
  return res?.result || {};
};

// 订单中心 - 自营订单 - 主菜单列表
export const selfOperatedOrdersPage = async (
  params: {
    current?: number;
    pageSize?: number;
    parentOrderNo?: string; //付款订单号
    subOrderNo?: string; //订单号
    userPhone?: string; //手机号
    orderStatus?: string; //订单状态
    orderChannel?: string; //对应渠道
    hasDeliveryNo?: string; //是否录入完成物流单号
    payTimeStart?: string; //支付日期开始时间
    payTimeEnd?: string; //支付日期结束时间
    createOrderTimeStart?: string; //创建订单开始时间
    createOrderTimeEnd?: string; //创建订单结束时间
    payTime?: any[] | string;
    createOrderTime?: any[] | string;
  },
  options?: Record<string, any>,
) => {
  const result = await POST_selfOperatedOrders(`/order/self-operated-orders-page`, params);
  return {
    data: result?.pageOrderInfoList || [],
    total: Number(result?.totalCount) || 0,
  };
};

// 订单中心 - 自营订单 - 子菜单列表
export const listSubOrder = async (params: { id?: string }) => {
  const result = await POST_selfOperatedOrders(`/order/list-sub-order`, {
    parentOrderId: params.id,
  });
  return {
    data: result?.subOrders || [],
    total: result?.subOrders?.length || 0,
  };
};

// 订单中心 - 自营订单 - 主订单详情
export const mainOrderDetails = async (id?: string) => {
  return await POST_selfOperatedOrders(`/order/main-order-details`, { id });
};

// 订单中心 - 自营订单 - 子订单详情
export const viewChildOrder = async (id?: string) => {
  return await POST_selfOperatedOrders(`/order/view-child-order`, { id });
};

// 订单中心 - 自营订单 - 物流详情
export const logisticsDetails = async (params: object) => {
  return await POST_selfOperatedOrders(`/order/logistics-details`, params);
};

// 订单中心 - 自营订单 - 上传 EXCEL 文件接口
export const importLogisticsInformation = async (options: any) => {
  const formData = new FormData();
  formData.append('file', options.file);
  return await request('/order/import-logistics-information', {
    method: 'POST',
    body: formData,
    timeout: TIMEOUT,
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
  });
};

// 订单中心 - 自营订单 - 上传 EXCEL 导出
export const orderExport = async (params: object) => {
  return await postRequest(
    '/order/export',
    params,
    {},
    { type: HOST_TYPE_POWER, responseType: 'blob' },
  );
};

// 订单中心 - 自营订单 - 保存备注
export const saveComment = async (params: object) => {
  return await POST_selfOperatedOrders('/order/save-comment', params);
};

// 订单中心 - 自营订单 - 修改 快递快单号
export const modifyTheCourierNumber = async (params: object) => {
  return await POST_selfOperatedOrders('/order/modify-the-courier-number', params);
};

// 订单中心 - 自营订单 - 作废处方笺
export const voidPrescription = async (params: object) => {
  return request(`/order/void-prescription`, {
    method: 'GET',
    params,
    host: POWER_HOST,
    type: HOST_TYPE_POWER,
  });
};

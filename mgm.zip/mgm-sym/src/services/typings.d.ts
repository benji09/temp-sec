declare namespace APIS {
  type CosResult = {
    code?: number;
    msg?: string;
    key?: string;
  };

  type listParams = {
    id?: number;
    name?: string;
    contentTile?: string;
    ownedPlate?: string[];
    contentType?: number;
    isRecommended?: string;
    pageNo?: number;
    current?: number;
    pageSize?: number;
    createdTime?: string;
  };

  type medicalParams = {
    skuId?: string;
    herbName?: string[];
    pageNo?: number;
    current?: number;
    pageSize?: number;
    status?: number;
  };

  type contentList = {
    message: string;
    status?: number;
    result?: any;
  };

  type LoginParams = {
    name: string;
    password: string;
  };
  type LoginResult = {
    status?: number | string;
    type?: number | string;
  };
  type detailParams = {
    id: number;
  };

  type updateCommendParams = {
    id: number;
    isRecommended: boolean;
    ownedPlate: string[];
    recommendTag: string[];
    userId?: number;
  };

  type saveCodeParams = {
    id: number;
    qrCodeIcon?: string;
    qrCodeLink?: string;
    userId?: string;
  };

  type BaseResponse<T> = {
    status: number;
    message?: string;
    result: T;
  };

  type CmsAddOrUpdateResponse = {
    coverImage?: string;
    createdTime?: string | number;
    isRecommended?: string;
    remark?: string;
    id?: number;
  };

  type CmsAddOrUpdate = {
    id?: number;
    contentTitle: string;
    contentTitleIcon: string;
    remark: string;
    coverImage: string;
    contentType: number | null;
    content: string;
    userId?: number | null;
  };
  type StandardModeList = {
    id?: number;
    formulaName?: string;
    herbName?: string;
    current?: number;
    pageSize?: number;
  };
  type StandardModeSaveOrUpdate = {
    id?: number;
    formulaName?: string;
    processingMethods?: number;
    usage?: number;
    dosage?: number;
    usageUnit?: number;
    rate?: number;
    herbFormulaInfos?: {
      herbId?: number;
      herbName?: string;
      skuId?: number;
      weight?: number;
      settlementPrice?: number;
      sellPrice?: number;
    }[];
    sellPrice?: number;
    settlementPrice?: number;
    remark?: string;
  };
  type UserInfo = {
    device: string;
    name?: string;
    portrait?: string;
    token: string;
    account?: null | string;
    device?: null | string;
    result?: string;
  };
  type AppraisalManageList = {
    current?: number;
    pageSize?: number;
    assessmentId?: string;
    userId?: string | undefined;
  };
  type processAssessment = {
    reports?: string[];
    remark?: string;
    status?: boolean;
    assessmentId?: string;
    foodPlanId?: string | number;
    exercisePlanId?: string | number;
  };
  type DrugOrderItem = {
    applicantBankAccount?: string;
    applicantBankAddress?: string;
    applicantEmail?: string;
    applicantMobile?: string;
    applicantName?: string;
    businessBankAccount?: string;
    businessBankAddress?: string;
    businessId?: string;
    businessName?: string;
    dealAmount?: number;
    dealTime?: number;
    directorId?: string;
    directorName?: string;
    effectTime?: number;
    insuredCode?: string;
    insuredIdCard?: string;
    insuredName?: string;
    managerId?: string;
    managerName?: string;
    policyCode: string;
    policyPhaseId?: number;
    policyRecordId: number;
    policyStatus?: number;
    refundStatus: number;
    supervisorId?: string;
    supervisorName?: string;
  };
  type ReturnVisitnItem = {
    age?: null;
    applyBirthday?: string;
    applyGender?: number;
    applyId: number;
    applyMobile?: string;
    applyName?: string;
    id: number;
    message?: string;
    process?: boolean;
    processUserId?: number;
    processUserName?: string;
    receiveId?: number;
    receiveName?: string;
    receiveTime?: number;
  };
  type MedicalServiceItem = {
    assistantName?: string;
    createTime?: string;
    doctorName?: string;
    endTime?: string;
    orderId?: string;
    orderType?: number;
    payType?: number;
    status?: number;
    userName?: null | string;
    medicine?: boolean;
  };

  type DrugOrderDetail = {
    policyPhaseId?: number;
    refundStatus?: number;
    refundPolicyInfo?: {
      policyRecordId?: number;
      policyPhaseId?: number;
      policyCode?: string;
      insuredCode?: string;
      dealTime?: number;
      policyStatus?: number;
      dealAmount?: number;
      effectTime?: number;
      applicantName?: string;
      applicantMobile?: string;
      applicantEmail?: string;
      applicantBankAddress?: string;
      applicantBankAccount?: string;
      insuredName?: string;
      insuredIdCard?: string;
      businessId?: string;
      businessName?: string;
      businessBankAddress?: string;
      businessBankAccount?: string;
      supervisorId?: string;
      supervisorName?: 李六;
      managerId?: string;
      managerName?: string;
      directorId?: string;
      directorName?: string;
      refundStatus?: number;
    };
    cards?: {
      cardId?: string;
      name?: string;
      right?: {
        rightMasterId?: string;
        name?: string;
        displayExt?: string;
        number?: number;
        usableTime?: number;
        overdueTime?: number;
        description?: string;
        disabled?: boolean;
        usable?: boolean;
        disabledReason?: string;
        infinitely?: boolean;
      }[];
    }[];
    applyInfos?: {
      applyId?: number;
      applyUserId?: number;
      applyStatus?: number;
      amount?: number;
      reason?: string;
      applyTime?: number;
      endTime?: number;
    }[];
  };
  type RemoteMenu = {
    id: number;
    menuName: string;
    sons: RemoteMenu[] | null;
  };
  type MedicalOrdersDetails = {
    appeal?: string;
    assistantName?: string;
    chat?: boolean;
    createTime?: string;
    diagnoseBirthDay?: string;
    diagnoseGender?: number;
    diagnoseName?: string;
    diagnosis?: string;
    doctorName?: string;
    endTime?: string;
    gender?: number;
    mobile?: string;
    orderId?: string;
    orderType?: string;
    prescribe?: boolean;
    remarks?: {
      createdAt?: string;
      name?: string;
      operatorId?: number;
      remarks?: string;
      remark?: string;
    }[];
    summary?: string;
    userBirthDay?: string;
    userId?: number;
    userName?: string;
  };

  type getWorkListType = {
    assistantId: number;
    assistantName: string;
    open: boolean;
    orderNumber: number;
    providerId: number;
    providerName: string;
    roomTagName: string[];
    work: boolean;
  };
  type menuListSons = {
    description?: string;
    display?: boolean;
    id?: number;
    menuName?: string;
    sons?: menuListSons[] | [];
    url?: string;
  };

  type RoleSetListType = {
    name?: string;
    mobile?: string[];
    current?: number;
    pageSize?: number;
  };

  type DoctorAccountItem = {
    providerId?: number;
    name?: string;
    avatar?: string;
    createdAt?: number;
    tagCode?: number;
    description?: string;
    department?: number;
    title?: string;
    personalDoctor?: boolean;
    maxBind?: number;
    canPrescribe?: boolean;
    caOpenId?: string;
    isHealthcare?: boolean;
    isPaediatrics?: boolean;
    isTester?: boolean;
    isChineseMedical?: boolean;
    isWesternMedical?: boolean;
    tags?: number[];
    tagsName?: string[];
  };
  type DoctorAccountDetail = {
    video?: string;
    birthday?: string;
    createAt?: number | null;
    department?: string;
    description?: string;
    education?: string;
    employment?: string;
    gander?: number;
    hospital?: string;
    img1?: string;
    img2?: string;
    mobile?: string;
    name?: string;
    providerId?: number;
    jobStatus?: number;
    skilled?: string;
    title?: string;
  };
  type RightsRequestParam = {
    pageSize?: number | undefined;
    current?: number | undefined;
    userId?: string | undefined;
  };

  type RightCardItem = {
    status?: number;
    cardSecret?: string;
    lockState?: number;
    userId?: number | undefined;
    userName?: string | undefined;
    cardMasterId?: string | undefined;
    cardId?: string | undefined;
    cardName?: string | undefined;
    displayExt?: string | undefined;
    activeTime?: string | undefined;
    planCode?: string | number;
  };
  type RightsDetail = {
    rightsMasterId: string;
    rightsId: string;
    usable: boolean;
    name: string;
    displayExt: string;
    number: number;
    code: string;
    uselessType: string;
    uselessValue: string;
    usableTime: string;
    overdueTime: string;
    description: string;
    infinitely: boolean;
    canDisable: boolean;
    total: number;
    serviceType?: number;
  };
  type RightCardDetail = {
    card: {
      cardMasterId: string;
      cardId: string;
      usable: boolean;
      name: string;
      displayExt: string;
      activeTime: string;
      planCode: string;
      deviceId?: number | string;
    };
    cardRelational: {
      name: string;
      idCardType: number;
      idCardNumber: string;
      primary: boolean;
    }[];
    rights: RightsDetail[];
    mwyPolicyInfo?: {
      activation: boolean;
      policyInfo?: {
        policyId: string; // 激活保单ID
        orderId: string; // 订单号
        serialId: string; // 投保单号/流水号
        payName: string; // 投保人/购买人姓名
        payMobile: string; // 投保人/购买人电话
        useName: string; // 被保险人/使用人姓名
        useMobile: string; // 被保险人/使用人电话
        useIdCardType: number; // 被保险人/使用人证件类型 身份证0、护照1、军官证2、驾照3、出生证明4、户口薄5、港澳台胞证6、其他8
        useIdCard: string; // 被保险人/使用人证件号
        activationType: number; //  用户激活版本 0：个人版 1：家庭版
        effectDate: string; // 生效日期/激活日期 '2021-12-12'
        hesitationPeriod: number; // 犹豫期
        salesType: number; // 销售方式 0：勾选版 1：单售版
        dealTime: string; // 成交时间 毫秒值
        dealAmount: string; // 成交金额 以分为单位
        businessId: string; // 业务员 ID 多个业务员ID用 # 分割
      };
    };
    payInfo?: {
      code?: number; //0成功 其它失败，失败原因在message
      message?: string; //错误消息
      timestamp?: number; // 交易时间戳
      outTradeNo?: string; //商户单号
      transactionId?: string; //订单号
      tradeType?: string; //交易类型
      tradeState?: string; //交易状态
      tradeStateDesc?: string; // 交易状态描述
      attach?: string;
      successTime?: string; // 交易成功时间
      amount?: string; // 支付金额
      payService?: string; // 支付服务 10000 中药 10001买药
    };
  };
  type ProviderTagItem = {
    tagId: number;
    name: string;
  };
  type BindSize = {
    childrenBindSize: number;
    kwyHealthcareSize: number;
    privateBindSize: number;
  };
  type AssistantInfo = {
    assistantId: number;
    birthday?: string;
    createdAt?: number;
    description?: string;
    gender?: number;
    isLeader: boolean;
    key?: string;
    mobile?: string;
    name?: string;
    portrait?: string;
    size?: number;
    canDelete?: boolean;
    tempAssistant?: AssistantInfo;
  };
  type BindAssistantItem = {
    assistantId: number;
    date: number;
    isGroup: boolean;
    providerId: number;
  };
  type kwyHealthcareGroupType = {
    groupName?: string;
    introduce?: string;
    options?: {
      avatar?: string;
      department?: string;
      description?: string;
      id?: number;
      name?: string;
      title?: string;
    }[];
    portrait?: string;
    providerId?: number;
    teamPhoto?: string;
  };

  type DDOrderRequestParam = {
    pageSize?: number | undefined;
    current?: number | undefined;
    userId?: string | undefined;
    mobile?: string | undefined;
    tag?: number | undefined;
  };
  type DDOrderItem = {
    nick: string;
    createdDate: string;
    orderStatusCn: string;
    price: number;
    deductionAmount: number;
    mobile: string;
    ddOrderNo: string;
    orderStatus: number;
    userId: number;
    rights: boolean;
  };
  type roleListType = {
    check: boolean;
    description: string;
    roleId: number;
    roleName: string;
  };
  type getDrugOrderSellType = {
    orderNo?: string;
    current?: number;
    pageSize?: number;
  };
  type getDrugOrderSellListType = {
    activeVersion?: number;
    createdTime?: string;
    customerName?: string;
    id?: string;
    isOpenInvoice?: boolean;
    isRefund?: boolean;
    orderNo?: string;
    saleType?: number;
    status?: number;
    userId?: string;
  };
  type policySecrecyInfoType = {
    card: {
      activeTime: string;
      cardId: string;
      cardMasterId: string;
      displayExt: string;
      name: string;
      usable: boolean;
      userName: string;
    };
    mwyPolicyInfo: {
      activation: boolean;
      policyInfo: {
        activationType: number;
        businessId: string;
        cardId: number;
        dealAmount: number;
        dealTime: number;
        effectDate: string;
        hesitationPeriod: number;
        orderId: string;
        payMobile: string;
        payName: string;
        policyId: number;
        salesType: number;
        serialId: string;
        useIdCard: string;
        useIdCardType: number;
        useMobile: string;
        useName: string;
      };
    };
    payInfo: {
      amount: string;
      attach: string;
      code: number;
      message: string;
      outTradeNo: string;
      payService: string;
      successTime: string;
      timestamp: number;
      tradeState: string;
      tradeStateDesc: string;
      tradeType: string;
      transactionId: string;
    };
    rights: [
      {
        canDisable: boolean;
        code: string;
        description: string;
        displayExt: string;
        infinitely: boolean;
        name: string;
        number: number;
        overdueTime: string;
        rightsId: string;
        rightsMasterId: string;
        usable: boolean;
        usableTime: string;
        uselessType: string;
        uselessValue: string;
        total: number;
      },
    ];
  };
  type saleOpenInvoiceDataType = {
    address?: string;
    bankAccount?: string;
    email?: string;
    identifierNumber?: string;
    invoiceAmount?: number | string;
    invoiceCode?: string;
    invoiceName?: string;
    invoiceNumber?: string;
    logId?: string;
    mobile?: string;
    openBank?: string;
    openInvoiceTime?: number;
  };
  type saleRefundDataType = {
    accountName?: string;
    accountNumber?: string;
    bankNumber?: string;
    logId?: string;
    openBank?: string;
    refundAmount?: number;
    refundTime?: number;
  };
  type ActivationCodeInsertData = {
    certify?: string;
    genCount?: number;
    remark?: string;
    skuNo?: string;
    transNo?: string;
  };
  type CustomerCardPalletListType = {
    content: CardPalletListType[];
    number: number;
    size: number;
    totalElements: number;
    totalPages: number;
  };
  type CardPalletListType = {
    activeMessage: string;
    activeTime: number;
    allowedTransfer: boolean;
    cardId: string;
    closed: boolean;
    createdAt: number;
    gainWay: string;
    latestActiveTime: number;
    ownerMobile: string;
    ownerName: string;
    relationshipNumber: string;
    skuName: string;
    skuNo: string;
    status: number;
    planCode: string;
  };
  type LinkConfigProps = {
    key?: string;
    fullLink?: string;
    linkParams?: string;
  };
  type SaveLinkConfig = {
    id?: number;
    params?: string;
  };
  type CardSelling = {
    createdTime?: string;
    goodsName?: string;
    id?: string;
    sellPrice?: string;
    sellStatus?: boolean;
    skuNo?: string;
    planCode?: string;
  };
  type CardSellingDetail = {
    price?: string;
    skuNo?: string;
    isOpen?: boolean;
    planCode?: string;
    masterId?: string;
    createdTime?: string;
    discountPrice?: string;
    effectiveDays?: string;
    lastActivationDate?: string;
    horseRaceLamp?: boolean;
    cardDetail?: {
      unit?: string;
      code?: string;
      name?: string;
      order?: number;
      number?: number;
      description?: string;
      isInfinitely?: boolean;
      usableOffset?: number;
      rightsMasterId?: string;
    }[];
    imgAndUrls?: {
      goodsImg?: string;
      goodsUrl?: string;
    }[];
    id?: string;
    planId?: string;
    goodsName?: string;
    goodsDesc?: string;
    autoRenew?: boolean;
    mwyAgreement?: boolean;
    allowTransfer?: boolean;
    validPeriodMethod?: number | string;
    preferentialMethod?: number;
  };
  type CardSellingRequest = {
    skuNo?: string;
    goodsName?: string;
    planCode?: string;
    pageNo?: number;
    current?: number;
    pageSize?: number;
  };
  type AddOrUpdateCardSellReques = {
    allowTransfer?: boolean;
    discountPrice?: number; // 优惠价
    effectiveDays?: number; // 激活有效天数
    goodsDesc?: string; // 商品描述
    goodsName?: string; // 权益名称
    id?: string;
    isOpen?: boolean; // 是否开启
    lastActivationDate?: string; // 最后激活日期
    masterId?: number | string;
    planCode?: string;
    price?: number; // 销售金额
    skuNo?: string;
  };
  type getServiceChatType = {
    TimeDate?: string[];
    assistantId?: string;
    assistantName?: string;
    current?: number;
    orderId?: string;
    pageSize?: number;
    userId?: string;
  };
  type getProviderListType = {
    TimeDate?: string[];
    current?: number;
    mobile?: string;
    msgType?: string;
    orderNo?: string;
    pageSize?: number;
    providerId?: number | string;
    name?: string;
    tags?: number[];
  };
  type PlanType = {
    planId?: any;
    createdAt?: any;
    createName?: any;
    updatedAt?: any;
    modifyName?: any;
    planName?: any;
    description?: any;
  };
  type RuleListItem = {
    createdTime: number;
    description: string;
    id: number;
    name: string;
    type: number;
  };
  type AddLabelsType = {
    groupIds?: number | string[];
    id?: number;
    name?: string;
    remark?: string;
    sort?: number;
  };
  type OrderListParams = {
    userId?: string;
    mobile?: string;
    orderNo?: string;
    deliveryNo?: string;
    page?: number;
    pageSize?: number;
  };
  type ListDictionary = {
    dictionary?: number | string;
  };
  type DictionaryType = {
    key?: number;
    value?: string;
    id?: string;
    name?: string;
  };
  type BaseResponse<T> = {
    status?: number;
    message?: string;
    result?: T;
  };
  /**
   * SCYPSJ(1, "商城药品数据")
   * QTFLYPSJ(2, "前台分类药品数据")
   * TYMK(3, "通用名库")
   * BZKSJ(4, "标准库数据")
   * WFYPQSJ(5, "我方商品全数据")
   * ZDGL(6, "诊断管理")
   * YWGMS(7, "药物过敏史")
   * GWJBS(8, "过往疾病史")
   * DSFK(9, "第三方数据")
   * DXZ(10, "序值模板")
   */
  type ExcelTemplateType =
    | 'SCYPSJ'
    | 'QTFLYPSJ'
    | 'TYMK'
    | 'BZKSJ'
    | 'WFYPQSJ'
    | 'ZDGL'
    | 'YWGMS'
    | 'GWJBS'
    | 'DSFK'
    | 'DXZ';
}

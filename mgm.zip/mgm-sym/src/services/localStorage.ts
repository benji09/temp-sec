/*
 * @Author: zyx
 * @Date: 2021-06-18 15:19:31
 * @LastEditTime: 2021-08-20 13:48:34
 * @Description: 封装localStorage
 * @FilePath: \management-system\src\services\localStorage.ts
 */
import { getItemUserInfo } from '@/utils/userInfoEncrypt';

export function getItem(key: string): any {
  return window.localStorage.getItem(key);
}

export function setItem(key: string, value: any): any {
  return window.localStorage.setItem(key, value);
}

export function getDLInfo(key: string): { _device: string; _token: string } | undefined {
  const data = getItemUserInfo(key);
  return {
    _device: data?.device || '',
    _token: data?.token || '',
  };
}

export function removeItem(key: string): void {
  localStorage.removeItem(key);
}

export function putLocalStorage(key: string, value: any) {
  window.localStorage.setItem(key, value);
}

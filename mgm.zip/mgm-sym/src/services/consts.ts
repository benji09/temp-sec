export const COS_UPLOAD = '/cos/public/upload';
export const COS_DOWN = '/cos/download?id=';
export const COS_DOWNLOAD = '/cos/public/download?id=';

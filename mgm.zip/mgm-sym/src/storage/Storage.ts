import type { KeyType } from '../encryt/types';

interface IStorage {
  setItem: (key: string | undefined, value?: KeyType, unique?: KeyType) => void;
  getItem: <T>(key: string, defaultValue?: KeyType, unique?: KeyType) => T;
  removeItem: (key: string, value?: KeyType, unique?: KeyType) => void;
  clearItem: () => void;
}
export default IStorage;

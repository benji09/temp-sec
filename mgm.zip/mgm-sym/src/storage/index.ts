/*
 * @Author: zyx
 * @Date: 2021-08-11 22:04:02
 * @LastEditTime: 2022-02-22 11:33:36
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\storage\LocalStorage.ts
 */

import LocalStorage from './LocalStorage';
import type IStorage from './Storage';
import type { KeyType } from './types';

let storage: IStorage;

function getLocalStorage() {
  if (!storage) storage = new LocalStorage();
  return storage;
}

function setItem(key: string | undefined, value: KeyType) {
  return getLocalStorage().setItem(key, value);
}
function getItem<T = any>(key: string) {
  return getLocalStorage().getItem<T>(key);
}
function removeItem(key: string) {
  return getLocalStorage().removeItem(key);
}
function clearItem() {
  return getLocalStorage().clearItem();
}

export { setItem, getItem, removeItem, clearItem };

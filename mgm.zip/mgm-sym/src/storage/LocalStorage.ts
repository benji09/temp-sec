/*
 * @Author: your name
 * @Date: 2021-08-18 17:20:51
 * @LastEditTime: 2022-02-22 11:33:16
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\storage\LocalStorage.ts
 */
import DESEncrypt from '@/encryt/DESEncrypt';
import { showErrorMessage } from '@/mamagement/Notification';

import type Storage from './Storage';
import type { KeyType } from '../encryt/types';

class LocalStorage implements Storage {
  public encrypt = new DESEncrypt();
  setItem(key: string | undefined, value: KeyType, unique: KeyType = '') {
    localStorage.setItem(`${key}${unique}`, value || '');
  }

  getItem<T = string>(key: string, defaultValue: KeyType = '', unique: KeyType = '') {
    try {
      const value = localStorage.getItem(`${key}${unique}`);
      return value as unknown as T;
    } catch (error) {
      showErrorMessage(`${error}`);
    }
    return defaultValue as unknown as T;
  }
  removeItem(key?: string) {
    localStorage.removeItem(key || '');
  }
  clearItem() {
    localStorage.clear();
  }
}
export default LocalStorage;

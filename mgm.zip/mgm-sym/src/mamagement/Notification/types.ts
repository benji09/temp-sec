enum MessageType { // 消息级别
  INFO,
  WARN,
  ERROR,
  SUCCESS,
}

type ContentType = string | null | undefined; // 消息内容类型
type StyleType = number; // 样式类型

export { MessageType, ContentType, StyleType };

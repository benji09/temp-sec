import { message } from 'antd';

import { DEFAULT_NOTIFY_STYLE } from './config';
import { MessageType } from './types';
import type IBaseNotification from './BaseNotification';
import type { ContentType, StyleType } from './types';

class Message implements IBaseNotification {
  show(msg: ContentType, type: MessageType, style: StyleType) {
    if (style === DEFAULT_NOTIFY_STYLE) this.defaultStyle(msg, type);
  }

  defaultStyle(msg: ContentType, type: MessageType) {
    if (type === MessageType.WARN) {
      message.warn(msg);
      return;
    }
    if (type === MessageType.ERROR) {
      message.error(msg);
      return;
    }
    if (type === MessageType.SUCCESS) {
      message.success(msg);
      return;
    }
    message.info(msg);
  }
}

export default Message;

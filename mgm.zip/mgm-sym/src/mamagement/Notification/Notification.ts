import { notification } from 'antd';

import { MessageType } from './types';
import { DEFAULT_NOTIFY_STYLE } from './config';
import type IBaseNotification from './BaseNotification';
import type { ContentType, StyleType } from './types';

class Notification implements IBaseNotification {
  show(msg: ContentType, type: MessageType, style: StyleType) {
    if (style === DEFAULT_NOTIFY_STYLE) this.defaultStyle(msg, type);
  }

  defaultStyle(msg: ContentType, type: MessageType) {
    if (type === MessageType.WARN) {
      notification.warn({ message: msg });
      return;
    }
    if (type === MessageType.ERROR) {
      notification.error({ message: msg });
      return;
    }
    if (type === MessageType.SUCCESS) {
      notification.success({ message: msg });
      return;
    }
    notification.info({ message: msg });
  }
}

export default Notification;

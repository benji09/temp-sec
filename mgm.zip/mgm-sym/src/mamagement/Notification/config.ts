const DEFAULT_NOTIFY_STYLE = 0; // 默认样式
const DEFAULT_NOTIFY_DURATION = 3000; // 默认展示时长

const nodifyStyle = DEFAULT_NOTIFY_STYLE;
const notifyDuration = DEFAULT_NOTIFY_DURATION;

export { nodifyStyle, notifyDuration, DEFAULT_NOTIFY_STYLE, DEFAULT_NOTIFY_DURATION };

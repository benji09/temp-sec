import type { ContentType, StyleType } from './types';
import type { MessageType } from './types';

interface IBaseNotification {
  /**
   * msg: 显示内容
   * type: 信息级别
   * style: 显示样式(保留字段，方便后期扩展)
   */
  show: (msg: ContentType, type: MessageType, style: StyleType) => void;
}
export default IBaseNotification;

import Message from './Message';
import Notification from './Notification';
import { nodifyStyle, notifyDuration } from './config';
import { MessageType } from './types';
import type { ContentType } from './types';
import type IBaseNotification from './BaseNotification';

let message: Message | undefined;
let notification: Notification | undefined;
let isShowing = false;

function getMessage(): Message {
  if (!message) message = new Message();
  return message;
}

function getNotification(): Message {
  if (!notification) notification = new Notification();
  return notification;
}

function showInfoMessage(msg: ContentType) {
  showMessage(msg, MessageType.INFO);
}
function showWarnMessage(msg: ContentType) {
  showMessage(msg, MessageType.WARN);
}
function showErrorMessage(msg: ContentType) {
  showMessage(msg, MessageType.ERROR);
}
function showSuccessMessage(msg: ContentType) {
  showMessage(msg, MessageType.SUCCESS);
}

function showInfoNotification(msg: ContentType) {
  showNotification(msg, MessageType.INFO);
}
function showWarnNotification(msg: ContentType) {
  showNotification(msg, MessageType.WARN);
}
function showErrorNotification(msg: ContentType) {
  showNotification(msg, MessageType.ERROR);
}
function showSuccessNotification(msg: ContentType) {
  showNotification(msg, MessageType.SUCCESS);
}

function showMessage(msg: ContentType, type: MessageType) {
  show(msg, type, getMessage());
}

function showNotification(msg: ContentType, type: MessageType) {
  show(msg, type, getNotification());
}

function show<T extends IBaseNotification>(
  msg: ContentType,
  type: MessageType,
  dispatch: T,
  style: number = nodifyStyle,
) {
  if (!msg || msg.trim().length < 1) return;
  if (isShowing) return;
  isShowing = true;
  dispatch.show(msg, type, style);
  setTimeout(() => {
    isShowing = false;
  }, notifyDuration);
}

export {
  showInfoNotification,
  showWarnNotification,
  showErrorNotification,
  showSuccessNotification,
  showInfoMessage,
  showWarnMessage,
  showErrorMessage,
  showSuccessMessage,
};

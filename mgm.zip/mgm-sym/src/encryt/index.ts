/*
 * @Author: zyx
 * @Date: 2021-08-13 17:13:06
 * @LastEditTime: 2021-08-16 10:30:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\encryt\index.ts
 */
import DESEncrypt from './DESEncrypt';
import type IEncrypt from './IEncrypt';
import type { KeyType } from './types';

let secrecy: IEncrypt;
function getDESEncrypt() {
  if (!secrecy) secrecy = new DESEncrypt();
  return secrecy;
}

function encrypt(value: KeyType, key: KeyType = '', defaultValue: KeyType = '') {
  return getDESEncrypt().encrypt(value, key, defaultValue);
}
function decode(value: KeyType, key: KeyType = '', defaultValue: KeyType = '') {
  return getDESEncrypt().decode(value, key, defaultValue);
}

export { encrypt, decode };

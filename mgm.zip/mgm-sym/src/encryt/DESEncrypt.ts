import CryptoJS from 'crypto-js';
import type IEncryt from './IEncrypt';
import type { KeyType } from './types';

class DESEncrypt implements IEncryt {
  encrypt(value: KeyType, key?: KeyType, defaultValue: KeyType = '') {
    try {
      const keyHex = CryptoJS.enc.Utf8.parse(key || '');
      const encrypted = CryptoJS.DES.encrypt(value || '', keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7,
      });
      return encrypted.toString();
    } catch {
      return defaultValue;
    }
  }
  decode(value: KeyType, key?: KeyType, defaultValue: KeyType = '') {
    try {
      const keyHex = CryptoJS.enc.Utf8.parse(key || '');
      const decrypted = CryptoJS.DES.decrypt(value || '', keyHex, {
        mode: CryptoJS.mode.ECB,
        padding: CryptoJS.pad.Pkcs7,
      });
      return decrypted.toString(CryptoJS.enc.Utf8);
    } catch {
      return defaultValue;
    }
  }
}

export default DESEncrypt;

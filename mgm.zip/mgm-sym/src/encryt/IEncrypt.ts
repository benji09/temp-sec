/*
 * @Author: your name
 * @Date: 2021-08-11 22:04:02
 * @LastEditTime: 2021-08-13 17:30:53
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\encryt\IEncrypt.ts
 */
import type { KeyType } from './types';

interface IEncrypt {
  encrypt: (value: KeyType, key?: KeyType, defaultValue?: KeyType) => KeyType;
  decode: (value: KeyType, key?: KeyType, defaultValue?: KeyType) => KeyType;
}
export default IEncrypt;

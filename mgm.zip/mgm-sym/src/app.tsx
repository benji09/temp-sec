import _ from 'lodash';
import moment from 'moment';
import undoable from 'redux-undo';
import { Link, history } from 'umi';
import { logger, Projects } from '@yuji/logger';
import { PageLoading } from '@ant-design/pro-layout';
import type { Reducer, AnyAction } from 'redux';
import type { ResponseError } from 'umi-request';
import type { StateWithHistory } from 'redux-undo';
import type { RequestConfig, RunTimeLayoutConfig } from 'umi';
import type { MenuDataItem, Settings as LayoutSettings } from '@ant-design/pro-layout';

import RightContent from '@/components/RightContent';
import { initPower } from '@/services/api';
import { getDLInfo } from '@/services/localStorage';
import { BI_URL, FINANCE_BI_URL, HOST, POWER_HOST } from '@/services/hosts';
import {
  trimString,
  getMessageByStatus,
  HOST_TYPE_POWER,
  HOST_TYPE_NORMAL,
  RESULT_TYPE_JSON,
  RESULT_TYPE_TEXT,
} from '@/utils/utils';

import KEYS from './utils/storageKeys';
import { setItem, getItem, removeItem } from './storage';
import { getItemUserInfo } from './utils/userInfoEncrypt';
import { showErrorMessage, showErrorNotification } from './mamagement/Notification';

import 'moment/locale/zh-cn';

moment.locale('zh-cn');
const loginPath = `/user/login${REACT_APP_ENV !== 'poc' ? '' : '2'}`;
const loginPath2 = `/user/login${REACT_APP_ENV === 'prod' ? '' : '2'}`;

// 本地菜单和权限菜单
const nativePathName = new Set<string>();
const powersPathName = new Set<string>();
let allPathName: any[] = [];

logger.builder.buildProject(Projects.MANAGEMENT_SYSTEM).buildEnv(REACT_APP_ENV).build();

/** 获取用户信息比较慢的时候会展示一个 loading */
export const initialStateConfig = {
  loading: <PageLoading />,
};

/**
 * @see  https://umijs.org/zh-CN/plugins/plugin-initial-state
 * */
export async function getInitialState(): Promise<{
  currentUser: APIS.UserInfo | null;
  settings?: Partial<LayoutSettings>;
}> {
  const cacheStr = getItemUserInfo(KEYS.KEY_USER_INFO);
  const userCache = cacheStr && Object.keys(cacheStr).length > 0 ? cacheStr : null;
  const path = history.location.pathname;
  if (userCache == null && !(path === loginPath || path === loginPath2 || path === '/403')) {
    history.push(loginPath);
  }
  return {
    currentUser: userCache,
    settings: {},
  };
}

const addApiLogger = (options: any, response: any, res: any = undefined) => {
  const { startTime, urlName } = options;
  const duration = new Date().getTime() - startTime;
  logger.api({
    duration,
    url: urlName,
    status: res?.status,
    httpStatus: response?.status ?? -999999,
    message: res?.message,
  });
};

const requestInterceptor = (url: string, options: any) => {
  const { data, params, host, type = HOST_TYPE_NORMAL } = options;

  let _url = (host || HOST) + url;
  if (type === HOST_TYPE_POWER) {
    _url = (host || POWER_HOST) + url;
  }

  const _options = options;
  if (type === HOST_TYPE_NORMAL) {
    _options.headers = {
      ...getDLInfo(KEYS.KEY_USER_INFO),
    };
  } else if (type === HOST_TYPE_POWER) {
    const { _device, _token } = getDLInfo(KEYS.KEY_USER_INFO) || {};
    _options.headers = {
      device: _device,
      token: _token,
    };
  }
  _options.timeout = _url.endsWith('/upload') ? 600000 : 30000;
  _options.data = trimString(data);
  _options.params = trimString(params);
  _options.startTime = new Date().getTime();
  _options.urlName = url;
  return {
    url: _url,
    options: _options,
  };
};

const reLogin = () => {
  removeItem(KEYS.KEY_USER_INFO);
  const path = history.location.pathname;
  if (!(path === loginPath || path === loginPath2 || path === '/403')) {
    history.push(loginPath);
  }
};

const responseInterceptor = async (response: Response, options: any) => {
  if (options.responseType === 'blob') return response;
  const { type = HOST_TYPE_NORMAL, resultType = RESULT_TYPE_JSON } = options;
  let res: any;
  if (type === HOST_TYPE_POWER) {
    res = {
      status: -999,
      message: undefined,
      result: undefined,
    };
    if (response.status === 200) {
      res.status = 0;
      if (resultType === RESULT_TYPE_TEXT) {
        res.result = await response
          .clone()
          .text()
          .catch(() => undefined);
      } else {
        res.result = await response
          .clone()
          .json()
          .catch(() => undefined);
      }
    } else if (response.status === 401) {
      res.status = -300;
    } else {
      res.status = response.status;
      // if (response.status === 500) {
      const { message } = await response
        .clone()
        .json()
        .catch(() => undefined);
      res.message = message;
      // } else if (response.status !== 403) {
      //   res.message = `未知状态码：${res.status}`;
      // }
    }
  } else {
    res = await response.clone().json();
    // const { status } = res;
    // if (typeof status === 'undefined') {
    //   const temp = res;
    //   res = {
    //     status: -999,
    //     message: undefined,
    //     result: temp,
    //   };
    //   if (response.status === 200) {
    //     res.status = 0;
    //   } else if (response.status === 401) {
    //     res.status = -300;
    //   } else {
    //     res.status = response.status;
    //     const { message } = temp;
    //     res.message = message;
    //   }
    // }
  }

  if (response.status !== 200) {
    showErrorMessage(getMessageByStatus(response.status, res.message));
  }

  const { status } = res;
  addApiLogger(options, response, res);

  if (status) {
    if (status === -300) {
      reLogin();
    } else if (status !== 0) {
      showErrorMessage(getMessageByStatus(status, res.message) || '');
    }
  }
  return res;
};

export const request: RequestConfig = {
  errorHandler: (error: ResponseError) => {
    // const { messages } = getIntl(getLocale());
    const { response } = error;
    const { options } = error.request;
    if (!response) {
      showErrorNotification('您的网络发生异常，无法连接服务器');
    }
    addApiLogger(options, response);
    throw error;
  },
  requestInterceptors: [requestInterceptor],
  responseInterceptors: [responseInterceptor],
};

// ProLayout 支持的api https://procomponents.ant.design/components/layout
export const layout: RunTimeLayoutConfig = async ({ initialState }) => {
  return {
    rightContentRender: () => <RightContent />,
    disableContentMargin: false,
    onPageChange: () => {
      const userInfo = getDLInfo(KEYS.KEY_USER_INFO);

      logger.asyncToken(userInfo?._token);
      logger.pathChange();
      /* eslint no-underscore-dangle: 0 */
      const path = history.location.pathname;
      if (
        !userInfo?._device &&
        !userInfo?._token &&
        !(path === loginPath || path === loginPath2 || path === '/403')
      ) {
        history.push(loginPath);
        return;
      }
      if (nativePathName.has(path)) {
        if (!powersPathName.has(path)) {
          history.push('/403');
        } else {
          if (path === '/BI/accessBI') {
            if (BI_URL()) {
              window.open(
                `${BI_URL(
                  getItemUserInfo(KEYS.KEY_USER_INFO)?.token || '',
                  getItemUserInfo(KEYS.KEY_USER_INFO)?.device || '',
                )}`,
              );
            } else {
              showErrorMessage(' BI 报表暂不支持 POC 环境');
            }
          }
          if (path === '/BI/financeBI') {
            if (FINANCE_BI_URL()) {
              window.open(
                `${FINANCE_BI_URL(
                  getItemUserInfo(KEYS.KEY_USER_INFO)?.token || '',
                  getItemUserInfo(KEYS.KEY_USER_INFO)?.device || '',
                )}`,
              );
            } else {
              showErrorMessage(' BI 报表暂不支持 POC 环境');
            }
          }
        }
      } else {
        history.push('/404');
      }
    },
    links: [],
    logo: false,
    pageTitleRender: false,
    breadcrumbProps: {
      separator: '>',
      itemRender: (route, _params, routes) => {
        const index = routes.indexOf(route);
        if (index === 0 || index === routes.length - 1) return <span>{route.breadcrumbName}</span>;
        return <Link to={route.path}>{route.breadcrumbName}</Link>;
      },
    },
    menu: {
      locale: false,
      params: initialState?.currentUser,
      // request: (params, defaultMenuData) => initRemoteMenu(defaultMenuData),
      request: (params, defaultMenuData) => initRemoteMenuPower(defaultMenuData),
    },
    disableMobile: true,
    ...initialState?.settings,
  };
};

export const dva = {
  config: {
    onError(e: Error) {
      showErrorMessage(e.message);
    },
    onReducer: (reducer: Reducer<any, AnyAction>) => {
      const undoReducer = undoable(reducer);
      return function (state: StateWithHistory<any>, action: AnyAction) {
        const newState = undoReducer(state, action);
        const router = newState.present.router ? newState.present.router : newState.present.routing;
        return { ...newState, router };
      };
    },
  },
};

async function initRemoteMenuPower(defaultMenuData: MenuDataItem[]) {
  const needPowerCache = powersPathName.size < 1;
  // 将路由中的二维数组降为一维数组并存入数组中
  allPathName = _.cloneDeep(defaultMenuData);
  for (let i = 0; i < allPathName.length; i++) {
    if (allPathName[i].children) {
      allPathName = allPathName
        .slice(0, i + 1)
        .concat(allPathName[i].children, allPathName.slice(i + 1));
      delete allPathName[i].children;
    }
  }

  // 获取到本地所有的菜单路由
  allPathName.forEach((item) => {
    const itemPath = item.path ?? '';
    if (item.whiteMenu) {
      powersPathName.add(itemPath);
    }
    nativePathName.add(itemPath);
  });

  const cacheStr = getItemUserInfo(KEYS.KEY_USER_INFO);
  if (!cacheStr || Object.keys(cacheStr).length < 1) return defaultMenuData;

  // 读取缓存
  if (needPowerCache) {
    const powers = (getItem(KEYS.KEY_LOCAL_POWER) ?? '').split(',') ?? [];
    powers.forEach((item: string) => powersPathName.add(item));
  }

  // 获取到后端返给前端的菜单和权限数据
  const menus: any = await initPower();
  if (!(menus && menus.result && menus.result.length > 0)) {
    powersPathName.clear();
    allPathName.forEach((item) => {
      if (item.whiteMenu) {
        powersPathName.add(item.path || '');
      }
    });
    const cacheMenus: string[] = [];
    powersPathName.forEach((item: string) => cacheMenus.push(item));
    setItem(KEYS.KEY_LOCAL_POWER, cacheMenus.join(','));

    setItem(KEYS.KEY_POWER, JSON.stringify([]));
    return defaultMenuData;
  }

  // 将用户的菜单和权限赋值过去
  const remoteMenus: any[] = menus.result;
  // 展示出来的菜单
  const newMenu: any[] = [];
  const newPower: string[] = [];
  remoteMenus.forEach((menusItem) => {
    if (menusItem.type === 'MENU') {
      defaultMenuData.forEach((localItem) => {
        if (localItem.code === menusItem.code) {
          const tempItem = _.cloneDeep(localItem);
          tempItem.hideInMenu = false;
          powersPathName.add(tempItem.path ?? '');

          const childrenSize = tempItem.children?.length || 0;
          for (let i = 0; i < childrenSize; i += 1) {
            if (tempItem.children) {
              const childItem = tempItem.children[i];
              (menusItem.operations || []).forEach((sonItem: any) => {
                if (newPower.indexOf(`${localItem.code}-${sonItem.operationCode}`) === -1) {
                  newPower.push(`${localItem.code}-${sonItem.operationCode}`);
                }
                if (
                  `${localItem.code}-${childItem.code}` ===
                  `${localItem.code}-${sonItem.operationCode}`
                ) {
                  childItem.hideInMenu = false;
                  powersPathName.add(childItem.path ?? '');
                }
              });
            }
          }
          newMenu.push(tempItem);
        }
      });
      // 加入缓存
      const cacheMenus: string[] = [];
      powersPathName.forEach((item: string) => cacheMenus.push(item));
      setItem(KEYS.KEY_LOCAL_POWER, cacheMenus.join(','));
    } else {
      menusItem.operations?.forEach((operationsItem: { groupCode: any; operationCode: any }) => {
        newPower.push(`${operationsItem.groupCode}-${operationsItem.operationCode}`);
      });
    }
  });
  setItem(KEYS.KEY_POWER, JSON.stringify(newPower));
  return newMenu;
}

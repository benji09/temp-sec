import { useEffect, useRef } from 'react';
import { Tabs } from 'zarm';

import type { ITabConfig } from './schema';

import logo from '@/assets/images/tab.png';

import styles from './index.less';

interface TabType extends ITabConfig {
  isTpl?: boolean;
}

const { Panel } = Tabs;

const XTab = (props: TabType) => {
  const { tabs = ['分类一', '分类二'], activeColor, color, fontSize, sourceData, isTpl } = props;

  const tabWrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (tabWrapRef.current) {
      const res = tabWrapRef.current.querySelector('.za-tabs__line') as HTMLElement;
      if (res) {
        res.style.backgroundColor = activeColor;
      }
    }
  }, [activeColor]);

  return isTpl ? (
    <div>
      <img style={{ width: '100%' }} src={logo} alt="" />
    </div>
  ) : (
    <div className={styles.tabWrap} ref={tabWrapRef}>
      <Tabs onChange={() => {}}>
        {tabs.map((item, i) => {
          return (
            <Panel title={item} key={String(i)}>
              <div className={styles.content}>
                {sourceData
                  .filter((ite) => ite.type === i)
                  .map((ite, index) => {
                    return (
                      <div className={styles.item} key={String(index)}>
                        <a className={styles.imgWrap} href={ite.link} title={ite.desc}>
                          <img src={ite.imgUrl[0] && ite.imgUrl[0].url} alt={ite.title} />
                          <div className={styles.title} style={{ fontSize, color }}>
                            {ite.title}
                          </div>
                        </a>
                        <span className={styles.price}> {ite.price} </span>
                      </div>
                    );
                  })}
              </div>
            </Panel>
          );
        })}
      </Tabs>
    </div>
  );
};

export default XTab;

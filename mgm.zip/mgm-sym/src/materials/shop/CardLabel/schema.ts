import type {
  IColorConfigType,
  INumberConfigType,
  ITextConfigType,
  ITextAreaConfigType,
  IUploadConfigType,
  IRichTextConfigType,
  TColorDefaultType,
  TNumberDefaultType,
  TTextDefaultType,
  TUploadDefaultType,
} from '@/components/FormComponents/types';

export type TZLEditData = (
  | IUploadConfigType
  | ITextConfigType
  | IColorConfigType
  | INumberConfigType
  | ITextAreaConfigType
  | IRichTextConfigType
)[];
export interface IZLConfig {
  imgUrl: TUploadDefaultType;
  title: TTextDefaultType;
  titColor: TColorDefaultType;
  desc: TTextDefaultType;
  round: TNumberDefaultType;
  backgroundColor: TColorDefaultType;
  frontColor: TColorDefaultType;
  link: TTextDefaultType;
}

export interface ICardSchema {
  editData: TZLEditData;
  config: IZLConfig;
}

const CardLabel: ICardSchema = {
  editData: [
    {
      key: 'imgUrl',
      name: '图片',
      type: 'Upload',
    },
    {
      key: 'title',
      name: '标题',
      type: 'Text',
    },
    {
      key: 'titColor',
      name: '标题颜色',
      type: 'Color',
    },
    {
      key: 'desc',
      name: '描述',
      type: 'Text',
    },
    {
      key: 'round',
      name: '圆角',
      type: 'Number',
    },
    {
      key: 'backgroundColor',
      name: '背景色',
      type: 'Color',
    },
    {
      key: 'frontColor',
      name: '前景色',
      type: 'Color',
    },
    {
      key: 'link',
      name: '跳转链接',
      type: 'Text',
    },
  ],
  config: {
    imgUrl: [
      {
        uid: '001',
        name: 'image.png',
        status: 'done',
        url: ``,
      },
    ],
    backgroundColor: 'rgba(168,11,212,1)',
    round: 4,
    link: 'https://yesdream.cn/',
    title: '贵宾专享',
    titColor: 'rgba(255,255,255,1)',
    desc: '满199减100',
    frontColor: 'rgba(240,123,123,1)',
  },
};

export default CardLabel;

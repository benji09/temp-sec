const template = {
  type: 'Chart',
  h: 102,
  displayName: '柱状图组件',
};
export default template;

import { memo } from 'react';
import { Progress } from 'zarm';

import type { IXProgressConfig } from './schema';

import logo from '@/assets/images/progress.png';

const XProgress = memo((props: IXProgressConfig & { isTpl: boolean }) => {
  const { theme, size, shape, percent, strokeWidth, isTpl } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} alt="" />
        </div>
      ) : (
        <div style={{ textAlign: 'center' }}>
          <Progress
            shape={shape}
            size={size}
            percent={percent}
            theme={theme}
            strokeWidth={strokeWidth}
          />
        </div>
      )}
    </>
  );
});

export default XProgress;

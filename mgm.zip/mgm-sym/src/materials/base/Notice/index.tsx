import { memo } from 'react';
import { NoticeBar } from 'zarm';

import type { INoticeConfig } from './schema';

import logo from '@/assets/images/notice.png';

const Notice = memo((props: INoticeConfig & { isTpl: boolean }) => {
  const { text, speed, theme, isClose = false, isTpl } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} alt="" />
        </div>
      ) : (
        <NoticeBar theme={theme === 'default' ? undefined : theme} closable={isClose} speed={speed}>
          <span style={{ color: 'inherit' }}>{text}</span>
        </NoticeBar>
      )}
    </>
  );
});

export default Notice;

const template = {
  type: 'ImageThree',
  h: 59,
  displayName: '三图',
};
export default template;

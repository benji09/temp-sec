const template = {
  type: 'Carousel',
  h: 82,
  displayName: '轮播图组件',
};
export default template;

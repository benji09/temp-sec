const template = {
  type: 'ImageOne',
  h: 96,
  displayName: '单图',
};
export default template;

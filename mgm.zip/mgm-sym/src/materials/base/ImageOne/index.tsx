import { memo } from 'react';

import { openNewPage } from '@/utils/utils';

import type { IImageOneConfig } from './schema';

import logo from '@/assets/images/img_1.png';
import imgDefault from '@/assets/images/imgDefault1.png';

const ImageOne = memo((props: IImageOneConfig) => {
  const { marginTop, imgUrl, linkUrl } = props;
  return (
    <>
      {props.isTpl && (
        <div>
          <img src={logo} alt="" style={{ width: '100%' }} />
        </div>
      )}
      {!props.isTpl && (
        <div
          style={{
            overflow: 'hidden',
            position: 'absolute',
            width: `${props.baseWidth}%`,
            height: `${props.baseHeight}%`,
            borderRadius: props.baseRadius,
            transform: `translate(${props.baseLeft}px,${props.baseTop}px) scale(${
              props.baseScale / 100
            }) rotate(${props.baseRotate}deg)`,
          }}
        >
          <div
            style={{
              width: '100%',
              textAlign: 'center',
              overflow: 'hidden',
              position: 'relative',
              marginTop,
            }}
          >
            <div onClick={() => openNewPage(linkUrl)} style={{ width: '100%' }}>
              <img
                src={imgUrl && imgUrl.length > 0 ? imgUrl[0].url : imgDefault}
                style={{ width: '100%' }}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
});

export default ImageOne;

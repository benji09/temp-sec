import type {
  IUploadConfigType,
  TUploadDefaultType,
  TTextDefaultType,
  ITextConfigType,
  INumberConfigType,
  TNumberDefaultType,
} from '@/components/FormComponents/types';

import type { ICommonBaseType } from '../../common';
import { baseDefault } from '../../common';

export type TImageOneEditData = (INumberConfigType | IUploadConfigType | ITextConfigType)[];

export interface IImageOneConfig extends ICommonBaseType {
  marginTop: TNumberDefaultType;
  imgUrl: TUploadDefaultType;
  linkUrl: TTextDefaultType;
}

export interface IImageOneSchema {
  editData: TImageOneEditData;
  config: IImageOneConfig;
}

const ImageOne: IImageOneSchema = {
  editData: [
    {
      key: 'marginTop',
      name: '段前',
      type: 'Number',
    },
    {
      key: 'imgUrl',
      name: '图片',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl',
      name: '点击链接',
      type: 'Text',
    },
  ],
  config: {
    marginTop: 0,
    imgUrl: [],
    linkUrl: '',
    ...baseDefault,
  },
};

export default ImageOne;

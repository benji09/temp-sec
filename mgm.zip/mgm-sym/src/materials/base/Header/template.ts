const template = {
  type: 'Header',
  h: 28,
  displayName: '页头组件',
};
export default template;

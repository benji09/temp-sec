const template = {
  type: 'Footer',
  h: 36,
  displayName: '页脚组件',
};
export default template;

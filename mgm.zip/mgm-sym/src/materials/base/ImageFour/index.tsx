import { memo } from 'react';

import { openNewPage } from '@/utils/utils';

import type { IImageFourConfig } from './schema';

import logo from '@/assets/images/img_4.png';
import imgDefault from '@/assets/images/imgDefault4.png';

const ImageFour = memo((props: IImageFourConfig) => {
  const {
    marginTop,
    imgSpace,
    imgUrl1,
    linkUrl1,
    imgUrl2,
    linkUrl2,
    imgUrl3,
    linkUrl3,
    imgUrl4,
    linkUrl4,
  } = props;
  return (
    <>
      {props.isTpl && (
        <div>
          <img src={logo} alt="" style={{ width: '100%' }} />
        </div>
      )}
      {!props.isTpl && (
        <div
          style={{
            overflow: 'hidden',
            position: 'absolute',
            width: `${props.baseWidth}%`,
            height: `${props.baseHeight}%`,
            borderRadius: props.baseRadius,
            transform: `translate(${props.baseLeft}px,${props.baseTop}px) 
      scale(${props.baseScale / 100}) 
      rotate(${props.baseRotate}deg)`,
          }}
        >
          <div
            style={{
              width: '100%',
              textAlign: 'center',
              overflow: 'hidden',
              position: 'relative',
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop,
            }}
          >
            <div
              onClick={() => openNewPage(linkUrl1)}
              style={{ width: `${25 - imgSpace / 4}%`, maxWidth: '25%' }}
            >
              <img
                src={imgUrl1 && imgUrl1.length > 0 ? imgUrl1[0].url : imgDefault}
                style={{ width: '100%' }}
              />
            </div>
            <div
              onClick={() => openNewPage(linkUrl2)}
              style={{ width: `${25 - imgSpace / 4}%`, maxWidth: '25%' }}
            >
              <img
                src={imgUrl2 && imgUrl2.length > 0 ? imgUrl2[0].url : imgDefault}
                style={{ width: '100%' }}
              />
            </div>
            <div
              onClick={() => openNewPage(linkUrl3)}
              style={{ width: `${25 - imgSpace / 4}%`, maxWidth: '25%' }}
            >
              <img
                src={imgUrl3 && imgUrl3.length > 0 ? imgUrl3[0].url : imgDefault}
                style={{ width: '100%' }}
              />
            </div>
            <div
              onClick={() => openNewPage(linkUrl4)}
              style={{ width: `${25 - imgSpace / 4}%`, maxWidth: '25%' }}
            >
              <img
                src={imgUrl4 && imgUrl4.length > 0 ? imgUrl4[0].url : imgDefault}
                style={{ width: '100%' }}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
});

export default ImageFour;

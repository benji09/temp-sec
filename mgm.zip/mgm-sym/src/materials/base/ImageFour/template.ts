const template = {
  type: 'ImageFour',
  h: 47,
  displayName: '四图',
};
export default template;

import type {
  IUploadConfigType,
  TUploadDefaultType,
  TTextDefaultType,
  ITextConfigType,
  INumberConfigType,
  TNumberDefaultType,
} from '@/components/FormComponents/types';

import type { ICommonBaseType } from '../../common';
import { baseDefault } from '../../common';

export type TImageFourEditData = (INumberConfigType | IUploadConfigType | ITextConfigType)[];

export interface IImageFourConfig extends ICommonBaseType {
  marginTop: TNumberDefaultType;
  imgSpace: TNumberDefaultType;
  imgUrl1: TUploadDefaultType;
  linkUrl1: TTextDefaultType;
  imgUrl2: TUploadDefaultType;
  linkUrl2: TTextDefaultType;
  imgUrl3: TUploadDefaultType;
  linkUrl3: TTextDefaultType;
  imgUrl4: TUploadDefaultType;
  linkUrl4: TTextDefaultType;
}

export interface IImageFourSchema {
  editData: TImageFourEditData;
  config: IImageFourConfig;
}

const ImageFour: IImageFourSchema = {
  editData: [
    {
      key: 'marginTop',
      name: '段前',
      type: 'Number',
    },
    {
      key: 'imgSpace',
      name: '图片间距',
      type: 'Number',
    },
    {
      key: 'imgUrl1',
      name: '图片1',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl1',
      name: '点击链接1',
      type: 'Text',
    },
    {
      key: 'imgUrl2',
      name: '图片2',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl2',
      name: '点击链接2',
      type: 'Text',
    },
    {
      key: 'imgUrl3',
      name: '图片3',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl3',
      name: '点击链接3',
      type: 'Text',
    },
    {
      key: 'imgUrl4',
      name: '图片4',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl4',
      name: '点击链接4',
      type: 'Text',
    },
  ],
  config: {
    marginTop: 0,
    imgSpace: 1,
    imgUrl1: [],
    linkUrl1: '',
    imgUrl2: [],
    linkUrl2: '',
    imgUrl3: [],
    linkUrl3: '',
    imgUrl4: [],
    linkUrl4: '',
    ...baseDefault,
  },
};

export default ImageFour;

const template = {
  type: 'LongText',
  h: 36,
  displayName: '长文本',
};
export default template;

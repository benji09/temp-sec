import { memo } from 'react';

import type { ILongTextConfig } from './schema';

import logo from '@/assets/images/longText.png';

const LongText = memo((props: ILongTextConfig & { isTpl: boolean }) => {
  const {
    marginTop,
    text,
    fontSize,
    color,
    indent,
    lineHeight,
    textAlign,
    backgroundColor,
    padding,
    radius,
    isTpl,
  } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} alt="" style={{ width: '100%' }} />
        </div>
      ) : (
        <div
          style={{
            marginTop,
            color,
            textIndent: `${indent}px`,
            fontSize,
            lineHeight,
            textAlign,
            backgroundColor,
            padding,
            height: '100%',
            borderRadius: radius,
          }}
        >
          {text}
        </div>
      )}
    </>
  );
});
export default LongText;

import { memo } from 'react';

import type { ITextConfig } from './schema';

import logo from '@/assets/images/text.png';

const Text = memo((props: ITextConfig & { isTpl: boolean }) => {
  const { align, text, fontSize, color, lineHeight, isTpl } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} alt="" />
        </div>
      ) : (
        <div style={{ color, textAlign: align, fontSize, lineHeight }}>{text}</div>
      )}
    </>
  );
});
export default Text;

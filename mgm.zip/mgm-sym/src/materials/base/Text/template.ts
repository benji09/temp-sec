const template = {
  type: 'Text',
  h: 20,
  displayName: '文本组件',
};
export default template;

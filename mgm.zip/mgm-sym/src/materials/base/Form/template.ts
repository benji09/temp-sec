const template = {
  type: 'Form',
  h: 172,
  displayName: '表格组件',
};
export default template;

import type {
  IColorConfigType,
  INumberConfigType,
  ITextConfigType,
  TColorDefaultType,
  TNumberDefaultType,
  TTextDefaultType,
} from '@/components/FormComponents/types';

export type TWhiteTplEditData = (IColorConfigType | INumberConfigType | ITextConfigType)[];
export interface IWhiteTplConfig {
  backgroundColor: TColorDefaultType;
  text: TTextDefaultType;
  fontSize: TNumberDefaultType;
  color: TColorDefaultType;
  lineHeight: TNumberDefaultType;
}

export interface IWhiteTplSchema {
  editData: TWhiteTplEditData;
  config: IWhiteTplConfig;
}

const WhiteTpl: IWhiteTplSchema = {
  editData: [
    {
      key: 'backgroundColor',
      name: '背景色',
      type: 'Color',
    },
    {
      key: 'lineHeight',
      name: '行高',
      type: 'Number',
    },
    {
      key: 'text',
      name: '文字',
      type: 'Text',
    },
    {
      key: 'color',
      name: '文字颜色',
      type: 'Color',
    },
    {
      key: 'fontSize',
      name: '文字大小',
      type: 'Number',
    },
  ],
  config: {
    backgroundColor: 'rgba(255,255,255,1)',
    text: '',
    fontSize: 16,
    color: 'rgba(210,210,210,1)',
    lineHeight: 30,
  },
};

export default WhiteTpl;

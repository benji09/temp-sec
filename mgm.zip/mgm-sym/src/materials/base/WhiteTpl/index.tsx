import { memo } from 'react';

import type { IWhiteTplConfig } from './schema';

import logo from '@/assets/images/white.png';

import styles from './index.less';

interface IProps extends IWhiteTplConfig {
  isTpl: boolean;
}

const WhiteTpl = memo((props: IProps) => {
  const { backgroundColor, text, fontSize, color, lineHeight, isTpl } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} alt="" />
        </div>
      ) : (
        <div className={styles.whiteTpl} style={{ backgroundColor, lineHeight: `${lineHeight}px` }}>
          <div className={styles.title} style={{ fontSize, color }}>
            {text}
          </div>
        </div>
      )}
    </>
  );
});

export default WhiteTpl;

// import Carousel from './Carousel/template';
// import Footer from './Footer/template';
// import Form from './Form/template';
// import Header from './Header/template';
// import Icon from './Icon/template';
// import Image from './Image/template';
// import List from './List/template';
// import Notice from './Notice/template';
// import Qrcode from './Qrcode/template';
// import Tab from './Tab/template';
// import Text from './Text/template';
// import RichText from './RichText/template';
// import WhiteTpl from './WhiteTpl/template';
import LongText from './LongText/template';
import ImageOne from './ImageOne/template';
import ImageTwo from './ImageTwo/template';
import ImageThree from './ImageThree/template';
import ImageFour from './ImageFour/template';
import FixedBottomButton from './FixedBottomButton/template';

const basicTemplate = [
  // Carousel,
  // Footer,
  // Form,
  // Header,
  // Icon,
  // Image,
  // List,
  // Notice,
  // Qrcode,
  // Tab,
  // Text,
  // RichText,
  // WhiteTpl,
  ImageOne,
  ImageTwo,
  ImageThree,
  ImageFour,
  LongText,
  FixedBottomButton,
];
const BasicTemplate = basicTemplate.map((v) => {
  return { ...v, category: 'base' };
});

export default BasicTemplate;

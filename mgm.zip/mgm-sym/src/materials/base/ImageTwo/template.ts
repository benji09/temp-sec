const template = {
  type: 'ImageTwo',
  h: 82,
  displayName: '双图',
};
export default template;

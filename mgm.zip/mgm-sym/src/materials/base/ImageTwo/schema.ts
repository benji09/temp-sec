import type {
  IUploadConfigType,
  TUploadDefaultType,
  TTextDefaultType,
  ITextConfigType,
  INumberConfigType,
  TNumberDefaultType,
} from '@/components/FormComponents/types';

import { baseDefault } from '../../common';
import type { ICommonBaseType } from '../../common';

export type TImageTwoEditData = (INumberConfigType | IUploadConfigType | ITextConfigType)[];

export interface IImageTwoConfig extends ICommonBaseType {
  marginTop: TNumberDefaultType;
  imgSpace: TNumberDefaultType;
  imgUrl1: TUploadDefaultType;
  linkUrl1: TTextDefaultType;
  imgUrl2: TUploadDefaultType;
  linkUrl2: TTextDefaultType;
}

export interface IImageTwoSchema {
  editData: TImageTwoEditData;
  config: IImageTwoConfig;
}

const ImageTwo: IImageTwoSchema = {
  editData: [
    {
      key: 'marginTop',
      name: '段前',
      type: 'Number',
    },
    {
      key: 'imgSpace',
      name: '图片间距',
      type: 'Number',
    },
    {
      key: 'imgUrl1',
      name: '图片1',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl1',
      name: '点击链接1',
      type: 'Text',
    },
    {
      key: 'imgUrl2',
      name: '图片2',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'linkUrl2',
      name: '点击链接2',
      type: 'Text',
    },
  ],
  config: {
    marginTop: 0,
    imgSpace: 1,
    imgUrl1: [],
    linkUrl1: '',
    imgUrl2: [],
    linkUrl2: '',
    ...baseDefault,
  },
};

export default ImageTwo;

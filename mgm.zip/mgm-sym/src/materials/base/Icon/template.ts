const template = {
  type: 'Icon',
  h: 36,
  displayName: '图标组件',
};
export default template;

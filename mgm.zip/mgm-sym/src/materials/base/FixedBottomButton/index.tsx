import { memo } from 'react';

import { openNewPage } from '@/utils/utils';

import type { IFooterConfig } from './schema';

import logo from '@/assets/images/fixedBottom.png';
import defaultBtnImg from '@/assets/images/fixedBtn.png';

export default memo((props: IFooterConfig) => {
  const { align, imgUrl, clickUrl } = props;

  return (
    <>
      {props.isTpl && (
        <div>
          <img src={logo} alt="" style={{ width: '100%' }} />
        </div>
      )}
      {!props.isTpl && (
        <div
          style={{
            overflow: 'hidden',
            position: 'absolute',
            width: `${props.baseWidth}%`,
            height: `${props.baseHeight}%`,
            borderRadius: props.baseRadius,
            transform: `translate(${props.baseLeft}px,${props.baseTop}px) 
                scale(${props.baseScale / 100}) 
                rotate(${props.baseRotate}deg)`,
          }}
        >
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: align,
              width: '100%',
            }}
            onClick={() => openNewPage(clickUrl)}
          >
            <img src={imgUrl.length ? imgUrl[0].url : defaultBtnImg} style={{ width: '100%' }} />
          </div>
        </div>
      )}
    </>
  );
});

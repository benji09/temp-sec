import { FixedEnum } from '@/core/enums';

const template = {
  type: 'FixedBottomButton',
  h: 36,
  displayName: '吸底按钮',
  fixed: FixedEnum.bottom,
  only: true,
};
export default template;

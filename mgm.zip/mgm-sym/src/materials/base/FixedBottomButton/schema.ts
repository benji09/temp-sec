import type { ICommonBaseType } from '@/materials/common';
import { baseDefault } from '@/materials/common';
import type {
  ISelectConfigType,
  ITextConfigType,
  IUploadConfigType,
  TSelectDefaultType,
  TTextDefaultType,
  TUploadDefaultType,
} from '@/components/FormComponents/types';

export type TFooterSelectKeyType = 'flex-start' | 'center' | 'flex-end';

export type TFooterEditData = (
  | IUploadConfigType
  | ITextConfigType
  | ISelectConfigType<TFooterSelectKeyType>
)[];
export interface IFooterConfig extends ICommonBaseType {
  imgUrl: TUploadDefaultType;
  clickUrl: TTextDefaultType;
  align: TSelectDefaultType<TFooterSelectKeyType>;
}

export interface IFooterSchema {
  editData: TFooterEditData;
  config: IFooterConfig;
}

const FixedBottomButton: IFooterSchema = {
  editData: [
    {
      key: 'imgUrl',
      name: '图片',
      type: 'Upload',
      isCrop: false,
    },
    {
      key: 'clickUrl',
      name: '点击链接',
      type: 'Text',
    },
  ],
  config: {
    imgUrl: [],
    clickUrl: '',
    align: 'flex-end',
    ...baseDefault,
  },
};
export default FixedBottomButton;

const template = {
  type: 'Calendar',
  h: 185,
  displayName: '日历组件',
};
export default template;

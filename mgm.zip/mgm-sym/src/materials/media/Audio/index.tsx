import { memo } from 'react';
import ReactAudioPlayer from 'react-audio-player';

import type { IAudioConfig } from './schema';

import logo from '@/assets/images/music@2x.png';

import styles from './index.less';

const AudioPlayer = memo((props: IAudioConfig & { isTpl: boolean }) => {
  const { height, url, isTpl } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} style={{ width: '100%' }} alt="音频播放组件" />
        </div>
      ) : (
        <div className={styles.audioWrap}>
          <ReactAudioPlayer
            src={url}
            autoPlay={false}
            controls
            style={{
              width: '100%',
              height: `${height}px`,
            }}
          />
        </div>
      )}
    </>
  );
});

export default AudioPlayer;

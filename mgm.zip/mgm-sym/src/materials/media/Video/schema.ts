import type {
  INumberConfigType,
  ITextConfigType,
  IUploadConfigType,
  TNumberDefaultType,
  TTextDefaultType,
  TUploadDefaultType,
} from '@/components/FormComponents/types';

export type TVideoEditData = (INumberConfigType | IUploadConfigType | ITextConfigType)[];
export interface IVideoConfig {
  marginTop: TNumberDefaultType;
  poster: TUploadDefaultType;
  videoUrl: TTextDefaultType;
  uploadVideo: TUploadDefaultType;
}

export interface IVideoSchema {
  editData: TVideoEditData;
  config: IVideoConfig;
}

const Video: IVideoSchema = {
  editData: [
    {
      key: 'marginTop',
      name: '段前',
      type: 'Number',
    },
    {
      key: 'poster',
      name: '视频封面',
      type: 'Upload',
    },
    {
      key: 'videoUrl',
      name: '视频链接',
      type: 'Text',
    },
    {
      key: 'uploadVideo',
      name: '上传视频',
      type: 'UploadVideo',
    },
  ],
  config: {
    marginTop: 0,
    poster: [],
    videoUrl: '',
    uploadVideo: [],
  },
};

export default Video;

const template = {
  type: 'Video',
  h: 105,
  displayName: '视频',
};
export default template;

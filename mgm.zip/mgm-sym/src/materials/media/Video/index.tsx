import { memo } from 'react';
import { Player, BigPlayButton } from 'video-react';

import type { IVideoConfig } from './schema';

import logo from '@/assets/images/video.png';
import imgDefault from '@/assets/images/imgDefaultPoster.png';

import './index.css';

const VideoPlayer = memo((props: IVideoConfig & { isTpl: boolean }) => {
  const { marginTop, poster, videoUrl, isTpl } = props;
  return (
    <>
      {isTpl ? (
        <div>
          <img src={logo} alt="" style={{ width: '100%' }} />
        </div>
      ) : (
        <div style={{ marginTop }}>
          <Player
            playsInline
            poster={poster && poster.length > 0 ? poster[0].url : imgDefault}
            src={
              videoUrl && videoUrl.length > 0
                ? `${videoUrl.replace('.MP4', '.mp4')}?code=${Math.random()}`
                : videoUrl
            }
          >
            {videoUrl && videoUrl.startsWith('http') ? <BigPlayButton position="center" /> : null}
          </Player>
        </div>
      )}
    </>
  );
});

export default VideoPlayer;

declare module 'slash2';
declare module '*.css';
declare module '*.less';
declare module '*.scss';
declare module '*.sass';
declare module '*.svg';
declare module '*.png';
declare module '*.jpg';
declare module '*.jpeg';
declare module '*.gif';
declare module '*.bmp';
declare module '*.tiff';
declare module '*.ico';
declare module 'omit.js';
declare module 'numeral';
declare module '@antv/data-set';
declare module 'react-fittext';
declare module 'bizcharts-plugin-slider';
declare module '@yuji/logger';

// google analytics interface
type GAFieldsObject = {
  eventCategory: string;
  eventAction: string;
  eventLabel?: string;
  eventValue?: number;
  nonInteraction?: boolean;
  currentCates?: null | string[];
  opera?: string; // note (@livs-ops): fix property 'opera' does not exist on type 'Window & typeof globalThis'
};

type Window = {
  ga: (
    command: 'send',
    hitType: 'event' | 'pageview',
    fieldsObject: GAFieldsObject | string,
  ) => void;
  reloadAuthorized: () => void;
  routerBase: string;
  currentCates: unknown[];
  getFaceUrl: string;
};

declare let ga: () => void;

declare const REACT_APP_ENV: 'test' | 'poc' | 'prod' | false;

declare module 'dom-to-image' {
  const domtoimage: any;
  export default domtoimage;
}

declare let getFaceUrl: any;

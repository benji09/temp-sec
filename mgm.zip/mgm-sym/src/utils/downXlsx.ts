export const ClickDownXlsx = (res: any, fileName: string = '', suffix = 'xlsx') => {
  const blob = new Blob([res]);
  const objectURL = URL.createObjectURL(blob);
  let btn: HTMLAnchorElement | null = document.createElement('a');
  btn.download = `${fileName}.${suffix}`;
  btn.href = objectURL;
  btn.click();
  URL.revokeObjectURL(objectURL);
  btn = null;
};

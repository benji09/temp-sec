export function timeStamp(value: number | undefined) {
  // 时间戳为10位需*1000，时间戳为13位的话不需乘1000
  const date = value ? new Date(String(value).length === 10 ? value * 1000 : value) : '';
  const Y = date && date.getFullYear();
  const M =
    date && date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date && date.getMonth() + 1;
  const D = date && date.getDate() < 10 ? '0' + date.getDate() : date && date.getDate();
  const h = date && date.getHours() < 10 ? '0' + date.getHours() : date && date.getHours();
  const m = date && date.getMinutes() < 10 ? '0' + date.getMinutes() : date && date.getMinutes();
  const s = date && date.getSeconds() < 10 ? '0' + date.getSeconds() : date && date.getSeconds();
  if (value) {
    return Y + '-' + M + '-' + D + ' ' + h + ':' + m + ':' + s;
  } else {
    return '';
  }
}
export function formatDate(value: number | undefined) {
  //  时间戳为10位需*1000，时间戳为13位的话不需乘1000
  const date = value ? new Date(String(value).length === 10 ? value * 1000 : value) : '';
  const Y = date && date.getFullYear();
  const M =
    date && (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '月';
  const D =
    date && date.getDate() < 10 ? '0' + date.getDate() + '日 ' : date && date.getDate() + '日 ';
  const h =
    date && date.getHours() < 10 ? '0' + date.getHours() + ':' : date && date.getHours() + ':';
  const m =
    date && date.getMinutes() < 10
      ? '0' + date.getMinutes() + ':'
      : date && date.getMinutes() + ':';
  const s = date && date.getSeconds() < 10 ? '0' + date.getSeconds() : date && date.getSeconds();
  if (value) {
    return Y + '年' + M + D + h + m + s;
  } else {
    return '';
  }
}

export default { timeStamp, formatDate };

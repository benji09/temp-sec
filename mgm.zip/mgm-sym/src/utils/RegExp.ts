// 手机号
export const mobilePhoneReg = (mobile: string) => {
  const mobilePhone = /^[0-9]{11}$/;
  const mobilePhonereg = new RegExp(mobilePhone);
  return mobilePhonereg.test(mobile);
};
// 手机号
export const cardSingleMobilePhoneReg = (mobile: string) => {
  const mobilePhone = /^(?:0|86|\\+86)?1[3-9]\d{9}/;
  const mobilePhonereg = new RegExp(mobilePhone);
  return mobilePhonereg.test(mobile);
};

// 密码6-20为不可使用特殊字符
export const passwordReg = (password: string) => {
  const checkout = /^[a-zA-Z0-9]{6,20}$/;
  const passwordreg = new RegExp(checkout);
  return passwordreg.test(password);
};
//
export const numberReg = (Id: string) => {
  const Number = /^\d*$/;
  const Numberreg = new RegExp(Number);
  return Numberreg.test(Id);
};
// 密码6-20为不可使用特殊字符
export const EmailReg = (password: string) => {
  const Email = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
  const passwordreg = new RegExp(Email);
  return passwordreg.test(password);
};

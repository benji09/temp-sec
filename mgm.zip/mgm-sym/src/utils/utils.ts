import { useState, useEffect } from 'react';
import dayjs from 'dayjs';
import { Upload } from 'antd';
import { isArray } from 'lodash';
import type { RcFile } from 'antd/lib/upload';

import { getItem } from '@/services/localStorage';
import { showErrorMessage } from '@/mamagement/Notification';

import KEYS from './storageKeys';
import { FileSizeUnit, FileTypeUnit } from './fileSizeUnit';

const reg =
  /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+(?::\d+)?|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/;

export const isUrl = (path: string): boolean => reg.test(path);

export const useDebounce = <T>(value: T, delay: number): T => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const timeout = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timeout);
  }, [value, delay]);
  return debouncedValue;
};

export const openNewPage = (url: string) => {
  const isPreview = getItem(KEYS.KEY_IS_PREVIEW);
  if (isPreview && url && url.startsWith('http')) window.open(url);
};

export const getMessageByStatus = (status: number, def: string): string => {
  let msg = def;
  switch (status) {
    // case -100: {
    //   msg = '无效的目标';
    //   break;
    // }
    // case -200: {
    //   msg = '无效的设备';
    //   break;
    // }
    case -403: {
      msg = '无访问权限';
      break;
    }
    case -401: {
      msg = '无效的token';
      break;
    }
    // case -500: {
    //   msg = '服务器内部错误';
    //   break;
    // }
    // case -600: {
    //   msg = '校验未通过';
    //   break;
    // }
    // case -999: {
    //   msg = '服务器内部错误';
    //   break;
    // }
    default: {
      break;
    }
  }
  return msg;
};

const MAX_IMAGE_SIZE = 1;
const MAX_VIDEO_SIZE = 200;

// 文件类型
function checkFileType(file: RcFile, type: string) {
  const isImg = file.type && file.type.indexOf(type) >= 0;
  if (isImg) return true;

  showErrorMessage(`请上传${FileTypeUnit[type]}文件`);
  return false;
}
// 文件大小
export function checkFileSize(file: RcFile, maxSize: number, unit: number) {
  let countBySize = 0;
  if (unit === 1) {
    countBySize = maxSize / 8;
  }
  if (unit === 2) {
    countBySize = maxSize;
  }
  if (unit === 3) {
    countBySize = maxSize * 1024;
  }
  if (unit === 4) {
    countBySize = maxSize * 1024 * 1024;
  }
  if (unit === 5) {
    countBySize = maxSize * 1024 * 1024 * 1024;
  }
  if (unit === 6) {
    countBySize = maxSize * 1024 * 1024 * 1024 * 1024;
  }
  const sizeLimit = file.size < countBySize;
  if (sizeLimit) return true;
  showErrorMessage(`文件必须小于 ${maxSize}${FileSizeUnit(unit)}`);
  return false;
}
// 文件宽高
function checkFileWideAndHight(file: RcFile, maxWidth: number, maxHeight: number) {
  const xlsxJson = new Promise((resolve) => {
    const URL = window.URL || window.webkitURL;
    const img = new Image();
    img.onload = function () {
      // 宽高 300 * 300 内
      if (img.width > maxWidth || img.height > maxHeight) {
        showErrorMessage(`请上传 ${maxWidth} * ${maxHeight} 的图片`);
        resolve(false);
      }
      resolve(true);
    };
    img.src = URL.createObjectURL(file);
  });
  return xlsxJson;
}
// 上传微信分享图片
export function checkImageTypeAndSizeAndWideAndHight(
  file: RcFile,
  maxWidth: number = 300,
  maxHeight: number = 300,
) {
  return new Promise(async (resolve: (value: string | boolean) => void) => {
    // 文件类型为图片
    if (!checkFileType(file, 'image')) resolve(Upload.LIST_IGNORE);
    // 大小 200k 以内
    if (!checkFileSize(file, 200, 3)) resolve(Upload.LIST_IGNORE);
    // 宽高
    checkFileWideAndHight(file, maxWidth, maxHeight).then((res) => {
      if (!res) resolve(Upload.LIST_IGNORE);
      resolve(true);
    });
  });
}
// 检查图片的类型和大小
export function checkImageTypeAndSize(
  file: RcFile,
  fileList?: RcFile[],
  type: string = 'image',
  maxSize: number = MAX_IMAGE_SIZE,
  unit: number = 4,
) {
  if (!checkFileType(file, type)) return Upload.LIST_IGNORE;
  if (!checkFileSize(file, maxSize, unit)) return Upload.LIST_IGNORE;
  return true;
}
// 检查视频的类型和大小
export function checkVideoTypeAndSize(file: RcFile) {
  if (!checkFileType(file, 'video')) return Upload.LIST_IGNORE;
  if (!checkFileSize(file, MAX_VIDEO_SIZE, 4)) return Upload.LIST_IGNORE;
  return true;
}
// 检查 pdf 的类型和大小
export function checkPdfTypeAndSize(file: RcFile) {
  if (!checkFileType(file, 'pdf')) return Upload.LIST_IGNORE;
  if (!checkFileSize(file, MAX_VIDEO_SIZE, 4)) return Upload.LIST_IGNORE;
  return true;
}

export const DEFAULT_TIME_FORMAT = 'YYYY-MM-DD HH:mm:ss';
export const TIME_FORMAT_DAY = 'YYYY-MM-DD';

export function formatTime(
  time: number | string | undefined,
  format: string = DEFAULT_TIME_FORMAT,
  defaultTime: string | undefined | null = '',
) {
  if (!time || time === '0') return defaultTime;

  if (!isNaN(Number(time))) {
    if (String(time).length === 10) {
      return dayjs.unix(Number(time)).format(format);
    }
    return dayjs(Number(time)).format(format);
  } else {
    return time;
  }
}

export const defaultFormLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

export const isFalsy = (value: unknown) => (value === 0 ? false : !value);

export const isVoid = (value: unknown) =>
  value === undefined ||
  value === null ||
  value === '' ||
  (typeof value === 'string' && value.trim().length < 1);

export const cleanObject = (object?: Record<string, any>) => {
  if (!object) return {};
  const result = { ...object };
  Object.keys(result).forEach((key) => {
    const value = result[key];
    if (isVoid(value)) {
      delete result[key];
    }
  });
  return result;
};

export const trimString = (object?: Record<string, any>) => {
  if (!object) return object;
  if (Object.prototype.toString.call(object) !== '[Object Object]') return object;
  const result = { ...object };
  Object.keys(result).forEach((key) => {
    const value = result[key];
    if (typeof value === 'string') result[key] = value.trim();
  });
  return result;
};

export const checkIsNumberForSearch = (
  data: any | undefined,
  msgSuffix: string | undefined = undefined,
  msgPreffix: string = '请输入正确的 ',
) => {
  if (data && data.toString().trim().length > 0) {
    if (!/^\d+$/.test(data.toString())) {
      if (msgSuffix) showErrorMessage(`${msgPreffix}${msgSuffix}`);
      return {
        data: [],
        total: 0,
      };
    }
  }
  return null;
};

/**
 * 根据传入数据加工成所需金额数据
 * @param value 需要进行加工的数据
 * @param defaultValue 默认值
 * @param fractionDigits 小数保留位数
 * @param prefix 前缀
 * @returns
 */
export const getSafeMoney = (
  value: number | string | undefined | null,
  defaultValue: string | number | undefined = undefined,
  fractionDigits: number = 2,
  prefix: string | number = '￥',
) => {
  if (value === undefined || value === null) return defaultValue;
  const valueStr = String(value).trim();
  if (valueStr.length < 1) return defaultValue;
  let result;
  const temp = valueStr.split('.');
  if (temp && temp.length > 1 && temp[1].length > fractionDigits) {
    result = parseFloat(valueStr).toFixed(fractionDigits);
  } else {
    result = valueStr;
  }
  return `${prefix}${result}`;
};

export const HOST_TYPE_OTHER = -1; // 其他域名配置方式
export const HOST_TYPE_NORMAL = 0; // 默认方式，使用基本配置域名
export const HOST_TYPE_POWER = 1; // 权限相关域名

export const RESULT_TYPE_JSON = 100; // json 数据格式
export const RESULT_TYPE_TEXT = 101; // text 数据格式
export const RESULT_TYPE_BLOB = 102; // blob 数据格式

// InputNumber 中截取整数
export function defaultParser(
  values: string | undefined,
  requireInteger: boolean = true,
  fractionDigits: number = 2,
  defaultValue: number = 0,
) {
  if (!values || !/^\d+(.)?\d*$/.test(values)) return defaultValue;
  if (requireInteger || values.indexOf('.') < 0) return parseInt(values, 10);
  const temp = values.split('.');
  if (temp.length > 1 && temp[1].length > fractionDigits)
    return parseFloat(values).toFixed(fractionDigits);
  return parseFloat(values);
}

// 判断字段是否存在
const isFields = (data: any) => {
  if (typeof data === 'undefined' || data === null) return true;
  if (typeof data === 'string' && data.trim() === '') return true;
  // 判读除数据是否是对象 如果是则判断对象里面是否有数据
  // if (Object.prototype.toString.call(data) === '[object Object]' && data.object.keys().length <= 0) return true;
  if (isArray(data) && data.length <= 0) return true;
  return false;
};
export function hasFields(data: any, Fields: string[]) {
  if (Object.keys(data ?? {}).length < 1 || Fields.length < 1) return undefined;
  let newFields = {};

  const tempFields = Fields.map((item) => {
    newFields = data[item];
    if (isFields(newFields)) return false;
    return true;
  });

  // 如果数组中有 false 则代表数据中有不存在的数据
  if (tempFields.indexOf(false) >= 0) {
    return true;
  }
  return false;
}

// 上传文件信息
export const UploadSucceed = 1; // 成功
export const UploadFailure = 2; // 失败
export const UploadProgress = 3; // 上传中
export const UploadResult = (status: number, type: string = ''): string => {
  if (!status) return '';
  if (status === UploadSucceed) return `${type} 文件上传成功`;
  else if (status === UploadFailure) return `${type} 文件上传失败`;
  else if (status === UploadProgress) return `${type} 文件上传中`;

  return '';
};

// 上传文件格式
export const typeUploaded = (type: string = ''): string => `只能上传格式为 ${type} 的文件`;

// 身份证隐藏

export function idCardNoHiding(idCardNo: string) {
  if (!idCardNo) return '';
  // 身份证 18 位
  let str = '';
  str = idCardNo.slice(0, 4) + '**********' + idCardNo.slice(idCardNo.length - 4);

  return str;
}

/*
 * @Author: zyx
 * @Date: 2021-08-16 14:28:45
 * @LastEditTime: 2022-02-22 16:12:34
 * @Description: 将登录时获取的token等信息 加密存入 解密获取
 * @FilePath: \management-system\src\utils\userInfoGetItem.ts
 */

import { decode, encrypt } from '@/encryt/index';
import { getItem, setItem } from '@/storage/index';
import type { KeyType } from '@/storage/types.d';

const setItemLocalPower = (key: string | undefined, value: KeyType) => {
  const valueEncrypt = encrypt(value, 'YVJI', '');
  setItem(key, valueEncrypt);
};
const getItemLocalPower = (Names: string) => {
  const storageData = String(getItem(Names));

  // 判断是否存在 不存在则返回
  if (!storageData) return undefined;

  try {
    const decodeData = decode(storageData, 'YVJI');
    return decodeData;
  } catch (error) {
    return undefined;
  }
};
export { setItemLocalPower, getItemLocalPower };

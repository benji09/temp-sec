/*
 * @Author: zyx
 * @Date: 2021-08-13 17:17:13
 * @LastEditTime: 2021-12-22 11:41:52
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\utils\storageName.ts
 */
export const FileSizeUnit = (status: null | undefined | number): string => {
  if (status === undefined || status === null) return '';
  switch (status) {
    case 1:
      return 'b';
    case 2:
      return 'B';
    case 3:
      return 'KB';
    case 4:
      return 'MB';
    case 5:
      return 'GB';
    case 6:
      return 'TB';
    default:
      return '';
  }
};
export const FileTypeUnit = {
  image: '图片',
  video: '视频',
  pdf: ' pdf ',
};

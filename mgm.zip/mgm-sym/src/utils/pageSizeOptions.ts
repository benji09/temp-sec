/*
 * @Author: zyx
 * @Date: 2021-09-10 16:20:18
 * @LastEditors: zyx
 * @LastEditTime: 2021-09-13 16:03:39
 * @Desc:
 */
const ModalPageList = ['5', '6', '7', '8', '9', '10', '15', '20', '30', '50'];

export { ModalPageList };

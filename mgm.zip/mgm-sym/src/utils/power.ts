/*
 * @Author: zyx
 * @Date: 2021-08-31 15:40:14
 * @LastEditors: zyx
 * @LastEditTime: 2021-12-22 14:48:00
 * @Desc: 校验权限
 */
import { getItem } from '@/storage';
import KEYS from './storageKeys';
// 账号管理
// 账号管理医生页面
export const PERMISSION_ADD = 'G01-M02'; // 医生新增
export const PERMISSION_SCHEDULE = 'G01-M02'; // 医生排班表
export const PERMISSION_EDIT = 'G01-M02'; // 医生编辑
export const PERMISSION_VIEWMOBILE = 'G01-M02'; // 医生查看手机号
export const PERMISSION_CONFIG = 'G01-M02'; // 医生配置
export const PERMISSION_ASSISTANT = 'G01-M02'; // 医生组员
export const PERMISSION_PROTECTION = 'G01-M02'; // 医生保健团
export const PERMISSION_TEAM = 'G01-M02'; // 医生工作组
// 账号管理助手页面
export const ASSISTANT_ADD = 'G01-M01'; // 助手新增
export const ASSISTANT_VIEW = 'G01-M01'; // 助手查看手机号
export const ASSISTANT_EDIT = 'G01-M01'; // 助手编辑
// 回访管理回访列表页面
export const ROUTER_VIEW = 'G04-M11'; // 回访列表查看手机号
export const ROUTER_CONSULT = 'consult-consult-message-return'; // 回访列表标记为已回访
// 卡券中心
// 卡券中心发放权益卡管理页面
export const ISSUING_UOLOADEXCEL = 'G12-M26'; // 发放权益卡 批量导入
export const ISSUING_ADD = 'G12-M26'; // 发放权益卡 新增
export const ISSUING_CLOSE = 'G12-M26'; // 发放权益卡 关闭
export const ISSUING_DETAILED = 'G12-M26'; // 发放权益卡 查看详情
// 卡券中心生成激活码
export const CODE_ADD = 'G12-M27'; // 生成激活码 新增
export const CODE_DOWNLOAD = 'G12-M27'; // 生成激活码 关闭
export const CODE_DETAILED = 'G12-M27'; // 生成激活码 查看详情
// 卡券中心售卡管理
export const CARDSELL_ADD = 'G12-M28'; // 售卡管理 新增
export const CARDSELL_CONFIG = 'G12-M28'; // 售卡管理 配置
export const CARDSELL_NOTE = 'G12-M28'; // 售卡管理 短信
// 卡券中心权益卡管理
export const EQUITYCARD_ADD = 'G12-M29'; // 权益卡管理 新增
export const EQUITYCARD_DETAILED = 'G12-M29'; // 权益卡管理 详情
// 操作员账号管理
// 菜单操作分组
export const SEARCH_GROUP = 'G03-M07'; // 搜索操作分组
export const CREATE_GROUP = 'G03-M07'; // 创建新操作分组
// 菜单操作
export const SEARCH_OPERATION = 'G03-M08'; // 搜索操作
export const CREATE_OPERATION = 'G03-M08'; // 创建新操作
// 菜单角色
export const SEARCH_ROLE = 'G03-M09'; // 角色-新增
export const FIND_ROLE = 'G03-M09'; // 角色-查找角色
export const LIST_OPERATOR_ROLE = 'G03-M09'; // 角色-查找操作员的角色
export const RELATE_OPERATION = 'G03-M09'; // 修改操作与角色的关系
// 菜单操作员
export const SEARCH_OPERATOR = 'G03-M10'; // 搜索操作员
export const RELATE_OPERATOR = 'G03-M10'; // 修改用户与角色的关系

// 黑名单列表
export const BLACKLIST_PAGE = 'blacklist-page'; // 黑名单列表
export const BLACKLIST_ADD = 'blacklist-add'; // 黑名单新增
export const BLACKLIST_DEL = 'blacklist-del'; // 黑名单删除
// Banner列表
export const BANNER_PAGE = 'banner-page'; // Banner列表
export const BANNER_DETAIL = 'banner-detail'; // Banner详情
export const BANNER_SAVE_UPDATE = 'banner-save-update'; // 新增或更新
// 西药管理列表
export const PRESCRIPTIONS_PAGE = 'prescriptions-get-prescription-by-page'; //  西药列表
export const PRESCRIPTIONS_ADD = 'prescriptions-add-prescription'; //  西药新增药方
export const PRESCRIPTIONS_DETAIL = 'prescriptions-get-prescription'; // 药方详情
export const PRESCRIPTIONS_UPDATE_DETAIL = 'prescriptions-update-prescription'; // 药方详情
export const PRESCRIPTIONS_UPDATE_PARTS = 'prescriptions-update-parts'; // 新增或更新药品
export const PRESCRIPTIONS_ADD_PARTS = 'prescriptions-add-parts'; // 新增或更新药品
// 医护上门列表
export const MEDICAL_PAGE = 'medical-get-order-list'; //  西药列表
export const MEDICAL_ADD = 'medical-add-order'; //  西药新增药方
export const MEDICAL_DETAIL = 'medical-detail'; // 药方详情

export function checkPermission(powerIds: string[], callback: (result: any) => any) {
  if (powerIds.length < 1) return;
  const powerList = JSON.parse(getItem<string>(KEYS.KEY_POWER)) || '';
  const tempObj = {};
  powerIds.forEach((item) => {
    if (powerList.indexOf(item) !== -1) {
      tempObj[`${item}`] = true;
    } else {
      tempObj[`${item}`] = false;
    }
  });
  callback(tempObj);
}

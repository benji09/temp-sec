/*
 * @Author: zyx
 * @Date: 2021-08-13 17:17:13
 * @LastEditTime: 2022-02-22 14:02:16
 * @LastEditors: zyx
 * @Description: In User Settings Edit
 * @FilePath: \management-system\src\utils\storageName.ts
 */
const KEYS = {
  KEY_POWER: '_power',
  KEY_USER_INFO: '_userInfo',
  KEYS_EDITED_CMS: '_editedCms',
  KEY_CMS_PAGE_DATA: '_cmsPageData',
  KEY_CMS_ADD_OR_MODIFY: '_cmsAddOrModify',
  KEY_IS_PREVIEW: '_isPreview',
  KEY_LOCAL_POWER: '_localPower',
  KEY_TABLE_PAGE_SIZE: '_tablePageSize',
  KEYS_MODAL_LIST_PAGE: '_modalListPage',
  KEYS_DESTINY_SIZE: '_destinySize',
  KEYS_COLUMN_STATUS: '_columnsStatus',
  KEY_COLLAPSED: '_collapsed',

  KEY_LOCAL_POWER_LIST: '_localPowerList',
  KEY_LOGGER_KEY: '_logger_key',
};

export default KEYS;

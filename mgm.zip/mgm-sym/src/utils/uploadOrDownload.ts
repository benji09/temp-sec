import XLSX from 'xlsx';

interface resultJsonType {
  关联订单号?: number | string;
  流水号?: number | string;
  消息类型?: number | string;
  渠道?: string;
  用户手机号?: number | string;
  销售日期?: number | string;
}
export const upLoadExcel = async (e: any) => {
  const xlsxJson = new Promise((resolve) => {
    const fileName = e?.target?.files[0];
    const reader = new FileReader();
    reader.readAsBinaryString(fileName);
    reader.onload = async (el) => {
      const formData = new FormData();
      formData.append('file', fileName); // 可以传到后台的数据
      const params = formData;
      const workbook = XLSX.read(el.target?.result, { type: 'binary' });
      const sheetList = workbook.SheetNames;
      const resultJson: resultJsonType[] = [];
      const resultFormulae = [];
      sheetList.forEach((y: string | number) => {
        const json = XLSX.utils.sheet_to_json(workbook.Sheets[y]);
        const formulae = XLSX.utils.sheet_to_formulae(workbook.Sheets[y]);
        if (json.length > 0) {
          resultJson.push(json as resultJsonType);
          resultFormulae.push(formulae);
        }
      });
      resolve({ resultJson, params });
    };
  });
  return xlsxJson;
};

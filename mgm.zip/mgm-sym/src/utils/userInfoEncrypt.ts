/*
 * @Author: zyx
 * @Date: 2021-08-16 14:28:45
 * @LastEditTime: 2021-09-13 11:24:30
 * @Description: 将登录时获取的token等信息 加密存入 解密获取
 * @FilePath: \management-system\src\utils\userInfoGetItem.ts
 */

import { decode, encrypt } from '@/encryt/index';
import { getItem, setItem } from '@/storage/index';
import type { KeyType } from '@/storage/types.d';

const setItemUserInfo = (key: string | undefined, value: KeyType) => {
  const valueEncrypt = encrypt(value, 'YVJI', '');
  setItem(key, valueEncrypt);
};
const getItemUserInfo = (Names: string) => {
  let data: any = {};

  const storageData = String(getItem(Names));
  // 判断是否存在 不存在则返回
  if (!storageData) {
    data = {};
    return undefined;
  }
  // 判断反序列化对象中是否存在要查找的对象
  if (storageData in data) {
    data[storageData] = storageData;
  }
  // 当反序列对象中没有东西时 对本地中的东西进行解码返回
  if (Object.keys(data).length <= 0) {
    try {
      const decodeData = decode(storageData, 'YVJI');
      // 存入反序列对象中
      if (decodeData?.trim()) {
        try {
          data[storageData] = JSON.parse(decodeData || '');
          return data[storageData];
        } catch (error) {
          return undefined;
        }
      }
      return undefined;
    } catch (error) {
      return undefined;
    }
  }
  return undefined;
};
export { setItemUserInfo, getItemUserInfo };

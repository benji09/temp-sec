import { hasPower } from '@/services/api';

export const PERMISSION_ADD = 1; // 新增
export const PERMISSION_EDIT = 3; // 编辑
export const PERMISSION_CONFIG = 6; // 配置
export const PERMISSION_MENEBERS = 11; // 组员
export const PERMISSION_SCHEDULE = 22; // 排班表
export const ASSITANT_ADD = 15; // 助手新增
export const ASSITANT_EDIT = 16; // 助手编辑

export function checkPermission(powerIds: number[], callback: (result: any) => any) {
  if (powerIds.length < 1) return;
  const tempObj = {};
  powerIds.forEach((item) => {
    hasPower(item)
      .then((res) => (tempObj[`${item}`] = res && res.status === 0 && res.result === true))
      .catch(() => (tempObj[`${item}`] = false))
      .finally(() => {
        if (Object.keys(tempObj).length === powerIds.length) callback(tempObj);
      });
  });
}

const common = {
  getParam: function(name) {
    //先获取#后面的参数
    var getValue = function(name, str) {
      //获取参数name的值
      var reg = new RegExp("(^|!|&|\\?)" + name + "=([^&]*)(&|$)");
      //再获取?后面的参数
      var r = str.match(reg);
      if (r != null) {
        try {
          return decodeURIComponent(r[2]);
        } catch (e) {
          console.log(e + "r[2]:" + r[2]);
          return null;
        }
      }
      return null;
    };
    var str = document.location.hash.substr(2);
    var value = getValue(name, str);
    if (value == null) {
      str = document.location.search.substr(1);
      value = getValue(name, str);
    }
    return value;
  },
  //		设置URL参数
  setParam: function(name, value) {
    var setValue = function(name, value, str) {
      if ((typeof name) === "object") {
        str = value;
        value = name;
        for (var key in value) {
          str = setValue(key, value[key], str);
        }
        return str;
      } else {
        var prefix = str ? "&" : "";
        var reg = new RegExp("(^|!|&|\\?)" + name + "=([^&]*)(&|$)");
        r = str.match(reg);
        // value = encodeURIComponent(value);
        if (r) {
          if (r[2]) {
            var newValue = r[0].replace(r[2], value);
            str = str.replace(r[0], newValue);
          } else {
            var newValue = prefix + name + "=" + value + "&";
            str = str.replace(r[0], newValue);
          }
        } else {
          var newValue = prefix + name + "=" + value;
          str += newValue;
        }

        return str;
      }
    }
    var search = document.location.search.substr(1);
    search = setValue(name, value, search);
    if (history.replaceState) {
      history.replaceState({}, null, "?" + search);
    } else {
      console.error("history.replaceState:" + history.replaceState);
    }
  },
  //		删除URL参数
  removeParam: function(name) {
    var search = document.location.search.substr(1);
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    r = search.match(reg);
    if (r) {
      if (r[1] && r[3]) {
        search = search.replace(r[0], '&');
      } else {
        search = search.replace(r[0], '');
      }
    }
    if (history.replaceState) {
      history.replaceState({}, null, "?" + search);
    } else {
      console.error("history.replaceState:" + history.replaceState);
    }
  },
  setLocalUserId: function(){
    let getUserId = this.getParam('userId');
    if(getUserId) localStorage.setItem('userid', getUserId);
  },
}

export default common;
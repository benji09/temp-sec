import { POST } from './request';

// 发送短信验证码
export const getMoblieCode = (prams) => {
  return POST({
    methodName: 'getMoblieCode',
    ...prams
  })
}

// 添加用户个人信息
export const addUserInfo = (prams) => {
  return POST({
    methodName: 'addUserInfo',
    ...prams
  })
}

// 添加用户健康信息
export const addHealthInfo = (prams) => {
  return POST({
    methodName: 'addHealthInfo',
    ...prams
  })
}

// 修改用户个人信息
export const updateUserInfo = (prams) => {
  return POST({
    methodName: 'updateUserInfo',
    ...prams
  })
}

// 根据用户id 获取用户基本信息与健康信息
export const slectUserAndHealthInfo = (prams) => {
  return POST({
    methodName: 'slectUserAndHealthInfo',
    ...prams
  })
}

// 通过微信公众号传入的code,获取用户信息
export const getUserInfoByCode = (prams) => {
  return POST({
    methodName: 'getUserInfoByCode',
    ...prams
  })
}

// 修改健康信息
export const modifyHealthInformation = (prams) => {
  return POST({
    methodName: 'modifyHealthInformation',
    ...prams
  })
}


// 获取全部省市区数据
export const getAreaInformation = (prams) => {
  return POST({
    methodName: 'getAreaInformation',
    ...prams
  })
}

// 更新用户确认状态
export const modifyStatus = (prams) => {
  return POST({
    methodName: 'modifyStatus',
    ...prams
  })
}
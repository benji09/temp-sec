import axios from 'axios'
const qs = require('qs');
import { baseURL } from './env'

// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
axios.defaults.baseURL = baseURL

// axios.defaults.headers['X-Token'] = getToken();

// 创建axios实例
const service = axios.create()

// request拦截器
service.interceptors.request.use(
  config => {
    // if (store.getters.token) {
    //   config.headers['X-Token'] = store.getters.token // 让每个请求携带自定义token 请根据实际情况自行修改
    // }
    config.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    config.data = qs.stringify(config.data)
    return config
  },
  // error => {
  //   if(error.message.includes('timeout')){   // 判断请求异常信息中是否含有超时timeout字符串
  //     Message({
  //       message: '请求接口超时',
  //       type: 'error',
  //       duration: 5 * 1000
  //     })
  //     return Promise.reject(error);          // reject这个错误信息
  //   }
  //   // Do something with request error
  //   console.log(error) // for debug
  //   Promise.reject(error)
  // }
)

// response 拦截器
service.interceptors.response.use(
  response => {
  //   /**
  //    * code为非20000是抛错 可结合自己业务进行修改
  //    */
  //   const res = response.data
  //   if(res.status == -1){
  //     Message({
  //       message: '用户登录信息token过期',
  //       type: 'error',
  //       duration: 5 * 1000
  //     })
  //     store.dispatch('LogOut').then(() => {
  //       location.reload() // 为了重新实例化vue-router对象 避免bug
  //     })
  //   }
    return response.data
  },
  // error => {
  //   if(error.message.includes('timeout')){   // 判断请求异常信息中是否含有超时timeout字符串
  //     Message({
  //       message: '请求接口超时',
  //       type: 'error',
  //       duration: 5 * 1000
  //     })
  //     return Promise.reject(error);          // reject这个错误信息
  //   }
  //   Message({
  //     message: error.message,
  //     type: 'error',
  //     duration: 5 * 1000
  //   })
  //   return Promise.reject(error)
  // }
)

export default service

const POST = (options) => service.post('/cgms/servlet/ACSClientHttp', {
  beanName: 'gzaddinformationservice',
  appcode: 'cgms',
  userid: localStorage.getItem('userid') || '',
  ...options
});

export {
  POST
}

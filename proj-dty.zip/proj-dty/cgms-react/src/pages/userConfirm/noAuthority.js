import React, { useEffect } from 'react';
import "./index.css";
import notOpenStatus from './images/not-open-status.png';

function noAuthority() {
    useEffect(() => {
        document.title = '用户确认';
    }, [])
    return (
        <div className="home">
            <div className="not-open">
                <img src={notOpenStatus} alt="" />
                <div>很遗憾，本服务号内容仅对项目用户开放</div>
            </div>
        </div>
    );
}

export default noAuthority;

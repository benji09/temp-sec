import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { Toast } from 'antd-mobile';

import InputRadio  from '../../components/inputRadio';

import { modifyStatus } from '../../utils/api';
import common from '../../utils/tool';
import "./index.css";
// import notOpenStatus from './images/not-open-status.png';

function userConfirm() {
    const history = useHistory();
    const [confirmState, setconfirmState] = useState(-1);

    useEffect(() => {
        document.title = '用户确认';
        common.setLocalUserId();
    }, [])

    const checkUserRight = () => {
        if(confirmState == -1) return Toast.info('请选确认您是项目用户', 2);;
        if(confirmState == 0) return history.replace('/noAuthority');
        Toast.loading('请求中...');
        modifyStatus({
            participateinstate: confirmState
        })
            .then((res) => {
                Toast.hide();
                if (res.success == 't') {
                    history.replace("/submiterBaseInfo" + location.search);
                } else {
                    Toast.info(res.error_msg || '操作失败，请稍后重试', 2);
                }
            })
            .catch(() => {
                Toast.hide();
            })
    }

    return (
        <div className="home">
            <div className="home-inner-wrap">
                <div className="confirm-state">
                    本服务号所有信息，仅针对在海南省博鳌市乐城医疗先行区参与真实世界研究的用户，请确认您是参加该项目的用户。
                </div>
                <div className="radio-group">
                    <div className="radio-box" onClick={() => setconfirmState(1)} >
                        <InputRadio checked={confirmState == 1}/>
                        <label htmlFor="yes01">是</label>
                    </div>
                    <div className="radio-box" onClick={() => setconfirmState(0)}>
                        <InputRadio checked={confirmState == 0}/>
                        <label htmlFor="no01">否</label>
                    </div>
                </div>
                <div className="next-btn" onClick={checkUserRight}>下一步</div>
            </div>
            {/* <div className="not-open" style={{display: 'none'}}>
                <img src={notOpenStatus} alt="" />
                <div>很遗憾，本服务号内容仅对项目用户开放</div>
            </div>
            <div className="home-inner-wrap">
                <div className="confirm-state-next">
                本服务号所有信息，仅针对如下用户：
                <br />
                1、在海南省博鳌市乐城医疗先行区参与真实世界研究的用户
                <br />
                2、申请参与“XX项目”的用户
                <br />
                <br />
                请确认您是以上两类用户
                </div>
                <div className="radio-group">
                    <div className="radio-box">
                        <input type="radio" name="confirmState02" id="yes02" defaultChecked={true} />
                        <label htmlFor="yes02">是</label>
                    </div>
                    <div className="radio-box">
                        <input type="radio" name="confirmState02" id="no02" />
                        <label htmlFor="no02">否</label>
                    </div>
                </div>
                <div className="next-btn" onClick={checkUserRight}>下一步</div>
            </div> */}
        </div>
    );
}

export default userConfirm;

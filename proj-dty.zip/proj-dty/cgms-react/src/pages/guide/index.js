import React, { useState, useEffect} from 'react';
import { PhotoProvider, PhotoConsumer } from 'react-photo-view';

import descPage1 from "./images/page1.jpg";
import descPage2 from "./images/page2.jpg";
import descPage3 from "./images/page3.jpg";
import descPage4 from "./images/page4.jpg";
import descPage5 from "./images/page5.jpg";
import descPage6 from "./images/page6.jpg";
import descPage7 from "./images/page7.jpg";
import descPage8 from "./images/page8.jpg";
import descPage9 from "./images/page9.jpg";

import 'react-photo-view/dist/index.css';
import "./index.css";

const guide = () => {
    const [photoImages] = useState([descPage1, descPage2, descPage3, descPage4, descPage5, descPage6, descPage7, descPage8, descPage9])
    useEffect(() => {
        document.title = '产品说明书';
    }, [])
    return (
        <div className="guide">
            <PhotoProvider photoClosable maskClosable>
                {photoImages.map((item, index) => (
                    <PhotoConsumer key={index} src={item} intro={item}>
                        <img src={item} alt="" />
                    </PhotoConsumer>
                ))}
            </PhotoProvider>
        </div>
    )
}
export default guide;
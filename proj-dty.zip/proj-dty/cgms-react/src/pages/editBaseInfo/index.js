import React, { useState, useRef, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { Toast } from 'antd-mobile';

import Pickerprovince from "../../components/province";

import { updateUserInfo } from '../../utils/api';

export default function EditBaseInfo() {
  let history = useHistory();
  let location = useLocation()?.state;
  let getUserInfo = location?.userInfo || {};
  const [provinceInfo, setprovinceInfo] = useState('');
  const [userInfo, setUserInfo] = useState({});
  const [borderEditName, setBorderEditName] = useState(false);
  const [borderProvince, setBorderProvince] = useState(false);

  useEffect(() => {
    document.title = '个人信息';
    if(getUserInfo.proviceid){
      setprovinceInfo([Number(getUserInfo.proviceid), Number(getUserInfo.cityid), Number(getUserInfo.areaid)])
    }
    setUserInfo(getUserInfo);
  }, [])

  // 设置边框颜色
  function setBorderFun(){
    setBorderEditName(!userInfo.userrealname);
    setBorderProvince(!(provinceInfo && provinceInfo[2]));
  }
  
  // 修改提交
  function saveBaseInfo(){
    setBorderFun();
    if(!userInfo.userrealname) return Toast.info('请将信息填写完整');
    Toast.loading('请求中...');
    updateUserInfo({
      username: userInfo.userrealname,
      proviceid: provinceInfo[0],
      cityid: provinceInfo[1],
      areaid: provinceInfo[2],
    })
    .then((res) => {
      Toast.hide();
      if(res.success == 't') {
        Toast.info(res.error_msg || '操作成功', 2);
        setTimeout(() => {
          history.replace("/userInfo");
        }, 2000)
      } else {
        Toast.info(res.error_msg || '操作失败，请稍后重试', 2);
      }
    })
    .catch(()=>{
      Toast.hide();
    })
  }

  // 修改名字
  function editName(e){
    let getVal = e.target.value;
    setUserInfo({
      ...userInfo,
      userrealname: getVal
    })
  }

  return (
    <div className='boxView editBaseInfo'>
      <div className="form">
        <div className="flexBetween">
          <div className="name">姓名</div>
          <div className="edit">
            <input onChange={editName} className={ borderEditName?'borderErr':'' } value={userInfo.userrealname} type="text" maxLength="4" placeholder="请填写姓名"/>
          </div>
        </div>
        <div className="flexBetween">
          <div className="name">手机号</div>
          <div className="edit">
            <input style={{backgroundColor: 'rgba(234, 234, 234, 0.39)', color: 'rgba(0, 0, 0, 0.25)'}} value={userInfo.mobile} type="text" maxLength="40" placeholder="" disabled />
          </div>
        </div>
        <div className="flexBetween">
          <div className="name">常住地</div>
          <Pickerprovince provinceInfo={provinceInfo} className={ borderProvince?'borderErr':'' } setprovinceInfo={setprovinceInfo} />
        </div>

      </div>
      <div onClick={saveBaseInfo} className="btn fixedSubmitBtn">保存</div>
    </div>
  );
}

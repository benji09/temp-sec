import React, { useState, useRef, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { Toast} from 'antd-mobile';

import Pickerprovince from "../../components/province";
import InputRadio  from '../../components/inputRadio';

import { addUserInfo, getMoblieCode } from '../../utils/api';
import common from '../../utils/tool';

import banner from '../../assets/images/banner.jpg'
import './index.css'

export default function SubmiterBaseInfo() {
  const history = useHistory();
  const [agreementStatus, SetAgreementStatus] = useState(false);
  const [userInfo, setUserInfo] = useState({mobile: ''});
  const [provinceInfo, setprovinceInfo] = useState('');
  const [stateClicked, setStateClicked] = useState(false);
  const [confirmClicked, setConfirmClicked] = useState(false);
  let codeTotalTime = 60;
  let [moblieCodeTime, setMoblieCodeTime] = useState(codeTotalTime);
  let myInterval = null;

  let [borderName, setBorderName] = useState(false);
  let [borderPhone, setBorderPhone] = useState(false);
  let [borderCode, setBorderCode] = useState(false);
  let [borderPicker, setBorderPicker] = useState(false);

  useEffect(() => {
    document.title = '基本信息';
    common.setLocalUserId();
  }, [])

  // 倒计时
  function intervalFun(){
    myInterval && clearInterval(myInterval);
    console.log(moblieCodeTime);
    myInterval = setInterval(() => {
      if(moblieCodeTime > 0){
        setMoblieCodeTime(--moblieCodeTime)
      } else {
        setMoblieCodeTime(codeTotalTime)
        clearInterval(myInterval);
      }
    }, 1000)
  }

  // 协议切换
  function handelAgreementStatus(){
    SetAgreementStatus(!agreementStatus)
  }

  function handleStep(){
    if(!userInfo.username){
      setBorderName(true);
      return Toast.info('请填写姓名', 2);
    }
    if(!userInfo.mobile){
      setBorderPhone(true);
      return Toast.info('请填写手机号码', 2);
    }
    if(userInfo.mobile.length != 11 || !/^\d{11}$/.test(userInfo.mobile)){
      setBorderPhone(true);
      return Toast.info('请填写正确手机号码', 2);
    }
    if(!userInfo.smscode){
      setBorderCode(true);
      return Toast.info('请填写验证码', 2);
    }
    if(!provinceInfo || !provinceInfo.length){
      console.log(provinceInfo);
      setBorderPicker(true);
      return Toast.info('请选择地区', 2);
    }
    if(!agreementStatus) return Toast.info('请勾选用户知情确认函', 2);
    setBorderName(false);
    setBorderPhone(false);
    setBorderCode(false);
    setBorderPicker(false);
    addUserInfoFun(); //提交接口添加信息
  }

  function addUserInfoFun(){
    Toast.loading('请求中...');
    addUserInfo({
      ...userInfo,
      proviceid: provinceInfo[0],
      cityid: provinceInfo[1],
      areaid: provinceInfo[2],
    })
    .then((res) => {
      Toast.hide();
      if(res.success == 't') {
        history.replace("/submitHealthInfo" + location.search, {origin: 'add'});
      } else {
        Toast.info(res.error_msg || '操作失败，请稍后重试', 2);
      }
    })
    .catch(()=>{
      Toast.hide();
    })
  }

  // 发送验证码
  function getMoblieCodeFun(){
    if(!userInfo.mobile) return Toast.info('请填写手机号码', 2);
    if(userInfo.mobile.length != 11 || !/^\d{11}$/.test(userInfo.mobile)) return Toast.info('请填写正确手机号码', 2);
    if(moblieCodeTime != codeTotalTime) return;
    
    Toast.loading('发送中...');
    getMoblieCode({
      mobile: userInfo.mobile
    })
    .then((res) => {
      Toast.hide();
      if(res.success == 't') {
        Toast.info(res.error_msg || '操作成功', 2);
        intervalFun(); //倒计时
      } else {
        Toast.info(res.error_msg || '操作失败，请稍后重试', 2);
      }
    })
    .catch(()=>{
      Toast.hide();
      Toast.info('服务器错误，请联系管理员', 2);
    })
  }

  // 编辑名字
  function editName(e){
    let getVal = e.target.value;
    setUserInfo({
      ...userInfo,
      username: getVal
    });
    setBorderName(false);
    // (getVal && getVal.length) ? setBorderName(false) : setBorderName(true);
  }

  // 编辑手机号
  function editPhone(e){
    let getVal = e.target.value.slice(0,11);
    setUserInfo({
      ...userInfo,
      mobile: getVal
    });
    setBorderPhone(false);
    // (getVal && getVal.length == 11) ? setBorderPhone(false) : setBorderPhone(true);
  }

  // 编辑验证码
  function editCode(e){
    let getVal = e.target.value.slice(0,6);
    setUserInfo({
      ...userInfo,
      smscode: getVal
    });
    setBorderCode(false);
    // (getVal && getVal.length) ? setBorderCode(false) : setBorderCode(true);
  }

  // 省市区
  function setprovinceInfoFun(arr){
    setprovinceInfo(arr);
    setBorderPicker(false);
    // (arr && arr.length == 3) ? setBorderPicker(false) : setBorderPicker(true);
  }

  // 显示协议
  const showContent = () => {
    setStateClicked(!stateClicked);
    setConfirmClicked(true);
  }

  const closeAlertBox = () => {
    if (confirmClicked) {
      setStateClicked(false);
    } 
  }

  return (
    <div className='boxView submiterBaseInfo'>
      <img src={ banner } className="banner" alt="" />
      <div className="form">
        <div className="flexBetween">
          <div className="name">姓名</div>
          <div className="edit">
            <input onChange={editName} className={ borderName?'borderErr':'' } value={userInfo.username} type="text" maxLength="30" placeholder="请填写姓名"/>
          </div>
        </div>
        <div className="flexBetween">
          <div className="name">手机号</div>
          <div className="edit">
            <input onChange={editPhone} className={ borderPhone?'borderErr':'' } value={userInfo.mobile} type="number" placeholder="请填写手机号"/>
          </div>
        </div>
        <div className="flexBetween">
          <div className="name">验证码</div>
          <div className="edit getCode">
            <input onChange={editCode} className={ borderCode?'borderErr':'' } value={userInfo.smscode} type="number" placeholder="请填写验证码"/>
            <button onClick={getMoblieCodeFun} className={ (moblieCodeTime != 60 || userInfo.mobile.length != 11) && 'buttonDis'}>
              { moblieCodeTime >= 0 && moblieCodeTime != codeTotalTime && `${ moblieCodeTime }s`}
              { moblieCodeTime >= 0 && moblieCodeTime != codeTotalTime && <br/>}
              { (moblieCodeTime >= 0 && moblieCodeTime != codeTotalTime)? '后重新获取' : '发送验证码'}
            </button>
          </div>
        </div>
        <div className="flexBetween">
          <div className="name">常住地</div>
          <Pickerprovince className={ borderPicker?'borderErr':'' } setprovinceInfo={setprovinceInfoFun}/>
        </div>

        <div className="flexLeft agreement">
          <div onClick={ handelAgreementStatus }>
            <InputRadio checked={ agreementStatus }/>
            <span>我已阅读并同意</span>
          </div>
          <span className="cnt" onClick={showContent}>《用户知情确认函》</span>
        </div>
        <div className="btn stepNext" onClick={ handleStep }>下一步</div>
      </div>
      {/* 知情书内容 */}
      <div className={stateClicked ? "agreement-alert-wrap"  : "alert-hidden"}>
        <div className="alert-box">
          <div className="title">个人信息知情同意书</div>
          <div className="detail">
            拜耳医药保健有限公司（“拜耳”）深知个人信息对您而言十分重要，并将尽最大努力保护您的个人信息。我们致力于维护您对我们的信任，我们将严格遵守适用的中国法律法规，依据合法、正当和必要的原则，明确告知您我们收集和使用您的个人数据的规则、目的、方法和范围，并获取您相应的同意。请仔细阅读本知情同意书，并根据您的需要询问任意事项。
            <br />
            <br />
            <strong>收集和使用您的个人信息：</strong>
            <br />
            限于本知情同意书所规定的目的，拜耳收集和使用您所提供的如下信息，包括：
            <br />
            （1）姓名；（2）手机号码；（3）电子邮箱地址；（4）微信账号；（5）居住地址；（6）联系地址（书面材料邮寄地址）
            <br />
            与糖尿病相关的个人健康信息，包括：（1）性别；（2）糖尿病类型；（3）出生日期；（4）确诊时间；（5）治疗方案；（6）血糖监测频率等
            <br />
            上述信息将被用于以下目的：
            <br />
             • 拜耳与您的交流（用于电话、短信、微信或邮件的信息传递和相关材料的推送）;
            <br />
             • 拜耳邀请您参加会议（用于电话、短信、微信、邮件等口头或书面邀请）;
            <br />
             • 拜耳产品的宣传和市场推广活动；
            <br />
             • 拜耳产品的真实世界研究活动；
            <br />
             • 管理并持续改进客户关系。
            <br />
            其中为邀请您参加上述会议或活动，如有需要，您的以下额外信息还将被收集用于会议或活动组织和行程安排（例如用于如酒店、机票等交通工具的预订和购买保险等）以及服务费用的支付：
            <br />
            （1）证件号码（如身份证）；（2）护照号码（用于国际会议）；（3）银行卡号；（4）教育背景；（5）可能含有个人头像的活动照片；（6）接送地址
            <br />
            以上所有罗列的信息统称为“个人信息”。
            <br />
            我们将严格遵守中国关于个人数据保护的相关法律法规，仅为限定的目的在必要的情况下收集、使用您的个人信息：
            <br />
            •已经收集到的个人信息，拜耳将妥善保存并承诺仅用于您同意参与的活动或目的；
            <br />
            •对于尚未收集的个人信息，当您同意参与本知情同意书所规定的活动或使用目的时，拜耳将收集您的相关个人信息。在签署本知情同意书后，为了避免您重复签署，每次您向拜耳提供您的个人信息时，拜耳将视为您同意本知情同意书的内容，从而严格按照本知情同意书的规定收集使用您所提供的个人信息。
            <br />
            •如您不同意本知情同意书所约定的收集或使用方式，您可以在任何时候，通过以下（→联系方式）撤回您的同意或限制我们使用您的个人信息。
            <br />
            <br />
            <strong>向第三方分享/传输个人信息：</strong>
            <br />
            我们可能会与拜耳集团其他公司分享您的个人信息。拜耳集团公司包括拜耳股份有限公司（一家根据德国法律成立的公司）和拜耳股份有限公司直接或间接控制的任何其他实体。
            <br />
            为了本知情同意书所述之目的，我们也可能会使用专业服务承包商并与之分享我们收集的您的个人信息。该等服务承包商由我们精心挑选并定期受我们监督。根据相关委托协议，服务承包商仅可依据我们的指令并严格按照我们的指示处理您个人信息。
            <br />
            我们仅在必要时才分享信息且分享仅限于本声明所示的目的。如果改变了收集和使用目的，则需要另行获得您的同意。
            <br />
            <br />
            <strong>个人信息保存 :</strong>
            <br />
            我们仅在为实现本知情同意书下目的所必要的时间内保留您的个人数据。如您对个人信息保存时间有异议，您可以在任何时候，通过以下（→联系方式），撤回您的同意或限制我们使用您的个人信息。
            <br />
            <br />
            <strong>个人信息保护：</strong>
            <br />
            拜耳已制定了相关政策并采取了相关安全措施，以保护您的个人信息免受未经授权的访问、篡改、泄露、毁损或丢失。我们将采取合理措施确保拜耳不会收集与本知情同意书所规定的目的无关的个人信息。
            <br />
            <br />
            <strong>您享有的权利：</strong>
            <br />
            • 对我们存储的您的个人信息享有的知情权；
            <br />
            • 要求更正或限制处理您个人信息的权利；
            <br />
            • 您有权在任何时间通过以下（→联系方式），撤销您所作出的有关拜耳收集和使用您个人信息的同意，或要求拜耳停止向您发送任何信息或材料。
            <br />
            • 根据法律法规要求，在以下情况，我们将无法响应您的请求：
            <br />
             o 事关国家安全
            <br />
             o 事关公共安全、公共健康、重大公共利益
            <br />
             o 事关犯罪调查、控诉和审判
            <br />
             o 能够证明您滥用您的权利
            <br />
             o 响应您的请求会严重损害您或其他个人或组织的合法权利。
            <br />
            <br />
            <strong>联系方式：</strong>
            <br />
            如果您在将来任何时间针对您的个人信息有任何疑虑或投诉，也请拨打拜耳 热线电话400-810-0360或发送邮件到DP.China@bayer.com。
            <br />
            <br />
            <div style={{textAlign: 'center'}}><strong>您的同意声明</strong></div>
            <strong>本人已阅读本知情同意书中的信息，并已获得机会询问相关问题。本人同意拜耳按照本知情同意书的约定收集使用本人个人信息。</strong>
            <br />
          </div>
          <div className="btn" onClick={closeAlertBox}>确定</div>
        </div>
      </div>
    </div>
  );
}

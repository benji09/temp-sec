import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router';
import { useHistory } from 'react-router-dom';
import { Toast, Picker, DatePicker, Modal } from "antd-mobile";
import _ from "lodash";
import { addHealthInfo, modifyHealthInformation } from '../../utils/api';
import common from '../../utils/tool';

import dateSelector from "./images/date-selector.svg";
import healthInfoBanner from "./images/health-info-banner.jpg";
import infoRightArrow from "./images/info-right-arrow.svg";

import "./index.css";

const genderTypes = [
  {value: 1, label: '男'},
  {value: 0, label: '女'},
];

// 糖尿病类型
const diabetesTypes =  [
  {value: '1型糖尿病', label: '1型糖尿病'},
  {value: '2型糖尿病', label: '2型糖尿病'},
  {value: '妊娠糖尿病', label: '妊娠糖尿病'},
  {value: '糖尿病前期', label: '糖尿病前期'},
  {value: '其它糖尿病', label: '其它糖尿病'},
  {value: '未患糖尿病', label: '未患糖尿病'},
  {value: '不清楚', label: '不清楚'}
];

const governpreceptTypes = [
  {value: '饮食运动', label: '饮食运动' },
  {value: '口服药', label: '口服药' },
  {value: '胰岛素', label: '胰岛素' },
  {value: '不清楚', label: '不清楚' },
  {value: '不治疗', label: '不治疗' },
  {value: '其他', label: '其他' }
]

// 血糖监测频率
const bloodMonitoringFrequency = [
  {value: '1-3次/周', label: '1-3次/周'},
  {value: '4-6次/周',  label: '4-6次/周'},
  {value: '>=7次/周', label: '>=7次/周'},
  {value: '不固定', label: '不固定'},
  {value: '不监测血糖', label: '不监测血糖'},
];


const submitHealthInfo = () => {
  let location = useLocation();
  const history = useHistory();
  const [genderType, setGenderType] = useState();
  const [diabetesType, setDiabetesType] = useState('');
  const [frequencyType, setFrequencyType] = useState('');
  const [genderItem, setGenderItem] = useState();
  const [birthday, setBirthday] = useState('');
  const [definitetime, setDefinitetime] = useState('');
  const [governprecept, setGovernprecept] = useState([]);
  const [originPage, setOriginPage] = useState('');
  const [newDiabetesTypes, setNewDiabetesTypes] = useState([]);

  let [borderType, setBorderType] = useState(false);
  let [borderBirthday, setBorderBirthday] = useState(false);
  let [borderTime, setBorderTime] = useState(false);
  let [borderFrequency, setBorderFrequency] = useState(false);

 
  useEffect(() => {
    common.setLocalUserId();
    const userInfo = location?.state?.userInfo || {};
    const originPage = location?.state?.origin || 'add';
    setOriginPage(originPage);
    if (originPage == 'add') {
      document.title = '健康信息';
    }else if (originPage == 'edit') {
      document.title = '个人信息';
      if (Object.keys(userInfo)?.length > 0) {
        getGender(userInfo.usersex);
        setGenderItem(userInfo.usersex);
        setBirthday(userInfo.birthday);
        setDefinitetime(userInfo.definitetime);
        setGovernprecept(userInfo.governprecept?.split(',') || []);
        setDiabetesType(userInfo.diabetestype);
        setFrequencyType(userInfo.detectionfrequency);
      }
    }
  }, []);
  
  useEffect(() => {
    localStorage.getItem('otherUrl') == 1 && Modal.alert('注册成功', <div style={{"marginTop": "5vw"}}>您可以开始使用公众号功能了</div>, [
      { text: '好的', onPress: closeView()}
    ])
  })
  
  function closeView(){
    localStorage.setItem('otherUrl', 0);
    var ua = window.navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i) != 'micromessenger') return;
    //安卓手机
    document.addEventListener(
      "WeixinJSBridgeReady",
      function () {
        WeixinJSBridge.call("closeWindow");
      },
      false
    );
    //ios手机
    WeixinJSBridge.call("closeWindow");
  }

  const getGender = (gender) => {
    setGenderType(gender.toString());
    if (gender == 1) {
      let clone = _.cloneDeep(diabetesTypes);
      clone.splice(2, 1);
      setNewDiabetesTypes(clone);
    }
  }
  const diabetesChange = (v) => {
    setDiabetesType(v.toString());
    setBorderType(false);
  }
  const frequencyChange = (v) => {
    setFrequencyType(v.toString());
    setBorderFrequency(false);
  }
   
  const birthdayChange = (v) => {
    setBirthday(toFormatDate(v));
    setBorderBirthday(false);
  }
  
  const definitetimeChange = (v) => {
    setDefinitetime(toFormatDate(v).slice(0, 7));
    setBorderTime(false);
  }
  // 选择治疗方案
  const selectItem = (v) => {
    if (v == '饮食运动' || v == '口服药' || v =='胰岛素') {
      if (governprecept.findIndex(item => item == '不清楚') != -1) {
        governprecept.splice(governprecept.findIndex(item => item == '不清楚'), 1);
      }
      if (governprecept.findIndex(item => item == '不治疗' ) != -1) {
        governprecept.splice(governprecept.findIndex(item => item == '不治疗'), 1); 
      }
    }
    if (v == '不清楚' || v == '不治疗') {
      if (governprecept.findIndex(item => item == '饮食运动') != -1) {
        governprecept.splice(governprecept.findIndex(item => item == '饮食运动'), 1);
      }
      if (governprecept.findIndex(item => item == '口服药') != -1) {
        governprecept.splice(governprecept.findIndex(item => item == '口服药'), 1);
      }
      if (governprecept.findIndex(item => item == '胰岛素') != -1) {
        governprecept.splice(governprecept.findIndex(item => item == '胰岛素'), 1);
      }
    }
    const filterId = governprecept.join(',').includes(v) ? governprecept.filter((item) => item !== v) : [...governprecept, v];
    setGovernprecept(filterId);
  }


  function toFormatDate(val) {
    const date = new Date(val);
    const year = date.getFullYear();
    const month =
      date.getMonth() + 1 >= 10
        ? date.getMonth() + 1
        : '0' + (date.getMonth() + 1);
    const day = date.getDate() >= 10 ? date.getDate() : '0' + date.getDate();
    return `${year}-${month}-${day}`
  }

  // 设置边框颜色
  function setBorderFun(){
    setBorderType(!diabetesType);
    setBorderBirthday(!birthday);
    setBorderTime(!definitetime);
    setBorderFrequency(!frequencyType);
  }

  // 填写提交
  const onSubmit = () => {
    setBorderFun();
    if (genderType == '' ||
      diabetesType == '' ||
      birthday == '' || 
      definitetime == '' || 
      governprecept == '' ||
      frequencyType == ''
    ) {
      Toast.info('请将信息填写完整', 1);
      return;
    }
    // 忽略当月天数比较
    if (new Date(definitetime).getTime() > new Date(birthday.slice(0, 7)).getTime()) {
      Toast.info('确诊时间不能早于出生日期', 1);
      return;
    }
    const params = {
      usersex: genderType,
      diabetestype: diabetesType,
      birthday: birthday,
      definitetime: definitetime,
      governprecept: governprecept.toString(),
      detectionfrequency: frequencyType
    }
    addHealthInfo(params).then((res) => {
      if (res.success == 't') {
          let getBackPage = common.getParam('backPage');
          // getBackPage = getBackPage ? getBackPage.replace(/\|/g, '?').replace(/@/g, '&') : '';
          getBackPage = getBackPage ? decodeURIComponent(getBackPage) : '';
          if(getBackPage){
            if(getBackPage.includes('.weixin.qq.com') || getBackPage.includes('http://h5.baleina.cn')){
              localStorage.setItem('otherUrl', 1);
              window.location.href = getBackPage;
            } else {
              Toast.success('注册成功，您可以开始使用公众号功能了', 1, () => {
                window.location.replace(getBackPage);
              });
            }
          } else {
            Toast.success('注册成功，您可以开始使用公众号功能了', 1, () => {
              history.replace('/userInfo');
            });
          }
      } else {
        Toast.info(res.error_msg || '操作失败，请稍后重试', 1);
      }
    })
  }
  // 修改保存
  const onSave = () => {
    setBorderFun();
    if (genderType == '' ||
      diabetesType == '' ||
      birthday == '' || 
      definitetime == '' || 
      governprecept == '' ||
      frequencyType == ''
    ) {
      Toast.info('请将信息填写完整', 1);
      return;
    }
    // 忽略当月天数比较
    if (new Date(definitetime).getTime() > new Date(birthday.slice(0, 7)).getTime()) {
      Toast.info('确诊时间不能早于出生日期', 1);
      return;
    }
    const params = {
      beanName: 'gzhealthinformationservice',
      usersex: genderType,
      diabetestype: diabetesType,
      birthday: birthday,
      definitetime: definitetime,
      governprecept: governprecept.toString(),
      detectionfrequency: frequencyType
    }
    modifyHealthInformation(params)
    .then((res) => {
      if (res.success == 't') {
        Toast.success('保存成功', 2, () => {
          if(common.getParam('backPage')){
            window.location.replace(common.getParam('backPage'))
          } else {
            history.replace('/userInfo');
          }
        });
      }else {
        Toast.info(res.error_msg || '操作失败，请稍后重试', 2);
      }
    })
    .catch(()=>{
    })
  }

  return (
    <div className="submit-health-info">
      {originPage != 'edit' && <div className="health-info-banner">
        <img src={healthInfoBanner} alt="" />
      </div>}
      <div className="health-info-form">
        <div className="field">
          <span className="required">性别</span>
          <div className="gender">
            {genderTypes.map((item) => {
              return (
                <div 
                  key={item.value}
                  className={String(genderItem) === String(item.value) ? 'gender-item active' : 'gender-item'}
                  onClick={() => {getGender(item.value); setGenderItem(item.value)}}
                >
                  {item.label}
                </div>
              )
            })}
          </div>
        </div>
        <div className="field">
          <span>糖尿病类型</span>
          <Picker 
            data={genderType == 1 ? newDiabetesTypes : diabetesTypes}
            cols={1} 
            onOk={diabetesChange}
          >
            <div className={`${diabetesType ? 'input-type' : 'input-gray'} ${borderType?'borderErr':''}`}>
              {diabetesType ? diabetesType : '请选择'}
              <img src={infoRightArrow} alt="" />
            </div>
          </Picker>

        </div>
        <div className="field">
          <span>出生日期</span>
          <DatePicker
            mode="date"
            format='YYYY-MM-DD'
            onOk={birthdayChange}
            minDate={new Date(1900, 1, 1, 0, 0, 0)}
            maxDate={new Date()}
          >
            <div className={`${birthday ? 'input-type' : 'input-gray'} ${borderBirthday?'borderErr':''}`}>
              {birthday ? birthday : '请选择日期'}
              <img src={dateSelector} alt="" />
            </div>
          </DatePicker>
        </div>
        <div className="field">
          <span>确诊时间</span>
          <DatePicker
            mode="month"
            format="YYYY-MM"
            onOk={definitetimeChange}
            minDate={new Date(1900, 1, 1, 0, 0, 0)}
            maxDate={new Date()}
          >
            <div className={`${definitetime ? 'input-type' : 'input-gray'} ${borderTime?'borderErr':''}`}>
              <div>{definitetime ? definitetime : '请选择日期'}</div>
              <img src={dateSelector} alt="" />
            </div>
          </DatePicker>
        </div>
        <div className="field" style={{'alignItems': 'start'}}>
          <span>治疗方案(多选)</span>
          <div className="therapeutic-schedule">
            {governpreceptTypes.map((item) => {
              return (
                <div 
                  key={item.value}
                  className={ governprecept?.includes(item.value) ? 'governprecept-item active' : 'governprecept-item'}
                  onClick={() => {selectItem(item.value)}}
                >
                  {item.label}
                </div>
              )
            })}

          </div>
        </div>
        <div className="field">
          <span>血糖监测频率</span>
          <Picker 
            data={bloodMonitoringFrequency} 
            cols={1} 
            onOk={frequencyChange}
          >
            <div className={`${frequencyType ? 'input-type' : 'input-gray'} ${borderFrequency?'borderErr':''}`}>
              {frequencyType ? frequencyType : '请选择'}
              <img src={infoRightArrow} alt="" />
            </div>
          </Picker>
        </div>
      </div>
      {originPage == 'add' && (
        <div className="btn submit" onClick={onSubmit}>提交</div>
      )}
      {originPage == 'edit' && (
        <div className="btn save" onClick={onSave}>保存</div>
      )}
    </div>
  )
}

export default submitHealthInfo;
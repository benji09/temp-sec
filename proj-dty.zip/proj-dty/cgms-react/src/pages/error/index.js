import React, { useEffect } from 'react';
import { Toast } from "antd-mobile";

const error = () => {
    useEffect(() => {
      localStorage.getItem('qqq') && Toast.info('3333') && closeView()
    })

    function closeView(){
      //安卓手机
      document.addEventListener(
        "WeixinJSBridgeReady",
        function () {
          WeixinJSBridge.call("closeWindow");
        },
        false
      );
      //ios手机
      WeixinJSBridge.call("closeWindow");
    }

    function hrefView(){
      localStorage.setItem('qqq', true);
      window.location.href ='https://work.weixin.qq.com/kfid/kfcff0f3d4cee4344df'
    }

    return (
      <div>
        <button onClick={ closeView }>关闭</button>
        <button onClick={ hrefView }>跳转</button>
      </div>
    )
}
export default error;
import React, { useState, useRef, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { Toast } from 'antd-mobile';
import common from '../../utils/tool';
import { slectUserAndHealthInfo } from '../../utils/api';

import './index.css'

export default function UserInfo() {
  const history = useHistory();
  const [navIndex, setNavIndex] = useState(0);
  const [userInfo, setUserInfo] = useState({});

  useEffect(() => {
    common.setLocalUserId();
    document.title = '个人信息';
    handleUserInfo(); //查询用户信息
    localStorage.setItem('otherUrl', 0);
  }, [])

  // 查询用户信息
  function handleUserInfo() {
    Toast.loading('请求中...');
    slectUserAndHealthInfo()
    .then((res) => {
      Toast.hide();
      if(res.success == 't') {
        setUserInfo(res.result?.[0] || {});
      } else {
        Toast.info(res.error_msg || '操作失败，请稍后重试', 2);
      }
    })
    .catch(()=>{
      Toast.hide();
      Toast.info('服务器错误，请联系管理员', 2);
    })
  }

  // 跳转编辑页面
  function handleHref() {
    if (!navIndex) {  //跳转编辑健康信息
      history.push({ pathname: "/editBaseInfo", state: { userInfo }});
    } else { //跳转编辑基本信息
      history.push("/submitHealthInfo", {userInfo: userInfo, origin: 'edit'});
    }
  }

  function showGovernprecept(str){
    if(str && str.length){
      let arr = str.split(',');
      return arr.map(item => {
        return item && <div key={item}>{ item }</div>;
      })
    } else {
      return '-'
    }
  }

  return (
    <div className='boxView userInfo'>
      <div className="userInfoCot">
        <div className="navList">
          <div onClick={() => setNavIndex(0)} className={navIndex == 0 ? "navItem active" : "navItem"}>基本信息</div>
          <div onClick={() => setNavIndex(1)} className={navIndex == 1 ? "navItem active" : "navItem"}>健康信息</div>
        </div>

        <div className="detail">
          {/* 基本信息 */}
          {navIndex == 0 &&
            <div className="form">
              <div className="flexBetween">
                <div className="name">姓名</div>
                <div className="desc">{ userInfo.userrealname || '-' }</div>
              </div>
              <div className="flexBetween">
                <div className="name">手机号</div>
                <div className="desc">{ userInfo.mobile || '-' }</div>
              </div>
              <div className="flexBetween">
                <div className="name">常住地</div>
                <div className="desc">{ userInfo.provicename? `${ userInfo.provicename} ${userInfo.cityname} ${userInfo.areaname}` : '-' }</div>
              </div>
            </div>
          }

          {/* 健康信息 */}
          {navIndex == 1 &&
            <div className="form">
              <div className="flexBetween">
                <div className="name">性别</div>
                <div className="desc">{ userInfo.usersex ? (userInfo.usersex == 1 ? '男' : '女') : '-' }</div>
              </div>
              <div className="flexBetween">
                <div className="name">糖尿病类型</div>
                <div className="desc">{ userInfo.diabetestype || '-' }</div>
              </div>
              <div className="flexBetween">
                <div className="name">出生日期</div>
                <div className="desc">{ userInfo.birthday || '-' }</div>
              </div>
              <div className="flexBetween">
                <div className="name">确诊时间</div>
                <div className="desc">{ userInfo.definitetime || '-' }</div>
              </div>
              <div className="flexBetween governprecept">
                <div className="name">治疗方案</div>
                <div className="desc">{ showGovernprecept(userInfo.governprecept) }</div>
              </div>
              <div className="flexBetween">
                <div className="name">血糖监测频率</div>
                <div className="desc">{ userInfo.detectionfrequency || '-' }</div>
              </div>
            </div>
          }
        </div>

        <div onClick={handleHref} className="btn fixedSubmitBtn">修改</div>
      </div>
    </div>
  );
}

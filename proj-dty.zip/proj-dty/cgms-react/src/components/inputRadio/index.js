import React from 'react';
import './index.css';

export default function InputRadio(props) {
  let { checked, idName ,style } = props;
  return (
    <span id={ idName } className={checked ? "InputRadio InputRadioActive" : "InputRadio"} style={ style }> 
      <span></span>
    </span>
    // <input type="radio" name="confirmState" id="yes01" checked={confirmState == 1} onClick={() => setconfirmState(1)} />
  )
}

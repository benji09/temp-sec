import React, { useState, useRef, useEffect } from 'react';
import { Picker } from 'antd-mobile'

import "./index.css"
import city from './cityData';
import moreRight from '../../assets/images/moreRight.png';

export default function Pickerprovince(props) {
  let { provinceInfo, setprovinceInfo, className } = props;
  const extraElement = useRef(null);
  const [cityValue, setCityValue] = useState('');
  const [cityLable, setCityLable] = useState('');
  const [cityData] = useState(city);

  useEffect(() => {
    if (provinceInfo && provinceInfo.length) {
      setCityValue(provinceInfo)
    }
  }, [provinceInfo]);

  useEffect(() => {
    if (extraElement.current.getAttribute('extra') !== '请选择') {
      const val = extraElement.current.getAttribute('extra').split(',').join(' ');
      setCityLable(val);
    }
  }, [cityValue]);

  
  // 省市区数据改变
  const cityDataChange = (val) => {
    setCityValue(val);
    const getVal = extraElement.current.getAttribute('extra').split(',');
    setprovinceInfo(val)
  };

  return (
    <div>
      <Picker value={cityValue} data={cityData} onOk={cityDataChange}>
        <div
          ref={extraElement}
          className={`${cityLable ? "edit picker-prov" : "edit picker-prov input-gray"} ${ className }` }
        >
          {cityLable ? cityLable : '请选择地区'}

          <img src={ moreRight } alt="" className="moreRight"/>
        </div>
      </Picker>
    </div>
  )
}

import userConfirm from '../pages/userConfirm';
import noAuthority from '../pages/userConfirm/noAuthority';
import submiterBaseInfo from '../pages/submiterBaseInfo';
import submitHealthInfo from '../pages/submitHealthInfo';
import userInfo from '../pages/userInfo';
import editBaseInfo from '../pages/editBaseInfo';
import error from '../pages/error';
import guide from '../pages/guide';

const routers = [
  {
    title: '用户确认',
    path: '/',
    component: userConfirm,
  },
  {
    title: '用户确认',
    path: '/userConfirm',
    component: userConfirm,
  },
  {
    title: '用户确认',
    path: '/noAuthority',
    component: noAuthority,
  },
  {
    title: '基本信息',
    path: '/submiterBaseInfo',
    component: submiterBaseInfo
  },
  {
    title: '健康信息',
    path: '/submitHealthInfo',
    component: submitHealthInfo
  },
  {
    title: '个人信息',
    path: '/userInfo',
    component: userInfo
  },
  {
    title: '个人信息',
    path: '/editBaseInfo',
    component: editBaseInfo
  },
  {
    title: '个人信息',
    path: '/editHealthInfo',
    component: submitHealthInfo
  },
  {
    title: '错误页',
    path: '/error',
    component: error
  },
  {
    title: '产品说明书',
    path: '/guide',
    component: guide
  }
];

export default routers;

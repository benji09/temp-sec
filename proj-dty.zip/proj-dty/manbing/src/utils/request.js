import axios from "axios";
import { Toast } from "antd-mobile"; // 非必须 -- 案例

const baseURL = ''; //根据项目配置前缀 -- 一般抽离成单独文件
// 可以根据 运行环境判断：const baseURL = process.env.NODE_ENV === 'development' ? 'url01' : 'url02'
// 或者根据 url的包含判断：const baseURL = location.href.includes("http://aaa.com") ? 'url01' : 'url02'
// 或者根据 url的host判断：const baseURL = location.host === "http://aaa.com" ? 'url01' : 'url02'

const service = axios.create({
  baseURL: baseURL,
  timeout: 1000 * 30, //接口超时配置
  // withCredentials: true, //表示跨域请求时是否需要使用凭证
  headers: {
    "Content-Type": "application/json; charset=utf-8", //自行更换form表单或者其他
  },
});

service.interceptors.request.use(
  (config) => {
    config.headers.token = localStorage.getItem("_tk_") || '';
    return config;
  },
  (err) => {
    return Promise.reject(err);
  }
);

service.interceptors.response.use(
	response => {
			//code为非20000是抛错 可结合自己业务进行修改
			const res = response.data
			if (res.status == -999) {
				  window.location.href = '/login';
					setTimeout(() => {
						window.location.reload() // 为了重新实例化对象 避免bug
					}, 1500)
				return;
			}
			return response.data
		},
		error => {
			let { msg } = error.message;
			Toast.fail(msg.includes('timeout') ? '请求接口超时' : msg);
			return Promise.reject(error); // reject这个错误信息
		}
);

// 写法一：
const GET = (url, params = {}) => service.get(url, { params }); //注意这是参数是 对象，{params: params} 简写
const POST = (url, params = {}) => service.post(url, params);

// 写法二：
// const GET = (url, params = {}, config = {}) =>
//   service(url, {
//     method: "get",
//     params,
//     ...config,
//   });

// const POST = (url, data = {}, config = {}) =>
//    service(url, {
//     method: "post",
//     data,
//     ...config,
//   });
	
// 写法三：
// const GET = (url, params = {}) => service({
// 	url,
// 	method: 'get',
// 	params,  //注意这里的参数key是 params
// })

// const POST = (url, data = {}) => service({
// 	url,
// 	method: 'post',
// 	data, //注意这里的参数key是 data
// })

export { GET, POST };
export default service;

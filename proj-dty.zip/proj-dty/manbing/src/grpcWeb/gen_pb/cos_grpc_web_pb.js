/**
 * @fileoverview gRPC-Web generated client stub for im
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.im = require('./cos_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.im.CosServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.im.CosServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.im.UploadRequest,
 *   !proto.im.UploadResponse>}
 */
const methodDescriptor_CosService_Upload = new grpc.web.MethodDescriptor(
  '/im.CosService/Upload',
  grpc.web.MethodType.UNARY,
  proto.im.UploadRequest,
  proto.im.UploadResponse,
  /**
   * @param {!proto.im.UploadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.UploadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.im.UploadRequest,
 *   !proto.im.UploadResponse>}
 */
const methodInfo_CosService_Upload = new grpc.web.AbstractClientBase.MethodInfo(
  proto.im.UploadResponse,
  /**
   * @param {!proto.im.UploadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.UploadResponse.deserializeBinary
);


/**
 * @param {!proto.im.UploadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.im.UploadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.im.UploadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.im.CosServiceClient.prototype.upload =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/im.CosService/Upload',
      request,
      metadata || {},
      methodDescriptor_CosService_Upload,
      callback);
};


/**
 * @param {!proto.im.UploadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.im.UploadResponse>}
 *     Promise that resolves to the response
 */
proto.im.CosServicePromiseClient.prototype.upload =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/im.CosService/Upload',
      request,
      metadata || {},
      methodDescriptor_CosService_Upload);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.im.DownloadRequest,
 *   !proto.im.DownloadResponse>}
 */
const methodDescriptor_CosService_Download = new grpc.web.MethodDescriptor(
  '/im.CosService/Download',
  grpc.web.MethodType.UNARY,
  proto.im.DownloadRequest,
  proto.im.DownloadResponse,
  /**
   * @param {!proto.im.DownloadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.DownloadResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.im.DownloadRequest,
 *   !proto.im.DownloadResponse>}
 */
const methodInfo_CosService_Download = new grpc.web.AbstractClientBase.MethodInfo(
  proto.im.DownloadResponse,
  /**
   * @param {!proto.im.DownloadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.DownloadResponse.deserializeBinary
);


/**
 * @param {!proto.im.DownloadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.im.DownloadResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.im.DownloadResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.im.CosServiceClient.prototype.download =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/im.CosService/Download',
      request,
      metadata || {},
      methodDescriptor_CosService_Download,
      callback);
};


/**
 * @param {!proto.im.DownloadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.im.DownloadResponse>}
 *     Promise that resolves to the response
 */
proto.im.CosServicePromiseClient.prototype.download =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/im.CosService/Download',
      request,
      metadata || {},
      methodDescriptor_CosService_Download);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.im.UploadBase64Request,
 *   !proto.im.UploadBase64Response>}
 */
const methodDescriptor_CosService_UploadBase64 = new grpc.web.MethodDescriptor(
  '/im.CosService/UploadBase64',
  grpc.web.MethodType.UNARY,
  proto.im.UploadBase64Request,
  proto.im.UploadBase64Response,
  /**
   * @param {!proto.im.UploadBase64Request} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.UploadBase64Response.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.im.UploadBase64Request,
 *   !proto.im.UploadBase64Response>}
 */
const methodInfo_CosService_UploadBase64 = new grpc.web.AbstractClientBase.MethodInfo(
  proto.im.UploadBase64Response,
  /**
   * @param {!proto.im.UploadBase64Request} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.UploadBase64Response.deserializeBinary
);


/**
 * @param {!proto.im.UploadBase64Request} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.im.UploadBase64Response)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.im.UploadBase64Response>|undefined}
 *     The XHR Node Readable Stream
 */
proto.im.CosServiceClient.prototype.uploadBase64 =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/im.CosService/UploadBase64',
      request,
      metadata || {},
      methodDescriptor_CosService_UploadBase64,
      callback);
};


/**
 * @param {!proto.im.UploadBase64Request} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.im.UploadBase64Response>}
 *     Promise that resolves to the response
 */
proto.im.CosServicePromiseClient.prototype.uploadBase64 =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/im.CosService/UploadBase64',
      request,
      metadata || {},
      methodDescriptor_CosService_UploadBase64);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.im.DownloadRequest,
 *   !proto.im.DownloadBase64Response>}
 */
const methodDescriptor_CosService_DownloadBase64 = new grpc.web.MethodDescriptor(
  '/im.CosService/DownloadBase64',
  grpc.web.MethodType.UNARY,
  proto.im.DownloadRequest,
  proto.im.DownloadBase64Response,
  /**
   * @param {!proto.im.DownloadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.DownloadBase64Response.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.im.DownloadRequest,
 *   !proto.im.DownloadBase64Response>}
 */
const methodInfo_CosService_DownloadBase64 = new grpc.web.AbstractClientBase.MethodInfo(
  proto.im.DownloadBase64Response,
  /**
   * @param {!proto.im.DownloadRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.im.DownloadBase64Response.deserializeBinary
);


/**
 * @param {!proto.im.DownloadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.im.DownloadBase64Response)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.im.DownloadBase64Response>|undefined}
 *     The XHR Node Readable Stream
 */
proto.im.CosServiceClient.prototype.downloadBase64 =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/im.CosService/DownloadBase64',
      request,
      metadata || {},
      methodDescriptor_CosService_DownloadBase64,
      callback);
};


/**
 * @param {!proto.im.DownloadRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.im.DownloadBase64Response>}
 *     Promise that resolves to the response
 */
proto.im.CosServicePromiseClient.prototype.downloadBase64 =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/im.CosService/DownloadBase64',
      request,
      metadata || {},
      methodDescriptor_CosService_DownloadBase64);
};


module.exports = proto.im;


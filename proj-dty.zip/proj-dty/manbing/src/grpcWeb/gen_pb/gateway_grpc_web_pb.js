/**
 * @fileoverview gRPC-Web generated client stub for yujigrpc
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.yujigrpc = require('./gateway_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.yujigrpc.ApiGatewayClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.yujigrpc.ApiGatewayPromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.yujigrpc.ApiRequest,
 *   !proto.yujigrpc.ApiResponse>}
 */
const methodDescriptor_ApiGateway_Call = new grpc.web.MethodDescriptor(
  '/yujigrpc.ApiGateway/Call',
  grpc.web.MethodType.UNARY,
  proto.yujigrpc.ApiRequest,
  proto.yujigrpc.ApiResponse,
  /**
   * @param {!proto.yujigrpc.ApiRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.yujigrpc.ApiResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.yujigrpc.ApiRequest,
 *   !proto.yujigrpc.ApiResponse>}
 */
const methodInfo_ApiGateway_Call = new grpc.web.AbstractClientBase.MethodInfo(
  proto.yujigrpc.ApiResponse,
  /**
   * @param {!proto.yujigrpc.ApiRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.yujigrpc.ApiResponse.deserializeBinary
);


/**
 * @param {!proto.yujigrpc.ApiRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.yujigrpc.ApiResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.yujigrpc.ApiResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.yujigrpc.ApiGatewayClient.prototype.call =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/yujigrpc.ApiGateway/Call',
      request,
      metadata || {},
      methodDescriptor_ApiGateway_Call,
      callback);
};


/**
 * @param {!proto.yujigrpc.ApiRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.yujigrpc.ApiResponse>}
 *     Promise that resolves to the response
 */
proto.yujigrpc.ApiGatewayPromiseClient.prototype.call =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/yujigrpc.ApiGateway/Call',
      request,
      metadata || {},
      methodDescriptor_ApiGateway_Call);
};


module.exports = proto.yujigrpc;


/**
 * @fileoverview gRPC-Web generated client stub for grpc_gateway
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


/* eslint-disable */
// @ts-nocheck



const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.grpc_gateway = require('./gateway_pb.js');

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.grpc_gateway.GrpcGatewayServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.grpc_gateway.GrpcGatewayServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.grpc_gateway.ApiRequest,
 *   !proto.grpc_gateway.ApiResponse>}
 */
const methodDescriptor_GrpcGatewayService_Call = new grpc.web.MethodDescriptor(
  '/grpc_gateway.GrpcGatewayService/Call',
  grpc.web.MethodType.UNARY,
  proto.grpc_gateway.ApiRequest,
  proto.grpc_gateway.ApiResponse,
  /**
   * @param {!proto.grpc_gateway.ApiRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.grpc_gateway.ApiResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.grpc_gateway.ApiRequest,
 *   !proto.grpc_gateway.ApiResponse>}
 */
const methodInfo_GrpcGatewayService_Call = new grpc.web.AbstractClientBase.MethodInfo(
  proto.grpc_gateway.ApiResponse,
  /**
   * @param {!proto.grpc_gateway.ApiRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.grpc_gateway.ApiResponse.deserializeBinary
);


/**
 * @param {!proto.grpc_gateway.ApiRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.grpc_gateway.ApiResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.grpc_gateway.ApiResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.grpc_gateway.GrpcGatewayServiceClient.prototype.call =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/grpc_gateway.GrpcGatewayService/Call',
      request,
      metadata || {},
      methodDescriptor_GrpcGatewayService_Call,
      callback);
};


/**
 * @param {!proto.grpc_gateway.ApiRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.grpc_gateway.ApiResponse>}
 *     Promise that resolves to the response
 */
proto.grpc_gateway.GrpcGatewayServicePromiseClient.prototype.call =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/grpc_gateway.GrpcGatewayService/Call',
      request,
      metadata || {},
      methodDescriptor_GrpcGatewayService_Call);
};


module.exports = proto.grpc_gateway;


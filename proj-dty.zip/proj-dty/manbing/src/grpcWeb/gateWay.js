import grpcpb from './pb/gateway_pb';
import { GrpcGatewayServiceClient } from './pb/gateway_grpc_web_pb';

import config from '../config';

let url;
if (config.env === 'prod') {
  url = '';
} else {
  url = '.' + config.env;
}

const firstToUpper = (str) => {
  return str.trim().toLowerCase().replace(str[0], str[0].toUpperCase());
};

const client = new GrpcGatewayServiceClient(
  `https://grpc-gateway-envoy${url}.yesdream.cn`
);

const gateWayRequest = (params, metadata = {}) => {
  console.log(`request ${url} target:`, params.target);
  console.log(`request params`, JSON.parse(params.request));
  const request = new grpcpb.ApiRequest();
  for (const key of Reflect.ownKeys(params)) {
    request[`set${firstToUpper(key)}`](params[key]);
  }
  return new Promise((resolve, reject) => {
    if (localStorage.getItem('_dv_') && localStorage.getItem('_tk_')) {
      metadata.token = localStorage.getItem('_tk_');
      metadata.device = localStorage.getItem('_dv_');
    }
    client.call(request, metadata, (err, response) => {
      if (err) {
        console.log(err);
        reject(err);
      } else {
        const result = response.toObject();
        const systemError = result.status === -999999;
        const noAccess = result.status === -300000;
        const parameterAnormal = result.status === -400000;
        const serverException = result.status === -500000;
        if (systemError) {
          console.log('系统异常');
          resolve(result);
        }
        if (noAccess) {
          location.replace('/login');
          resolve(result);
        }
        if (parameterAnormal) {
          resolve(result);
        }
        if (serverException) {
          resolve(result);
        }
        if (result.status === 0) {
          resolve(JSON.parse(result.response));
        } else {
          resolve(result);
        }
      }
    });
  });
};

export default gateWayRequest;

import { Toast } from 'antd-mobile';

import grpcpb from './gen_pb/gateway_pb.js';
import grpcwebpb from './gen_pb/gateway_grpc_web_pb.js';
import { initialUppercase } from '../utils/contextHandler';
import config from '../config';

/* grpc web 调用封装
 * serviceName: proto service name
 * messageName: proto message request name
 * rpcFuncName: proto rpc function name(注意首字母小写)
 * payload: 需要发送的消息实体
 * callback: rpc简单调用后的callback
 */

let url;
if (config.env === 'prod') {
  url = '';
} else {
  url = '.' + config.env;
}

class GrpcWeb {
  constructor({ serviceName, serviceUrl }) {
    const ads = serviceUrl || `https://en-grpc${url}.yesdream.cn`;
    console.log('grpc request url:', ads);
    this.client = new grpcwebpb[`${serviceName}Client`](ads);
  }

  useRpc(messageName, rpcFuncName, payload = {}, metadata, callback) {
    const request = new grpcpb[messageName]();
    for (const key in payload) {
      const funcName = `set${initialUppercase(key)}`;
      if (Reflect.has(request, funcName)) {
        request[funcName](payload[key]);
      }
    }
    this.client[rpcFuncName](request, metadata, callback);
  }
}

export function grpcret(payload, metadata = {}, serviceUrl) {
  if (localStorage.getItem('_dv_') && localStorage.getItem('_tk_')) {
    metadata.token = localStorage.getItem('_tk_');
    metadata.device = localStorage.getItem('_dv_');
  }
  return new Promise((resolve, reject) => {
    const grpcWeb = new GrpcWeb({ serviceName: 'ApiGateway', serviceUrl });
    grpcWeb.useRpc('ApiRequest', 'call', payload, metadata, (err, res) => {
      if (err) {
        console.log('grpcret err', err);
        reject(err);
      } else {
        const result = res.toObject();
        console.log(payload);
        if (
          result.status === -300 ||
          result.status === -200 ||
          result.status === -100
        ) {
          location.href = '/login';
        }
        if(result.status === -999) {
          console.log(result);
          Toast.info('系统异常');
          return;
        }
        resolve(result);
      }
    });
  });
}

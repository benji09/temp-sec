import grpcpb from './gen_pb/cos_pb';
import { CosServiceClient } from './gen_pb/cos_grpc_web_pb.js';

let url = '';
// if (config.env === 'prod') {
//   url = '';
// } else {
//   url = '.' + config.env;
// }

const client = new CosServiceClient(
  `https://cos-core-envoy${url}.yesdream.cn`
);

const cosRequest = (methodName, params, metadata = {}) => {
  console.log(`https://cos-core-envoy${url}.yesdream.cn`);
  let request;
  if (methodName !== 'DownloadBase64') {
    request = new grpcpb[`${methodName}Request`]();
  } else {
    request = new grpcpb[`DownloadRequest`]();
  }
  for (const key of Reflect.ownKeys(params)) {
    request[`set${key}`](params[key]);
  }
  return new Promise((resolve, reject) => {
    if (localStorage.getItem('_dv_') && localStorage.getItem('_tk_')) {
      metadata.token = localStorage.getItem('_tk_');
      metadata.device = localStorage.getItem('_dv_');
    }
    metadata.aid = 1004;
    client[methodName.charAt(0).toLowerCase() + methodName.slice(1)](
      request,
      metadata,
      (err, response) => {
        if (err) {
          console.log(err);
          reject(err);
        } else {
          console.log(response);
          resolve(response.toObject());
        }
      }
    );
  });
};

export default cosRequest;

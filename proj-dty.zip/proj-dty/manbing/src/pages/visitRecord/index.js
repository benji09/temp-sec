import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { InputItem, DatePicker, TextareaItem } from 'antd-mobile';

import "./index.less";

// import CalendarIcon from './images/CalendarIcon.png';

const VisitRecord = () => {
  let history = useHistory();

  // 用户上传图片列表
  const [imgList, setImgList] = useState([
    "https://file-test-1304455996.cos.ap-shanghai.myqcloud.com/14818922728061706241254979181.jfif",
    "https://file-test-1304455996.cos.ap-shanghai.myqcloud.com/14818922728061706241254979181.jfif",
    "https://file-test-1304455996.cos.ap-shanghai.myqcloud.com/14818922728061706241254979181.jfif",
    "https://file-test-1304455996.cos.ap-shanghai.myqcloud.com/14818922728061706241254979181.jfif",
    "https://file-test-1304455996.cos.ap-shanghai.myqcloud.com/14818922728061706241254979181.jfif",
  ]);

  return (
    <div className="AddVisitRecord">
      <div className="cotBox">
        <div className="title">首次就诊日期</div>
        <div className="item">2021-12-15</div>
        <div className="br"></div>

        <div className="title">视力数据</div>
        <div className="item">左眼视力：1.7</div>
        <div className="item">右眼视力：1.7</div>
        <div className="br"></div>

        <div className="title flex_lc">
          影像材料
          <span>（最多5张）</span>
        </div>
        <div className="item flex_lc imgList">
          {
            imgList.map(ii => {
              return <img className='imgItem' src={ii} alt="" />
            })
          }
        </div>
        <div className="br mt_28"></div>

        <div className="title">备注</div>
        <div className="item">这里是备注内容段落文本这里是备注内容段落文本这里是备注内容段落文本这里是备注内容</div>
      </div>
    </div>
  )
}
export default VisitRecord;
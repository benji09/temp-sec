import React, { useState, useEffect} from 'react';
import { useHistory } from 'react-router-dom';

import jobTitle from './images/job-title.svg';
import department from './images/department.svg';

import "./index.less";

const BindDoctor = () => {
    let history = useHistory();

    

    const toKnow = () => {

    }

    const goBack = () => {
        history.goBack();
    }
    return (
        <div className="bind-doctor">
            <div className="doctor-info">
                <div className="photo">
                    <img src="" alt="" />
                </div>
                <div className="photo-r">
                    <div className="name">刘医生</div>
                    <div className="job">
                        <div className="job-title">
                            <img src={jobTitle} alt="" />
                            <span>副主任医师</span>
                        </div>
                        <div className="department">
                            <img src={department} alt="" />
                            <span>中西医结核科</span>
                        </div>
                    </div>
                    <div className="brief">医院名称医院名称医院名称医院名称医院名称医院名称</div>
                </div>
            </div>
            <div className="verify-phone">
                <h2>请填写手机号，便于我们更好地了解和联系您</h2>
                <div className="number">
                    <input type="text" placeholder="请输入手机号" />
                </div>
                <div className="code">
                    <input type="text" placeholder="请输入验证码" />
                    <span>35s重新获取验证码</span>
                </div>
                <div className="warning">验证码错误</div>
                <div className="next-step next-step-disabled">下一步，填写个人信息</div>
            </div>

        </div>
    )
}
export default BindDoctor;
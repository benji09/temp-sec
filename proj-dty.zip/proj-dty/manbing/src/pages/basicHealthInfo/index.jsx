import React, { useState, useEffect} from 'react';
import { useHistory } from 'react-router-dom';

import titleFront from '../../assets/icons/title-front.svg';

import "./index.less";

const Basichealthinfo = () => {
    let history = useHistory();

    useEffect(() => {
        document.title = '个人基本健康信息';
    }, [])

    const toKnow = () => {

    }

    const goBack = () => {
        history.goBack();
    }
    return (
        <div className="basic-health-info">
            <h2>请您填写以下基本信息，让医生更好地了解您的情况。</h2>
            <div className="user-info">
                <div className="title">
                    <img src={titleFront} alt="" />
                    基本信息
                </div>
                <div className="content">
                    <div className="item">
                        <span>真实姓名</span>
                        <span>欧阳娜娜</span>
                    </div>
                    <div className="item">
                        <span>性别</span>
                        <span>女</span>
                    </div>
                    <div className="item">
                        <span>预计参与人数</span>
                        <span>0</span>
                    </div>
                </div>
            </div>
            <div className="illness-info user-info">
                <div className="title">
                    <img src={titleFront} alt="" />
                    疾病信息
                </div>
                <div className="content">
                    <div className="item">
                        <span>疾病诊断</span>
                        <span>糖尿病性黄斑水肿（DEM）</span>
                    </div>
                    <div className="item">
                        <span>确诊年份</span>
                        <span>请选择</span>
                    </div>
                    <div className="item">
                        <span>目前治疗方案</span>
                        <span>药物治疗</span>
                    </div>
                    <div className="item">
                        <span>糖尿病类型</span>
                        <span>2型</span>
                    </div>
                    <div className="item">
                        <span>既往病史</span>
                    </div>
                    <textarea name="" id="" cols="30" rows="10" placeholder="请填写您的过往重要病史"></textarea>
                </div>
            </div>
            <div className="save-btn">保存</div>
        </div>
    )
}
export default Basichealthinfo;
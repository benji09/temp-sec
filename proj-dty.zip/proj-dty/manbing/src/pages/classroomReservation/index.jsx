import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';

import reservationHeaderBg from './images/reservation-header-bg.png';
import titleFront from './images/title-front.svg';
import reservationRightArrow from './images/reservation-right-arrow.svg';
import reservationWarning from './images/reservation-warning.svg';

import './index.less';

const ClassroomReservation = () => {
     
    useEffect(() => {
       
    }, []);

    return (
        <div className="classroom-reservation">
            <header style={{
                background: `url(${reservationHeaderBg})`,
                backgroundSize: '100% 100%',
            }}>
                <h2>课堂名称课堂名称课堂名称课堂名称课堂名称</h2>
            </header>
            <div className="reservation-content">
                <div className="reservation-info">
                    <div>
                        <span>预约时间</span>
                        <span>2021-12-15 14:55 -17:29</span>
                    </div>
                    <div>
                        <span>医生</span>
                        <span>欧阳娜娜</span>
                    </div>
                    <div>
                        <span>医院名称</span>
                        <span>上海复旦大学耳鼻喉科医院</span>
                    </div>
                    <div>
                        <span>预计参与人数</span>
                        <span>15人</span>
                    </div>
                </div>
                <div className="event-intro">
                    <div className="title">
                        <img src={titleFront} alt="" />
                        <span>活动简介</span>
                    </div>
                    <p>这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本这里是活动简介段落文本</p>
                </div>
                <div className="material">
                    <div className="material-l">
                        <img src={titleFront} alt="" />
                        <span>患教资料</span>
                    </div>
                    <div className="material-r">
                        <span>资料名字资料名字资料名资料名字资</span>
                        <img src={reservationRightArrow} alt="" />
                    </div>
                    
                </div>
                <div className="warning">
                    <img src={reservationWarning} alt="" />
                    <div>温馨提示：电话知识小课堂开课时，系统会自动呼叫您的手机号，把您加入知识小课堂。如果您不想参加，可选择不接听或挂断电话。如果在任何时间都不想接听小课堂，请拨打400-805-1797。</div>
                </div>
            </div>
            <footer>
                <div>预约参与</div>
            </footer>
            
        </div>
    )

  
}
export default ClassroomReservation;

import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { Toast } from 'antd-mobile';

import classroomBanner from './images/classroom-banner.png';
import classroomDate from './images/classroom-date.svg';

import './index.css';

const physicalExaminationGiftbag = () => {

   

    return (
        <div className="patient-classroom">
            <img src={classroomBanner} alt="" className="banner" />
            <div className="classroom-list">
                <div className="date">2021年12月</div>
                <div className="list">
                    <div className="list-item">
                        <h2>患教课堂名称最长字段展示一行最多一展示一行最多一行</h2>
                        <div className="host-info">
                            <div className="info-l">
                                <div className="info-l-t">
                                    <img src={classroomDate} alt="" />
                                    <span>2021-12-15 14:55 -17:29</span>
                                </div>
                                <div className="info-l-b">
                                    <span>欧阳娜娜</span>
                                    <span>上海复旦大学附属医院</span>
                                </div>
                            </div>
                            <div className='info-r'>立即预约</div>
                        </div>
                    </div>
                </div>

                <div className="list">
                    <div className="list-item">
                        <h2>患教课堂名称最长字段展示一行最多一展示一行最多一行</h2>
                        <div className="host-info">
                            <div className="info-l">
                                <div className="info-l-t">
                                    <img src={classroomDate} alt="" />
                                    <span>2021-12-15 14:55 -17:29</span>
                                </div>
                                <div className="info-l-b">
                                    <span>欧阳娜娜</span>
                                    <span>上海复旦大学附属医院</span>
                                </div>
                            </div>
                            <div className='info-r-2'>
                                已预约
                            </div>
                        </div>
                    </div>
                </div>

                <div className="list">
                    <div className="list-item">
                        <h2>患教课堂名称最长字段展示一行最多一展示一行最多一行</h2>
                        <div className="host-info">
                            <div className="info-l">
                                <div className="info-l-t">
                                    <img src={classroomDate} alt="" />
                                    <span>2021-12-15 14:55 -17:29</span>
                                </div>
                                <div className="info-l-b">
                                    <span>欧阳娜娜</span>
                                    <span>上海复旦大学附属医院</span>
                                </div>
                            </div>
                            <div className='info-r-3'>已结束</div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )

  
}
export default physicalExaminationGiftbag;

import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { InputItem, DatePicker, TextareaItem } from 'antd-mobile';
import ImgUpload from '../../components/ImgUpload';

import "./index.less";

// import CalendarIcon from './images/CalendarIcon.png';

const AddVisitRecord = () => {
  let history = useHistory();

  const [selectTime, setSelectTime] = useState(new Date());
  // 用户上传图片列表
  const [uploadImgList, setUploadImgList] = useState([]);

  function handleInputTime(t) {
    setSelectTime(t)
  }

  function handleYMD(t) {
    let add0 = m => m > 9 ? m : '0' + m;
    return `${t.getFullYear()}-${add0(t.getMonth() + 1)}-${add0(t.getDate())}`
  }


  return (
    <div className="AddVisitRecord">
      <div className="cotBox">
        {/* 就诊日期 */}
        <div className="flex_lc">
          <div className="star">*</div>
          <div className="title">首次就诊日期</div>
        </div>
        <div className="flex_bc">
          <div className="name">就诊日期：</div>
          <DatePicker
            mode="date"
            maxDate={new Date()}
            value={selectTime}
            format={'YYYY-MM-DD'}
            onChange={time => handleInputTime(time)}
          >
            <div className="inputBox flex_lc">
              <span>{handleYMD(selectTime)}</span>
              {/* <img src={CalendarIcon} alt="" /> */}
            </div>
          </DatePicker>
        </div>

        {/* 视力数据 */}
        <div className="title mt_64">视力数据</div>
        <div className="flex_bc">
          <div className="name">左眼视力：</div>
          <div className="inputBox">
            <InputItem
              type="money"
              placeholder='数值范围0-5.2'
              maxLength="3"
            />
          </div>
        </div>
        <div className="flex_bc">
          <div className="name">右眼视力：</div>
          <div className="inputBox">
            <InputItem
              type="money"
              placeholder='数值范围0-5.2'
              maxLength="3"
            />
          </div>
        </div>

        <div className="flex_lc title mt_64">影像材料 <span>（最多5张）</span></div>
        <ImgUpload
          handleImgList={setUploadImgList}
          length='3' //每行显示数量
          multiple //是否多选
          selectable={uploadImgList.length < 9} //长度限制
        />

        <div className="title mt_64">备注</div>
        <div className="flex_bc">
          <TextareaItem
            className="textarea"
            rows={6}
            count={150}
            placeholder="非必填，请填写病情相关信息。示例：水肿是否减退，有无不良反应等"
          />
        </div>
      </div>

      <div className="btn saveBtn">确认就诊</div>
    </div>
  )
}
export default AddVisitRecord;
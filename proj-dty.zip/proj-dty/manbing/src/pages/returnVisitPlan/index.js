import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { InputItem, Button } from 'antd-mobile';

import { Calendar } from 'react-h5-calendar'

import "./index.less";
import "./calendar.less";

import headerBG from './images/headerBG.png';
import dateMore from './images/dateMore.png';
import Department from './images/Department.png';
import Qualifications from './images/Qualifications.png';

const Enroll = () => {
  let history = useHistory();

  const [planInfo, setPlanInfo] = useState(null);

  function onCalendarTouchStart(e) {
    console.log(e);
  }

  // 点击日期
  function onCalendarDateClick(e){
    console.log(e);
    let getData = `${e.$y}-${e.$M}-${e.$D}`
    console.log(getData);
  }

  // markType: 'circle' 模拟绿色小点
  // markType: 'dot' 模拟黄色小点
  const [markDates, setmarkDates] = useState([
    { color: '#459', date: '2022-01-19', markType: 'circle' },
    { color: '#a8f', date: '2022-01-23', markType: 'dot' },
    { color: '#a5f', date: '2022-01-25', markType: 'circle' },
    { color: '#a5f', date: '2022-01-31', markType: 'circle' },
    { color: '#a5f', date: '2022-2-2', markType: 'dot' },
  ]);


  return (
    <div className="returnVisitPlan">
      <div
        className="headerTips"
        style={{
          background: `url(${headerBG}) no-repeat`,
          backgroundSize: "100vw 43.466666vw"
        }}
      >
        <div className="flex_cc span01">
          以下是医生为您设置的复诊计划，请您按时复诊哦。
        </div>

        <div className="flex_cc span02">
          <span>下次复诊日期：</span>
          <span className='date'>2021年12月23日</span>
          <img className='dateMore' src={dateMore} alt="" />
        </div>
      </div>

      {/* 日历 */}
      <div className="calendar">
        <Calendar
          showType='month'
          markDates={markDates}
          onDateClick={onCalendarDateClick}
        />
      </div>

      {/* 连接样式 */}
      <div className="flex_bc concat">
        <div className="flex_bc item">
          <div className="around"></div>
          <div className="around"></div>
        </div>

        <div className="flex_bc item">
          <div className="around"></div>
          <div className="around"></div>
        </div>
      </div>

      {/* 复诊计划 */}
      <div className="plan">
        {planInfo ? (
          <div>
            <div className="planTitle">复诊日</div>
            <div className="flex_cc docterInfo">
              <div className="name">哈啊哈</div>
              <div className="flex_cc">
                <div className="tagItem">
                  <img src={Qualifications} alt="" />
                  <span>副主任医师</span>
                </div>
                <div className="tagItem">
                  <img src={Department} alt="" />
                  <span>中西医结核科</span>
                </div>
              </div>
            </div>
            <div className="desc">医院名称医院名称医院名称医院名称医院名称医院名称医院名称名称医院名称名称医院名称</div>
            <div className="btn hrefRecord">查看记录</div>
          </div>
        ) : (
          <div>
            <div className="noDataTitle">暂无复诊计划</div>
            <div className="btn hrefRecord">前往添加</div>
          </div>
        )}
      </div>
    </div>
  )
}
export default Enroll;
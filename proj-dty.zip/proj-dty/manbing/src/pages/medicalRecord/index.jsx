import React, { useState, useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { Toast } from 'antd-mobile';

import mrAddIcon from './images/mr-add-icon.svg';
import mrCheck from './images/mr-check.svg';
import mrDelete from './images/mr-delete.svg';

import './index.less';

const medicalRecord = () => {

    return (
        <div className="medical-record">
            <div className="records">
                <div className="item first-item">
                    <div className="item-l">
                        <div>首次就诊</div>
                        <div>2021-12-24</div>
                    </div>
                    <div className="item-r">查看记录</div>
                </div>

                {/* 添加就诊后结构 */}
                <div className="item">
                    <div className="item-l">
                        <div>首次就诊</div>
                        <div>2021-12-24</div>
                    </div>
                    <div className="after-add">
                        <span>查看记录</span>
                        <div>
                            <img src={mrDelete} alt="" />
                        </div>
                    </div>
                </div>


                <div className="item last-item">
                    <div className="item-l">
                        <div>首次就诊</div>
                        <div>2021-12-24</div>
                    </div>
                    <div className="item-r">确认就诊</div>
                </div>

            </div>
            <div className="add-records">
                <div className="add-icon">
                    <img src={mrAddIcon} alt="" />
                </div>
                <span>添加更多就诊记录</span>
            </div>
            <div className="check-calendar">
                <span>查看复诊日历</span>
                <img src={mrCheck} alt="" />
            </div>

            
        </div>
    )
}
export default medicalRecord;

import React, { useState, useEffect} from 'react';
import { useHistory } from 'react-router-dom';

import jobTitle from './images/job-title.svg';
import department from './images/department.svg';

import "./index.less";

const DoctorMessage = () => {
    let history = useHistory();

    useEffect(() => {
        document.title = '医生消息';
    }, [])

    const toKnow = () => {

    }

    const goBack = () => {
        history.goBack();
    }
    return (
        <div className="doctor-message">
            <div className="doctor-info">
                <div className="photo">
                    <img src="" alt="" />
                </div>
                <div className="photo-r">
                    <div className="name">刘医生</div>
                    <div className="job">
                        <div className="job-title">
                            <img src={jobTitle} alt="" />
                            <span>副主任医师</span>
                        </div>
                        <div className="department">
                            <img src={department} alt="" />
                            <span>中西医结核科</span>
                        </div>
                    </div>
                    <div className="brief">医院名称医院名称医院名称医院名称医院名称医院名称</div>
                </div>
            </div>

            {/* 信息模板 */}
            {/* 填写 */}
            <div className="fill-in">
                <div className="time">2021-02-19  07:50</div>
                <div className="message-box">
                    <div className="title">XXX医生提醒您填写基本健康信息</div>
                    <div className="line"></div>
                    <div className="btn">立即填写</div>
                </div>
            </div>
            {/* 文章 */}
            <div className="fill-in">
                <div className="time">2021-02-19  07:50</div>
                <div className="message-box">
                    <div className="title">XXX医生提醒您填写基本健康信息</div>
                    <div className="line"></div>
                    <div className="article">
                        <img src="" alt="" />
                        <p>这是一篇文章名称最长显示字段为这么长快速开始看字段为这么速开始看字段</p>
                    </div>
                </div>
            </div>

            {/* 预约 */}
            <div className="fill-in">
                <div className="time">2021-02-19  07:50</div>
                <div className="message-box">
                    <div className="title">XXX医生提醒您填写基本健康信息</div>
                    <div className="line"></div>
                    <div className="btn">点击预约</div>
                </div>
            </div>
            {/* 查看计划 */}
            <div className="fill-in">
                <div className="time">2021-02-19  07:50</div>
                <div className="message-box">
                    <div className="title">XXX医生提醒您填写基本健康信息</div>
                    <div className="line"></div>
                    <div className="btn">点击查看计划</div>
                </div>
            </div>

        </div>
    )
}
export default DoctorMessage;
import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { InputItem, Button } from 'antd-mobile';

import "./index.less";

import lineLeft from './images/lineLeft.png';
import lineRight from './images/lineRight.png';

const Enroll = () => {
  let history = useHistory();

  function handlePhone(e) {
    console.log(e);
  }

  return (
    <div className="Enroll px_32 py_32">
      <div className="cardBox color_333">
        <div className="flex_bc">
          <div className="flex_cc txt">姓名</div>
          <InputItem
            type="phone"
            onChange={handlePhone}
            className='am_input'
          />
        </div>
        <div className="flex_bc phone">
          <div className="flex_cc txt">手机号</div>
          <InputItem
            type="phone"
            onChange={handlePhone}
            className='am_input'
          />
        </div>

        <div className='btn submit'>提交</div>
      </div>

      <div className="cardBox color_333 mt_32 desc">
        <div className="flex_cc mb_40">
          <img src={lineLeft} alt="" className="titleLine" />
          <span className='title'>温馨提示</span>
          <img src={lineRight} alt="" className="titleLine" />
        </div>

        <div className='item'>
        1、在患教课堂开始前的5~10分钟，我们的客服会接通您填写的手机，将您接入患教课堂，请注意来自021-33260987的电话，保持您的手机通畅；
        </div>

        <div className='item'>
        2、患教课堂采用网络电话的形式，因此患教课堂不需要消耗您的手机费用；
        </div>

        <div className='item'>
        3、由于参与患教课堂的还有其他患者，请在参会过程中将电话静音，在提问环节开始后再提问；
        </div>

        <div className='item'>
        4、为保证患教课堂效果，请提前学习医生发送的患教资料。资料再活动信息中可查看。
        </div>

      </div>
    </div>
  )
}
export default Enroll;
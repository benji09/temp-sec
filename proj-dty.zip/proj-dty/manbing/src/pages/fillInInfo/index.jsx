import React, { useState, useEffect} from 'react';
import { useHistory } from 'react-router-dom';

import jobTitle from './images/job-title.svg';
import department from './images/department.svg';

import "./index.less";

const FillInInfo = () => {
    let history = useHistory();

    

    const toKnow = () => {

    }

    const goBack = () => {
        history.goBack();
    }
    return (
        <div className="fill-in-info">
            <h2>请您填写以下基本信息，让医生更好地了解您的情况。</h2>
            <div className="info">
                <div className="info-item">
                    <span>真实姓名：</span>
                    <input type="text" placeholder="请填写您的真实姓名" />
                </div>
                <div className="info-item">
                    <span>性别：</span>
                    <input type="text" placeholder='' />
                </div>
                <div className="info-item">
                    <span>出生年月：</span>
                    <input type="text" placeholder="点击选择" />
                </div>
                <div className="info-item">
                    <span>疾病诊断：</span>
                    <input type="text" placeholder="" />
                </div>
                <div className="info-item">
                    <span>糖尿病类型：</span>
                    <input type="text" placeholder="点击选择" />
                </div>
            </div>
            <div className="save-btn">保存</div>
            <div className="skip">暂不完善，跳过这一步</div>
        </div>
    )
}
export default FillInInfo;
import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { DatePicker, InputItem, TextareaItem, Picker } from 'antd-mobile';

import ImgUpload from '../../components/ImgUpload';

import "./addPatientRecord.less";

function formatDate(date) {
  /* eslint no-confusing-arrow: 0 */
  const pad = n => n < 10 ? `0${n}` : n;
  const dateStr = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  const timeStr = `${pad(date.getHours())}:${pad(date.getMinutes())}`;
  return `${dateStr} ${timeStr}`;
}

const nowTimeStamp = Date.now();
const nowDate = new Date(nowTimeStamp);

const PatientData = () => {
  let history = useHistory();
  // 用户上传图片列表
  const [uploadImgList, setUploadImgList] = useState([]);
  const [nowDate, setNowDate] = useState([
    { value: 11, label: '哈啊哈11', },
    { value: 22, label: '哈啊哈22', },
  ]);
  const [pickerVal, setPickerVal] = useState('');


  function handlePhone(e) {
    console.log(e);
  }

  return (
    <div className="AddPatientRecord">
      <div className="bg_fff">
        <div className="visitDate">
          <div className="flex_bc bb">
            <div className="txt">就诊日期</div>
            <DatePicker
              value={nowDate}
              onOk={handlePhone}
            />
          </div>
        </div>

        <div className="visionData bb">
          <div className="flex_bc">
            <div className="txt">视力数据：</div>
          </div>

          <div className="flex_bc">
            <div className="txt">左眼视力</div>
            <InputItem
              className='inputBox'
              type="number"
              placeholder="视力范围0~5.2"
              onChange={handlePhone}
            />
          </div>

          <div className="flex_bc">
            <div className="txt">右眼视力</div>
            <InputItem
              className='inputBox'
              type="number"
              placeholder="视力范围0~5.2"
              onChange={handlePhone}
            />
          </div>
        </div>

        <div className="visionData bb">
          <div className="flex_bc">
            <div className="txt">影像材料：</div>
          </div>

          <div className="flex_bc">
            <div className="txt">OTC</div>
          </div>

          <div className="ImgListBox">
            <ImgUpload
              handleImgList={setUploadImgList}
              length='3' //每行显示数量
              multiple //是否多选
              selectable={uploadImgList.length < 9} //长度限制
            />
          </div>
        </div>

        <div className="visionData bb">
          <div className="flex_bc">
            <div className="txt">眼底造影</div>
          </div>

          <div className="ImgListBox">
            <ImgUpload
              handleImgList={setUploadImgList}
              length='3' //每行显示数量
              multiple //是否多选
              selectable={uploadImgList.length < 9} //长度限制
            />
          </div>
        </div>

        <div className="visionData bb">
          <div className="flex_bc">
            <div className="txt">裂隙灯</div>
          </div>

          <div className="ImgListBox">
            <ImgUpload
              handleImgList={setUploadImgList}
              length='3' //每行显示数量
              multiple //是否多选
              selectable={uploadImgList.length < 9} //长度限制
            />
          </div>
        </div>

        <div className="visionData bb">
          <div className="flex_bc">
            <div className="txt">其它</div>
          </div>

          <div className="ImgListBox">
            <ImgUpload
              handleImgList={setUploadImgList}
              length='3' //每行显示数量
              multiple //是否多选
              selectable={uploadImgList.length < 9} //长度限制
            />
          </div>
        </div>

        <div className="visionData areaBox">
          <div className="flex_bc">
            <div className="txt">备注</div>
          </div>
          <div className="flex_bc">
            <TextareaItem
              className='areaItem'
              placeholder="非必填，请填写病情相关信息。示例：水肿是否减退，有无不良反应等"
              rows="3"
              onChange={handlePhone}
            />
          </div>
        </div>
      </div>

      <div className="submitBox">
        <div className="btn submit">保存</div>
      </div>
    </div>
  )
}
export default PatientData;

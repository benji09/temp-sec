import React, { useState, useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { InputItem, TextareaItem, Picker, List } from 'antd-mobile';

import "./patientData.less";

import MoreIcon from './images/moreIcon.png'

const PatientData = () => {
  let history = useHistory();
  const [pickerArr, setPickerArr] = useState([
    { value: 11, label: '哈啊哈11', },
    { value: 22, label: '哈啊哈22', },
  ]);
  const [pickerVal, setPickerVal] = useState('');


  function handlePhone(e) {
    console.log(e);
  }

  return (
    <div className="PatientData">
      <div className="tips">
        请您填写患者基线数据，如果患者只有一只眼睛患病，则只需填写一只眼睛的水肿和视力数据。
        <br />
        糖化血红蛋白非必要填。
      </div>

      <div className="bg_fff formBox">
        <div className="flex_bc">
          <div className="txt">患病眼睛</div>
          <Picker
            data={pickerArr}
            cols={1}
            onOk={handlePhone}
          >
            <div className="inputBox pickerBox">
              <span>{pickerVal || '请选择'}</span>
              <img src={MoreIcon} alt="" className="moreIcon" />
            </div>
          </Picker>
          <div className="unit"></div>
        </div>

        <div className="flex_bc">
          <div className="txt">左眼视力</div>
          <InputItem
            className='inputBox'
            type="number"
            placeholder="请填写"
            onChange={handlePhone}
          />
          <div className="unit"></div>
        </div>

        <div className="flex_bc">
          <div className="txt">左眼水肿</div>
          <InputItem
            className='inputBox'
            type="number"
            placeholder="请填写"
            onChange={handlePhone}
          />
          <div className="unit">μm</div>
        </div>

        <div className="flex_bc">
          <div className="txt">右眼视力</div>
          <InputItem
            className='inputBox'
            type="number"
            placeholder="请填写"
            onChange={handlePhone}
          />
          <div className="unit"></div>
        </div>

        <div className="flex_bc">
          <div className="txt">右眼水肿</div>
          <InputItem
            className='inputBox'
            type="number"
            placeholder="请填写"
            onChange={handlePhone}
          />
          <div className="unit">μm</div>
        </div>

        <div className="flex_bc">
          <div className="txt">糖化血红蛋白</div>
          <InputItem
            className='inputBox'
            type="number"
            placeholder="请填写"
            onChange={handlePhone}
          />
          <div className="unit">%</div>
        </div>

        <div className="flex_bc areaItem">
          <div className="txt">备注</div>
          <TextareaItem
            className='inputBox'
            type="number"
            placeholder="请填写"
            rows="3"
            onChange={handlePhone}
          />
          <div className="unit"></div>
        </div>
      </div>

      <div className="submitBox">
        <div className="btn submit">保存</div>
      </div>
    </div>
  )
}
export default PatientData;

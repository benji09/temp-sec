import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import routers from '../routers';
import 'antd-mobile/dist/antd-mobile.css'; 
import './App.less';

const App = () => {
  return (
    <Router>
      <Switch>
        {routers.map((item, index) => {
          return (
            <Route
              key={index}
              exact
              path={item.path}
              render={() => {
               return <item.component />;
              }}
            />
          );
        })}
      </Switch>
    </Router>
  );
};

export default App;

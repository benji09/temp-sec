import React, { useState } from 'react';
import { ImagePicker } from 'antd-mobile';
import { Toast } from 'antd-mobile';
import { compress } from '../../utils/image';
import cosRequest from '../../grpcWeb/cos';
// import config from '../../config';
// const imgBaseUrl = config.env === 'prod' ? '' : '.' + config.env;

const imgBaseUrl = '.'

const ImagePickerExample = (props) => {
  const { handleImgList, ...options } = props;
  const [imgList, setImgList] = useState([]);

  const uploadImg = (imgObj) => {
    return new Promise((resolve, reject) => {
      compress(
        imgObj.file,
        {
          compress: {
            width: 1600,
            height: 1600,
            quality: 0.5,
          },
        },
        async (result) => {
          const fullName = result.name.split('.');
          const FileName = fullName[0];
          const Suffix = fullName[1];
          console.log('UploadBase64开始执行', result.name);
          const uploadResult = await cosRequest('UploadBase64', {
            FileName,
            Suffix,
            FileType: 1,
            File: result.base64,
          });
          console.log('上传图片结束', uploadResult);
          resolve({
            ...imgObj,
            fileUrl: `https://cos-gateway${imgBaseUrl}.yesdream.cn/cos/download?id=${uploadResult.fileId}`
          })
        }
      );
    })
  };

  // 新增-删除 图片事件
  function onChange(files, type, index) {
    // console.log(files, type, index);
    if (type == 'add') {
      let taskAll = files.map(ii => {
        if (ii.fileUrl) {
          return ii;
        } else {
          return uploadImg(ii)
        }
      })

      Toast.loading('上传中...', 1000, '', false);
      Promise.all(taskAll).then(res => {
        console.log(res);
        Toast.hide();
        setImgList(res);
        handleImgList(res.map(ii => ii.fileUrl));
      })
    } else {
      setImgList(files);
      handleImgList(files.map(ii => ii.fileUrl));
    }
  }
  
  return (
    <ImagePicker
      files={imgList}
      onChange={onChange}
      // length='3' //每行显示数量
      // multiple //是否多选
      // selectable={imgList.length < 9} //长度限制
      {
        ...options
      }
    />
  )
}

export default ImagePickerExample


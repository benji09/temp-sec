// 个人基本健康信息
import BasicHealthInfo from "../pages/basicHealthInfo";
// 医生消息
import DoctorMessage from "../pages/doctorMessage";
// 患教课堂
import PatientClassroom from "../pages/patientClassroom";
// 患教课堂-预约
import ClassroomReservation from '../pages/classroomReservation';
// 患教课堂 - 报名
import Enroll from "../pages/enroll";
// app - 填写患者数据
import AppPatientData from '../pages/app/patientData';
// app - 填写患者就诊记录
import AppAddPatientRecord from '../pages/app/addPatientRecord';
// 就诊记录
import MedicalRecord from '../pages/medicalRecord';
// 中国眼底病患者管理项目-注册绑定
import BindDoctor from '../pages/bindDoctor';
// 中国眼底病患者管理项目-填写个人信息
import FillInInfo from '../pages/fillInInfo';
// 复诊计划
import ReturnVisitPlan from '../pages/returnVisitPlan';
// 确认就诊 - 添加就诊记录
import AddVisitRecord from '../pages/addVisitRecord';
// 就诊记录
import VisitRecord from '../pages/visitRecord';

const routers = [
  {
    title: '个人基本健康信息',
    path: '/',
    component: BasicHealthInfo,
  },
  {
    title: '医生消息',
    path: '/doctormessage',
    component: DoctorMessage,
  },
  {
    title: '患教课堂',
    path: '/patientclassroom',
    component: PatientClassroom,
  },
  {
    title: '患教课堂预约',
    path: '/classroomreservation',
    component: ClassroomReservation,
  },
  {
    title: '患教课堂',
    path: '/enroll',
    component: Enroll,
  },
  {
    title: '填写患者数据',
    path: '/AppPatientData',
    component: AppPatientData,
  },
  {
    title: '添加患者就诊记录',
    path: '/AppAddPatientRecord',
    component: AppAddPatientRecord,
  },
  {
    title: '就诊记录',
    path: '/medicalrecord',
    component: MedicalRecord,
  },
  {
    title: '中国眼底病患者管理项目',
    path: '/bindDoctor',
    component: BindDoctor,
  },
  {
    title: '中国眼底病患者管理项目',
    path: '/fillininfo',
    component: FillInInfo,
  },
  {
    title: '复诊计划',
    path: '/ReturnVisitPlan',
    component: ReturnVisitPlan,
  },
  {
    title: '确认就诊',
    path: '/AddVisitRecord',
    component: AddVisitRecord,
  },
  {
    title: '就诊记录',
    path: '/VisitRecord',
    component: VisitRecord,
  },
]
 
export default routers;


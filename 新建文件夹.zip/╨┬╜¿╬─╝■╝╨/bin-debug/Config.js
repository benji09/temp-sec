/**
 * app配置文件
 */
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Config = (function () {
    function Config() {
    }
    Config.HOST = "http://192.168.1.134:8360";
    Config.COLOR_MAIN = 0x39f4e6;
    Config.DEBUG = true;
    return Config;
}());
__reflect(Config.prototype, "Config");
//# sourceMappingURL=Config.js.map
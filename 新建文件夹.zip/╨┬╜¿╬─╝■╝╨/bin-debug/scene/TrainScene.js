var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var TrainScene = (function (_super) {
    __extends(TrainScene, _super);
    function TrainScene() {
        var _this = _super.call(this) || this;
        _this.isInit = false;
        _this.timer = null;
        return _this;
    }
    TrainScene.prototype.init = function () {
        this.setBackground('train_bg_png');
        Util.setTitle('答题闯关');
        this.name = 'trainScene';
        var bandges = Util.getConfig('bandge');
        this.bandges = bandges;
        var trainLevelGroup = new eui.Group();
        trainLevelGroup.y = 340;
        this.addChild(trainLevelGroup);
        this.trainLevelGroup = trainLevelGroup;
        this.trainLevel();
        // 我的收藏
        var favor_btn = this.createRightButton('我的收藏', function () {
            var scene = new FavorScene();
            ViewManager.getInstance().changeScene(scene);
        });
        this.addChild(favor_btn);
    };
    TrainScene.prototype.trainLevel = function () {
        this.trainLevelGroup.$children.length && this.trainLevelGroup.removeChildren();
        this.userInfo = DataManager.getInstance().getUser();
        if (!this.userInfo) {
            this.timer = new egret.Timer(500, 5);
            this.timer.addEventListener(egret.TimerEvent.TIMER, this.timerFunc, this);
            this.timer.start();
        }
        else {
            this.initLevel();
        }
    };
    TrainScene.prototype.timerFunc = function () {
        if (!this.isInit) {
            this.userInfo = DataManager.getInstance().getUser();
            if (this.userInfo)
                this.initLevel();
        }
    };
    TrainScene.prototype.initLevel = function () {
        var _this = this;
        this.isInit = true;
        if (this.timer)
            this.timer.stop();
        var currentTrain = Math.ceil(this.userInfo.lv / 8) - 1;
        var grayFilter = Util.grayFilter();
        var unOpenId = 2;
        // 关卡
        this.bandges.forEach(function (item, i) {
            item.icon = "train_icon_0" + (i + 1) + "_png";
            var trainLevelItem = new TrainLevelItem(item, i);
            trainLevelItem.x = i % 2 == 0 ? 120 : _this.stage.stageWidth - trainLevelItem.width - 120;
            var y = (i > 1 ? 1 : 0) * (trainLevelItem.height + 40) + (i % 2 == 0 ? 40 : 140);
            var ratio = Util.getRatio();
            trainLevelItem.y = ratio > 0.6 ? y * 0.8 : y;
            trainLevelItem.filters = _this.userInfo.lv < item.start ? [grayFilter] : [];
            if (i > unOpenId)
                trainLevelItem.filters = [grayFilter];
            _this.trainLevelGroup.addChild(trainLevelItem);
            var lock = Util.createBitmapByName('lock_png');
            var lock_ratio = lock.width / lock.height;
            lock.width = ratio > 0.6 ? 47 * 0.8 : 47;
            lock.height = lock.width / lock_ratio;
            lock.x = (trainLevelItem.width - lock.width) / 2 + 4;
            lock.y = 115;
            lock.visible = i > currentTrain || i > unOpenId;
            trainLevelItem.addChild(lock);
            trainLevelItem.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
                if (i <= unOpenId) {
                    if (_this.userInfo.lv < item.start) {
                        var alert_1 = new AlertPanel("提示\n请先通关前面的关卡再来哦！");
                        _this.addChild(alert_1);
                    }
                    else {
                        DataManager.getInstance().setCurrentBandge(item);
                        var scene = new TrainLevelScene(item, i);
                        ViewManager.getInstance().changeScene(scene);
                    }
                }
                else {
                    var alert_2 = new AlertPanel(item.name + " \u5173\u5361\u8FD8\u672A\u4E0A\u7EBF\uFF0C\n\u656C\u8BF7\u671F\u5F85");
                    _this.addChild(alert_2);
                }
                Util.playMusic('model_select_mp3');
            }, _this);
            if (i < _this.bandges.length - 1) {
                var lineName = "train_line_0" + (i + 1) + "_png";
                var line = Util.createBitmapByName(lineName);
                line.height = ratio > 0.6 ? line.height * 0.8 : line.height;
                line.x = (_this.stage.stageWidth - line.width) / 2;
                var line_y = i == 0 ? 165 : i == 1 ? 280 : 520;
                line.y = ratio > 0.6 ? line_y * 0.85 : line_y;
                _this.trainLevelGroup.addChild(line);
            }
            if (i == currentTrain && i <= unOpenId) {
                egret.Tween.get(trainLevelItem, { loop: true })
                    .to({ y: trainLevelItem.y + 15 }, 2000)
                    .to({ y: trainLevelItem.y }, 2000);
            }
        });
    };
    TrainScene.prototype.onBack = function () {
        var scene = new IndexScene();
        ViewManager.getInstance().changeScene(scene);
    };
    TrainScene.prototype.updateScene = function () {
        this.trainLevel();
    };
    return TrainScene;
}(Scene));
__reflect(TrainScene.prototype, "TrainScene");
//# sourceMappingURL=TrainScene.js.map
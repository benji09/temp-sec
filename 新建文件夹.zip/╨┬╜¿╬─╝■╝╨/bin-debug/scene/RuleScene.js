var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RuleScene = (function (_super) {
    __extends(RuleScene, _super);
    function RuleScene(type) {
        var _this = _super.call(this) || this;
        _this.type = type;
        return _this;
    }
    RuleScene.prototype.init = function () {
        this.setBackground('bg_with_title_png');
        var stage = ViewManager.getInstance().stage;
        // 标题
        var title = new Title('游戏规则');
        this.addChild(title);
        var title_line = Util.createBitmapByName('rule_line_png');
        title_line.x = (stage.stageWidth - title_line.width) / 2;
        title_line.y = 375;
        this.addChild(title_line);
        var label = new egret.TextField();
        label.text = '规 则 说 明';
        label.width = stage.width;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.y = title_line.y - 12;
        label.size = 38;
        label.bold = true;
        this.addChild(label);
        var y = 10;
        var group = new eui.Group;
        // 答题闯关
        if (this.type != 'PK排行榜') {
            var trainGroup = this.trainGroup();
            trainGroup.y = y;
            y = trainGroup.height + 124;
            group.addChild(trainGroup);
        }
        // PK挑战
        if (this.type != '闯关排行榜') {
            var pkGroup = this.pkGroup();
            pkGroup.y = y;
            group.addChild(pkGroup);
        }
        var myScroller = new eui.Scroller();
        myScroller.width = stage.stageWidth;
        myScroller.height = stage.stageHeight - 450;
        myScroller.y = 450;
        myScroller.viewport = group;
        this.addChild(myScroller);
    };
    RuleScene.prototype.trainGroup = function () {
        var group = new eui.Group();
        var border = Util.createBitmapByName('rule_border_png');
        border.height = 1066;
        group.addChild(border);
        group.width = border.width;
        group.height = border.height;
        group.x = (this.stage.stageWidth - group.width) / 2;
        var label = new egret.TextField();
        label.text = '答 题 闯 关';
        label.width = 150;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.textColor = Config.COLOR_MAIN;
        label.size = 28;
        label.y = 5;
        group.addChild(label);
        var icon = Util.createBitmapByName('flag_png');
        icon.x = 60;
        icon.y = 105;
        group.addChild(icon);
        var text = new egret.TextField();
        text.textFlow = [
            { text: '闯关过程分为4大关，每大关卡各8' },
            { text: '\n小关，每小关通完' },
            { text: '\n4大关通关后系统将结合您的签到活' },
            { text: '\n跃度生成您的专属五维评分雷达图' },
        ];
        text.size = 24;
        text.x = 155;
        text.y = 80;
        text.lineSpacing = 15;
        group.addChild(text);
        var text2 = new egret.TextField();
        text2.text = '+20';
        text2.size = 40;
        text2.x = 350;
        text2.y = 110;
        text2.textColor = Config.COLOR_MAIN;
        group.addChild(text2);
        var text3 = new egret.TextField();
        text3.text = '分';
        text3.size = text.size;
        text3.x = text2.x + text2.textWidth + 5;
        text3.y = text2.y + 7;
        group.addChild(text3);
        var title_line = Util.createBitmapByName('rule_line2_png');
        title_line.x = 46;
        title_line.y = 270;
        group.addChild(title_line);
        var title = new egret.TextField;
        title.text = '雷达图说明';
        title.width = group.width;
        title.textAlign = egret.HorizontalAlign.CENTER;
        title.textColor = Config.COLOR_MAIN;
        title.y = 260;
        title.size = 26;
        group.addChild(title);
        var textGroup = new egret.TextField;
        textGroup.textFlow = [
            { text: '当有任一关卡未通关时，五维图显示为未解锁' },
            { text: '\n状态。' },
            { text: '\n当所有关卡都通关时，会解锁五维图，并根据' },
            { text: '\n每个关卡的答题正确率进行五维图的绘制。' },
            { text: '\n对应关系：' },
            { text: '\n疾速先锋 = 知' },
            { text: '\n品牌大咖 = 熟' },
            { text: '\n产研使者 = 懂' },
            { text: '\n情报专家 = 晓' },
            { text: '\n签 到 率 = 最' },
            { text: '\n签 到 率 = 总签到天数 / 首次登陆至今天数' },
        ];
        textGroup.lineSpacing = 14;
        textGroup.x = icon.x;
        textGroup.y = 310;
        textGroup.size = 24;
        group.addChild(textGroup);
        var title_line2 = Util.createBitmapByName('rule_line2_png');
        title_line2.x = 46;
        title_line2.y = 775;
        group.addChild(title_line2);
        var title2 = new egret.TextField;
        title2.text = '闯关排行榜';
        title2.width = group.width;
        title2.textAlign = egret.HorizontalAlign.CENTER;
        title2.textColor = Config.COLOR_MAIN;
        title2.y = 765;
        title2.size = 26;
        group.addChild(title2);
        var textGroup2 = new egret.TextField;
        textGroup2.textFlow = [
            { text: '1.排名由积分高低决定' },
            { text: '\n2.个人积分榜如积分相同，则根据抵达该积分' },
            { text: '\n时间先后顺序排序' },
            { text: '\n3.战队或大区排行榜如积分相同，则根据系统' },
            { text: '\n随机排序' },
        ];
        textGroup2.lineSpacing = 14;
        textGroup2.x = icon.x;
        textGroup2.y = 818;
        textGroup2.size = 24;
        group.addChild(textGroup2);
        return group;
    };
    RuleScene.prototype.pkGroup = function () {
        var group = new eui.Group();
        var border = Util.createBitmapByName('rule_border_png');
        border.height = 920;
        group.addChild(border);
        group.width = border.width;
        group.height = border.height + 50;
        group.x = (this.stage.stageWidth - group.width) / 2;
        var label = new egret.TextField();
        label.text = 'P K 挑 战';
        label.width = 150;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.textColor = Config.COLOR_MAIN;
        label.size = 28;
        label.y = 5;
        group.addChild(label);
        var icon = Util.createBitmapByName('fight_png');
        icon.x = 50;
        icon.y = 230;
        group.addChild(icon);
        var textGroup = new egret.TextField;
        textGroup.text = '此环节以胜率为决胜条件，PK时与对手进行同时答题完成挑战，将以答题正确率决定挑战结果，分为胜利、平局和失败。参与PK挑战时系统会为您自动匹配对手，系统将为您优选真实选手。若无匹配人选，我们会安排v宝机器人（机器人也由系统随机分配，为V准宝、V敢宝、V韧宝）应邀您的对战。机器人的答题正确率为70%，每道题目答题时间为随机7-12s。每道题的答题时间为15秒，15秒后未作答，将自动进入下一题，未作答的题目视为答错。请做好准备吧!';
        textGroup.lineSpacing = 15;
        textGroup.x = 155;
        textGroup.y = 75;
        textGroup.width = 412;
        textGroup.size = 24;
        group.addChild(textGroup);
        var title_line = Util.createBitmapByName('rule_line2_png');
        title_line.x = 46;
        title_line.y = 608;
        group.addChild(title_line);
        var title = new egret.TextField;
        title.text = 'PK排行榜';
        title.width = group.width;
        title.textAlign = egret.HorizontalAlign.CENTER;
        title.textColor = Config.COLOR_MAIN;
        title.y = 600;
        title.size = 26;
        group.addChild(title);
        var textGroup2 = new egret.TextField;
        textGroup2.textFlow = [
            { text: '1.排名由选手胜率决定' },
            { text: '\n2.如胜率相同，则根据选手参与挑战的场次排序，' },
            { text: '\n多则优先' },
            { text: '\n3.个人、战队和大区排行榜均适用以上规则，如' },
            { text: '\n遇场次相同则根据系统随机排序' },
            { text: '\n4.排行榜以周为单位计算，只显示当周胜率' },
        ];
        textGroup2.lineSpacing = textGroup.lineSpacing;
        textGroup2.x = icon.x;
        textGroup2.y = 650;
        textGroup2.size = textGroup.size;
        group.addChild(textGroup2);
        return group;
    };
    return RuleScene;
}(Scene));
__reflect(RuleScene.prototype, "RuleScene");
//# sourceMappingURL=RuleScene.js.map
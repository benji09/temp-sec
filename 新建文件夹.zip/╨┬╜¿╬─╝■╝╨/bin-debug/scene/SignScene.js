var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var SignScene = (function (_super) {
    __extends(SignScene, _super);
    function SignScene(signData) {
        var _this = _super.call(this) || this;
        _this.MONTH = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVERMBER', 'DECEMBER'];
        _this.WEEK = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
        _this.signData = signData.data;
        return _this;
    }
    SignScene.prototype.init = function () {
        var _this = this;
        this.close_btn = '关闭';
        var bg = Util.createBitmapByName('sign_bg_png');
        bg.width = this.stage.stageWidth;
        this.addChild(bg);
        var signed = this.signData['signStr'].split('');
        var signedData = [];
        for (var i = 0; i < signed.length; i++) {
            if (signed[i] > 0) {
                signedData.push(i + 1);
            }
        }
        this.signed = signedData;
        this.createCalendar();
        // 更新用户数据
        Http.getInstance().post(Url.HTTP_USER_BASE_INFO, '', function (info) {
            DataManager.getInstance().updateUserInfo(info.data);
        });
        // 通知后台签到成功
        Http.getInstance().post(Url.HTTP_SIGN, {}, null);
        var time = 3;
        var timer_bg = Util.createBitmapByName('timer_bg_png');
        timer_bg.x = this.stage.stageWidth - timer_bg.width - 70;
        timer_bg.y = 20;
        timer_bg.blendMode = egret.BlendMode.ADD;
        this.addChild(timer_bg);
        var timer_num = new egret.TextField;
        timer_num.text = time + '';
        timer_num.x = timer_bg.x;
        timer_num.y = timer_bg.y;
        timer_num.width = timer_bg.width;
        timer_num.height = 94;
        timer_num.textAlign = egret.HorizontalAlign.CENTER;
        timer_num.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.addChild(timer_num);
        this.timer = setInterval(function () {
            if (time <= 1) {
                _this.onBack();
            }
            time--;
            timer_num.text = time + '';
        }, 1000);
    };
    SignScene.prototype.onBack = function () {
        var home = new IndexScene();
        ViewManager.getInstance().changeScene(home);
    };
    SignScene.prototype.release = function () {
        this.timer && clearInterval(this.timer);
    };
    // 创建日历
    SignScene.prototype.createCalendar = function () {
        var title = new egret.TextField;
        title.text = '每 日 签 到';
        title.x = 380;
        title.y = 190;
        title.size = 52;
        this.addChild(title);
        var curDate = new Date();
        var month = new egret.TextField;
        month.text = this.MONTH[curDate.getMonth()];
        month.x = 220;
        month.y = 386;
        month.size = 44;
        month.textColor = Config.COLOR_MAIN;
        month.bold = true;
        this.addChild(month);
        var year = new egret.TextField;
        year.text = curDate.getFullYear().toString();
        year.x = month.x + month.textWidth + 10;
        year.y = month.y;
        year.size = month.size;
        this.addChild(year);
        var group = new eui.Group();
        group.x = 155;
        group.y = 470;
        this.addChild(group);
        var width = 64; // 每个日期的宽度
        var left = 0; // 最初的左边距
        // 创建星期头部
        for (var i = 0; i < this.WEEK.length; i++) {
            var label = new egret.TextField();
            label.text = this.WEEK[i];
            label.x = i * width;
            label.width = width;
            label.textAlign = egret.HorizontalAlign.CENTER;
            label.size = 20;
            if (i >= 5) {
                label.size = 26;
                label.textColor = 0x80F5E8;
                label.bold = true;
                label.y = -3;
            }
            group.addChild(label);
        }
        var height = 88; // 每个数字的高度
        // 当前日期
        var currentDay = curDate.getDate();
        // 获取这个月有多少天，将月份下移到下一个月份，同时将日期设置为0；由于Date里的日期是1~31，所以Date对象自动跳转到上一个月的最后一天；getDate（）获取天数即可。
        curDate.setMonth(curDate.getMonth() + 1);
        curDate.setDate(0);
        var days = curDate.getDate();
        // 获取第一天星期几
        curDate.setDate(1);
        // 返回的是0-6，设置0为7
        var week1 = curDate.getDay() == 0 ? 7 : curDate.getDay();
        var max = week1 + days;
        for (var i = 0; i < max; i++) {
            if (i >= week1) {
                var day = i - week1 + 1;
                var sign = 0;
                if (this.signed.indexOf(day) > -1) {
                    sign = 1;
                }
                if (currentDay == day) {
                    sign = 2;
                }
                var singItem = new SignItem(day, sign);
                singItem.x = left + ((i - 1) % 7) * width;
                singItem.y = Math.ceil(i / 7) * height - 70;
                group.addChild(singItem);
            }
        }
        this.createSignText();
    };
    SignScene.prototype.createSignText = function () {
        var count = this.signData.uncasing_sign_count || 0;
        var text = new egret.TextField();
        text.textFlow = [
            { text: '您已连续签到 ' },
            { text: '      ' + count + '      ', style: { underline: true } },
            { text: ' 天' }
        ];
        text.x = 320;
        text.y = 1055;
        text.size = 22;
        this.addChild(text);
    };
    return SignScene;
}(Scene));
__reflect(SignScene.prototype, "SignScene");
var SignItem = (function (_super) {
    __extends(SignItem, _super);
    function SignItem(text, sign) {
        if (sign === void 0) { sign = 0; }
        var _this = _super.call(this) || this;
        _this.W = 88;
        _this.H = 88;
        _this.sign = 0;
        _this.text = text;
        _this.sign = sign;
        _this.width = _this.W;
        _this.height = _this.H;
        _this.init();
        return _this;
    }
    SignItem.prototype.init = function () {
        if (this.sign > 0) {
            var icon = Util.createBitmapByName('sign_mark_png');
            icon.x = (this.W - icon.width) / 2;
            icon.y = 20;
            this.addChild(icon);
            //当前签到中
            if (this.sign == 2) {
                icon.alpha = 0;
                egret.Tween.get(icon).to({ alpha: 1 }, 3000, egret.Ease.backInOut);
            }
        }
        var label = new egret.TextField();
        label.text = this.text;
        label.width = this.W;
        label.height = this.H;
        label.size = 28;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.addChild(label);
    };
    return SignItem;
}(egret.DisplayObjectContainer));
__reflect(SignItem.prototype, "SignItem");
//# sourceMappingURL=SignScene.js.map
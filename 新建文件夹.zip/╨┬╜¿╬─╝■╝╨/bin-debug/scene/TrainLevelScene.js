var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var TrainLevelScene = (function (_super) {
    __extends(TrainLevelScene, _super);
    function TrainLevelScene(bandge, index) {
        var _this = _super.call(this) || this;
        _this.bandge = bandge;
        _this.index = index;
        return _this;
    }
    TrainLevelScene.prototype.init = function () {
        this.setBackground('level_bg_png');
        this.name = 'trainLevelScene';
        var stage = ViewManager.getInstance().stage;
        // 标题
        var title = Util.createBitmapByName('level_title_png');
        title.x = (stage.stageWidth - title.width) / 2 + 20;
        title.y = 40;
        title.blendMode = egret.BlendMode.ADD;
        this.addChild(title);
        var textArr = ['疾病篇', '竞品篇', '产品篇', '品牌篇'];
        var title_text = new egret.TextField;
        title_text.text = textArr[this.index];
        title_text.x = 480;
        title_text.y = 268;
        title_text.size = 28;
        this.addChild(title_text);
        var icon = Util.createBitmapByName("train_icon_0" + (this.index + 1) + "_png");
        var ratio = icon.width / icon.height;
        icon.width = 200;
        icon.height = icon.width / ratio;
        icon.x = (stage.stageWidth - icon.width) / 2;
        icon.y = stage.stageHeight - 960;
        this.addChild(icon);
        var icon_text = new egret.TextField;
        icon_text.text = this.bandge.name;
        icon_text.width = stage.stageWidth;
        icon_text.textAlign = egret.HorizontalAlign.CENTER;
        icon_text.y = icon.y + icon.height;
        this.addChild(icon_text);
        var levelGroup = new eui.Group;
        levelGroup.width = 600;
        levelGroup.height = 600;
        levelGroup.x = (stage.stageWidth - levelGroup.width) / 2;
        levelGroup.y = stage.stageHeight - levelGroup.height - 160;
        this.levelGroup = levelGroup;
        this.addChild(this.levelGroup);
        this.level();
    };
    TrainLevelScene.prototype.level = function () {
        var _this = this;
        this.levelGroup.$children.length && this.levelGroup.removeChildren();
        var currentLevel = DataManager.getInstance().getUser().lv;
        var distance = 70;
        var position = [
            { x: 220 - distance, y: 1050 - this.levelGroup.height },
            { x: 500 - distance, y: 1000 - this.levelGroup.height },
            { x: 70 - distance, y: 855 - this.levelGroup.height },
            { x: 507 - distance, y: 850 - this.levelGroup.height },
            { x: 360 - distance, y: 820 - this.levelGroup.height },
            { x: 280 - distance, y: 700 - this.levelGroup.height },
            { x: 440 - distance, y: 680 - this.levelGroup.height },
            { x: 160 - distance, y: 670 - this.levelGroup.height },
        ];
        var grayFilter = Util.grayFilter();
        var flag = true;
        var _loop_1 = function (i) {
            var level = Util.createBitmapByName("level_panel_pass_0" + i + "_png");
            // 每关的信息
            var level_data = this_1.bandge.levels[i - 1];
            // 判断是否通关
            if (currentLevel < level_data.key) {
                // 未解锁
                level = Util.createBitmapByName("level_panel_lock_0" + i + "_png");
                level.filters = [grayFilter];
            }
            else if (currentLevel == level_data.key) {
                // 当前关卡
                level = Util.createBitmapByName("level_panel_0" + i + "_png");
            }
            level.x = position[i - 1].x;
            level.y = position[i - 1].y;
            level.touchEnabled = true;
            level.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
                if (!flag)
                    return;
                flag = false;
                //请求数据
                Util.playMusic('model_select_mp3');
                if (currentLevel >= level_data.key) {
                    Http.getInstance().post(Url.HTTP_TRAIN_START, { type: 1, tid: level_data.levelid }, function (json) {
                        if (json.data.questions.length > 0) {
                            var answer = new Answers();
                            answer.lifecycleId = json.data.lifecycleId;
                            answer.questions = json.data.questions;
                            var scene = new AnswerScene(answer, AnswerType.TRAIN, level_data);
                            ViewManager.getInstance().changeScene(scene);
                        }
                        else {
                            var alert_1 = new AlertPanel("提示\n题库未设置");
                            _this.addChild(alert_1);
                            flag = true;
                        }
                    });
                }
                else {
                    var alert_2 = new AlertPanel("提示\n请先通关前面的关卡后再来哦");
                    _this.addChild(alert_2);
                    flag = true;
                }
            }, this_1);
            this_1.levelGroup.addChild(level);
        };
        var this_1 = this;
        for (var i = this.bandge.levels.length; i > 0; i--) {
            _loop_1(i);
        }
    };
    TrainLevelScene.prototype.updateScene = function () {
        this.level();
    };
    return TrainLevelScene;
}(Scene));
__reflect(TrainLevelScene.prototype, "TrainLevelScene");
//# sourceMappingURL=TrainLevelScene.js.map
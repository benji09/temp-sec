var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var UserScene = (function (_super) {
    __extends(UserScene, _super);
    function UserScene() {
        return _super.call(this) || this;
    }
    UserScene.prototype.init = function () {
        var _this = this;
        Util.setTitle('个人中心');
        this.close_btn = '首页';
        this.userInfo = DataManager.getInstance().getUser();
        var bg = Util.createBitmapByName('bg_png');
        bg.width = this.stage.stageWidth;
        bg.height = this.stage.stageHeight;
        this.addChild(bg);
        var shareGroup = new eui.Group;
        this.addChild(shareGroup);
        var title_bg = Util.createBitmapByName('user_title_png');
        title_bg.x = (this.stage.stageWidth - title_bg.width) / 2;
        title_bg.y = 118;
        shareGroup.addChild(title_bg);
        // 标题
        var title = new Title('个人中心');
        shareGroup.addChild(title);
        var userGroup = new eui.Group;
        // 用户信息
        var infoGroup = this.infoGroup();
        infoGroup.y = 30;
        userGroup.addChild(infoGroup);
        // 维度图
        var radarGroup = this.radarGroup();
        radarGroup.y = 270;
        userGroup.addChild(radarGroup);
        // pk
        var pkGroup = this.pkGroup();
        pkGroup.y = 600;
        userGroup.addChild(pkGroup);
        var myScroller = new eui.Scroller();
        myScroller.width = this.stage.stageWidth;
        myScroller.height = this.stage.stageHeight - 450;
        myScroller.y = 290;
        myScroller.viewport = userGroup;
        shareGroup.addChild(myScroller);
        // 保存图片
        var saveBtn = new Button('icon_save_png', '保存图片', function () {
            var alert = new AlertPanel("提示\n请自行截图保存图片！");
            _this.addChild(alert);
        });
        saveBtn.x = 74;
        saveBtn.y = this.stage.stageHeight - 120;
        this.addChild(saveBtn);
        // 分享
        var shareBtn = new Button('icon_share_png', '分享', function () {
            var tips = new SharePanel();
            _this.addChild(tips);
        });
        shareBtn.x = this.stage.stageWidth - shareBtn.width - 74;
        shareBtn.y = saveBtn.y;
        this.addChild(shareBtn);
        // 积分规则
        var ruleBtn = this.createRightButton('游戏规则', function () {
            var scene = new RuleScene();
            ViewManager.getInstance().changeScene(scene);
        });
        this.addChild(ruleBtn);
        var lv = Math.floor((this.userInfo.lv - 1) / 8);
        // 注册微信分享
        Util.registerShare(shareGroup, lv, this.userInfo.nickName);
    };
    UserScene.prototype.infoGroup = function () {
        var group = new eui.Group;
        var info_bg = Util.createBitmapByName('info_bg_png');
        info_bg.x = (this.stage.stageWidth - info_bg.width) / 2;
        group.addChild(info_bg);
        // 头像边框
        var avatar_border = Util.createBitmapByName('avatar_border_png');
        avatar_border.x = 62;
        avatar_border.y = -21;
        group.addChild(avatar_border);
        // 头像
        var avatar = Util.setUserImg(this.userInfo.avatar, 130);
        avatar.x = 78;
        avatar.y = -5;
        group.addChild(avatar);
        var name_label = new egret.TextField;
        name_label.text = this.userInfo.nickName;
        name_label.x = 260;
        name_label.y = 37;
        name_label.size = 40;
        name_label.bold = true;
        name_label.textColor = 0x39f4e6;
        group.addChild(name_label);
        var score = new egret.TextField;
        score.text = "\u603B\u79EF\u5206\uFF1A" + this.userInfo.score;
        score.x = name_label.x;
        score.y = 103;
        group.addChild(score);
        var score_line = Util.createBitmapByName('line_png');
        score_line.width = 159;
        score_line.x = 250;
        score_line.y = 141;
        group.addChild(score_line);
        var rank = new egret.TextField;
        rank.text = "\u5168\u56FD\u6392\u540D\uFF1A" + this.userInfo.personRank;
        rank.x = 440;
        rank.y = score.y;
        score.size = rank.size = 26;
        group.addChild(rank);
        var rank_line = Util.createBitmapByName('line_png');
        rank_line.width = 187;
        rank_line.x = 435;
        rank_line.y = score_line.y;
        group.addChild(rank_line);
        return group;
    };
    UserScene.prototype.radarGroup = function () {
        var _this = this;
        var group = new eui.Group;
        var border = Util.createBitmapByName('border_png');
        border.x = (this.stage.stageWidth - border.width) / 2;
        border.height = 294;
        group.addChild(border);
        var x = 128;
        var y = 42;
        this.userInfo.attrInfo.forEach(function (item, index) {
            var lv = _this.userInfo.lv - 1 - index * 8;
            if (lv < 0) {
                lv = 0;
            }
            else if (lv > 8) {
                lv = 8;
            }
            item.lv = lv;
            if (index == 4)
                return;
            var process = _this.process(item, index);
            process.x = x;
            process.y = y;
            group.addChild(process);
            y += 44;
        });
        var score = new egret.TextField;
        score.text = "\u95EF\u5173\u79EF\u5206\uFF1A" + this.userInfo.trainScore;
        score.x = 175;
        score.y = 227;
        score.size = 16;
        group.addChild(score);
        var line = Util.createBitmapByName('line_png');
        line.x = score.x;
        line.y = 250;
        line.width = 172;
        group.addChild(line);
        // 雷达图
        var radar = this.radar();
        radar.x = 460;
        radar.y = 60;
        group.addChild(radar);
        return group;
    };
    UserScene.prototype.process = function (item, index) {
        var group = new eui.Group;
        var icon = Util.createBitmapByName("train_icon_0" + (index + 1) + "_png");
        icon.width = 44;
        icon.height = 44;
        group.addChild(icon);
        var process = Util.createBitmapByName("process_" + item.lv + "_png");
        process.x = 50;
        process.y = 10;
        process.blendMode = egret.BlendMode.ADD;
        group.addChild(process);
        var title = new egret.TextField;
        title.text = item.name;
        title.x = process.x + process.width + 10;
        title.y = process.y + 5;
        title.size = 16;
        group.addChild(title);
        return group;
    };
    UserScene.prototype.radar = function () {
        var group = new eui.Group;
        // 雷达图
        var radar_bg = Util.createBitmapByName('radar_bg_png');
        radar_bg.blendMode = egret.BlendMode.ADD;
        group.addChild(radar_bg);
        var radar = new Radar(this.userInfo.attrInfo, 130, 125);
        radar.rotation = -18;
        radar.x = -2;
        radar.y = 43;
        group.addChild(radar);
        var lock = Util.createBitmapByName('lock_png');
        var lock_ratio = lock.width / lock.height;
        lock.width = 30;
        lock.height = lock.width / lock_ratio;
        lock.x = 65;
        lock.y = 60;
        lock.visible = this.userInfo.lv < 32;
        group.addChild(lock);
        var arr = [
            { name: '知', attr: '疾病', x: 74, y: -30 },
            { name: '熟', attr: '品牌', x: 10, y: 154 },
            { name: '懂', attr: '产品', x: 136, y: 154 },
            { name: '晓', attr: '竞品', x: 172, y: 46 },
            { name: '最', attr: '活跃', x: -25, y: 46 },
        ];
        this.userInfo.attrInfo.forEach(function (item, index) {
            var text = new egret.TextField;
            text.textFlow = [
                { text: "" + arr[index].name, style: { size: 18 } },
                { text: "\n" + arr[index].attr, style: { size: 10 } }
            ];
            text.x = arr[index].x;
            text.y = arr[index].y;
            group.addChild(text);
        });
        return group;
    };
    UserScene.prototype.pkGroup = function () {
        var group = new eui.Group;
        var border = Util.createBitmapByName('border_png');
        border.x = (this.stage.stageWidth - border.width) / 2;
        border.height = 190;
        group.addChild(border);
        group.height = border.height;
        var fight = Util.createBitmapByName('fight_png');
        fight.x = 130;
        fight.y = 56;
        group.addChild(fight);
        var text = new egret.TextField;
        text.textFlow = [
            { text: "\u672C\u5468\u53C2\u8D5B\u573A\u6B21\uFF1A" + this.userInfo.pkCount },
            { text: "\n\u672C\u5468\u80DC\u7387\uFF1A" + (this.userInfo.pkRate ? this.userInfo.pkRate : '0%') },
        ];
        text.x = 256;
        text.y = 55;
        text.size = 20;
        text.lineSpacing = 40;
        group.addChild(text);
        var line = Util.createBitmapByName('line_png');
        line.x = 254;
        line.y = 90;
        line.width = 375;
        group.addChild(line);
        return group;
    };
    UserScene.prototype.onBack = function () {
        var home = new IndexScene();
        ViewManager.getInstance().changeScene(home);
    };
    return UserScene;
}(Scene));
__reflect(UserScene.prototype, "UserScene");
//# sourceMappingURL=UserScene.js.map
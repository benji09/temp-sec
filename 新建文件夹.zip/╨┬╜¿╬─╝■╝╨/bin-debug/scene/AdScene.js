var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var AdScene = (function (_super) {
    __extends(AdScene, _super);
    function AdScene(isNeedSign, signData) {
        var _this = _super.call(this) || this;
        _this.isNeedSign = isNeedSign;
        _this.signData = signData;
        return _this;
    }
    AdScene.prototype.init = function () {
        this.close_btn = '';
        var bg = Util.createBitmapByName('ad_bg_png');
        bg.width = this.stage.stageWidth;
        this.addChild(bg);
        var stage = ViewManager.getInstance().stage;
        var textGroup = new eui.Group;
        textGroup.y = stage.stageHeight - 100;
        this.addChild(textGroup);
        var arrow = Util.createBitmapByName('ad_arrow_png');
        arrow.x = (stage.stageWidth - arrow.width) / 2;
        textGroup.addChild(arrow);
        var ad_text = new egret.TextField;
        ad_text.text = '大有可V 等你而来';
        ad_text.size = 40;
        ad_text.x = (stage.stageWidth - ad_text.width) / 2;
        ad_text.y = -8;
        textGroup.addChild(ad_text);
        // 初始化游戏数据
        var scene = this.isNeedSign ? new SignScene(this.signData) : new IndexScene();
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            Util.playMusic('model_select_mp3');
            ViewManager.getInstance().changeScene(scene);
        }, this);
        var url = window.location.href.split('#')[0];
        Http.getInstance().post(Url.HTTP_JSSDK_CONFIG, { showurl: url }, function (json) {
            configSdk(json.data);
            setTimeout(function () {
                Util.registerShare(null, ShareType.NORMAL);
            }, 1000);
        });
    };
    return AdScene;
}(Scene));
__reflect(AdScene.prototype, "AdScene");
//# sourceMappingURL=AdScene.js.map
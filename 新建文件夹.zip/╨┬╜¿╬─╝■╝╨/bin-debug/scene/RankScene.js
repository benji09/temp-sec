var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RankScene = (function (_super) {
    __extends(RankScene, _super);
    function RankScene(label) {
        if (label === void 0) { label = '闯关排行榜'; }
        var _this = _super.call(this) || this;
        _this.currentIdx = 1;
        _this.personRank = [];
        _this.teamRank = [];
        _this.areaRank = [];
        _this.personPage = 1;
        _this.teamPage = 1;
        _this.size = 50;
        _this.topThree = new eui.Group;
        _this.otherGroup = new eui.Group;
        _this.topThreeUserData = [
            { w: 146, y: 194 },
            { w: 120, y: 295 },
            { w: 120, y: 295 },
        ];
        _this.label = label;
        if (_this.label === '闯关排行榜') {
            _this.personal_prot = Url.HTTP_PERSON_RANK_LIST;
            _this.team_prot = Url.HTTP_TEAM_RANK_LIST;
            _this.area_prot = Url.HTTP_PERSON_RANK_AREA;
        }
        else {
            _this.personal_prot = Url.HTTP_PERSON_PK_RANK_LIST;
            _this.team_prot = Url.HTTP_TEAM_PK_RANK_LIST;
            _this.area_prot = Url.HTTP_PERSON_PK_RANK_AREA;
        }
        return _this;
    }
    RankScene.prototype.init = function () {
        var _this = this;
        this.setBackground('rank_bg_png');
        Util.setTitle('排行榜');
        if (this.label === 'PK排行榜') {
            var categoryTitle = new egret.TextField;
            categoryTitle.text = this.label;
            categoryTitle.x = (this.stage.stageWidth - categoryTitle.width) / 2 - 20;
            categoryTitle.y = 35;
            categoryTitle.textColor = Config.COLOR_MAIN;
            categoryTitle.size = 40;
            this.addChild(categoryTitle);
        }
        this.initTitle();
        // 请求个人数据
        this.getRank(this.personal_prot, this.personPage, this.size)
            .then(function (data) {
            _this.personRank = data.list;
            _this.personPage = data.page;
            _this.initRanker(_this.currentIdx);
            _this.addChildAt(_this.topThree, 1);
        });
        // 请求战队数据
        this.getRank(this.team_prot, this.teamPage, this.size)
            .then(function (data) {
            _this.teamRank = data.list;
            _this.teamPage = data.page;
        });
        // 请求大区数据
        this.getRank(this.area_prot, 1, this.size)
            .then(function (data) {
            _this.areaRank = data.list;
        });
        // 积分规则
        var ruleText = this.label === '闯关排行榜' ? '闯关' : 'PK';
        var ruleBtn = this.createRightButton(ruleText + '游戏规则', function () {
            var scene = new RuleScene(_this.label);
            ViewManager.getInstance().changeScene(scene);
        });
        this.addChild(ruleBtn);
    };
    RankScene.prototype.getRank = function (url, page, size) {
        return new Promise(function (resolve) {
            Http.getInstance().post(url, { page: page, size: size }, function (json) {
                page = json.data.length == size ? page + 1 : -1;
                resolve({ list: json.data, page: page });
            });
        });
    };
    RankScene.prototype.initTitle = function () {
        var _this = this;
        var rank_variety = [
            { name: '个人排行榜', y: 0 },
            { name: '战队排行榜', y: 0 },
            { name: '大区排行榜', y: 450 },
        ];
        var titleArr = [];
        var x = 32;
        rank_variety.forEach(function (item, i) {
            var title = new RankTitle(item.name);
            title.x = x;
            title.y = 120;
            i != _this.currentIdx - 1 && title.hideFlag();
            _this.addChild(title);
            titleArr.push(title);
            x += title.width;
            title.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
                titleArr.forEach(function (t) { return t.hideFlag(); });
                title.showFlag();
                _this.currentIdx = i + 1;
                _this.initRanker(_this.currentIdx);
                _this.topThree.y = item.y;
                Util.playMusic('model_select_mp3');
            }, _this);
        });
    };
    RankScene.prototype.initRanker = function (type) {
        var _this = this;
        // 切换排名先删除清空子元素
        this.topThree.$children.length > 0 && this.topThree.removeChildren();
        this.otherGroup.$children.length > 0 && this.otherGroup.removeChildren();
        this.getMoreArrow && this.removeChild(this.getMoreArrow);
        this.scrollView && (this.scrollView.viewport.scrollV = 0, this.scrollView.stopAnimation());
        if (type == 3) {
            var rank_area_arrow = Util.createBitmapByName('rank_area_arrow_png');
            rank_area_arrow.x = (this.stage.stageWidth - rank_area_arrow.width) / 2;
            rank_area_arrow.y = -130;
            rank_area_arrow.blendMode = egret.BlendMode.ADD;
            this.topThree.addChild(rank_area_arrow);
        }
        var rankDatas = type == 1 ? this.personRank : type == 2 ? this.teamRank : this.areaRank;
        rankDatas.forEach(function (item, idx) {
            if (idx > 2)
                return;
            var topThreeUser = _this.topThreeUser(item, _this.topThreeUserData[idx].w, type);
            topThreeUser && (topThreeUser.y = _this.topThreeUserData[idx].y);
            topThreeUser.x = idx == 0 ? (_this.stage.stageWidth - topThreeUser.width) / 2 : idx == 1 ? 100 : _this.stage.stageWidth - topThreeUser.width - 100;
            _this.topThree.addChild(topThreeUser);
        });
        var platform = Util.createBitmapByName('rank_platform_png');
        platform.x = (this.stage.stageWidth - platform.width) / 2;
        platform.y = 350;
        this.topThree.addChild(platform);
        var platform_line = Util.createBitmapByName('rank_platform_line_png');
        platform_line.x = (this.stage.stageWidth - platform_line.width) / 2;
        platform_line.y = platform.y + platform.height - platform_line.height / 2 - 52;
        platform_line.blendMode = egret.BlendMode.ADD;
        this.topThree.addChild(platform_line);
        var myScroller = new eui.Scroller();
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = this.stage.stageWidth;
        myScroller.height = this.stage.stageHeight - 734;
        myScroller.y = platform_line.y + platform_line.height;
        //设置viewport
        myScroller.viewport = this.otherGroup;
        this.addChild(myScroller);
        this.scrollView = myScroller;
        // 上滑加载更多
        myScroller.addEventListener(eui.UIEvent.CHANGE_END, function () {
            if (myScroller.viewport.scrollV + myScroller.height >= myScroller.viewport.contentHeight) {
                _this.loadMoreData();
            }
        }, this);
        type != 3 && this.addItem(rankDatas);
        this.getMoreArrow = Util.createBitmapByName('rank_arrow_png');
        this.getMoreArrow.x = (this.stage.stageWidth - this.getMoreArrow.width) / 2;
        this.getMoreArrow.y = myScroller.height + myScroller.y;
        this.getMoreArrow.visible = rankDatas.length > 8;
        this.addChild(this.getMoreArrow);
    };
    RankScene.prototype.topThreeUser = function (userInfo, w, type) {
        if (!userInfo)
            return;
        var group = new eui.Group;
        group.width = w;
        if (type != 3) {
            var avatarGroup = this.avatarGroup(userInfo, w);
            group.addChild(avatarGroup);
        }
        else {
            var avatar = Util.createBitmapByName(userInfo.shortname + "_png");
            var avatar_ratio = avatar.width / avatar.height;
            avatar.width = w;
            avatar.height = w / avatar_ratio;
            avatar.y = -60;
            group.addChild(avatar);
        }
        try {
            var user = new egret.TextField;
            var name_1 = userInfo.userName || userInfo.teamName || '';
            var category = this.label === '闯关排行榜' ? '积分' : '胜率';
            var percent = this.label === '闯关排行榜' ? '' : '%';
            user.text = Util.getStrByWith(name_1, w, 24) + ("\n" + category + ":" + (parseFloat(userInfo.score.toFixed(2)) + percent));
            user.width = w + 60;
            user.x = -30;
            user.y = w + 15;
            user.lineSpacing = 10;
            user.size = 24;
            user.textAlign = egret.HorizontalAlign.CENTER;
            group.addChild(user);
        }
        catch (error) {
        }
        return group;
    };
    RankScene.prototype.otherUser = function (userInfo) {
        var group = new eui.Group;
        var item_bg = Util.createBitmapByName('rank_item_bg_png');
        item_bg.blendMode = egret.BlendMode.ADD;
        item_bg.visible = userInfo.serialNo % 2 == 1;
        group.addChild(item_bg);
        group.width = item_bg.width;
        group.height = item_bg.height;
        var number = new egret.TextField;
        number.text = userInfo.serialNo;
        number.x = 90;
        number.width = 100;
        number.height = group.height;
        number.textAlign = egret.HorizontalAlign.CENTER;
        number.verticalAlign = egret.VerticalAlign.MIDDLE;
        number.size = 50;
        group.addChild(number);
        var avatar = this.avatarGroup(userInfo, 88);
        avatar.x = 190;
        avatar.y = 15;
        group.addChild(avatar);
        var username = new egret.TextField;
        username.text = userInfo.userName || userInfo.teamName;
        username.x = 300;
        username.width = 200;
        username.height = group.height;
        username.verticalAlign = egret.VerticalAlign.MIDDLE;
        username.size = 24;
        group.addChild(username);
        var icon = Util.createBitmapByName(this.label === '闯关排行榜' ? 'rank_icon_png' : 'rank_pk_icon_png');
        icon.x = 510;
        icon.y = 40;
        group.addChild(icon);
        try {
            var scoreLabel = new egret.TextField;
            var percent = this.label === '闯关排行榜' ? '' : '%';
            scoreLabel.text = parseFloat(userInfo.score.toFixed(2)) + percent;
            scoreLabel.x = 567;
            scoreLabel.height = group.height;
            scoreLabel.verticalAlign = egret.VerticalAlign.MIDDLE;
            scoreLabel.size = 30;
            group.addChild(scoreLabel);
        }
        catch (error) {
        }
        return group;
    };
    RankScene.prototype.avatarGroup = function (userInfo, w) {
        var group = new eui.Group;
        group.width = group.height = w;
        var avatar_border = Util.createBitmapByName('avatar_border_png');
        avatar_border.width = avatar_border.height = w;
        group.addChild(avatar_border);
        var avatar = Util.setUserImg(userInfo.avatar, w - 32);
        if (avatar) {
            avatar.x = avatar.y = 16;
            group.addChild(avatar);
        }
        return group;
    };
    RankScene.prototype.addItem = function (data, y) {
        var _this = this;
        if (y === void 0) { y = 0; }
        data.forEach(function (item) {
            if (item.serialNo < 4)
                return;
            var otherUser = _this.otherUser(item);
            otherUser.y = y;
            _this.otherGroup.addChild(otherUser);
            y += otherUser.height;
        });
    };
    RankScene.prototype.loadMoreData = function () {
        var _this = this;
        if (this.currentIdx == 1 && this.personPage > 0) {
            this.getRank(this.personal_prot, this.personPage, this.size).then(function (data) {
                if (_this.personPage == data.page)
                    return;
                _this.personRank = _this.personRank.concat(data.list);
                _this.personPage = data.page;
                _this.addItem(data.list, _this.scrollView.viewport.contentHeight);
            });
        }
        if (this.currentIdx == 2 && this.teamPage > 0) {
            this.getRank(this.team_prot, this.teamPage, this.size).then(function (data) {
                if (_this.teamPage == data.page)
                    return;
                _this.teamRank = _this.teamRank.concat(data.list);
                _this.teamPage = data.page;
                _this.addItem(data.list, _this.scrollView.viewport.contentHeight);
            });
        }
    };
    return RankScene;
}(Scene));
__reflect(RankScene.prototype, "RankScene");
//# sourceMappingURL=RankScene.js.map
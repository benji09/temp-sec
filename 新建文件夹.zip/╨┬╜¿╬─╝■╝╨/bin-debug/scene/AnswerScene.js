var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/* 答题界面 */
var AnswerScene = (function (_super) {
    __extends(AnswerScene, _super);
    function AnswerScene(answers, type, levelData) {
        if (type === void 0) { type = AnswerType.TRAIN; }
        if (levelData === void 0) { levelData = null; }
        var _this = _super.call(this) || this;
        _this.curIdx = 1;
        _this.isNext = false;
        _this.ableClick = true;
        _this.answers = answers;
        _this.type = type;
        _this.levelData = levelData;
        return _this;
    }
    AnswerScene.prototype.init = function () {
        var _this = this;
        this.setBackground();
        this.start = +new Date();
        var stage = ViewManager.getInstance().stage;
        if (this.type == AnswerType.TRAIN) {
            var trainTitle = this.trainTitle();
            this.addChild(trainTitle);
            // 进度条
            var pBar = new ProcessBar(this.answers.questions.length, this.curIdx);
            pBar.x = 158;
            pBar.y = 100;
            this.addChild(pBar);
            this._progress = pBar;
        }
        else if (this.type == AnswerType.FAVOR) {
            var favor_line = Util.createBitmapByName('rule_line_png');
            favor_line.width = 560;
            favor_line.x = (stage.stageWidth - favor_line.width) / 2;
            favor_line.y = 156;
            this.addChild(favor_line);
            var favorTitle = new egret.TextField;
            favorTitle.text = this.levelData.name;
            favorTitle.size = 40;
            favorTitle.width = stage.stageWidth;
            favorTitle.textAlign = egret.HorizontalAlign.CENTER;
            favorTitle.y = 140;
            this.addChild(favorTitle);
        }
        var trainId = this.answers.questions[this.curIdx - 1].qid;
        var subject = Util.getTrain(trainId);
        if (!subject)
            return;
        this.curSubject = subject;
        //选项 
        var group = new eui.Group();
        group.height = 5000;
        group.touchEnabled = true;
        this.topicGroup = group;
        var topic = new Topic(subject);
        topic.x = (stage.stageWidth - topic.width) / 2;
        this.topic = topic;
        group.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.noticeGroup && (_this.noticeGroup.visible = false);
        }, this);
        group.addChild(topic);
        var myScroller = new eui.Scroller();
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = stage.stageWidth;
        myScroller.height = stage.stageHeight - 500;
        myScroller.y = 210;
        //设置viewport
        myScroller.viewport = group;
        this.addChild(myScroller);
        this.scroller = myScroller;
        var notice = this.notice();
        this.addChild(notice);
        var button_x = 68;
        var button_y = stage.stageHeight - 170;
        // 收藏按钮
        var favorButton = this.favorButton();
        favorButton.x = button_x;
        favorButton.y = button_y;
        favorButton.visible = this.type == AnswerType.TRAIN;
        this.addChild(favorButton);
        this.favButton = favorButton;
        // 删除按钮
        var removeFavor = this.removeFavor();
        removeFavor.x = button_x;
        removeFavor.y = button_y;
        removeFavor.visible = this.type == AnswerType.FAVOR;
        this.addChild(removeFavor);
        // 提交按钮
        var subButton = this.subButton();
        subButton.x = stage.stageWidth - subButton.width - button_x;
        subButton.y = button_y;
        this.addChild(subButton);
        this.commitButton = subButton;
    };
    AnswerScene.prototype.trainTitle = function () {
        var group = new eui.Group;
        var answer_title_bg = Util.createBitmapByName('answer_title_bg_png');
        answer_title_bg.x = 55;
        answer_title_bg.y = 66;
        group.addChild(answer_title_bg);
        var number = new egret.TextField();
        number.text = "Q" + this.curIdx;
        number.x = answer_title_bg.x;
        number.y = answer_title_bg.y + 4;
        number.width = answer_title_bg.width;
        number.height = answer_title_bg.height;
        number.textAlign = egret.HorizontalAlign.CENTER;
        number.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.numberText = number;
        group.addChild(number);
        return group;
    };
    AnswerScene.prototype.favorButton = function () {
        var _this = this;
        var button = new Button(this.answers.questions[this.curIdx - 1].isCollect ? 'icon_favor_png' : 'icon_favor_not_png', this.answers.questions[this.curIdx - 1].isCollect ? '已收藏' : '收藏', function () {
            //请求收藏id 
            var qid = _this.answers.questions[_this.curIdx - 1].qid;
            var isFavor = _this.answers.questions[_this.curIdx - 1].isCollect;
            Http.getInstance().post(Url.HTTP_FAVOR_SUBJECT, { qid: qid, type: isFavor ? 2 : 1 }, function () {
                _this.answers.questions[_this.curIdx - 1].isCollect = !isFavor;
                button.changeIcon(_this.answers.questions[_this.curIdx - 1].isCollect ? 'icon_favor_png' : 'icon_favor_not_png');
                button.changeText(_this.answers.questions[_this.curIdx - 1].isCollect ? '已收藏' : '收藏');
            });
        });
        return button;
    };
    AnswerScene.prototype.removeFavor = function () {
        var _this = this;
        var button = new Button('icon_remove_png', '删除', function () {
            //请求收藏id 
            var qid = _this.answers.questions[_this.curIdx - 1].qid;
            if (!_this.answers.questions[_this.curIdx - 1])
                return;
            Http.getInstance().post(Url.HTTP_FAVOR_SUBJECT, { qid: qid, type: 2 }, function () {
                _this.answers.questions.splice(_this.curIdx - 1, 1);
                if (_this.answers.questions.length == 0) {
                    var scene = new FavorScene();
                    ViewManager.getInstance().changeScene(scene);
                    return;
                }
                // 最后一项
                if (_this.curIdx >= _this.answers.questions.length) {
                    _this.curIdx = _this.answers.questions.length - 1;
                }
                _this.next();
            });
        });
        return button;
    };
    AnswerScene.prototype.subButton = function () {
        var _this = this;
        var subButton = new Button('icon_next_png', '提交', function () {
            var isEnd = _this.curIdx == _this.answers.questions.length;
            if (isEnd && _this.isNext) {
                if (!_this.ableClick)
                    return;
                _this.ableClick = false;
                if (_this.type == AnswerType.TRAIN) {
                    Http.getInstance().post(Url.HTTP_TRAIN_END, {
                        lifecycleid: _this.answers.lifecycleId,
                        levelid: _this.levelData.levelid
                    }, function (res) {
                        DataManager.getInstance().updateUser('lv', res.data.lv);
                        console.log("subButton -> res", res);
                        if (res.data.isOpen && res.data.isPass) {
                            var passAlert = new Pass(res.data.isOpen);
                            _this.addChild(passAlert);
                        }
                        else {
                            var icon = 'icon_pass_png';
                            var text = '恭喜您完成\n本小关的题目，请进入下一小关';
                            if (!res.data.isPass) {
                                icon = 'icon_fail_png';
                                text = '很遗憾\n闯关失败，请再接再厉哦！';
                            }
                            var nextLevel = res.data.isendlevel ? undefined : res.data.nextlevel;
                            var alert_1 = new AlertPanel(text, icon, 240, nextLevel);
                            alert_1.setFn(function () {
                                ViewManager.getInstance().backByName('trainLevelScene');
                            });
                            _this.addChild(alert_1);
                        }
                    });
                }
                else {
                    ViewManager.getInstance().back();
                }
            }
            else {
                if (_this.isNext) {
                    _this.isNext = false;
                    _this.next();
                }
                else {
                    var selectOption = _this.topic.getSelect();
                    if (!selectOption) {
                        _this.updateNotice('请选择答案');
                        return;
                    }
                    _this.isNext = true;
                    _this.topic.setDisableSelected();
                    subButton.ableClick(false);
                    var qid = _this.answers.questions[_this.curIdx - 1].qid;
                    var result_1 = _this.topic.getSelectResult();
                    var currentTime = +new Date();
                    var useTime = (currentTime - _this.start) / 1000;
                    var params = {
                        levelid: _this.levelData.levelid,
                        lifecycleid: _this.answers.lifecycleId,
                        qid: qid,
                        serialno: _this.curIdx,
                        qattrid: _this.curSubject.qattrid,
                        reply: selectOption,
                        iscorrect: result_1 ? 1 : 0,
                        useTime: useTime
                    };
                    Http.getInstance().post(Url.HTTP_TRAIN_SUBMIT, params, function () {
                        var noticeText = '恭喜您回答正确！';
                        if (result_1) {
                            Util.playMusic('answer_ok_mp3');
                            _this.isNext && _this.topic.setSelectedStatus(TopicItem.STATUS_OK);
                        }
                        else {
                            Util.playMusic('answer_err3_mp3');
                            noticeText = "\u56DE\u7B54\u9519\u8BEF\uFF0C\u6B63\u786E\u7B54\u6848\u662F" + _this.topic.getCorrectItem;
                            _this.isNext && _this.topic.setSelectedStatus(TopicItem.STATUS_ERROR);
                        }
                        _this.updateNotice(noticeText);
                        var buttonText = "下一题";
                        if (isEnd) {
                            buttonText = "结束";
                        }
                        subButton.changeText(buttonText);
                        subButton.ableClick(true);
                    });
                }
            }
        });
        return subButton;
    };
    AnswerScene.prototype.next = function () {
        this.noticeGroup && (this.noticeGroup.visible = false);
        this.start = +new Date();
        this.commitButton.changeText('提交');
        this.curIdx = this.curIdx + 1;
        if (this.type == AnswerType.TRAIN) {
            this.numberText.text = "Q" + this.curIdx;
            this.favButton.changeIcon(this.answers.questions[this.curIdx - 1].isCollect ? 'icon_favor_png' : 'icon_favor_not_png');
            this.favButton.changeText(this.answers.questions[this.curIdx - 1].isCollect ? '已收藏' : '收藏');
        }
        if (this._progress) {
            this._progress.setRate(this.curIdx);
        }
        var trainId = this.answers.questions[this.curIdx - 1].qid;
        var subject = Util.getTrain(trainId);
        if (!subject)
            return;
        this.curSubject = subject;
        this.topicGroup.removeChild(this.topic);
        //选项 
        var topic = new Topic(subject);
        topic.x = (this.stage.stageWidth - topic.width) / 2;
        this.topic = topic;
        this.topicGroup.addChild(topic);
        this.scroller.viewport.scrollV = 0;
    };
    AnswerScene.prototype.notice = function () {
        this.noticeGroup = new eui.Group;
        var notice_icon = Util.createBitmapByName('notice_png');
        this.noticeGroup.addChild(notice_icon);
        this.noticeGroup.height = notice_icon.height;
        var label = new egret.TextField;
        label.size = 32;
        label.bold = true;
        label.x = notice_icon.width + 10;
        label.y = 2;
        label.height = this.noticeGroup.height;
        label.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.noticeGroup.addChild(label);
        this.noticeGroup.y = this.stage.stageHeight - 240;
        this.noticeGroup.visible = false;
        return this.noticeGroup;
    };
    AnswerScene.prototype.updateNotice = function (text) {
        var label = this.noticeGroup.$children[1];
        label.text = text;
        this.noticeGroup.width = label.x + label.textWidth;
        this.noticeGroup.x = (this.stage.stageWidth - this.noticeGroup.width) / 2;
        this.noticeGroup.visible = true;
    };
    AnswerScene.prototype.onBack = function () {
        if (this.type == AnswerType.TRAIN) {
            var alert_2 = new AlertPanel('提示\n中途退出不做记录\n将重新开始闯关', '', 200, '', true);
            this.addChild(alert_2);
            return;
        }
        ViewManager.getInstance().backByName('favorScene');
    };
    return AnswerScene;
}(Scene));
__reflect(AnswerScene.prototype, "AnswerScene");
//# sourceMappingURL=AnswerScene.js.map
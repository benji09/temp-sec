var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var EquipmentScene = (function (_super) {
    __extends(EquipmentScene, _super);
    function EquipmentScene() {
        return _super.call(this) || this;
    }
    EquipmentScene.prototype.init = function () {
        this.setBackground('equipment_bg_png');
        Util.setTitle('武器装备');
        this.initList();
    };
    EquipmentScene.prototype.initList = function () {
        var _this = this;
        var group = new eui.Group();
        group.y = 340;
        this.addChild(group);
        var stage = ViewManager.getInstance().stage;
        var currentTrain = 3;
        var grayFilter = Util.grayFilter();
        EquipmentConfigs.forEach(function (item, i) {
            var trainLevelItem = new TrainLevelItem(item);
            trainLevelItem.x = i % 2 == 0 ? 120 : stage.stageWidth - trainLevelItem.width - 120;
            var y = (i > 1 ? 1 : 0) * (trainLevelItem.height + 40) + (i % 2 == 0 ? 40 : 140);
            var ratio = Util.getRatio();
            trainLevelItem.y = ratio > 0.6 ? y * 0.8 : y;
            trainLevelItem.filters = i == 3 ? [grayFilter] : [];
            group.addChild(trainLevelItem);
            var lock = Util.createBitmapByName('lock_png');
            var lock_ratio = lock.width / lock.height;
            lock.width = ratio > 0.6 ? 47 * 0.8 : 47;
            lock.height = lock.width / lock_ratio;
            lock.x = (trainLevelItem.width - lock.width) / 2 + 4;
            lock.y = 115;
            lock.visible = i == currentTrain;
            trainLevelItem.addChild(lock);
            trainLevelItem.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
                if (i == 3)
                    return;
                var scene = new EquipList(item);
                ViewManager.getInstance().changeScene(scene);
                Util.playMusic('model_select_mp3');
            }, _this);
        });
    };
    return EquipmentScene;
}(Scene));
__reflect(EquipmentScene.prototype, "EquipmentScene");
//# sourceMappingURL=EquipmentScene.js.map
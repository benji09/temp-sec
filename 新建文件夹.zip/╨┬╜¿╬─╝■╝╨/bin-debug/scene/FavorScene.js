var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var FavorScene = (function (_super) {
    __extends(FavorScene, _super);
    function FavorScene() {
        var _this = _super.call(this) || this;
        _this.flag = true;
        return _this;
    }
    FavorScene.prototype.init = function () {
        var _this = this;
        this.setBackground('favor_bg_png');
        Util.setTitle('答题闯关');
        this.name = 'favorScene';
        // 标题
        var title = new Title('我的收藏', 128);
        this.addChild(title);
        var bandges = Util.getConfig('bandge');
        var trainLevelGroup = new eui.Group();
        trainLevelGroup.y = 340;
        this.addChild(trainLevelGroup);
        var stage = ViewManager.getInstance().stage;
        bandges.forEach(function (item, i) {
            item.icon = "train_icon_0" + (i + 1) + "_png";
            var trainLevelItem = new TrainLevelItem(item, i);
            trainLevelItem.x = i % 2 == 0 ? 120 : stage.stageWidth - trainLevelItem.width - 120;
            var y = (i > 1 ? 1 : 0) * (trainLevelItem.height + 40) + (i % 2 == 0 ? 40 : 140);
            var ratio = Util.getRatio();
            trainLevelItem.y = ratio > 0.6 ? y * 0.8 : y;
            trainLevelGroup.addChild(trainLevelItem);
            trainLevelItem.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
                if (!_this.flag)
                    return;
                _this.flag = false;
                Http.getInstance().post(Url.HTTP_FAVOR_LIST, "", function (res) {
                    var favors = res.data;
                    var idx = favors && favors.filter(function (item) { return item.sort - 1 == i; });
                    if (idx && idx.length) {
                        _this.train(idx[0]);
                    }
                    else {
                        var alert_1 = new AlertPanel("提示\n暂无收藏！");
                        _this.addChild(alert_1);
                        _this.flag = true;
                    }
                    Util.playMusic('model_select_mp3');
                });
            }, _this);
        });
    };
    FavorScene.prototype.train = function (item) {
        Http.getInstance().post(Url.HTTP_TRAIN_START, { type: AnswerType.FAVOR, tid: item.qattrId }, function (res) {
            var answer = new Answers();
            answer.lifecycleId = item.qattrId;
            answer.questions = res.data;
            var levelData = item;
            levelData.name = item.attrVal;
            levelData.flag = "";
            var scene = new AnswerScene(answer, AnswerType.FAVOR, levelData);
            ViewManager.getInstance().changeScene(scene);
        });
    };
    FavorScene.prototype.onBack = function () {
        ViewManager.getInstance().backByName('trainScene');
    };
    FavorScene.prototype.updateScene = function () {
        this.flag = true;
    };
    return FavorScene;
}(Scene));
__reflect(FavorScene.prototype, "FavorScene");
//# sourceMappingURL=FavorScene.js.map
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Scene = (function (_super) {
    __extends(Scene, _super);
    function Scene() {
        var _this = _super.call(this) || this;
        _this.isRemove = true;
        _this.close_btn = '返回';
        _this.isBackHome = false;
        _this.backPage = false;
        _this.addEventListener(egret.Event.ADDED_TO_STAGE, _this.initScene, _this);
        _this.addEventListener(egret.Event.REMOVED_FROM_STAGE, _this.release, _this);
        return _this;
    }
    Scene.prototype.initScene = function () {
        if (this.isRemove) {
            this.init();
            this.isRemove = false;
            if (this.close_btn != '') {
                this.createNavButton();
            }
        }
    };
    Scene.prototype.createNavButton = function () {
        var _this = this;
        var btn = this.textGroup(this.close_btn);
        var flag = true;
        btn.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            if (!flag)
                return;
            flag = false;
            _this.onBack();
            Util.playMusic('model_select_mp3');
            _this.removeEvent && SocketX.getInstance().removeEventListener(_this.removeEvent);
            setTimeout(function () {
                flag = true;
            }, 300);
        }, this);
    };
    Scene.prototype.createRightButton = function (text, fn) {
        var btn = this.textGroup(text);
        btn.x = this.stage.stageWidth - btn.width;
        btn.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            Util.playMusic('model_select_mp3');
            fn();
        }, this);
        return btn;
    };
    Scene.prototype.textGroup = function (text) {
        var btn = new eui.Group;
        btn.height = 100;
        this.addChild(btn);
        var label = new egret.TextField;
        label.text = text;
        label.width = label.textWidth + 100;
        btn.width = label.width;
        label.height = btn.height;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.verticalAlign = egret.VerticalAlign.MIDDLE;
        btn.addChild(label);
        btn.touchEnabled = true;
        return btn;
    };
    Scene.prototype.setBackground = function (name) {
        if (name === void 0) { name = "bg_png"; }
        var bg = Util.createBitmapByName(name);
        bg.width = this.stage.stageWidth;
        bg.height = this.stage.stageHeight;
        this.addChildAt(bg, 0);
    };
    /**
     * 更新页面信息
     */
    Scene.prototype.updateScene = function () {
    };
    /**
     * 初始化界面
     */
    Scene.prototype.init = function () {
    };
    Scene.prototype.onBack = function () {
        ViewManager.getInstance().back();
    };
    /**
     * 释放界面
     */
    Scene.prototype.release = function () {
    };
    /**
     * 退出页面，需要加载动画
     */
    Scene.prototype.remove = function () {
        // 切换动画
        this.removeChildren();
        this.parent.removeChild(this);
        this.isRemove = true;
    };
    return Scene;
}(eui.UILayer));
__reflect(Scene.prototype, "Scene");
//# sourceMappingURL=Scene.js.map
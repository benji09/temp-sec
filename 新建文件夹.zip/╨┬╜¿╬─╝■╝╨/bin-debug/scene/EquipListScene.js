var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var EquipList = (function (_super) {
    __extends(EquipList, _super);
    function EquipList(config) {
        var _this = _super.call(this) || this;
        _this.config = config;
        return _this;
    }
    EquipList.prototype.init = function () {
        this.setBackground('bg_with_title_png');
        // 标题
        var title = new Title(this.config.name, 120, this.config.icon);
        this.addChild(title);
        this.changeTypeList(this.config);
    };
    EquipList.prototype.changeTypeList = function (config) {
        var _this = this;
        Http.getInstance().post(Url.HTTP_EQUIP_LIST, { catid: config.type }, function (res) {
            var group = new eui.Group();
            group.width = _this.stage.stageWidth;
            _this.addChild(group);
            var y = 40;
            var list = res.data;
            if (list != null) {
                list.forEach(function (item) {
                    var equipItem = new EquipItem(item);
                    equipItem.x = (_this.stage.stageWidth - equipItem.width) / 2;
                    equipItem.y = y;
                    y += equipItem.height + 50;
                    equipItem.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onSeeItemDetail(item), _this);
                    group.addChild(equipItem);
                });
            }
            else {
                var emptyTips = new egret.TextField();
                emptyTips.text = "暂无结果";
                emptyTips.width = _this.stage.stageWidth;
                emptyTips.textAlign = egret.HorizontalAlign.CENTER;
                emptyTips.y = 600;
                emptyTips.size = 40;
                _this.addChild(emptyTips);
            }
            group.height = y + 400;
            var myScroller = new eui.Scroller();
            //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
            myScroller.height = _this.stage.stageHeight - 474;
            myScroller.y = 340;
            //设置viewport
            myScroller.viewport = group;
            _this.addChild(myScroller);
        });
    };
    EquipList.prototype.onSeeItemDetail = function (item) {
        return function () {
            var audio = document.querySelector('#audio');
            audio.volume = 0;
            Util.playMusic('model_select_mp3');
            Http.getInstance().post(Url.HTTP_CMS_CONTENTLOG, { conid: item.contentId }, null);
            var thUserId = '';
            // if(item.url && item.url.toLowerCase().trim().endsWith('.pdf')){
            thUserId = "&wm=" + DataManager.getInstance().getUser().thUserId;
            // }
            showIFrame(item.url + thUserId, item.type);
        };
    };
    return EquipList;
}(Scene));
__reflect(EquipList.prototype, "EquipList");
//# sourceMappingURL=EquipListScene.js.map
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var BattleScene = (function (_super) {
    __extends(BattleScene, _super);
    function BattleScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.index = 0;
        _this.canSubmit = true;
        _this.TIMER = 15;
        _this.groupWidth = 514;
        _this.opponentRate = 1;
        return _this;
    }
    BattleScene.prototype.init = function () {
        var _this = this;
        this.setBackground();
        Util.setTitle('PK挑战');
        this.close_btn = '';
        this.initData();
        var stageW = this.stage.stageWidth;
        var stageH = this.stage.stageHeight;
        var userInfo = DataManager.getInstance().getUser();
        this.userInfo = userInfo;
        var leftUser = new PkUser(userInfo);
        leftUser.x = 68;
        leftUser.y = 116;
        this.addChild(leftUser);
        var pkData = DataManager.getInstance().getPkData();
        if (Config.DEBUG) {
            pkData = {
                pkCode: "6d8bcc2061b311eaaab4c72eb1651d0c",
                pkType: 3,
                pkUser: { userId: "3", teamId: 1002, nickName: "V准宝", robot: 1 },
                questions: [
                    { id: 5578 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 }
                ],
                status: 1,
                type: 3
            };
        }
        this.pkData = pkData;
        var rightUser = new PkUser(pkData.pkUser, 'right');
        rightUser.x = stageW - rightUser.width - leftUser.x;
        rightUser.y = leftUser.y;
        this.addChild(rightUser);
        var pkVs = Util.createBitmapByName('pk_vs_png');
        pkVs.x = (stageW - pkVs.width) / 2;
        pkVs.y = 182;
        pkVs.blendMode = egret.BlendMode.ADD;
        this.addChild(pkVs);
        // 倒计时
        var count_down_time = new egret.TextField();
        count_down_time.text = "00: " + this.TIMER;
        count_down_time.width = stageW;
        count_down_time.y = 115;
        count_down_time.textAlign = egret.HorizontalAlign.CENTER;
        count_down_time.size = 40;
        this.addChild(count_down_time);
        this.timeText = count_down_time;
        var line = Util.createBitmapByName('pk_line_png');
        line.width = stageW;
        line.y = 320;
        line.blendMode = egret.BlendMode.ADD;
        this.addChild(line);
        var ratio = Util.getRatio();
        var processY = ratio > 0.6 ? 640 * 0.8 : 640;
        var progress = new VProgress(this.pkData.questions.length);
        progress.x = 56;
        progress.y = processY;
        progress.setRate(1);
        this.addChild(progress);
        this.selfProgress = progress;
        var progress2 = new VProgress(this.pkData.questions.length);
        progress2.x = stageW - progress2.width - progress.x;
        progress2.y = processY;
        progress2.setRate(this.opponentRate);
        this.addChild(progress2);
        this.otherProgress = progress2;
        var trainId = this.pkData.questions[this.index]['id'];
        var subject = Util.getTrain(trainId);
        //选项 
        if (!subject)
            return;
        var group = new eui.Group();
        group.width = this.groupWidth;
        group.touchEnabled = true;
        group.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            _this.noticeGroup && (_this.noticeGroup.visible = false);
        }, this);
        var topic = new Topic(subject, this.groupWidth);
        this.topic = topic;
        group.addChild(topic);
        this.topicGroup = group;
        var myScroller = new eui.Scroller();
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = this.groupWidth;
        myScroller.height = stageH - 720;
        myScroller.y = 530;
        myScroller.x = (stageW - myScroller.width) / 2;
        //设置viewport
        myScroller.viewport = group;
        this.scroller = myScroller;
        this.addChild(myScroller);
        var notice = this.notice();
        this.addChild(notice);
        var submit = Util.createBitmapByName('pk_btn_png');
        var submitGroup = new eui.Group;
        this.submitButton = submitGroup;
        submitGroup.width = submit.width;
        submitGroup.height = submit.height;
        submitGroup.x = (stageW - submitGroup.width) / 2;
        submitGroup.y = stageH - 130;
        submitGroup.addChild(submit);
        this.addChild(submitGroup);
        var submitLabel = new egret.TextField;
        submitLabel.text = '提    交';
        submitLabel.width = submitGroup.width;
        submitLabel.height = submitGroup.height;
        submitLabel.textAlign = egret.HorizontalAlign.CENTER;
        submitLabel.verticalAlign = egret.VerticalAlign.MIDDLE;
        submitLabel.textColor = Config.COLOR_MAIN;
        submitLabel.size = 34;
        submitGroup.addChild(submitLabel);
        submitGroup.touchEnabled = true;
        submitGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            if (!_this.canSubmit)
                return;
            var selectOption = _this.topic.getSelect();
            if (!selectOption) {
                _this.updateNotice('请选择答案');
                return;
            }
            var result = _this.topic.getSelectResult();
            _this.submitResult(result, selectOption);
            _this.topic.setDisableSelected();
        }, this);
    };
    BattleScene.prototype.notice = function () {
        this.noticeGroup = new eui.Group;
        var notice_icon = Util.createBitmapByName('notice_png');
        this.noticeGroup.addChild(notice_icon);
        this.noticeGroup.height = notice_icon.height;
        var label = new egret.TextField;
        label.size = 32;
        label.bold = true;
        label.x = notice_icon.width + 10;
        label.y = 2;
        label.height = this.noticeGroup.height;
        label.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.noticeGroup.addChild(label);
        this.noticeGroup.y = this.stage.stageHeight - 180;
        this.noticeGroup.visible = false;
        return this.noticeGroup;
    };
    BattleScene.prototype.updateNotice = function (text) {
        var label = this.noticeGroup.$children[1];
        label.text = text;
        this.noticeGroup.width = label.x + label.textWidth;
        this.noticeGroup.x = (this.stage.stageWidth - this.noticeGroup.width) / 2 - 10;
        this.noticeGroup.visible = true;
    };
    BattleScene.prototype.initData = function () {
        var _this = this;
        this.timestamp = +new Date();
        this.timeNumber = this.TIMER;
        //注册答题结束事件
        SocketX.getInstance().addEventListener(NetEvent.PK_PROGRESS, this.updateProgress, this);
        SocketX.getInstance().addEventListener(NetEvent.PK_ANSWER, function (data) {
            if (data.data.tipsCode == InviteStatus.PK_END_WAIT) {
                var pk = new PkInviteScene(InviteStatus.PK_END_WAIT, '你的对手还在苦苦思索中\n请稍等...', _this.pkData.pkCode);
                ViewManager.getInstance().changeScene(pk);
            }
        }, this);
        //倒计时
        var timer = new egret.Timer(1000, this.TIMER + 10);
        this.timer = timer;
        timer.addEventListener(egret.TimerEvent.TIMER, function () {
            _this.timeNumber--;
            _this.timeText.text = "00: " + _this.timeNumber;
            if (_this.timeNumber < 10) {
                _this.timeText.text = "00: 0" + _this.timeNumber;
            }
            if (_this.timeNumber == 0) {
                timer.stop();
                if (!_this.canSubmit)
                    return;
                _this.submitNull();
            }
        }, this);
        timer.start();
    };
    BattleScene.prototype.submitResult = function (result, reply) {
        var _this = this;
        this.canSubmit = false;
        var qattrId = this.topic.getQAttrId();
        var useTime = (+new Date() - this.timestamp) / 1000;
        var params = {
            userId: this.userInfo.userId,
            pkCode: this.pkData.pkCode,
            type: this.pkData.pkType,
            qid: this.pkData.questions[this.index].id,
            qattrId: qattrId,
            reply: reply,
            isCorrect: result ? 1 : 0,
            useTime: useTime //答题时间
        };
        SocketX.getInstance().sendMsg(NetEvent.PK_ANSWER, params);
        var noticeText = '恭喜您回答正确！';
        if (result) {
            Util.playMusic('answer_ok_mp3');
            this.topic.setSelectedStatus(TopicItem.STATUS_OK);
        }
        else {
            noticeText = "\u56DE\u7B54\u9519\u8BEF\uFF0C\u6B63\u786E\u7B54\u6848\u662F" + this.topic.getCorrectItem;
            this.topic.setSelectedStatus(TopicItem.STATUS_ERROR);
            Util.playMusic('answer_err3_mp3');
        }
        this.updateNotice(noticeText);
        this.submitButton.visible = false;
        // if (Config.DEBUG) {
        //     let pk = new PkInviteScene(InviteStatus.PK_END_WAIT)
        //     ViewManager.getInstance().changeScene(pk)
        //     return
        // }
        //如果有下一題，直接进入下一题
        if (this.index < this.pkData.questions.length - 1) {
            setTimeout(function () {
                _this.next();
                _this.selfProgress.setRate(_this.index + 1);
                _this.timestamp = +new Date();
            }, 2000);
        }
        else {
            this.timeToEnd();
        }
    };
    BattleScene.prototype.timeToEnd = function () {
        var _this = this;
        this.timer1 = setTimeout(function () {
            console.log(333, _this.pkData.pkCode);
            SocketX.getInstance().addEventListener(NetEvent.PK_INFO, function (data) {
                var result = data.data;
                console.log("BattleScene -> timeToEnd -> result", result);
                if (result.status == 4) {
                    var pk = new PkInviteScene(InviteStatus.PK_END_WAIT, '你的对手还在苦苦思索中\n请稍等...', _this.pkData.pkCode);
                    ViewManager.getInstance().changeScene(pk);
                }
                else {
                    result = DataManager.getInstance().convertPkResult(result);
                    var resultScene = new PkResultScene(result);
                    ViewManager.getInstance().changeScene(resultScene);
                }
            });
            SocketX.getInstance().sendMsg(NetEvent.PK_INFO, { pkCode: _this.pkData.pkCode });
        }, 5000);
    };
    BattleScene.prototype.submitNull = function () {
        this.canSubmit = false;
        var qattrId = this.topic.getQAttrId();
        var useTime = this.TIMER - this.timeNumber;
        var params = {
            userId: this.userInfo.userId,
            pkCode: this.pkData.pkCode,
            type: this.pkData.pkType,
            qid: this.pkData.questions[this.index].id,
            qattrId: qattrId,
            reply: 'null',
            isCorrect: 0,
            useTime: useTime //答题时间
        };
        SocketX.getInstance().sendMsg(NetEvent.PK_ANSWER, params);
        Util.playMusic('answer_err3_mp3');
        this.selfProgress.setRate(this.index + 2);
        //如果有下一題，直接进入下一题
        if (this.index < this.pkData.questions.length - 1) {
            this.next();
            this.timestamp = +new Date();
        }
        else {
            this.timeToEnd();
        }
    };
    //进入下一题
    BattleScene.prototype.next = function () {
        this.noticeGroup && (this.noticeGroup.visible = false);
        this.canSubmit = true;
        this.submitButton.visible = true;
        this.index++;
        this.timeNumber = this.TIMER;
        this.timer.reset();
        this.timeText.text = "00: " + this.timeNumber;
        this.timer.start();
        this.topicGroup.removeChild(this.topic);
        var trainid = this.pkData.questions[this.index].id;
        var subject = Util.getTrain(trainid);
        if (!subject)
            return;
        //选项 
        var topic = new Topic(subject, this.groupWidth);
        this.topic = topic;
        this.topicGroup.addChild(topic);
        this.scroller.viewport.scrollV = 0;
    };
    /**
     * 更新进度条
     */
    BattleScene.prototype.updateProgress = function (data) {
        if (data.data.seriaNo != this.opponentRate) {
            return;
        }
        this.otherProgress.setRate(data.data.seriaNo + 1);
        this.opponentRate += 1;
    };
    BattleScene.prototype.release = function () {
        this.timer1 && clearTimeout(this.timer1);
    };
    return BattleScene;
}(Scene));
__reflect(BattleScene.prototype, "BattleScene");
//# sourceMappingURL=BattleScene.js.map
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PkInviteScene = (function (_super) {
    __extends(PkInviteScene, _super);
    function PkInviteScene(type, msg, pkCode) {
        if (msg === void 0) { msg = null; }
        var _this = _super.call(this) || this;
        _this.type = type;
        _this.msg = msg;
        _this.pkCode = pkCode;
        return _this;
    }
    PkInviteScene.prototype.init = function () {
        this.setBackground();
        this.close_btn = '';
        Util.setTitle('PK挑战');
        var stageW = ViewManager.getInstance().stage.stageWidth;
        var avatarGroup = new eui.Group;
        avatarGroup.y = 20;
        this.addChild(avatarGroup);
        this.avatarGroup = avatarGroup;
        var userInfo = DataManager.getInstance().getUser();
        var leftUser = new PkUser(userInfo);
        leftUser.x = 68;
        avatarGroup.addChild(leftUser);
        var pkData = DataManager.getInstance().getPkData();
        var rightUser = new PkUser(pkData ? pkData.pkUser : null, 'right');
        rightUser.x = stageW - rightUser.width - leftUser.x;
        avatarGroup.addChild(rightUser);
        var pkVs = Util.createBitmapByName('pk_vs_png');
        pkVs.x = (stageW - pkVs.width) / 2;
        pkVs.y = 66;
        pkVs.blendMode = egret.BlendMode.ADD;
        avatarGroup.addChild(pkVs);
        var line = Util.createBitmapByName('pk_line_png');
        line.width = stageW;
        line.y = 350;
        line.blendMode = egret.BlendMode.ADD;
        line.visible = false;
        this.addChild(line);
        this.line = line;
        var ratio = Util.getRatio();
        var waitPic = Util.createBitmapByName('pk_end_wait_png');
        waitPic.width = ratio > 0.6 ? waitPic.width * 0.8 : waitPic.width;
        waitPic.height = ratio > 0.6 ? waitPic.height * 0.8 : waitPic.height;
        waitPic.blendMode = egret.BlendMode.ADD;
        waitPic.x = ratio > 0.6 ? 30 : -30;
        waitPic.y = 520;
        waitPic.visible = false;
        this.addChild(waitPic);
        this.waitPic = waitPic;
        switch (this.type) {
            case InviteStatus.MATCHEND:
                this.matchEnd();
                this.avatarGroup.y = 420;
                break;
            default:
                this.pkEnd();
                this.close_btn = '返回';
                this.avatarGroup.y = 116;
                this.removeEvent = NetEvent.PK_END;
                break;
        }
    };
    PkInviteScene.prototype.matchEnd = function () {
        var _this = this;
        var stageW = this.stage.stageWidth;
        var label = new egret.TextField;
        label.text = '匹配\n成功';
        label.width = stageW;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.y = 622;
        label.textColor = Config.COLOR_MAIN;
        label.size = 60;
        label.bold = true;
        label.lineSpacing = 30;
        this.addChild(label);
        var seconds = 5;
        var countDown = new egret.TextField;
        countDown.text = '' + seconds;
        countDown.width = stageW;
        countDown.textAlign = egret.HorizontalAlign.CENTER;
        countDown.y = label.y + label.textHeight + 50;
        countDown.size = 60;
        this.addChild(countDown);
        var timer = new egret.Timer(1000, 8);
        this.timer1 = timer;
        timer.addEventListener(egret.TimerEvent.TIMER, function () {
            if (seconds <= 0)
                return;
            seconds--;
            countDown.text = '' + seconds;
        }, this);
        // if (Config.DEBUG) {
        //     timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
        //         let scene = new BattleScene()
        //         ViewManager.getInstance().changeScene(scene)
        //     }, this)
        // }
        timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, function () {
            ViewManager.getInstance().showLoading('哦噢，网络好像出现了问题，\n请重新匹配！');
            _this.close_btn = '返回';
            _this.createNavButton();
        }, this);
        timer.start();
    };
    PkInviteScene.prototype.pkEnd = function () {
        var _this = this;
        this.line.visible = true;
        this.waitPic.visible = true;
        var info = new LineInfo(this.msg, '(可返回主页，稍后到挑战记录查看结果)');
        this.addChild(info);
        SocketX.getInstance().addEventListener(NetEvent.PK_INFO, function (data) {
            var result = data.data;
            if (result.tipsCode != 12) {
                _this.timer && clearInterval(_this.timer);
                result = DataManager.getInstance().convertPkResult(result);
                var resultScene = new PkResultScene(result);
                ViewManager.getInstance().changeScene(resultScene);
            }
        });
        this.timer = setInterval(function () {
            SocketX.getInstance().sendMsg(NetEvent.PK_INFO, { pkCode: _this.pkCode });
        }, 1000);
    };
    PkInviteScene.prototype.onBack = function () {
        var isConnect = SocketX.getInstance().isconnect;
        if (isConnect) {
            SocketX.getInstance().sendMsg(NetEvent.CACEL_MATCH, {});
            SocketX.getInstance().close();
        }
        DataManager.getInstance().removePkData();
        ViewManager.getInstance().backByName('pkList');
    };
    PkInviteScene.prototype.release = function () {
        this.timer && clearInterval(this.timer);
        this.timer1 && this.timer1.stop();
    };
    return PkInviteScene;
}(Scene));
__reflect(PkInviteScene.prototype, "PkInviteScene");
//# sourceMappingURL=PkInviteScene.js.map
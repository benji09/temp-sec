var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PkResultScene = (function (_super) {
    __extends(PkResultScene, _super);
    function PkResultScene(result, back) {
        var _this = _super.call(this) || this;
        _this.result = result;
        _this.back = back;
        return _this;
    }
    PkResultScene.prototype.init = function () {
        var _this = this;
        this.setBackground();
        Util.setTitle('PK挑战');
        var stageW = this.stage.stageWidth;
        var stageH = this.stage.stageHeight;
        var userId = DataManager.getInstance().getUser().userId;
        var shareGroup = new eui.Group();
        this.addChild(shareGroup);
        this.shareGroup = shareGroup;
        shareGroup.width = stageW;
        var pkResult = this.result;
        console.log('pkResult', pkResult);
        // 玩家自己
        var self = pkResult.sender;
        var opponent = pkResult.receiver;
        if (pkResult.sender.pkUser.userId != userId) {
            self = pkResult.receiver;
            opponent = pkResult.sender;
        }
        var selfPkUser = self ? self.pkUser : null;
        var selfCorrect = '';
        var selfTime = '';
        if (self && self.pkResult) {
            selfCorrect = self.pkResult.isCorrect + '/' + self.pkResult.answerCount;
            selfTime = Util.converTimer(self.pkResult.userAnswerUseTimeTotal);
        }
        var leftUser = new PkUser(selfPkUser, "left", selfCorrect, selfTime);
        leftUser.x = 68;
        leftUser.y = 116;
        shareGroup.addChild(leftUser);
        // 对手
        var opponentPkUser = opponent ? opponent.pkUser : null;
        var opponentCorrect = '';
        var opponentTime = '';
        if (opponent && opponent.pkResult) {
            opponentCorrect = opponent.pkResult.isCorrect + '/' + opponent.pkResult.answerCount;
            opponentTime = Util.converTimer(opponent.pkResult.userAnswerUseTimeTotal);
        }
        var rightUser = new PkUser(opponentPkUser, 'right', opponentCorrect, opponentTime);
        rightUser.x = stageW - rightUser.width - leftUser.x;
        rightUser.y = leftUser.y;
        shareGroup.addChild(rightUser);
        var pkVs = Util.createBitmapByName('pk_vs_png');
        pkVs.x = (stageW - pkVs.width) / 2;
        pkVs.blendMode = egret.BlendMode.ADD;
        pkVs.y = 182;
        shareGroup.addChild(pkVs);
        var line = Util.createBitmapByName('pk_line_png');
        line.width = stageW;
        line.y = 350;
        shareGroup.addChild(line);
        // 无效局
        if (pkResult.status == PkResult.INVALID) {
            var waitPic = Util.createBitmapByName('pk_end_wait_png');
            waitPic.blendMode = egret.BlendMode.ADD;
            waitPic.x = -30;
            waitPic.y = 520;
            this.addChild(waitPic);
            var info = new LineInfo(pkResult.tipsMsg);
            shareGroup.addChild(info);
            return;
        }
        // 结果背景和音乐
        var music = "pass_mp3";
        var result = '挑战\n成功';
        if (pkResult.status == PkResult.FAIL) {
            result = '挑战\n失败';
            music = "nopass_mp3";
        }
        else if (pkResult.status == PkResult.DRAW) {
            result = '平局';
        }
        var resultBg = Util.createBitmapByName('pk_time_bg_png');
        var ratio = Util.getRatio();
        resultBg.width = ratio > 0.6 ? resultBg.width * 0.8 : resultBg.width;
        resultBg.height = ratio > 0.6 ? resultBg.height * 0.8 : resultBg.height;
        resultBg.x = ratio > 0.6 ? 150 : 100;
        resultBg.y = 520;
        shareGroup.addChild(resultBg);
        Util.playMusic(music);
        var resultText = new egret.TextField;
        resultText.text = result;
        resultText.width = stageW;
        resultText.height = resultBg.height;
        resultText.y = resultBg.y + 10;
        resultText.textAlign = egret.HorizontalAlign.CENTER;
        resultText.verticalAlign = egret.VerticalAlign.MIDDLE;
        resultText.size = 60;
        resultText.bold = true;
        resultText.lineSpacing = ratio > 0.6 ? 35 * 0.8 : 35;
        shareGroup.addChild(resultText);
        var weekCount = this.describe('本周参赛场次:' + self.pkUser.pkCount);
        weekCount.y = resultBg.y + resultBg.height + 10;
        shareGroup.addChild(weekCount);
        var weekRate = this.describe('本周胜率:' + self.pkUser.winRate);
        weekRate.y = weekCount.y + weekCount.height + 10;
        shareGroup.addChild(weekRate);
        // 保存图片
        var saveBtn = new Button('icon_save_png', '保存图片', function () {
            var alert = new AlertPanel("提示\n请自行截图保存图片！");
            _this.addChild(alert);
        });
        saveBtn.x = 74;
        saveBtn.y = stageH - 120;
        this.addChild(saveBtn);
        // 分享
        var shareBtn = new Button('icon_share_png', '分享', function () {
            var tips = new SharePanel();
            _this.addChild(tips);
        });
        shareBtn.x = this.stage.stageWidth - shareBtn.width - saveBtn.x;
        shareBtn.y = saveBtn.y;
        this.addChild(shareBtn);
        var status = ShareType.PK_WIN;
        if (pkResult.status == PkResult.FAIL) {
            status = ShareType.PK_FAIL;
        }
        else if (pkResult.status == PkResult.DRAW) {
            status = ShareType.PK_DRAW;
        }
        Util.registerShare(this.shareGroup, status, self.pkUser.nickName, opponent ? opponent.pkUser.nickName : '');
    };
    PkResultScene.prototype.describe = function (notice) {
        var ratio = Util.getRatio();
        var group = new eui.Group;
        var bg = Util.createBitmapByName('pk_notice_bg_png');
        bg.width = ratio > 0.6 ? bg.width * 0.8 : bg.width;
        bg.height = ratio > 0.6 ? bg.height * 0.8 : bg.height;
        bg.blendMode = egret.BlendMode.ADD;
        group.width = bg.width;
        group.height = bg.height;
        group.x = (this.stage.stageWidth - group.width) / 2;
        group.addChild(bg);
        var noticeText = new egret.TextField;
        noticeText.text = notice;
        noticeText.width = group.width;
        noticeText.height = group.height;
        noticeText.textAlign = egret.HorizontalAlign.CENTER;
        noticeText.verticalAlign = egret.VerticalAlign.MIDDLE;
        var size = 30;
        noticeText.size = ratio > 0.6 ? size * 0.8 : size;
        group.addChild(noticeText);
        return group;
    };
    PkResultScene.prototype.onBack = function () {
        var isConnect = SocketX.getInstance().isconnect;
        if (isConnect && !this.back) {
            SocketX.getInstance().sendMsg(NetEvent.CACEL_MATCH, {});
            SocketX.getInstance().close();
        }
        DataManager.getInstance().removePkData();
        if (this.back) {
            ViewManager.getInstance().backByName(this.back);
            return;
        }
        ViewManager.getInstance().backByName('pkList');
    };
    return PkResultScene;
}(Scene));
__reflect(PkResultScene.prototype, "PkResultScene");
//# sourceMappingURL=PkResultScene.js.map
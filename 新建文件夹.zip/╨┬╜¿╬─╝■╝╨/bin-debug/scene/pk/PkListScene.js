var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PkListScene = (function (_super) {
    __extends(PkListScene, _super);
    function PkListScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.config = [
            { icon: 'pk_person_png', title: '个人挑战赛', type: 1, status: 1 },
            { icon: 'pk_team_png', title: '团队挑战赛', type: 2, status: 0 }
        ];
        return _this;
    }
    PkListScene.prototype.init = function () {
        this.setBackground();
        Util.setTitle('PK挑战');
        this.close_btn = '首页';
        this.name = 'pkList';
        var stage = ViewManager.getInstance().stage;
        // 挑战记录
        var pkRecord = this.createRightButton('挑战记录', function () {
            var scene = new PkRecordScene();
            ViewManager.getInstance().changeScene(scene);
        });
        pkRecord.touchEnabled = false;
        this.pkRecord = pkRecord;
        this.addChild(pkRecord);
        var isConnect = SocketX.getInstance().isconnect;
        if (!isConnect) {
            ViewManager.getInstance().showLoading('连接中......');
            SocketX.getInstance().connectPersonPk(function () {
                setTimeout(function () {
                    ViewManager.getInstance().hideLoading();
                    pkRecord.touchEnabled = true;
                }, 1000);
            });
        }
        var pkTitle = new egret.TextField;
        pkTitle.text = 'PK挑战';
        pkTitle.size = 50;
        pkTitle.textColor = Config.COLOR_MAIN;
        pkTitle.x = (stage.stageWidth - pkTitle.textWidth) / 2;
        pkTitle.y = 166;
        pkTitle.bold = true;
        this.addChild(pkTitle);
        var ratio = Util.getRatio();
        var y = ratio > 0.6 ? 318 * 0.8 : 318;
        for (var _i = 0, _a = this.config; _i < _a.length; _i++) {
            var data = _a[_i];
            var item = new PkItem(data);
            this.addChild(item);
            item.y = y;
            y += ratio > 0.6 ? 464 * 0.8 : 464;
        }
    };
    PkListScene.prototype.onBack = function () {
        var isConnect = SocketX.getInstance().isconnect;
        isConnect && SocketX.getInstance().close();
        ViewManager.getInstance().back();
    };
    PkListScene.prototype.updateScene = function () {
        var _this = this;
        var isConnect = SocketX.getInstance().isconnect;
        console.log("PkListScene -> updateScene -> isConnect", isConnect);
        if (!isConnect) {
            this.pkRecord.touchEnabled = false;
            ViewManager.getInstance().showLoading('连接中......');
            SocketX.getInstance().connectPersonPk(function () {
                setTimeout(function () {
                    ViewManager.getInstance().hideLoading();
                    _this.pkRecord.touchEnabled = true;
                }, 1000);
            });
        }
    };
    return PkListScene;
}(Scene));
__reflect(PkListScene.prototype, "PkListScene");
//# sourceMappingURL=PkListScene.js.map
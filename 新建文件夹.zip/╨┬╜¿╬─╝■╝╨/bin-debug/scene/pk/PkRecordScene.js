var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PkRecordScene = (function (_super) {
    __extends(PkRecordScene, _super);
    function PkRecordScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.itemY = 0;
        _this.page = 1;
        _this.pageSize = 20;
        _this.end = false;
        _this.ableScroll = true;
        return _this;
    }
    PkRecordScene.prototype.init = function () {
        var _this = this;
        this.setBackground();
        this.close_btn = '返回PK挑战';
        Util.setTitle('PK挑战');
        this.name = 'pkRecord';
        var stageW = ViewManager.getInstance().stage.stageWidth;
        var bg = Util.createBitmapByName('sign_bg_png');
        bg.width = stageW;
        this.addChild(bg);
        var title = new egret.TextField;
        title.text = 'PK挑战';
        title.x = 416;
        title.y = 188;
        title.size = 50;
        title.bold = true;
        this.addChild(title);
        var isConnect = SocketX.getInstance().isconnect;
        if (isConnect) {
            this.getData();
        }
        else {
            SocketX.getInstance().connectPersonPk(function () {
                _this.getData();
            });
        }
        var group = new eui.Group();
        this.groupView = group;
        var myScroller = new eui.Scroller();
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = stageW;
        myScroller.height = 690;
        myScroller.x = 130;
        myScroller.y = 350;
        //设置viewport
        myScroller.viewport = group;
        this.addChild(myScroller);
        myScroller.addEventListener(eui.UIEvent.CHANGE_END, function () {
            if (myScroller.viewport.scrollV + myScroller.height >= myScroller.viewport.contentHeight) {
                if (!_this.end && _this.ableScroll) {
                    _this.ableScroll = false;
                    SocketX.getInstance().sendMsg(NetEvent.PK_RECORDS, { page: _this.page, pageSize: _this.pageSize });
                }
            }
        }, this);
        ViewManager.getInstance().showLoading('数据加载中...');
    };
    PkRecordScene.prototype.getData = function () {
        var _this = this;
        SocketX.getInstance().addEventListener(NetEvent.PK_RECORDS, function (data) {
            console.log("PkRecordScene -> init -> data", data);
            _this.ableScroll = true;
            ViewManager.getInstance().hideLoading();
            if (data.data.length == 0 && _this.page == 1) {
                var tip = new LineInfo('暂无挑战数据');
                tip.y = -150;
                _this.addChild(tip);
                return;
            }
            _this.updateGroup(data.data || []);
        });
        SocketX.getInstance().sendMsg(NetEvent.PK_RECORDS, { page: this.page, pageSize: this.pageSize });
    };
    PkRecordScene.prototype.updateGroup = function (list) {
        if (list.length < this.pageSize) {
            this.end = true;
        }
        this.page += 1;
        for (var _i = 0, list_1 = list; _i < list_1.length; _i++) {
            var data = list_1[_i];
            var item = new RecordItem(data);
            item.y = this.itemY + 10;
            this.groupView.addChild(item);
            this.itemY += 65;
        }
    };
    return PkRecordScene;
}(Scene));
__reflect(PkRecordScene.prototype, "PkRecordScene");
var RecordItem = (function (_super) {
    __extends(RecordItem, _super);
    function RecordItem(data) {
        var _this = _super.call(this) || this;
        _this.data = data;
        _this.width = 504;
        _this.height = 20;
        _this.init();
        return _this;
    }
    RecordItem.prototype.init = function () {
        var _this = this;
        var size = 20;
        var fightPerson = new egret.TextField;
        fightPerson.text = Util.getStrByWith(this.data.sendName, 100, 20) + '与' + Util.getStrByWith(this.data.acceptName, 100, 20) + '对战';
        fightPerson.width = 280;
        fightPerson.height = this.height;
        fightPerson.size = size;
        this.addChild(fightPerson);
        var result = new egret.TextField();
        result.text = this.data.pkResult.text;
        result.width = 100;
        result.height = this.height;
        result.size = size;
        result.x = fightPerson.width;
        result.textAlign = egret.HorizontalAlign.CENTER;
        if (this.data.pkResult.text == '平局') {
            result.textColor = 0xffffff;
        }
        else if (this.data.pkResult.text == '胜利') {
            result.textColor = Config.COLOR_MAIN;
        }
        else if (this.data.pkResult.text == '无效') {
            result.textColor = 0xf90008;
        }
        else {
            result.textColor = 0xb7b6b6;
        }
        this.addChild(result);
        var date = new egret.TextField();
        date.text = this.data.createTime;
        date.width = 125;
        date.height = this.height;
        date.size = size;
        date.x = fightPerson.width + result.width;
        date.textAlign = egret.HorizontalAlign.RIGHT;
        this.addChild(date);
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            SocketX.getInstance().addEventListener(NetEvent.PK_INFO, function (data) {
                var result = data.data;
                if (result.tipsCode == InviteStatus.WATTING) {
                    var pk = new PkInviteScene(InviteStatus.WATTING);
                    ViewManager.getInstance().changeScene(pk);
                }
                else {
                    result = DataManager.getInstance().convertPkResult(result);
                    var resultScene = new PkResultScene(result, 'pkRecord');
                    ViewManager.getInstance().changeScene(resultScene);
                }
            });
            SocketX.getInstance().sendMsg(NetEvent.PK_INFO, { pkCode: _this.data.pkCode });
        }, this);
    };
    RecordItem.prototype.updateScene = function () {
        var isConnect = SocketX.getInstance().isconnect;
        if (!isConnect) {
            ViewManager.getInstance().showLoading('连接中......');
            SocketX.getInstance().connectPersonPk(function () {
                setTimeout(function () {
                    ViewManager.getInstance().hideLoading();
                }, 1000);
            });
        }
    };
    return RecordItem;
}(eui.Group));
__reflect(RecordItem.prototype, "RecordItem");
//# sourceMappingURL=PkRecordScene.js.map
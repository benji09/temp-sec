var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 首页界面
 */
var IndexScene = (function (_super) {
    __extends(IndexScene, _super);
    function IndexScene() {
        return _super.call(this) || this;
    }
    IndexScene.prototype.init = function () {
        this.close_btn = '';
        this.setBackground('home_bg_png');
        this.name = 'home';
        this.createLayout();
    };
    IndexScene.prototype.createLayout = function () {
        var ratio = Util.getRatio();
        var stage = ViewManager.getInstance().stage;
        // 控制音乐播放
        var musicSwitch = new egret.Bitmap();
        musicSwitch.texture = RES.getRes('pause_png');
        musicSwitch.x = 20;
        musicSwitch.y = 20;
        musicSwitch.touchEnabled = true;
        this.addChild(musicSwitch);
        var audio = document.querySelector('#audio');
        musicSwitch.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            Util.playMusic('model_select_mp3');
            var isPaused = audio.paused;
            if (isPaused) {
                musicSwitch.texture = RES.getRes('play_png');
                musicStart();
            }
            else {
                musicSwitch.texture = RES.getRes('pause_png');
                musicStop();
            }
        }, this);
        // 排行榜
        var rank_btn = this.createRightButton('排行榜', function () {
            var scene = new RankCategoryScene();
            ViewManager.getInstance().changeScene(scene);
        });
        this.addChild(rank_btn);
        // 选项按钮
        var models = [
            { bg: 'home_item_01_png', y: 360, key: 1, label: '武器装备' },
            { bg: 'home_item_02_png', y: 660, key: 2, label: '答题闯关' },
            { bg: 'home_item_03_png', y: 660, key: 3, label: 'PK挑战' },
        ];
        for (var _i = 0, models_1 = models; _i < models_1.length; _i++) {
            var model = models_1[_i];
            var bg = Util.createBitmapByName(model.bg);
            var label = new egret.TextField;
            label.text = model.label;
            bg.width = ratio > 0.6 ? bg.width * 0.8 : bg.width;
            bg.height = ratio > 0.6 ? bg.height * 0.8 : bg.height;
            if (model.key == 1) {
                bg.x = (stage.stageWidth - bg.width) / 2;
            }
            else if (model.key == 2) {
                bg.x = 0;
            }
            else {
                bg.x = stage.stageWidth - bg.width;
            }
            bg.y = ratio > 0.6 ? model.y * 0.8 : model.y;
            label.x = bg.x;
            label.width = bg.width;
            label.textAlign = 'center';
            label.y = bg.y + bg.height - 40;
            this.addChild(bg);
            this.addChild(label);
            bg.touchEnabled = true;
            bg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch(model.key), this);
        }
        // 个人中心
        var userGroup = new eui.Group;
        userGroup.y = stage.stageHeight - 100;
        this.addChild(userGroup);
        var arrow = Util.createBitmapByName('home_arrow_png');
        arrow.x = (stage.stageWidth - arrow.width) / 2;
        userGroup.addChild(arrow);
        var userInfo = new egret.TextField;
        userInfo.text = '个人中心';
        userInfo.y = -4;
        userInfo.width = stage.stageWidth;
        userInfo.textAlign = 'center';
        userGroup.addChild(userInfo);
        userGroup.touchEnabled = true;
        userGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            var scene = new UserScene();
            Util.playMusic('model_select_mp3');
            ViewManager.getInstance().changeScene(scene);
        }, this);
    };
    // 页面跳转
    IndexScene.prototype.onTouch = function (key) {
        return function () {
            Util.playMusic('model_select_mp3');
            switch (key) {
                case 1:
                    var equipScene = new EquipmentScene();
                    ViewManager.getInstance().changeScene(equipScene);
                    break;
                case 2:
                    var trainScene = new TrainScene();
                    ViewManager.getInstance().changeScene(trainScene);
                    break;
                case 3:
                    var pk = new PkListScene();
                    ViewManager.getInstance().changeScene(pk);
                    break;
            }
        };
    };
    IndexScene.prototype.updateScene = function () {
        Http.getInstance().post(Url.HTTP_USER_INFO, "", function (res) {
            DataManager.getInstance().setUser(res.data);
            Util.setTitle("V来计划-" + res.data.teamName);
        });
    };
    return IndexScene;
}(Scene));
__reflect(IndexScene.prototype, "IndexScene");
//# sourceMappingURL=IndexScene.js.map
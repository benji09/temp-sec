var EquipmentConfigs = [
    { name: 'V书馆', icon: 'equip_icon_01_png', type: 20, qaids: '60' },
    { name: 'V情局', icon: 'equip_icon_02_png', type: 21, qaids: '61' },
    { name: 'V研所', icon: 'equip_icon_03_png', type: 22, qaids: '62' },
    { name: 'V基地', icon: 'equip_icon_04_png', type: 23, qaids: '63' }
];
//# sourceMappingURL=Common.js.map
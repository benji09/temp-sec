var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
/**
 * 题目信息
 */
var Topic = (function (_super) {
    __extends(Topic, _super);
    function Topic(subject, width, isTeamAnswer) {
        var _this = _super.call(this) || this;
        _this.options = {};
        _this.canSelected = true;
        _this.subject = subject;
        _this._width = width;
        _this.isTeamAnswer = isTeamAnswer;
        _this.init();
        return _this;
    }
    Topic.prototype.init = function () {
        var _this = this;
        console.log("Topic -> init -> this.getCorrectItem", this.getCorrectItem);
        var topicBg = Util.createBitmapByName('option_normal_png');
        if (typeof this._width === 'number' && this._width) {
            topicBg.width = this._width;
        }
        this.width = topicBg.width;
        //题目标题
        var qTitle = new egret.TextField();
        qTitle.y = 10;
        qTitle.width = this.width;
        var titleText = this.subject.title;
        if (this.subject.type == TopicType.MULTIPLE) {
            titleText += "(多选题)";
        }
        this.title = qTitle;
        qTitle.text = titleText;
        qTitle.bold = true;
        qTitle.lineSpacing = 10;
        qTitle.size = 28;
        this.addChild(qTitle);
        var y = qTitle.y + qTitle.height + 60;
        var optionNumArr = ['A', 'B', 'C', 'D', 'E', 'F'];
        this.subject.options.forEach(function (item, i) {
            if (item.name && item.name.length >= 1) {
                var topicItem = new TopicItem(optionNumArr[i], item, _this.width, _this.isTeamAnswer);
                topicItem.y = y;
                _this.addChild(topicItem);
                _this.options[item.flag] = topicItem;
                topicItem.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onSelect(item.flag), _this);
                y += topicItem.height + 30;
            }
        });
        this.height = y + 100;
    };
    Topic.prototype.onSelect = function (flag) {
        var _this = this;
        return function () {
            Util.playMusic('model_select_mp3');
            if (!_this.canSelected)
                return;
            //TODO 处理新的问题
            for (var k in _this.options) {
                var topicItem = _this.options[k];
                if (k == flag) {
                    if (_this.subject.type == TopicType.MULTIPLE) {
                        if (!_this.selected)
                            _this.selected = [];
                        var index = _this.selected.indexOf(flag);
                        if (index > -1) {
                            _this.selected.splice(index, 1);
                            topicItem.setStatus(TopicItem.STATUS_NORMAL);
                        }
                        else {
                            _this.selected.push(flag);
                            topicItem.setStatus(TopicItem.STATUS_SELECTED);
                        }
                    }
                    else {
                        _this.selected = flag;
                        topicItem.setStatus(TopicItem.STATUS_SELECTED);
                    }
                }
                else {
                    if (_this.subject.type == TopicType.MULTIPLE) {
                        continue;
                    }
                    topicItem.reset();
                }
            }
        };
    };
    /**
     * 获取答题选项
     */
    Topic.prototype.getSelect = function () {
        if (!this.selected)
            return null;
        if (this.subject.type == TopicType.MULTIPLE)
            return this.selected.join("");
        return this.selected;
    };
    /**
     * 设置题目状态
     */
    Topic.prototype.setSelectedStatus = function (status) {
        switch (this.subject.type) {
            case TopicType.SINGLE:
            case TopicType.MULTIPLE:
                var result = this.subject.result.split(',');
                for (var key in this.options) {
                    var option = this.options[key];
                    if (Util.inArray(key, this.selected)) {
                        if (Util.inArray(key, result)) {
                            option.setStatus(TopicItem.STATUS_OK);
                        }
                        else {
                            option.setStatus(TopicItem.STATUS_ERROR);
                        }
                    }
                    else {
                        if (Util.inArray(key, result)) {
                            option.setStatus(this.subject.type == TopicType.SINGLE ? TopicItem.STATUS_OK : TopicItem.STATUS_CORRECT);
                        }
                    }
                }
                break;
            case TopicType.BLANK:
                switch (status) {
                    case TopicItem.STATUS_OK:
                        this.textFlow[1]['style'].textColor = 0xABBF11;
                        this.title.textFlow = this.textFlow;
                        break;
                    case TopicItem.STATUS_ERROR:
                        this.textFlow[1]['style'].textColor = 0xFF0000;
                        this.title.textFlow = this.textFlow;
                        break;
                }
                break;
        }
    };
    /**
     * 不能选择
     */
    Topic.prototype.setDisableSelected = function () {
        this.canSelected = false;
    };
    /**
     * 判断题目的准确性
     */
    Topic.prototype.getSelectResult = function () {
        switch (this.subject.type) {
            case TopicType.SINGLE:
            case TopicType.BLANK:
                if (this.selected == this.subject.result) {
                    return true;
                }
                return false;
            case TopicType.MULTIPLE:
                var result = this.subject.result.split(',');
                if (result.sort().toString() == this.selected.sort().toString()) {
                    return true;
                }
                return false;
        }
    };
    Topic.prototype.getQAttrId = function () {
        return this.subject.qattrid;
    };
    /**
     * 设置正确选项
     */
    Topic.prototype.setCorrectItem = function () {
        var _this = this;
        this.subject.result.split(',').map(function (key) {
            _this.options[key].setStatus(TopicItem.STATUS_CORRECT);
        });
    };
    Object.defineProperty(Topic.prototype, "getCorrectItem", {
        get: function () {
            return this.subject.result.split(',');
        },
        enumerable: true,
        configurable: true
    });
    return Topic;
}(eui.Group));
__reflect(Topic.prototype, "Topic");
var TopicType;
(function (TopicType) {
    TopicType[TopicType["SINGLE"] = 1] = "SINGLE";
    TopicType[TopicType["MULTIPLE"] = 2] = "MULTIPLE";
    TopicType[TopicType["BLANK"] = 3] = "BLANK";
})(TopicType || (TopicType = {}));
var TopicItem = (function (_super) {
    __extends(TopicItem, _super);
    function TopicItem(optionNum, option, width, isTeamAnswer) {
        var _this = _super.call(this) || this;
        _this.BG_RES = ['option_normal_png', 'option_select_png', 'option_error_png', 'option_select_png', 'option_select_png'];
        _this.ICON_RES = { 2: "icon_err_png", 3: "icon_ok_png" };
        _this.width = width;
        _this.option = option;
        _this.optionNum = optionNum;
        _this.isTeamAnswer = isTeamAnswer;
        _this.status = TopicItem.STATUS_NORMAL;
        _this.touchEnabled = true;
        _this.init();
        return _this;
    }
    TopicItem.prototype.init = function () {
        var bg = Util.createBitmapByName('option_normal_png');
        bg.height = this.width === bg.width ? bg.height : 96;
        var textWidth = this.width === bg.width ? 380 : 320;
        var textX = this.width === bg.width ? 138 : 120;
        var textY = 26;
        var textSize = 26;
        var textSpacing = 10;
        // 答案内容
        var text = new egret.TextField;
        text.text = this.option.name;
        text.width = textWidth;
        text.lineSpacing = textSpacing;
        text.x = textX;
        text.size = textSize;
        text.textAlign = egret.HorizontalAlign.CENTER;
        text.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.addChild(text);
        this.text = text;
        var line = Math.ceil(text.textWidth / textWidth);
        var height = textY * 2 + line * text.textHeight;
        this.height = height < bg.height ? bg.height : height;
        text.height = this.height - 10;
        this.initBg();
        // 答案前缀
        var prefix = new egret.TextField;
        prefix.text = this.optionNum;
        prefix.width = 110;
        prefix.height = this.height;
        prefix.size = 40;
        prefix.textAlign = egret.HorizontalAlign.CENTER;
        prefix.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.addChild(prefix);
    };
    TopicItem.prototype.initBg = function () {
        var bg = Util.createBitmapByName(this.BG_RES[this.status]);
        var flag = bg.width == this.width;
        bg.width = this.width - 1;
        bg.height = this.height;
        this.addChild(bg);
        this.bg = bg;
        var icon = new egret.Bitmap();
        if (this.status == TopicItem.STATUS_OK || this.status == TopicItem.STATUS_ERROR) {
            this.icon.texture = RES.getRes(this.ICON_RES[this.status]);
        }
        icon.x = flag ? 520 : 438;
        icon.y = flag ? 5 : 12;
        this.icon = icon;
        this.addChild(icon);
    };
    TopicItem.prototype.onTap = function () {
        this.setStatus(TopicItem.STATUS_SELECTED);
    };
    /**
     * 重置状态
     */
    TopicItem.prototype.reset = function () {
        this.setStatus(TopicItem.STATUS_NORMAL);
    };
    /**
     * 设置状态  默认单选
     */
    TopicItem.prototype.setStatus = function (status) {
        if (this.status == status)
            return;
        this.status = status;
        this.bg.texture = RES.getRes(this.BG_RES[status]);
        if (this.isTeamAnswer)
            return;
        if (status == TopicItem.STATUS_OK || status == TopicItem.STATUS_ERROR) {
            this.icon.visible = true;
            this.icon.texture = RES.getRes(this.ICON_RES[status]);
        }
        else {
            this.icon.visible = false;
        }
    };
    TopicItem.prototype.release = function () {
        this.removeChildren();
    };
    TopicItem.STATUS_NORMAL = 0;
    TopicItem.STATUS_SELECTED = 1;
    TopicItem.STATUS_ERROR = 2;
    TopicItem.STATUS_OK = 3;
    TopicItem.STATUS_CORRECT = 4;
    return TopicItem;
}(egret.DisplayObjectContainer));
__reflect(TopicItem.prototype, "TopicItem");
//# sourceMappingURL=Topic.js.map
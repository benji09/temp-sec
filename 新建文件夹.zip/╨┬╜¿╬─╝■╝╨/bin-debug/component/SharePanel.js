var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var SharePanel = (function (_super) {
    __extends(SharePanel, _super);
    function SharePanel() {
        var _this = _super.call(this) || this;
        _this.init();
        return _this;
    }
    SharePanel.prototype.init = function () {
        var _this = this;
        var stage = ViewManager.getInstance().stage;
        var mask = Util.drawRoundRect(0, 0x000000, 0x000000, stage.stageWidth, stage.stageHeight, 0, 0.8);
        this.addChild(mask);
        var share_arrow = Util.createBitmapByName('share_arrow_png');
        share_arrow.x = 580;
        this.addChild(share_arrow);
        var share_tips;
        if (egret.Capabilities.os == 'Android') {
            share_tips = Util.createBitmapByName('share_tips_android_jpg');
            share_tips.width = stage.stageWidth;
            share_tips.height = stage.stageWidth * 0.634;
        }
        else {
            share_tips = Util.createBitmapByName('share_tips_jpg');
            share_tips.width = stage.stageWidth;
            share_tips.height = stage.stageWidth * 0.876;
        }
        share_tips.y = stage.stageHeight - share_tips.height;
        this.addChild(share_tips);
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            Util.playMusic('model_select_mp3');
            _this.parent.removeChild(_this);
        }, this);
    };
    return SharePanel;
}(eui.Group));
__reflect(SharePanel.prototype, "SharePanel");
var AlertLoading = (function (_super) {
    __extends(AlertLoading, _super);
    function AlertLoading(text) {
        if (text === void 0) { text = ''; }
        var _this = _super.call(this) || this;
        _this.text = text;
        _this.init();
        return _this;
    }
    AlertLoading.prototype.init = function () {
        this.height = 220;
        this.width = 500;
        var mask = Util.createBitmapByName('mask_png');
        mask.alpha = 0.4;
        mask.width = this.width;
        mask.height = this.height;
        this.addChild(mask);
        var loading = Util.createBitmapByName('loading_png');
        loading.width = 64;
        loading.height = 64;
        loading.x = this.width / 2;
        loading.y = loading.height / 2 + 20;
        loading.anchorOffsetX = loading.width / 2;
        loading.anchorOffsetY = loading.height / 2;
        egret.Tween.get(loading, { loop: true }).to({ rotation: 360 }, 2500);
        this.addChild(loading);
        var loadingText = new egret.TextField();
        loadingText.text = this.text;
        loadingText.size = 28;
        loadingText.y = loading.y + loading.height + 10;
        loadingText.width = this.width;
        loadingText.textAlign = egret.HorizontalAlign.CENTER;
        loadingText.verticalAlign = egret.VerticalAlign.MIDDLE;
        loadingText.lineSpacing = 10;
        this.loadingText = loadingText;
        this.addChild(loadingText);
    };
    AlertLoading.prototype.setText = function (text) {
        this.text = text;
        this.loadingText.text = this.text;
    };
    return AlertLoading;
}(eui.Group));
__reflect(AlertLoading.prototype, "AlertLoading");
//# sourceMappingURL=SharePanel.js.map
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var ProcessBar = (function (_super) {
    __extends(ProcessBar, _super);
    function ProcessBar(len, curIdx) {
        var _this = _super.call(this) || this;
        _this.barArr = [];
        _this.len = len;
        _this.curIdx = curIdx;
        _this.init();
        return _this;
    }
    ProcessBar.prototype.init = function () {
        var x = 10;
        var bg = Util.createBitmapByName('process_undone_png');
        for (var i = 0; i < this.len; i++) {
            var bar = new egret.Bitmap();
            var texture = RES.getRes('process_undone_png');
            bar.texture = texture;
            bar.x = x;
            var w = bg.width / this.len * 8;
            bar.width = w > bg.width ? bg.width : w;
            this.barArr.push(bar);
            this.addChild(bar);
            x += bar.width;
        }
        var line = new egret.Shape;
        line.graphics.lineStyle(1, 0xffffff);
        line.graphics.moveTo(0, 20);
        line.graphics.lineTo(10 + this.len * this.barArr[0].width, 20);
        this.addChild(line);
        var present = new egret.TextField;
        present.x = line.width + 20;
        present.size = 20;
        this.addChild(present);
        this.present = present;
        this.setRate(this.curIdx);
    };
    ProcessBar.prototype.setRate = function (index) {
        this.barArr.forEach(function (item, i) { return i < index && (item.texture = RES.getRes('process_done_png')); });
        this.present.text = index + '/' + this.len;
    };
    return ProcessBar;
}(eui.Group));
__reflect(ProcessBar.prototype, "ProcessBar");
//# sourceMappingURL=ProcessBar.js.map
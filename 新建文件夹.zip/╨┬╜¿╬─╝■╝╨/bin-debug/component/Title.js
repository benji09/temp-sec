var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Title = (function (_super) {
    __extends(Title, _super);
    function Title(text, y, iconName) {
        if (y === void 0) { y = 120; }
        var _this = _super.call(this) || this;
        _this.text = text;
        _this.iconName = iconName;
        _this.y = y;
        _this.init();
        return _this;
    }
    Title.prototype.init = function () {
        var stage = ViewManager.getInstance().stage;
        this.width = stage.stageWidth;
        this.height = 114;
        if (this.iconName) {
            var icon = Util.createBitmapByName(this.iconName);
            icon.x = 244;
            icon.y = 16;
            this.addChild(icon);
        }
        var title = new egret.TextField;
        title.text = this.text;
        title.width = this.width;
        title.height = this.height;
        title.textAlign = egret.HorizontalAlign.CENTER;
        title.verticalAlign = egret.VerticalAlign.MIDDLE;
        title.x = this.iconName ? 30 : 0;
        title.size = 50;
        title.bold = true;
        this.addChild(title);
    };
    return Title;
}(eui.Group));
__reflect(Title.prototype, "Title");
//# sourceMappingURL=Title.js.map
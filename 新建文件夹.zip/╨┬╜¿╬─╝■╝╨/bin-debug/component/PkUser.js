var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PkUser = (function (_super) {
    __extends(PkUser, _super);
    function PkUser(userInfo, type, score, time) {
        if (type === void 0) { type = 'left'; }
        var _this = _super.call(this) || this;
        _this.userInfo = userInfo;
        _this.type = type;
        _this.score = score;
        _this.time = time;
        _this.init();
        return _this;
    }
    PkUser.prototype.init = function () {
        var avatar_name = "pk_avatar_" + this.type + "_png";
        // 头像边框
        var avatar_border = Util.createBitmapByName(avatar_name);
        this.width = avatar_border.width;
        this.height = avatar_border.height;
        this.addChild(avatar_border);
        // 头像
        try {
            var url = Config.DEBUG ? 'http://thirdwx.qlogo.cn/mmopen/vi_32/cKqXyr3j6icxgs4TSy6cpMMkbsWXSdAfXqFkLysDgacAbrzulVqj6eulmZGRianMKqDJ9nUbpf1o0VqWXNtKP5yA/132' : this.userInfo.avatar;
            var avatar = Util.setUserImg(url, 172);
            avatar.x = 32;
            avatar.y = 32;
            this.addChild(avatar);
        }
        catch (error) {
        }
        // 名字
        var user_name = new egret.TextField;
        var nickName = this.userInfo && this.userInfo.nickName || '??';
        user_name.text = Util.getStrByWith(nickName, 180, 30);
        user_name.x = (this.width - user_name.textWidth) / 2;
        user_name.y = this.height + 30;
        this.addChild(user_name);
        // 正确率
        if (this.score) {
            var resultInfo = new egret.TextField;
            resultInfo.textFlow = [
                { text: '正确率：' + this.score },
                { text: '\n' + this.time },
            ];
            resultInfo.width = this.width;
            resultInfo.y = user_name.y + user_name.textHeight + 15;
            resultInfo.textAlign = egret.HorizontalAlign.CENTER;
            resultInfo.lineSpacing = 15;
            resultInfo.size = 22;
            this.addChild(resultInfo);
        }
    };
    return PkUser;
}(eui.Group));
__reflect(PkUser.prototype, "PkUser");
var TeamUser = (function (_super) {
    __extends(TeamUser, _super);
    function TeamUser(userinfo, type) {
        if (type === void 0) { type = UserPositionType.LEFT; }
        var _this = _super.call(this) || this;
        _this.canClick = true;
        _this.userinfo = userinfo || {};
        // test begin
        // this.userinfo.nickName = '周武Zhou Wu'
        // this.userinfo.avatar = 'http://127.0.0.1:8360/uploads/avatar/13886593297_avatar.jpg'
        // test end
        _this.type = type;
        _this.init();
        return _this;
    }
    TeamUser.prototype.init = function () {
        var bgname = 'pk_yellow_list_png';
        if (this.type === UserPositionType.RIGHT) {
            bgname = 'pk_green_list_png';
        }
        var bg = Util.createBitmapByName(bgname);
        this.width = bg.width;
        this.height = bg.height;
        this.addChild(bg);
        // 头像
        var avatar = new egret.Bitmap();
        avatar.width = avatar.height = 112;
        avatar.x = this.type == UserPositionType.LEFT ? 170 : 3;
        avatar.y = 3;
        this.addChild(avatar);
        this.avatar = avatar;
        if (this.userinfo) {
            Util.setUserImg(this.userinfo.avatar, avatar);
        }
        var shape = new egret.Shape();
        this.addChild(shape);
        var graphics = shape.graphics;
        graphics.beginFill(0xffffff);
        graphics.drawCircle(avatar.x + avatar.width / 2, avatar.y + avatar.height / 2, avatar.width / 2);
        graphics.endFill();
        avatar.mask = shape;
        // 人名
        var name = new egret.TextField();
        name.width = 150;
        name.size = 26;
        name.text = this.userinfo.nickName ? Util.getStrByWith(this.userinfo.nickName, name.width - 20, name.size) : '';
        name.x = this.type == UserPositionType.LEFT ? 0 : 130;
        name.height = bg.height - 10;
        name.wordWrap = false;
        name.multiline = false;
        name.textAlign = this.type == UserPositionType.LEFT ? 'right' : 'left';
        name.verticalAlign = 'middle';
        this.addChild(name);
        this.nameText = name;
        // 准备图标
        var readyImg = Util.createBitmapByName('pk_icon_ready_png');
        if (this.type == UserPositionType.LEFT) {
            readyImg.x = 140;
        }
        else {
            readyImg.x = 115;
        }
        readyImg.y = 80;
        this.readyImg = readyImg;
        this.addChild(readyImg);
        this.readyImg.visible = false;
    };
    TeamUser.prototype.addUserEventListener = function (callback, obj) {
        var _this = this;
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            if (!_this.canClick)
                return;
            var current = new Date().getTime();
            if (_this.clickTime && current - _this.clickTime < 1000)
                return;
            _this.clickTime = current;
            // this.canClick = false
            callback.bind(obj)(_this.userinfo);
        }, this);
    };
    TeamUser.prototype.resetClick = function () {
        this.canClick = true;
        this.clickTime = 0;
    };
    TeamUser.prototype.setDisableClick = function () {
        this.canClick = false;
    };
    /**
     * 更新用户信息
     */
    TeamUser.prototype.updateUser = function (userinfo) {
        this.userinfo = userinfo;
        //清空头像
        var texture = new egret.Texture();
        this.avatar.texture = texture;
        if (userinfo == null) {
            this.nameText.text = '';
            this.readyImg.visible = false;
            this.resetClick();
        }
        else {
            this.nameText.text = Util.getStrByWith(this.userinfo.nickName, 150 - 20, 26);
            Util.setUserImg(userinfo.avatar, this.avatar);
        }
    };
    /**
     * 准备好
     */
    TeamUser.prototype.setReady = function () {
        this.readyImg.visible = true;
    };
    /**
     * 设置用户结果状态
     */
    TeamUser.prototype.setWinnerStatus = function (status) {
        if (this.status == status)
            return;
        this.status = status;
        if (this.resultText) {
            this.resultText.parent.removeChild(this.resultText);
            this.resultText = null;
        }
        var textObj = {
            1: '成功',
            2: '平局',
            3: 'MVP',
            4: '失败'
        };
        var text = new egret.TextField;
        text.text = textObj[status];
        text.textColor = this.type == UserPositionType.LEFT ? 0x4b4c03 : 0xffffff;
        text.size = 20;
        text.x = this.type == UserPositionType.LEFT ? 100 : 130;
        text.y = 80;
        this.resultText = text;
        this.addChild(text);
        if (status === WinnerStatus.LOSE) {
            var grayFilter = Util.grayFilter();
            this.filters = [grayFilter];
        }
    };
    return TeamUser;
}(eui.Group));
__reflect(TeamUser.prototype, "TeamUser");
var LiteTeamUser = (function (_super) {
    __extends(LiteTeamUser, _super);
    function LiteTeamUser(userinfo, type) {
        if (type === void 0) { type = UserPositionType.LEFT; }
        var _this = _super.call(this) || this;
        _this.userinfo = userinfo || {};
        // test begin
        // this.userinfo.nickName = '周武'
        // this.userinfo.avatar = 'http://127.0.0.1:8360/uploads/avatar/13886593297_avatar.jpg'
        // test end
        _this.type = type;
        _this.init();
        return _this;
    }
    LiteTeamUser.prototype.init = function () {
        var bgname = 'pk_yellow_list_lite_png';
        if (this.type === UserPositionType.RIGHT) {
            bgname = 'pk_green_list_lite_png';
        }
        var bg = Util.createBitmapByName(bgname);
        this.width = bg.width;
        this.height = bg.height;
        this.addChild(bg);
        // 头像
        if (this.userinfo && this.userinfo.avatar) {
            var avatar = Util.setUserImg(this.userinfo.avatar, 112);
            avatar.x = this.type == UserPositionType.LEFT ? 54 : 3;
            avatar.y = 3;
            this.addChild(avatar);
        }
        // 人名
        if (this.userinfo && this.userinfo.nickName) {
            var name_1 = new egret.TextField();
            name_1.text = this.userinfo.nickName;
            name_1.x = this.type == UserPositionType.LEFT ? 0 : 110;
            name_1.width = 60;
            name_1.height = bg.height - 20;
            name_1.wordWrap = false;
            name_1.multiline = false;
            name_1.textAlign = this.type == UserPositionType.LEFT ? 'right' : 'left';
            name_1.verticalAlign = 'bottom';
            name_1.size = 18;
            this.addChild(name_1);
        }
    };
    return LiteTeamUser;
}(eui.Group));
__reflect(LiteTeamUser.prototype, "LiteTeamUser");
//# sourceMappingURL=PkUser.js.map
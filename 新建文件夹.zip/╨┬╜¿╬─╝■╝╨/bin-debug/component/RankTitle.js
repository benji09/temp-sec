var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var RankTitle = (function (_super) {
    __extends(RankTitle, _super);
    function RankTitle(text) {
        var _this = _super.call(this) || this;
        _this.init(text);
        return _this;
    }
    RankTitle.prototype.init = function (text) {
        var line = Util.createBitmapByName('rank_line_png');
        line.y = 40;
        line.blendMode = egret.BlendMode.ADD;
        this.line = line;
        this.addChild(line);
        this.width = line.width;
        var label = new egret.TextField;
        label.text = text;
        label.size = 34;
        label.width = this.width;
        label.textAlign = egret.HorizontalAlign.CENTER;
        this.addChild(label);
        this.touchEnabled = true;
    };
    RankTitle.prototype.hideFlag = function () {
        this.line.visible = false;
    };
    RankTitle.prototype.showFlag = function () {
        this.line.visible = true;
    };
    return RankTitle;
}(eui.Group));
__reflect(RankTitle.prototype, "RankTitle");
//# sourceMappingURL=RankTitle.js.map
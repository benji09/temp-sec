var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var VProgress = (function (_super) {
    __extends(VProgress, _super);
    function VProgress(max) {
        if (max === void 0) { max = 10; }
        var _this = _super.call(this) || this;
        _this.shapeW = 25;
        _this.shapeH = 12;
        _this.max = max;
        _this.init();
        return _this;
    }
    VProgress.prototype.init = function () {
        var space = 30;
        this.width = this.shapeW;
        var group = new eui.Group;
        group.width = this.shapeW;
        group.height = (this.shapeH + space) * this.max;
        this.addChild(group);
        this.processGroup = group;
        for (var i = 0; i < this.max; i++) {
            var shape = Util.drawRoundRect(0, 0xffffff, 0xffffff, this.shapeW, this.shapeH, 10);
            shape.y = group.height - (this.shapeH + space) * i;
            group.addChild(shape);
        }
        var process_text = new egret.TextField;
        process_text.text = '1/' + this.max;
        process_text.y = group.height + 40;
        process_text.anchorOffsetX = 8;
        process_text.textColor = Config.COLOR_MAIN;
        process_text.size = 20;
        this.addChild(process_text);
        this.process_text = process_text;
    };
    VProgress.prototype.setRate = function (rate) {
        var _this = this;
        if (rate > 10)
            return;
        this.process_text.text = rate + '/' + this.max;
        this.processGroup.$children.forEach(function (item, index, arr) {
            if (rate > index) {
                var y = item.y;
                var shape = Util.drawRoundRect(0, 0xffffff, Config.COLOR_MAIN, _this.shapeW, _this.shapeH, 10);
                shape.y = y;
                arr.splice(index, 1, shape);
            }
        });
    };
    return VProgress;
}(eui.Group));
__reflect(VProgress.prototype, "VProgress");
//# sourceMappingURL=VProgress.js.map
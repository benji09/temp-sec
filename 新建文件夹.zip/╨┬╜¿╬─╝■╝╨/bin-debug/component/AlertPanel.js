var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var AlertPanel = (function (_super) {
    __extends(AlertPanel, _super);
    function AlertPanel(text, iconName, h, tid, isAnswer) {
        var _this = _super.call(this) || this;
        _this.confirm = function () {
            ViewManager.getInstance().backByName('trainLevelScene');
        };
        _this.back = function () {
            _this.parent.removeChild(_this);
        };
        _this.text = text;
        _this.iconName = iconName;
        _this.h = h;
        _this.tid = tid;
        _this.isAnswer = isAnswer;
        _this.init();
        return _this;
    }
    AlertPanel.prototype.init = function () {
        var _this = this;
        var stage = ViewManager.getInstance().stage;
        var mask = Util.createBitmapByName('bg_png');
        mask.width = stage.stageWidth;
        mask.height = stage.stageHeight;
        this.addChild(mask);
        var group = new eui.Group;
        this.addChild(group);
        var border = Util.createBitmapByName('alert_border_png');
        group.addChild(border);
        group.width = border.width;
        group.height = border.height;
        if (this.h) {
            group.height = border.height = this.h;
        }
        group.x = (stage.stageWidth - group.width) / 2;
        group.y = 750 - group.height;
        if (this.iconName) {
            var icon = Util.createBitmapByName(this.iconName);
            icon.x = (group.width - icon.width) / 2;
            icon.y = 30;
            group.addChild(icon);
        }
        var label = new egret.TextField;
        label.text = this.text;
        label.width = group.width;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.lineSpacing = 15;
        label.y = this.iconName ? 120 : 45;
        group.addChild(label);
        var close = new Button('icon_next_png', this.isAnswer ? '确认' : '返回', this.isAnswer ? this.confirm : this.back);
        close.x = this.isAnswer ? stage.stageWidth - close.width - 100 : (stage.stageWidth - close.width) / 2;
        close.y = 866;
        this.addChild(close);
        this.close = close;
        if (this.isAnswer) {
            var cancelBtn = new Button('icon_remove_png', '取消', this.back);
            cancelBtn.x = 100;
            cancelBtn.y = close.y;
            this.addChild(cancelBtn);
        }
        if (this.iconName && this.iconName == 'icon_pass_png' && this.tid) {
            close.x = 100;
            var flag_1 = true;
            var continueTrain = new Button('icon_next_png', '继续闯关', function () {
                if (!flag_1)
                    return;
                flag_1 = false;
                Http.getInstance().post(Url.HTTP_TRAIN_START, { type: 1, tid: _this.tid }, function (json) {
                    if (json.data.questions.length > 0) {
                        var answer = new Answers();
                        answer.lifecycleId = json.data.lifecycleId;
                        answer.questions = json.data.questions;
                        var badge = DataManager.getInstance().getCurrentBandge();
                        var nextLevel = badge.levels.filter(function (item) { return item.levelid == _this.tid; });
                        var scene = new AnswerScene(answer, AnswerType.TRAIN, nextLevel[0]);
                        ViewManager.getInstance().changeScene(scene);
                    }
                    else {
                        var alert_1 = new AlertPanel("提示\n题库未设置");
                        _this.addChild(alert_1);
                        flag_1 = true;
                    }
                });
            });
            continueTrain.x = stage.stageWidth - continueTrain.width - close.x;
            continueTrain.y = close.y;
            this.addChild(continueTrain);
        }
    };
    AlertPanel.prototype.setFn = function (fn) {
        this.close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.back, this);
        this.close.addEventListener(egret.TouchEvent.TOUCH_TAP, fn, this);
    };
    return AlertPanel;
}(eui.Group));
__reflect(AlertPanel.prototype, "AlertPanel");
//# sourceMappingURL=AlertPanel.js.map
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var LineInfo = (function (_super) {
    __extends(LineInfo, _super);
    function LineInfo(text, text2) {
        var _this = _super.call(this) || this;
        _this.text = text;
        _this.text2 = text2;
        _this.init();
        return _this;
    }
    LineInfo.prototype.init = function () {
        var tip = new egret.TextField;
        tip.text = this.text;
        tip.width = ViewManager.getInstance().stage.stageWidth;
        tip.textAlign = egret.HorizontalAlign.CENTER;
        tip.y = 806;
        tip.size = 42;
        tip.bold = true;
        tip.lineSpacing = 20;
        this.tip = tip;
        this.addChild(tip);
    };
    LineInfo.prototype.setText = function (text) {
        this.tip.text = text;
    };
    return LineInfo;
}(eui.Group));
__reflect(LineInfo.prototype, "LineInfo");
//# sourceMappingURL=LineInfo.js.map
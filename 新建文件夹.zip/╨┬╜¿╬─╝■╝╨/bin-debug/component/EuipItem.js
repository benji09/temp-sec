var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var EquipItem = (function (_super) {
    __extends(EquipItem, _super);
    function EquipItem(data) {
        var _this = _super.call(this) || this;
        _this.data = data;
        _this.init();
        return _this;
    }
    EquipItem.prototype.init = function () {
        var type = this.data.type == EquipType.MP4 ? 'mp4' : this.data.type == EquipType.PDF ? 'pdf' : 'img';
        var listBg = Util.createBitmapByName("equip_bg_" + type + "_png");
        this.width = listBg.width;
        this.height = listBg.height;
        this.addChild(listBg);
        var title = new egret.TextField();
        title.text = this.data.title;
        title.width = 320;
        title.height = this.height;
        title.x = 50;
        title.verticalAlign = egret.VerticalAlign.MIDDLE;
        this.addChild(title);
    };
    return EquipItem;
}(eui.Group));
__reflect(EquipItem.prototype, "EquipItem");
//# sourceMappingURL=EuipItem.js.map
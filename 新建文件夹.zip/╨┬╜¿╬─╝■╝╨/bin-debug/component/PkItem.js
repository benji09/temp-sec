var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var PkItem = (function (_super) {
    __extends(PkItem, _super);
    function PkItem(data) {
        var _this = _super.call(this) || this;
        _this.data = data;
        _this.init();
        return _this;
    }
    PkItem.prototype.init = function () {
        var _this = this;
        var stageW = ViewManager.getInstance().stage.stageWidth;
        var ratio = Util.getRatio();
        var grayFilter = Util.grayFilter();
        var icon = Util.createBitmapByName(this.data.icon);
        icon.width = ratio > 0.6 ? icon.width * 0.8 : icon.width;
        icon.height = ratio > 0.6 ? icon.height * 0.8 : icon.height;
        icon.x = (stageW - icon.width) / 2;
        icon.filters = this.data.status === 0 ? [grayFilter] : [];
        icon.blendMode = egret.BlendMode.ADD;
        this.addChild(icon);
        if (this.data.title) {
            var group = new eui.Group;
            this.addChild(group);
            var titleBg = Util.createBitmapByName('pk_btn_png');
            group.width = titleBg.width;
            group.height = titleBg.height;
            group.x = (stageW - group.width) / 2;
            group.y = icon.height + 40;
            group.addChild(titleBg);
            var title = new egret.TextField();
            title.text = this.data.title;
            title.width = titleBg.width;
            title.height = titleBg.height;
            title.verticalAlign = egret.VerticalAlign.MIDDLE;
            title.textAlign = egret.HorizontalAlign.CENTER;
            title.textColor = Config.COLOR_MAIN;
            title.size = 36;
            group.addChild(title);
            if (this.data.status === 0) {
                group.filters = [grayFilter];
                var lock = Util.createBitmapByName('lock_png');
                var ratio_1 = lock.width / lock.height;
                lock.width = 50;
                lock.height = lock.width / ratio_1;
                lock.x = (group.width - lock.width) / 2;
                lock.y = (group.height - lock.height) / 2;
                group.addChild(lock);
            }
            var userInfo_1 = DataManager.getInstance().getUser();
            group.touchEnabled = true;
            group.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
                if (_this.data.status === 0) {
                    return;
                }
                if (userInfo_1.teamId == 1327) {
                    ViewManager.getInstance().showLoading('默认战队请到QA环境体验此功能！');
                    setTimeout(function () {
                        ViewManager.getInstance().hideLoading();
                    }, 2000);
                    return;
                }
                Util.playMusic('model_select_mp3');
                var scene = new PkMatchScene();
                ViewManager.getInstance().changeScene(scene);
            }, this);
        }
    };
    return PkItem;
}(eui.Group));
__reflect(PkItem.prototype, "PkItem");
//# sourceMappingURL=PkItem.js.map
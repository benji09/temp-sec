var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Radar = (function (_super) {
    __extends(Radar, _super);
    function Radar(data, width, height) {
        var _this = _super.call(this) || this;
        data.push(data.shift());
        _this.data = data;
        _this.shape = new egret.Shape();
        _this.addChild(_this.shape);
        _this.drawRadar(width, height);
        return _this;
    }
    Radar.prototype.drawRadar = function (width, height) {
        var step = this.data.length;
        var r = width / 2;
        var graphics = this.shape.graphics;
        var points = [];
        // 画底部多边形
        var sx_1 = 0;
        var sy_1 = 0;
        graphics.lineStyle(2, 0xffffff);
        for (var i = 0; i < step; i++) {
            var rad = ((2 * Math.PI) / step) * i;
            var x = r + Math.cos(rad) * r;
            var y = r + Math.sin(rad) * r;
            points.push({ x: x, y: y });
            if (i == 0) {
                sx_1 = x;
                sy_1 = y;
                graphics.moveTo(x, y);
            }
            else {
                graphics.lineTo(x, y);
            }
        }
        graphics.lineTo(sx_1, sy_1);
        graphics.endFill();
        // 不规则遮罩
        var sx = 0;
        var sy = 0;
        graphics.lineStyle(0, 0x534da6);
        graphics.beginFill(0x534da6, 1);
        for (var i = 0; i < step; i++) {
            var rad = ((2 * Math.PI) / step) * i;
            var rate = this.data[i].rate > 1 ? 1 : this.data[i].rate;
            var x = r + Math.cos(rad) * r * rate;
            var y = r + Math.sin(rad) * r * rate;
            if (i == 0) {
                sx = x;
                sy = y;
                graphics.moveTo(x, y);
            }
            else {
                graphics.lineTo(x, y);
            }
        }
        graphics.lineTo(sx, sy);
        graphics.endFill();
        graphics.lineStyle(2, 0xffffff);
        // 中间连接线
        for (var k in points) {
            graphics.moveTo(width / 2, height / 2);
            graphics.lineTo(points[k]['x'], points[k]['y']);
        }
        graphics.endFill();
    };
    return Radar;
}(egret.Sprite));
__reflect(Radar.prototype, "Radar");
//# sourceMappingURL=Radar.js.map
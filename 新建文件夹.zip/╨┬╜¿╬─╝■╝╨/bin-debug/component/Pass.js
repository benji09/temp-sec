var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Pass = (function (_super) {
    __extends(Pass, _super);
    function Pass(i) {
        var _this = _super.call(this) || this;
        _this.init(i);
        return _this;
    }
    Pass.prototype.init = function (i) {
        var stage = ViewManager.getInstance().stage;
        var mask = Util.createBitmapByName('bg_png');
        mask.width = stage.stageWidth;
        mask.height = stage.stageHeight;
        this.addChild(mask);
        var congratulate = new egret.TextField;
        congratulate.textFlow = [
            { text: '恭喜你!', style: { textColor: Config.COLOR_MAIN, size: 60, bold: true } },
            { text: '\n获得勋章', style: { size: 40 } }
        ];
        congratulate.width = stage.stageWidth;
        congratulate.textAlign = egret.HorizontalAlign.CENTER;
        congratulate.y = 230;
        congratulate.lineSpacing = 40;
        this.addChild(congratulate);
        var icon = Util.createBitmapByName("train_icon_0" + i + "_png");
        var ratio = icon.width / icon.height;
        icon.width = 310;
        icon.height = icon.width / ratio;
        icon.x = (stage.stageWidth - icon.width) / 2;
        icon.y = 470;
        this.addChild(icon);
        var bandge = Util.getConfig('bandge');
        var label = new egret.TextField;
        label.text = bandge[i - 1].name;
        label.width = stage.stageWidth;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.y = 835;
        label.size = 40;
        this.addChild(label);
        var close = new Button('icon_next_png', '返回', function () {
            ViewManager.getInstance().backByName('trainScene');
        });
        close.x = (stage.stageWidth - close.width) / 2;
        close.y = 1055;
        this.addChild(close);
    };
    return Pass;
}(eui.Group));
__reflect(Pass.prototype, "Pass");
//# sourceMappingURL=Pass.js.map
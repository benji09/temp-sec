var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var TrainLevelItem = (function (_super) {
    __extends(TrainLevelItem, _super);
    function TrainLevelItem(item, i) {
        var _this = _super.call(this) || this;
        _this.init(item, i);
        return _this;
    }
    TrainLevelItem.prototype.init = function (item, i) {
        this.touchEnabled = true;
        var ratio = Util.getRatio();
        var cone = Util.createBitmapByName("cone_png");
        cone.y = i ? 60 : 70;
        cone.width = ratio > 0.6 ? cone.width * 0.8 : cone.width;
        cone.height = ratio > 0.6 ? cone.height * 0.8 : cone.height;
        this.width = cone.width;
        this.height = 320;
        this.addChild(cone);
        var label = new egret.TextField();
        label.text = item.name;
        label.width = this.width + 4;
        label.textAlign = egret.HorizontalAlign.CENTER;
        this.addChild(label);
        var icon = Util.createBitmapByName(item.icon);
        icon.x = (this.width - icon.width) / 2 + 4;
        icon.y = i ? 30 : 50;
        this.addChild(icon);
        if (i != undefined) {
            var number = new egret.TextField();
            number.text = i + 1;
            var x = 130;
            var y = 170;
            number.x = ratio > 0.6 ? x * 0.85 : x;
            number.y = ratio > 0.6 ? y * 0.85 : y;
            number.size = ratio > 0.6 ? 30 * 0.8 : 30;
            number.fontFamily = 'MyFont';
            this.addChild(number);
        }
    };
    return TrainLevelItem;
}(eui.Group));
__reflect(TrainLevelItem.prototype, "TrainLevelItem");
//# sourceMappingURL=TrainLevelItem.js.map
var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var Button = (function (_super) {
    __extends(Button, _super);
    function Button(iconName, text, fn) {
        var _this = _super.call(this) || this;
        var border = Util.createBitmapByName('button_png');
        _this.addChild(border);
        _this.width = border.width;
        _this.height = border.height;
        var icon = new egret.Bitmap();
        icon.texture = RES.getRes(iconName);
        icon.x = 30;
        icon.y = 16;
        _this.addChild(icon);
        _this.iconImg = icon;
        var label = new egret.TextField;
        label.text = text;
        label.width = 100;
        label.textAlign = egret.HorizontalAlign.CENTER;
        label.x = 90;
        label.y = 26;
        label.size = 24;
        _this.addChild(label);
        _this.labelText = label;
        _this.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            Util.playMusic('model_select_mp3');
            fn();
        }, _this);
        return _this;
    }
    Button.prototype.changeIcon = function (iconName) {
        this.iconImg.texture = RES.getRes(iconName);
    };
    Button.prototype.changeText = function (text) {
        this.labelText.text = text;
    };
    Button.prototype.ableClick = function (bool) {
        this.touchEnabled = bool;
    };
    return Button;
}(eui.Button));
__reflect(Button.prototype, "Button");
//# sourceMappingURL=Button.js.map
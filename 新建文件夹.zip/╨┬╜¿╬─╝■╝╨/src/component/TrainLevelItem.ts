class TrainLevelItem extends eui.Group {
    constructor(item, i?) {
        super()
        this.init(item, i)
    }

    public init(item, i) {
        this.touchEnabled = true

        let ratio = Util.getRatio()
        
        let cone = Util.createBitmapByName(`cone_png`)
        cone.y = i ? 60 : 70
        cone.width = ratio > 0.6 ? cone.width * 0.8 : cone.width
        cone.height = ratio > 0.6 ? cone.height * 0.8 : cone.height
        this.width = cone.width
        this.height = 320
        this.addChild(cone)

        let label = new egret.TextField()
        label.text = item.name
        label.width = this.width + 4
        label.textAlign = egret.HorizontalAlign.CENTER
        this.addChild(label)

        let icon = Util.createBitmapByName(item.icon)
        icon.x = (this.width - icon.width) / 2 + 4
        icon.y = i ? 30 : 50
        this.addChild(icon)

        if (i != undefined) {
            let number = new egret.TextField()
            number.text = i + 1
            let x = 130
            let y = 170
            number.x = ratio > 0.6 ? x * 0.85 : x
            number.y = ratio > 0.6 ? y * 0.85 : y
            number.size = ratio > 0.6 ? 30 * 0.8 : 30
            number.fontFamily = 'MyFont'
            this.addChild(number)
        }
    }
}

class VProgress extends eui.Group {
    private max
    private process_text
    private processGroup
    private shapeW = 25
    private shapeH = 12

    constructor(max = 10) {
        super()
        this.max = max
        this.init()
    }

    public init() {
        let space = 30
        this.width = this.shapeW

        let group = new eui.Group
        group.width = this.shapeW
        group.height = (this.shapeH + space) * this.max
        this.addChild(group)
        this.processGroup = group
        for (let i = 0; i < this.max; i++) {
            let shape = Util.drawRoundRect(0, 0xffffff, 0xffffff, this.shapeW, this.shapeH, 10)
            shape.y = group.height - (this.shapeH + space) * i
            group.addChild(shape)
        }

        let process_text = new egret.TextField
        process_text.text = '1/' + this.max
        process_text.y = group.height + 40
        process_text.anchorOffsetX = 8
        process_text.textColor = Config.COLOR_MAIN
        process_text.size = 20
        this.addChild(process_text)
        this.process_text = process_text
    }

    public setRate(rate) {
        if (rate > 10) return
        this.process_text.text = rate + '/' + this.max
        this.processGroup.$children.forEach((item, index, arr) => {
            if (rate > index) {
                let y = item.y
                let shape = Util.drawRoundRect(0, 0xffffff, Config.COLOR_MAIN, this.shapeW, this.shapeH, 10)
                shape.y = y
                arr.splice(index, 1, shape)
            }
        })
    }
}
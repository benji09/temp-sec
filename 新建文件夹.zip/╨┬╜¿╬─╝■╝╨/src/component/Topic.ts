/**
 * 题目信息
 */
class Topic extends eui.Group {
    //答案
    public answer
    private subject: Subject

    private options = {}

    private selected

    private canSelected = true

    private textFlow
    private title
    private isTeamAnswer
    private _width

    constructor(subject: Subject, width?, isTeamAnswer?) {
        super()
        this.subject = subject
        this._width = width
        this.isTeamAnswer = isTeamAnswer
        this.init()
    }

    private init() {
        console.log("Topic -> init -> this.getCorrectItem", this.getCorrectItem)
        let topicBg = Util.createBitmapByName('option_normal_png')
        if (typeof this._width === 'number' && this._width) {
            topicBg.width = this._width
        }
        this.width = topicBg.width

        //题目标题
        let qTitle = new egret.TextField()
        qTitle.y = 10
        qTitle.width = this.width

        let titleText = this.subject.title
        if (this.subject.type == TopicType.MULTIPLE) {//多选题
            titleText += "(多选题)"
        }
        this.title = qTitle
        qTitle.text = titleText
        qTitle.bold = true
        qTitle.lineSpacing = 10
        qTitle.size = 28
        this.addChild(qTitle)

        let y = qTitle.y + qTitle.height + 60
        let optionNumArr = ['A', 'B', 'C', 'D', 'E', 'F']
        this.subject.options.forEach((item, i) => {
            if (item.name && item.name.length >= 1) {
                let topicItem = new TopicItem(optionNumArr[i], item, this.width, this.isTeamAnswer)
                topicItem.y = y
                this.addChild(topicItem)
                this.options[item.flag] = topicItem
                topicItem.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onSelect(item.flag), this)
                y += topicItem.height + 30
            }
        })
        this.height = y + 100
    }

    private onSelect(flag) {
        return () => {
            Util.playMusic('model_select_mp3')
            if (!this.canSelected) return
            //TODO 处理新的问题
            for (let k in this.options) {
                let topicItem = this.options[k]
                if (k == flag) {
                    if (this.subject.type == TopicType.MULTIPLE) { //多选题 重复点击会取消
                        if (!this.selected) this.selected = []
                        let index = this.selected.indexOf(flag)
                        if (index > -1) {//已选择 取消
                            this.selected.splice(index, 1)
                            topicItem.setStatus(TopicItem.STATUS_NORMAL)
                        } else { //未选择 请选择
                            this.selected.push(flag)
                            topicItem.setStatus(TopicItem.STATUS_SELECTED)
                        }
                    } else { //单选
                        this.selected = flag
                        topicItem.setStatus(TopicItem.STATUS_SELECTED)
                    }
                } else {
                    if (this.subject.type == TopicType.MULTIPLE) {
                        continue
                    }
                    topicItem.reset()
                }
            }
        }
    }

    /**
     * 获取答题选项
     */
    public getSelect() {
        if (!this.selected) return null
        if (this.subject.type == TopicType.MULTIPLE) return this.selected.join("")
        return this.selected
    }
    /**
     * 设置题目状态
     */
    public setSelectedStatus(status) {
        switch (this.subject.type) {
            case TopicType.SINGLE:
            case TopicType.MULTIPLE:
                let result = this.subject.result.split(',')
                for (let key in this.options) {
                    let option = this.options[key]
                    if (Util.inArray(key, this.selected)) {
                        if (Util.inArray(key, result)) {
                            option.setStatus(TopicItem.STATUS_OK)
                        } else {
                            option.setStatus(TopicItem.STATUS_ERROR)
                        }
                    } else {
                        if (Util.inArray(key, result)) {
                            option.setStatus(this.subject.type == TopicType.SINGLE ? TopicItem.STATUS_OK : TopicItem.STATUS_CORRECT)
                        }
                    }
                }
                break
            case TopicType.BLANK:
                switch (status) {
                    case TopicItem.STATUS_OK:
                        this.textFlow[1]['style'].textColor = 0xABBF11
                        this.title.textFlow = this.textFlow
                        break
                    case TopicItem.STATUS_ERROR:
                        this.textFlow[1]['style'].textColor = 0xFF0000
                        this.title.textFlow = this.textFlow
                        break
                }
                break
        }
    }

    /**
     * 不能选择
     */
    public setDisableSelected() {
        this.canSelected = false
    }

    /**
     * 判断题目的准确性
     */
    public getSelectResult() {
        switch (this.subject.type) {
            case TopicType.SINGLE:
            case TopicType.BLANK:
                if (this.selected == this.subject.result) {
                    return true
                }
                return false
            case TopicType.MULTIPLE:
                let result = this.subject.result.split(',')
                if (result.sort().toString() == this.selected.sort().toString()) {
                    return true
                }
                return false
        }
    }

    public getQAttrId() {
        return this.subject.qattrid
    }

    /**
     * 设置正确选项
     */
    public setCorrectItem() {
        this.subject.result.split(',').map(key => {
            this.options[key].setStatus(TopicItem.STATUS_CORRECT)
        })
    }

    public get getCorrectItem() {
        return this.subject.result.split(',')
    }
}

enum TopicType {
    SINGLE = 1,
    MULTIPLE = 2,
    BLANK = 3,
}

class TopicItem extends egret.DisplayObjectContainer {
    private bg: egret.Bitmap
    private icon: egret.Bitmap
    private text: egret.TextField

    private option
    private readonly BG_RES = ['option_normal_png', 'option_select_png', 'option_error_png', 'option_select_png', 'option_select_png']

    private readonly ICON_RES = { 2: "icon_err_png", 3: "icon_ok_png" }

    public static readonly STATUS_NORMAL = 0
    public static readonly STATUS_SELECTED = 1
    public static readonly STATUS_ERROR = 2
    public static readonly STATUS_OK = 3
    public static readonly STATUS_CORRECT = 4

    private status
    private optionNum
    private isTeamAnswer

    public constructor(optionNum, option, width, isTeamAnswer?) {
        super()
        this.width = width
        this.option = option
        this.optionNum = optionNum
        this.isTeamAnswer = isTeamAnswer
        this.status = TopicItem.STATUS_NORMAL
        this.touchEnabled = true
        this.init()
    }

    public init() {
        let bg = Util.createBitmapByName('option_normal_png')
        bg.height = this.width === bg.width ? bg.height : 96

        let textWidth = this.width === bg.width ? 380 : 320
        let textX = this.width === bg.width ? 138 : 120
        let textY = 26
        let textSize = 26
        let textSpacing = 10

        // 答案内容
        let text = new egret.TextField
        text.text = this.option.name
        text.width = textWidth
        text.lineSpacing = textSpacing
        text.x = textX
        text.size = textSize
        text.textAlign = egret.HorizontalAlign.CENTER
        text.verticalAlign = egret.VerticalAlign.MIDDLE
        this.addChild(text)
        this.text = text

        let line = Math.ceil(text.textWidth / textWidth)
        let height = textY * 2 + line * text.textHeight
        this.height = height < bg.height ? bg.height : height
        text.height = this.height - 10
        this.initBg()
        
        // 答案前缀
        let prefix = new egret.TextField
        prefix.text = this.optionNum
        prefix.width = 110
        prefix.height = this.height
        prefix.size = 40
        prefix.textAlign = egret.HorizontalAlign.CENTER
        prefix.verticalAlign = egret.VerticalAlign.MIDDLE
        this.addChild(prefix)
    }

    private initBg() {
        let bg = Util.createBitmapByName(this.BG_RES[this.status])
        let flag = bg.width == this.width
        bg.width = this.width - 1
        bg.height = this.height
        this.addChild(bg)
        this.bg = bg

        let icon = new egret.Bitmap()
        if (this.status == TopicItem.STATUS_OK || this.status == TopicItem.STATUS_ERROR) {
            this.icon.texture = RES.getRes(this.ICON_RES[this.status])
        }
        icon.x = flag ? 520 : 438
        icon.y = flag ? 5 : 12
        this.icon = icon
        this.addChild(icon)
    }

    private onTap() {
        this.setStatus(TopicItem.STATUS_SELECTED)
    }
    /**
     * 重置状态
     */
    public reset() {
        this.setStatus(TopicItem.STATUS_NORMAL)
    }

    /**
     * 设置状态  默认单选
     */
    public setStatus(status: number) {
        if (this.status == status) return
        this.status = status
        this.bg.texture = RES.getRes(this.BG_RES[status])
        if (this.isTeamAnswer) return
        if (status == TopicItem.STATUS_OK || status == TopicItem.STATUS_ERROR) {
            this.icon.visible = true
            this.icon.texture = RES.getRes(this.ICON_RES[status])
        } else {
            this.icon.visible = false
        }
    }

    public release() {
        this.removeChildren()
    }
}
class AlertPanel extends eui.Group {
    private text
    private iconName
    private h
    private tid
    private close
    private isAnswer
    public constructor(text, iconName?, h?, tid?, isAnswer?) {
        super()
        this.text = text
        this.iconName = iconName
        this.h = h
        this.tid = tid
        this.isAnswer = isAnswer
        this.init()
    }

    public init() {
        let stage = ViewManager.getInstance().stage
        let mask = Util.createBitmapByName('bg_png')
        mask.width = stage.stageWidth
        mask.height = stage.stageHeight
        this.addChild(mask)
        
        let group = new eui.Group
        this.addChild(group)

        let border = Util.createBitmapByName('alert_border_png')
        group.addChild(border)

        group.width = border.width
        group.height = border.height
        if (this.h) {
            group.height = border.height = this.h
        }
        group.x = (stage.stageWidth - group.width) / 2
        group.y = 750 - group.height

        if (this.iconName) {
            let icon = Util.createBitmapByName(this.iconName)
            icon.x = (group.width - icon.width) / 2
            icon.y = 30
            group.addChild(icon)
        }

        let label = new egret.TextField
        label.text = this.text
        label.width = group.width
        label.textAlign = egret.HorizontalAlign.CENTER
        label.lineSpacing = 15
        label.y = this.iconName ? 120 : 45
        group.addChild(label)

        let close = new Button('icon_next_png', this.isAnswer ? '确认' : '返回' , this.isAnswer ? this.confirm : this.back)
        close.x = this.isAnswer ? stage.stageWidth - close.width - 100 : (stage.stageWidth - close.width) / 2
        close.y = 866
        this.addChild(close)
        this.close = close

        if (this.isAnswer) {
            let cancelBtn = new Button('icon_remove_png', '取消', this.back)
            cancelBtn.x = 100
            cancelBtn.y = close.y
            this.addChild(cancelBtn)
        }

        if (this.iconName && this.iconName == 'icon_pass_png' && this.tid) {
            close.x = 100
            let flag = true
            let continueTrain = new Button('icon_next_png', '继续闯关' , () => {
                if (!flag) return
                flag = false
                Http.getInstance().post(Url.HTTP_TRAIN_START, { type: 1, tid: this.tid }, json => {
                    if (json.data.questions.length > 0) {
                        let answer = new Answers()
                        answer.lifecycleId = json.data.lifecycleId
                        answer.questions = json.data.questions
                        let badge = DataManager.getInstance().getCurrentBandge()
                        let nextLevel = badge.levels.filter(item => item.levelid == this.tid)
                        let scene = new AnswerScene(answer, AnswerType.TRAIN, nextLevel[0])
                        ViewManager.getInstance().changeScene(scene)
                    } else {
                        let alert = new AlertPanel("提示\n题库未设置")
                        this.addChild(alert)
                        flag = true
                    }
                })
            })
            continueTrain.x = stage.stageWidth - continueTrain.width - close.x
            continueTrain.y = close.y
            this.addChild(continueTrain)
        }
    }

    private confirm = () => {
        ViewManager.getInstance().backByName('trainLevelScene')
    }

    private back = () => {
        this.parent.removeChild(this)
    }

    public setFn(fn) {
        this.close.removeEventListener(egret.TouchEvent.TOUCH_TAP, this.back, this)
        this.close.addEventListener(egret.TouchEvent.TOUCH_TAP, fn, this)
    }
}
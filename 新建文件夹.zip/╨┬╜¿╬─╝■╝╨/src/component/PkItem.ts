
class PkItem extends eui.Group {
    private data

    constructor(data) {
        super()
        this.data = data
        this.init()
    }

    private init() {
        let stageW = ViewManager.getInstance().stage.stageWidth
        let ratio = Util.getRatio()
        let grayFilter = Util.grayFilter()
        let icon: egret.Bitmap = Util.createBitmapByName(this.data.icon)
        icon.width = ratio > 0.6 ? icon.width * 0.8 : icon.width
        icon.height = ratio > 0.6 ? icon.height * 0.8 : icon.height
        icon.x = (stageW - icon.width) / 2
        icon.filters = this.data.status === 0 ? [grayFilter] : []
        icon.blendMode = egret.BlendMode.ADD
        this.addChild(icon)

        if (this.data.title) {
            let group = new eui.Group
            this.addChild(group)

            let titleBg = Util.createBitmapByName('pk_btn_png')
            group.width = titleBg.width
            group.height = titleBg.height
            group.x = (stageW - group.width) / 2
            group.y = icon.height + 40
            group.addChild(titleBg)

            let title = new egret.TextField()
            title.text = this.data.title
            title.width = titleBg.width
            title.height = titleBg.height
            title.verticalAlign = egret.VerticalAlign.MIDDLE
            title.textAlign = egret.HorizontalAlign.CENTER
            title.textColor = Config.COLOR_MAIN
            title.size = 36
            group.addChild(title)

            if (this.data.status === 0) {
                group.filters = [grayFilter]

                let lock = Util.createBitmapByName('lock_png')
                let ratio = lock.width / lock.height
                lock.width = 50
                lock.height = lock.width / ratio
                lock.x = (group.width - lock.width) / 2
                lock.y = (group.height - lock.height) / 2
                group.addChild(lock)
            }

            let userInfo = DataManager.getInstance().getUser()
            group.touchEnabled = true
            group.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                if (this.data.status === 0) {
                    return
                }
                if (userInfo.teamId == 1327) {
                    ViewManager.getInstance().showLoading('默认战队请到QA环境体验此功能！')
                    setTimeout(() => {
                        ViewManager.getInstance().hideLoading()
                    }, 2000)
                    return
                }
                Util.playMusic('model_select_mp3')
                let scene = new PkMatchScene()
                ViewManager.getInstance().changeScene(scene)
            }, this)
        }
    }
}
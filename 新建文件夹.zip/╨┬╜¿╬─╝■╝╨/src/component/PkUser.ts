class PkUser extends eui.Group {
    private userInfo
    private type
    private score
    private time
    constructor(userInfo, type = 'left', score?:string, time?:string) {
        super()
        this.userInfo = userInfo
        this.type = type
        this.score = score
        this.time = time
        this.init()
    }

    public init() {
        let avatar_name = `pk_avatar_${this.type}_png`

        // 头像边框
        let avatar_border = Util.createBitmapByName(avatar_name)
        this.width = avatar_border.width
        this.height = avatar_border.height
        this.addChild(avatar_border)

        // 头像
        try {
            let url = Config.DEBUG ? 'http://thirdwx.qlogo.cn/mmopen/vi_32/cKqXyr3j6icxgs4TSy6cpMMkbsWXSdAfXqFkLysDgacAbrzulVqj6eulmZGRianMKqDJ9nUbpf1o0VqWXNtKP5yA/132' : this.userInfo.avatar
            let avatar = Util.setUserImg(url, 172)
            avatar.x = 32
            avatar.y = 32
            this.addChild(avatar)
        } catch (error) {
            
        }

        // 名字
        let user_name = new egret.TextField
        let nickName = this.userInfo && this.userInfo.nickName || '??'
        user_name.text = Util.getStrByWith(nickName, 180, 30)
        user_name.x = (this.width - user_name.textWidth) / 2
        user_name.y = this.height + 30
        this.addChild(user_name)

        // 正确率
        if (this.score) {
            let resultInfo = new egret.TextField
            resultInfo.textFlow = [
                {text: '正确率：' + this.score},
                {text: '\n' + this.time},
            ]
            resultInfo.width = this.width
            resultInfo.y = user_name.y + user_name.textHeight + 15
            resultInfo.textAlign = egret.HorizontalAlign.CENTER
            resultInfo.lineSpacing = 15
            resultInfo.size = 22
            this.addChild(resultInfo)
        }
    }
}

class TeamUser extends eui.Group {
    private userinfo
    private type: UserPositionType

    private icon
    private avatar
    private nameText
    private readyImg
    private status

    private clickTime
    private canClick = true

    private resultText


    constructor(userinfo, type = UserPositionType.LEFT) {
        super()
        this.userinfo = userinfo || {}
        // test begin
        // this.userinfo.nickName = '周武Zhou Wu'
        // this.userinfo.avatar = 'http://127.0.0.1:8360/uploads/avatar/13886593297_avatar.jpg'
        // test end
        this.type = type
        this.init()
    }

    public init() {
        let bgname = 'pk_yellow_list_png'
        if (this.type === UserPositionType.RIGHT) {
            bgname = 'pk_green_list_png'
        }

        let bg = Util.createBitmapByName(bgname)
        this.width = bg.width
        this.height = bg.height
        this.addChild(bg)

        // 头像
        let avatar = new egret.Bitmap()
        avatar.width = avatar.height = 112
        avatar.x = this.type == UserPositionType.LEFT ? 170 : 3
        avatar.y = 3
        this.addChild(avatar)
        this.avatar = avatar
        if (this.userinfo) {
            Util.setUserImg(this.userinfo.avatar, avatar)
        }

        let shape = new egret.Shape()
        this.addChild(shape)
        let graphics = shape.graphics
        graphics.beginFill(0xffffff)
        graphics.drawCircle(avatar.x + avatar.width / 2, avatar.y + avatar.height / 2, avatar.width / 2)
        graphics.endFill()
        avatar.mask = shape

        // 人名
        let name = new egret.TextField()
        name.width = 150
        name.size = 26
        name.text = this.userinfo.nickName ? Util.getStrByWith(this.userinfo.nickName, name.width - 20, name.size) : ''
        name.x = this.type == UserPositionType.LEFT ? 0 : 130
        name.height = bg.height - 10
        name.wordWrap = false
        name.multiline = false
        name.textAlign = this.type == UserPositionType.LEFT ? 'right' : 'left'
        name.verticalAlign = 'middle'
        this.addChild(name)
        this.nameText = name

        // 准备图标
        let readyImg = Util.createBitmapByName('pk_icon_ready_png')
        if (this.type == UserPositionType.LEFT) {
            readyImg.x = 140
        } else {
            readyImg.x = 115
        }
        readyImg.y = 80
        this.readyImg = readyImg
        this.addChild(readyImg)
        this.readyImg.visible = false
    }

    public addUserEventListener(callback, obj) {

        this.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            if (!this.canClick) return
            let current = new Date().getTime()
            if (this.clickTime && current - this.clickTime < 1000) return
            this.clickTime = current
            // this.canClick = false
            callback.bind(obj)(this.userinfo)
        }, this)
    }

    public resetClick() {
        this.canClick = true
        this.clickTime = 0
    }

    public setDisableClick() {
        this.canClick = false
    }

    /**
     * 更新用户信息
     */
    public updateUser(userinfo) {
        this.userinfo = userinfo
        //清空头像
        let texture = new egret.Texture()
        this.avatar.texture = texture
        if (userinfo == null) {
            this.nameText.text = ''
            this.readyImg.visible = false
            this.resetClick()
        } else {
            this.nameText.text = Util.getStrByWith(this.userinfo.nickName, 150 - 20, 26)
            Util.setUserImg(userinfo.avatar, this.avatar)
        }
    }

    /**
     * 准备好
     */
    public setReady() {
        this.readyImg.visible = true
    }


    /**
     * 设置用户结果状态
     */
    public setWinnerStatus(status) {
        if (this.status == status) return
        this.status = status
        if (this.resultText) {
            this.resultText.parent.removeChild(this.resultText)
            this.resultText = null
        }
        let textObj = {
            1: '成功',
            2: '平局',
            3: 'MVP',
            4: '失败'
        }

        let text = new egret.TextField
        text.text = textObj[status]
        text.textColor = this.type == UserPositionType.LEFT ? 0x4b4c03 : 0xffffff
        text.size = 20
        text.x = this.type == UserPositionType.LEFT ? 100 : 130
        text.y = 80
        this.resultText = text
        this.addChild(text)

        if (status === WinnerStatus.LOSE) {
            let grayFilter = Util.grayFilter()
            this.filters = [grayFilter]
        }
    }
}


class LiteTeamUser extends eui.Group {
    private userinfo
    private type: UserPositionType

    constructor(userinfo, type = UserPositionType.LEFT) {
        super()
        this.userinfo = userinfo || {}
        // test begin
        // this.userinfo.nickName = '周武'
        // this.userinfo.avatar = 'http://127.0.0.1:8360/uploads/avatar/13886593297_avatar.jpg'
        // test end
        this.type = type
        this.init()
    }


    public init() {
        let bgname = 'pk_yellow_list_lite_png'
        if (this.type === UserPositionType.RIGHT) {
            bgname = 'pk_green_list_lite_png'
        }

        let bg = Util.createBitmapByName(bgname)
        this.width = bg.width
        this.height = bg.height
        this.addChild(bg)

        // 头像
        if (this.userinfo && this.userinfo.avatar) {
            let avatar = Util.setUserImg(this.userinfo.avatar, 112)
            avatar.x = this.type == UserPositionType.LEFT ? 54 : 3
            avatar.y = 3
            this.addChild(avatar)
        }

        // 人名
        if (this.userinfo && this.userinfo.nickName) {
            let name = new egret.TextField()
            name.text = this.userinfo.nickName
            name.x = this.type == UserPositionType.LEFT ? 0 : 110
            name.width = 60
            name.height = bg.height - 20
            name.wordWrap = false
            name.multiline = false
            name.textAlign = this.type == UserPositionType.LEFT ? 'right' : 'left'
            name.verticalAlign = 'bottom'
            name.size = 18
            this.addChild(name)
        }
    }
}
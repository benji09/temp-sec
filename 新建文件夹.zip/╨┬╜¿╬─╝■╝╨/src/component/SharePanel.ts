class SharePanel extends eui.Group {
    public constructor() {
        super()
        this.init()
    }

    public init() {
        let stage = ViewManager.getInstance().stage
        let mask = Util.drawRoundRect(0, 0x000000, 0x000000, stage.stageWidth, stage.stageHeight, 0, 0.8)
        this.addChild(mask)

        let share_arrow = Util.createBitmapByName('share_arrow_png')
        share_arrow.x = 580
        this.addChild(share_arrow)

        let share_tips
        if (egret.Capabilities.os == 'Android') {
            share_tips = Util.createBitmapByName('share_tips_android_jpg')
            share_tips.width = stage.stageWidth
            share_tips.height = stage.stageWidth * 0.634
        } else {
            share_tips = Util.createBitmapByName('share_tips_jpg')
            share_tips.width = stage.stageWidth
            share_tips.height = stage.stageWidth * 0.876
        }
        share_tips.y = stage.stageHeight - share_tips.height
        this.addChild(share_tips)


        this.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            Util.playMusic('model_select_mp3')
            this.parent.removeChild(this)
        }, this)
    }
}

class AlertLoading extends eui.Group {
    private text
    private loadingText
    public constructor(text = '') {
        super()
        this.text = text
        this.init()
    }

    private init() {
        this.height = 220
        this.width = 500

        let mask: egret.Bitmap = Util.createBitmapByName('mask_png')
        mask.alpha = 0.4
        mask.width = this.width
        mask.height = this.height
        this.addChild(mask)

        let loading = Util.createBitmapByName('loading_png')
        loading.width = 64
        loading.height = 64
        loading.x = this.width / 2
        loading.y = loading.height / 2 + 20
        loading.anchorOffsetX = loading.width / 2
        loading.anchorOffsetY = loading.height / 2
        egret.Tween.get(loading, { loop: true }).to({ rotation: 360 }, 2500)
        this.addChild(loading)

        let loadingText = new egret.TextField()
        loadingText.text = this.text
        loadingText.size = 28
        loadingText.y = loading.y + loading.height + 10
        loadingText.width = this.width
        loadingText.textAlign = egret.HorizontalAlign.CENTER
        loadingText.verticalAlign = egret.VerticalAlign.MIDDLE
        loadingText.lineSpacing = 10
        this.loadingText = loadingText
        this.addChild(loadingText)
    }

    public setText(text) {
        this.text = text
        this.loadingText.text = this.text
    }
}
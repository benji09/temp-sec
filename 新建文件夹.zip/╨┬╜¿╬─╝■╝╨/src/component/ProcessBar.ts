class ProcessBar extends eui.Group {
    private len
    private curIdx
    private barArr = []
    private present
    constructor(len, curIdx) {
        super()
        this.len = len
        this.curIdx = curIdx
        this.init()
    }

    private init() {
        let x = 10
        let bg = Util.createBitmapByName('process_undone_png')
        for (let i = 0; i < this.len; i++) {
            let bar = new egret.Bitmap()
            let texture: egret.Texture = RES.getRes('process_undone_png')
            bar.texture = texture
            bar.x = x
            let w = bg.width / this.len * 8
            bar.width = w > bg.width ? bg.width : w
            this.barArr.push(bar)
            this.addChild(bar)
            x += bar.width
        }

        let line = new egret.Shape
        line.graphics.lineStyle(1, 0xffffff)
        line.graphics.moveTo(0, 20)
        line.graphics.lineTo(10 + this.len * this.barArr[0].width, 20)
        this.addChild(line)

        let present = new egret.TextField
        present.x = line.width + 20
        present.size = 20
        this.addChild(present)
        this.present = present

        this.setRate(this.curIdx)
    }

    public setRate(index) {
        this.barArr.forEach((item, i) => i < index && (item.texture = RES.getRes('process_done_png')))
        this.present.text = index + '/' + this.len
    }
}

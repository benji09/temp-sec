class Button extends eui.Button{
    private iconImg
    private labelText
    public constructor(iconName: string, text: string, fn: Function){
        super()
        let border = Util.createBitmapByName('button_png')
        this.addChild(border)
        this.width = border.width
        this.height = border.height

        let icon = new egret.Bitmap()
        icon.texture = RES.getRes(iconName)
        icon.x = 30
        icon.y = 16
        this.addChild(icon)
        this.iconImg = icon

        let label = new egret.TextField
        label.text = text
        label.width = 100
        label.textAlign = egret.HorizontalAlign.CENTER
        label.x = 90
        label.y = 26
        label.size = 24
        this.addChild(label)
        this.labelText = label

        this.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            Util.playMusic('model_select_mp3')
            fn()
        }, this)
    }

    public changeIcon(iconName) {
        this.iconImg.texture = RES.getRes(iconName)
    }

    public changeText(text) {
        this.labelText.text = text
    }

    public ableClick(bool) {
        this.touchEnabled = bool
    }
}
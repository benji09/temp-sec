class LineInfo extends eui.Group{
    private text
    private text2
    private tip
    constructor(text, text2?){
        super()
        this.text = text
        this.text2 = text2
        this.init()
    }

    private init() {
        let tip = new egret.TextField
        tip.text = this.text
        tip.width = ViewManager.getInstance().stage.stageWidth
        tip.textAlign = egret.HorizontalAlign.CENTER
        tip.y = 806
        tip.size = 42
        tip.bold = true
        tip.lineSpacing = 20
        this.tip = tip
        this.addChild(tip)
    }

    public setText(text){
        this.tip.text = text 
    }
}
class RankTitle extends eui.Group {
    private line
    constructor(text) {
        super()
        this.init(text)
    }

    private init(text) {
        let line = Util.createBitmapByName('rank_line_png')
        line.y = 40
        line.blendMode = egret.BlendMode.ADD
        this.line = line
        this.addChild(line)
        this.width = line.width
        
        let label = new egret.TextField
        label.text = text
        label.size = 34
        label.width = this.width
        label.textAlign = egret.HorizontalAlign.CENTER
        this.addChild(label)
        this.touchEnabled = true
    }

    public hideFlag() {
        this.line.visible = false
    }

    public showFlag() {
        this.line.visible = true
    }
}
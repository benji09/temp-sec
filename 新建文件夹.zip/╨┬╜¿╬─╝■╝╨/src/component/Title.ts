class Title extends eui.Group {
    private text: string
    private iconName
    public constructor(text: string, y = 120, iconName?) {
        super()
        this.text = text
        this.iconName = iconName
        this.y = y
        this.init()
    }

    public init() {
        let stage = ViewManager.getInstance().stage
        this.width = stage.stageWidth
        this.height = 114

        if (this.iconName) {
            let icon = Util.createBitmapByName(this.iconName)
            icon.x = 244
            icon.y = 16
            this.addChild(icon)
        }

        let title = new egret.TextField
        title.text = this.text
        title.width = this.width
        title.height = this.height
        title.textAlign = egret.HorizontalAlign.CENTER
        title.verticalAlign = egret.VerticalAlign.MIDDLE
        title.x = this.iconName ? 30 : 0
        title.size = 50
        title.bold = true
        this.addChild(title)
    }
}
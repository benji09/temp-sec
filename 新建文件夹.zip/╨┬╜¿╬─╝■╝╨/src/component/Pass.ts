class Pass extends eui.Group {
    public constructor(i) {
        super()
        this.init(i)
    }

    public init(i) {
        let stage = ViewManager.getInstance().stage
        let mask = Util.createBitmapByName('bg_png')
        mask.width = stage.stageWidth
        mask.height = stage.stageHeight
        this.addChild(mask)

        let congratulate = new egret.TextField
        congratulate.textFlow = [
            { text: '恭喜你!', style: { textColor: Config.COLOR_MAIN, size: 60, bold: true }},
            { text: '\n获得勋章', style: { size: 40 }}
        ]
        congratulate.width = stage.stageWidth
        congratulate.textAlign = egret.HorizontalAlign.CENTER
        congratulate.y = 230
        congratulate.lineSpacing = 40
        this.addChild(congratulate)

        let icon = Util.createBitmapByName(`train_icon_0${i}_png`)
        let ratio = icon.width / icon.height
        icon.width = 310
        icon.height = icon.width / ratio
        icon.x = (stage.stageWidth - icon.width) / 2
        icon.y = 470
        this.addChild(icon)

        let bandge = Util.getConfig('bandge')
        let label = new egret.TextField
        label.text = bandge[i - 1].name
        label.width = stage.stageWidth
        label.textAlign = egret.HorizontalAlign.CENTER
        label.y = 835
        label.size = 40
        this.addChild(label)

        let close = new Button('icon_next_png', '返回' , () => {
            ViewManager.getInstance().backByName('trainScene')
        })
        close.x = (stage.stageWidth - close.width) / 2
        close.y = 1055
        this.addChild(close)
    }
}
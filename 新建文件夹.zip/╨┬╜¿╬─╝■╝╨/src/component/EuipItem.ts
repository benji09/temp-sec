class EquipItem extends eui.Group {
    private data
    constructor(data) {
        super()
        this.data = data
        this.init()
    }

    private init() {
        let type = this.data.type == EquipType.MP4 ? 'mp4' : this.data.type == EquipType.PDF ? 'pdf' : 'img'
        let listBg = Util.createBitmapByName(`equip_bg_${type}_png`)
        
        this.width = listBg.width
        this.height = listBg.height
        this.addChild(listBg)

        let title = new egret.TextField()
        title.text = this.data.title
        title.width = 320
        title.height = this.height
        title.x = 50
        title.verticalAlign = egret.VerticalAlign.MIDDLE
        this.addChild(title)
    }
}
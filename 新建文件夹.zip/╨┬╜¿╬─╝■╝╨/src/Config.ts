/**
 * app配置文件
 */

class Config {
    public static readonly HOST = "http://192.168.1.134:8360"
    public static readonly COLOR_MAIN = 0x39f4e6
    public static readonly DEBUG = true
}
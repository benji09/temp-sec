
class Answers{
    /**
     * 每次答题训练的id
     */
    public lifecycleId:string;
    /**
     * 题目id列表
     */
    public questions:Array<any>; 
}
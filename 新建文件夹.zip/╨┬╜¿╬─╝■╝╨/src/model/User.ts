class User{
	// public avatar
    // isSign: 0
    // lv: 1
    // lvName: "入门新兵"
    // lvShow: "LV.1"
    // nickName: "测试string"
    // personRank: 0
    // pkBeat: 0
    // pkWin: 0
    // score: 0
    // signTotal: 0
    // teamId: 1001
    // teamName: "默认测试战队"
    // teamRank: 0
    // trainDay: 0
    // trainFail: 0
    // trainSuccess: 0
    // trainTotal: 0
    // userId: 59
}
/**
 * 场景事件
 */

class SceneEvent {
    
}
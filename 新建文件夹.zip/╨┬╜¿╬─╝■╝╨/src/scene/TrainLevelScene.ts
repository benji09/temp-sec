class TrainLevelScene extends Scene {
    private bandge
    private index
    private levelGroup
    constructor(bandge, index) {
        super()
        this.bandge = bandge
        this.index = index
    }

    public init() {
        this.setBackground('level_bg_png')
        this.name = 'trainLevelScene'
        let stage = ViewManager.getInstance().stage

        // 标题
        let title = Util.createBitmapByName('level_title_png')
        title.x = (stage.stageWidth - title.width) / 2 + 20
        title.y = 40
        title.blendMode = egret.BlendMode.ADD
        this.addChild(title)

        let textArr = ['疾病篇', '竞品篇', '产品篇', '品牌篇']

        let title_text = new egret.TextField
        title_text.text = textArr[this.index]
        title_text.x = 480
        title_text.y = 268
        title_text.size = 28
        this.addChild(title_text)

        let icon = Util.createBitmapByName(`train_icon_0${this.index + 1}_png`)
        let ratio = icon.width / icon.height
        icon.width = 200
        icon.height = icon.width / ratio
        icon.x = (stage.stageWidth - icon.width) / 2
        icon.y = stage.stageHeight - 960
        this.addChild(icon)

        let icon_text = new egret.TextField
        icon_text.text = this.bandge.name
        icon_text.width = stage.stageWidth
        icon_text.textAlign = egret.HorizontalAlign.CENTER
        icon_text.y = icon.y + icon.height
        this.addChild(icon_text)

        let levelGroup = new eui.Group
        levelGroup.width = 600
        levelGroup.height = 600
        levelGroup.x = (stage.stageWidth - levelGroup.width) / 2
        levelGroup.y = stage.stageHeight - levelGroup.height - 160
        this.levelGroup = levelGroup
        this.addChild(this.levelGroup)

        this.level()
    }

    private level() {
        this.levelGroup.$children.length && this.levelGroup.removeChildren()

        let currentLevel = DataManager.getInstance().getUser().lv
        
        let distance = 70
        let position = [
            {x: 220 - distance, y: 1050 - this.levelGroup.height},
            {x: 500 - distance, y: 1000 - this.levelGroup.height},
            {x: 70 - distance, y: 855 - this.levelGroup.height},
            {x: 507 - distance, y: 850 - this.levelGroup.height},
            {x: 360 - distance, y: 820 - this.levelGroup.height},
            {x: 280 - distance, y: 700 - this.levelGroup.height},
            {x: 440 - distance, y: 680 - this.levelGroup.height},
            {x: 160 - distance, y: 670 - this.levelGroup.height},
        ]

        let grayFilter = Util.grayFilter()
        let flag = true
        for (let i = this.bandge.levels.length; i > 0; i--) {
            let level = Util.createBitmapByName(`level_panel_pass_0${i}_png`)

            // 每关的信息
            let level_data = this.bandge.levels[i - 1]
            // 判断是否通关
            if (currentLevel < level_data.key) {
                // 未解锁
                level = Util.createBitmapByName(`level_panel_lock_0${i}_png`)
                level.filters = [grayFilter]
            } else if (currentLevel == level_data.key) {
                // 当前关卡
                level = Util.createBitmapByName(`level_panel_0${i}_png`)
            }

            level.x = position[i - 1].x
            level.y = position[i - 1].y

            level.touchEnabled = true
            level.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                if (!flag) return
                flag = false
                //请求数据
                Util.playMusic('model_select_mp3')
                if (currentLevel >= level_data.key) {
                    Http.getInstance().post(Url.HTTP_TRAIN_START, { type: 1, tid: level_data.levelid }, json => {
                        if (json.data.questions.length > 0) {
                            let answer = new Answers()
                            answer.lifecycleId = json.data.lifecycleId
                            answer.questions = json.data.questions
                            let scene = new AnswerScene(answer, AnswerType.TRAIN, level_data)
                            ViewManager.getInstance().changeScene(scene)
                        } else {
                            let alert = new AlertPanel("提示\n题库未设置")
                            this.addChild(alert)
                            flag = true
                        }
                    })
                } else {
                    let alert = new AlertPanel("提示\n请先通关前面的关卡后再来哦")
                    this.addChild(alert)
                    flag = true
                }
            }, this)

            this.levelGroup.addChild(level)
        }
    }

    public updateScene() {
        this.level()
    }
}
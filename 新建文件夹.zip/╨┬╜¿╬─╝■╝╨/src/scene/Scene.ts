class Scene extends eui.UILayer {
    private isRemove: boolean = true
    public close_btn: string = '返回'
    public isBackHome = false
    public backPage: any = false
    public removeEvent

    public constructor() {
        super()
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.initScene, this)
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.release, this)
    }

    private initScene() {
        if (this.isRemove) { //防止多次加载
            this.init()
            this.isRemove = false
            if (this.close_btn != '') {
                this.createNavButton()
            }
        }
    }

    public createNavButton() {
        let btn = this.textGroup(this.close_btn)

        let flag = true
        btn.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            if (!flag) return
            flag = false
            this.onBack()
            Util.playMusic('model_select_mp3')
            this.removeEvent && SocketX.getInstance().removeEventListener(this.removeEvent)
            setTimeout(() => {
                flag = true
            }, 300)
        }, this)
    }

    public createRightButton(text: string, fn: Function) {
        let btn = this.textGroup(text)
        btn.x = this.stage.stageWidth - btn.width

        btn.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            Util.playMusic('model_select_mp3')
            fn()
        }, this)

        return btn
    }

    private textGroup(text: string) {
        let btn = new eui.Group
        btn.height = 100
        this.addChild(btn)

        let label = new egret.TextField
        label.text = text
        label.width = label.textWidth + 100
        btn.width = label.width
        label.height = btn.height
        label.textAlign = egret.HorizontalAlign.CENTER
        label.verticalAlign = egret.VerticalAlign.MIDDLE
        btn.addChild(label)
        btn.touchEnabled = true

        return btn
    }

    public setBackground(name = "bg_png") {
        let bg = Util.createBitmapByName(name)
        bg.width = this.stage.stageWidth
        bg.height = this.stage.stageHeight
        this.addChildAt(bg, 0)
    }

    /**
     * 更新页面信息 
     */
    public updateScene() {

    }

    /**
     * 初始化界面
     */
    public init() {

    }

    public onBack() {
        ViewManager.getInstance().back()
    }

    /**
     * 释放界面
     */
    public release() {

    }

    /**
     * 退出页面，需要加载动画
     */
    public remove() {
        // 切换动画
        this.removeChildren()
        this.parent.removeChild(this)
        this.isRemove = true
    }
}
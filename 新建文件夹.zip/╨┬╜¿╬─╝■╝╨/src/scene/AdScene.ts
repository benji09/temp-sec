class AdScene extends Scene {
    private isNeedSign
    private signData
    constructor(isNeedSign, signData?) {
        super()
        this.isNeedSign = isNeedSign
        this.signData = signData
    }

    public init() {
        this.close_btn = ''

        let bg = Util.createBitmapByName('ad_bg_png')
        bg.width = this.stage.stageWidth
        this.addChild(bg)

        let stage = ViewManager.getInstance().stage

        let textGroup = new eui.Group
        textGroup.y = stage.stageHeight - 100
        this.addChild(textGroup)

        let arrow = Util.createBitmapByName('ad_arrow_png')
        arrow.x = (stage.stageWidth - arrow.width) / 2
        textGroup.addChild(arrow)

        let ad_text = new egret.TextField
        ad_text.text = '大有可V 等你而来'
        ad_text.size = 40
        ad_text.x = (stage.stageWidth - ad_text.width) / 2
        ad_text.y = -8
        textGroup.addChild(ad_text)

        // 初始化游戏数据
        let scene = this.isNeedSign ? new SignScene(this.signData) : new IndexScene()
        this.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            Util.playMusic('model_select_mp3')
            ViewManager.getInstance().changeScene(scene)
        }, this)

        let url = window.location.href.split('#')[0]
        Http.getInstance().post(Url.HTTP_JSSDK_CONFIG, { showurl: url }, (json) => {
            configSdk(json.data)
            setTimeout(() => {
                Util.registerShare(null, ShareType.NORMAL)
            }, 1000)
        })
    }
}
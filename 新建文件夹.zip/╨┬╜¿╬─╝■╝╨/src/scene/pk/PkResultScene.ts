class PkResultScene extends Scene {
    private result
    private shareGroup
    private back
    constructor(result, back?) {
        super()
        this.result = result
        this.back = back
    }

    public init() {
        this.setBackground()
        Util.setTitle('PK挑战')
        let stageW = this.stage.stageWidth
        let stageH = this.stage.stageHeight
        let userId = DataManager.getInstance().getUser().userId

        let shareGroup = new eui.Group()
        this.addChild(shareGroup)
        this.shareGroup = shareGroup
        shareGroup.width = stageW

        let pkResult = this.result
        console.log('pkResult', pkResult)

        // 玩家自己
        let self = pkResult.sender
        let opponent = pkResult.receiver
        if (pkResult.sender.pkUser.userId != userId) {
            self = pkResult.receiver
            opponent = pkResult.sender
        }
        let selfPkUser = self ? self.pkUser : null
        let selfCorrect = ''
        let selfTime = ''
        if (self && self.pkResult) {
            selfCorrect = self.pkResult.isCorrect + '/' + self.pkResult.answerCount
            selfTime = Util.converTimer(self.pkResult.userAnswerUseTimeTotal)
        }

        let leftUser = new PkUser(selfPkUser, "left", selfCorrect, selfTime)
        leftUser.x = 68
        leftUser.y = 116
        shareGroup.addChild(leftUser)

        // 对手
        let opponentPkUser = opponent ? opponent.pkUser : null
        let opponentCorrect = ''
        let opponentTime = ''
        if (opponent && opponent.pkResult) {
            opponentCorrect = opponent.pkResult.isCorrect + '/' + opponent.pkResult.answerCount
            opponentTime = Util.converTimer(opponent.pkResult.userAnswerUseTimeTotal)
        }

        let rightUser = new PkUser(opponentPkUser, 'right', opponentCorrect, opponentTime)
        rightUser.x = stageW - rightUser.width - leftUser.x
        rightUser.y = leftUser.y
        shareGroup.addChild(rightUser)

        let pkVs = Util.createBitmapByName('pk_vs_png')
        pkVs.x = (stageW - pkVs.width) / 2
        pkVs.blendMode = egret.BlendMode.ADD
        pkVs.y = 182
        shareGroup.addChild(pkVs)

        let line = Util.createBitmapByName('pk_line_png')
        line.width = stageW
        line.y = 350
        shareGroup.addChild(line)

        // 无效局
        if (pkResult.status == PkResult.INVALID) {
            let waitPic = Util.createBitmapByName('pk_end_wait_png')
            waitPic.blendMode = egret.BlendMode.ADD
            waitPic.x = -30
            waitPic.y = 520
            this.addChild(waitPic)

            let info = new LineInfo(pkResult.tipsMsg)
            shareGroup.addChild(info)
            return
        }

        // 结果背景和音乐
        let music = "pass_mp3"
        let result = '挑战\n成功'
        if (pkResult.status == PkResult.FAIL) {
            result = '挑战\n失败'
            music = "nopass_mp3"
        } else if (pkResult.status == PkResult.DRAW) {
            result = '平局'
        }
        let resultBg = Util.createBitmapByName('pk_time_bg_png')
        let ratio = Util.getRatio()
        resultBg.width = ratio > 0.6 ? resultBg.width * 0.8 : resultBg.width
        resultBg.height = ratio > 0.6 ? resultBg.height * 0.8 : resultBg.height
        resultBg.x = ratio > 0.6 ? 150 : 100
        resultBg.y = 520
        shareGroup.addChild(resultBg)
        Util.playMusic(music)

        let resultText = new egret.TextField
        resultText.text = result
        resultText.width = stageW
        resultText.height = resultBg.height
        resultText.y = resultBg.y + 10
        resultText.textAlign = egret.HorizontalAlign.CENTER
        resultText.verticalAlign = egret.VerticalAlign.MIDDLE
        resultText.size = 60
        resultText.bold = true
        resultText.lineSpacing = ratio > 0.6 ? 35 * 0.8 : 35
        shareGroup.addChild(resultText)

        let weekCount = this.describe('本周参赛场次:' + self.pkUser.pkCount)
        weekCount.y = resultBg.y + resultBg.height + 10
        shareGroup.addChild(weekCount)

        let weekRate = this.describe('本周胜率:' + self.pkUser.winRate)
        weekRate.y = weekCount.y + weekCount.height + 10
        shareGroup.addChild(weekRate)

        // 保存图片
        let saveBtn = new Button('icon_save_png', '保存图片', () => {
            let alert = new AlertPanel("提示\n请自行截图保存图片！")
            this.addChild(alert)
        })
        saveBtn.x = 74
        saveBtn.y = stageH - 120
        this.addChild(saveBtn)

        // 分享
        let shareBtn = new Button('icon_share_png', '分享', () => {
            let tips = new SharePanel()
            this.addChild(tips)
        })
        shareBtn.x = this.stage.stageWidth - shareBtn.width - saveBtn.x
        shareBtn.y = saveBtn.y
        this.addChild(shareBtn)

        let status = ShareType.PK_WIN
        if (pkResult.status == PkResult.FAIL) {
            status = ShareType.PK_FAIL
        } else if (pkResult.status == PkResult.DRAW) {
            status = ShareType.PK_DRAW
        }
        Util.registerShare(this.shareGroup, status, self.pkUser.nickName, opponent ? opponent.pkUser.nickName : '')
    }

    private describe(notice) {
        let ratio = Util.getRatio()
        let group = new eui.Group
        let bg = Util.createBitmapByName('pk_notice_bg_png')
        bg.width = ratio > 0.6 ? bg.width * 0.8 : bg.width
        bg.height = ratio > 0.6 ? bg.height * 0.8 : bg.height
        bg.blendMode = egret.BlendMode.ADD
        group.width = bg.width
        group.height = bg.height
        group.x = (this.stage.stageWidth - group.width) / 2
        group.addChild(bg)

        let noticeText = new egret.TextField
        noticeText.text = notice
        noticeText.width = group.width
        noticeText.height = group.height
        noticeText.textAlign = egret.HorizontalAlign.CENTER
        noticeText.verticalAlign = egret.VerticalAlign.MIDDLE
        let size = 30
        noticeText.size = ratio > 0.6 ? size * 0.8 : size
        group.addChild(noticeText)

        return group
    }

    public onBack() {
        let isConnect = SocketX.getInstance().isconnect
        if (isConnect && !this.back) {
            SocketX.getInstance().sendMsg(NetEvent.CACEL_MATCH, {})
            SocketX.getInstance().close()
        }
        DataManager.getInstance().removePkData()
        if (this.back) {
            ViewManager.getInstance().backByName(this.back)
            return
        }
        ViewManager.getInstance().backByName('pkList')
    }
}
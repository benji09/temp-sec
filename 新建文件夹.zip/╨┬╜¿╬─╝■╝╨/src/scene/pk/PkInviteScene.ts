class PkInviteScene extends Scene {
    private avatarGroup
    private type
    private msg
    private line
    private waitPic
    private pkCode
    constructor(type, msg = null, pkCode?) {
        super()
        this.type = type
        this.msg = msg
        this.pkCode = pkCode
    }

    public init() {
        this.setBackground()
        this.close_btn = ''
        Util.setTitle('PK挑战')

        let stageW = ViewManager.getInstance().stage.stageWidth
        let avatarGroup = new eui.Group
        avatarGroup.y = 20
        this.addChild(avatarGroup)
        this.avatarGroup = avatarGroup

        let userInfo = DataManager.getInstance().getUser()
        let leftUser = new PkUser(userInfo)
        leftUser.x = 68
        avatarGroup.addChild(leftUser)

        let pkData = DataManager.getInstance().getPkData()
        let rightUser = new PkUser(pkData ? pkData.pkUser : null, 'right')
        rightUser.x = stageW - rightUser.width - leftUser.x
        avatarGroup.addChild(rightUser)

        let pkVs = Util.createBitmapByName('pk_vs_png')
        pkVs.x = (stageW - pkVs.width) / 2
        pkVs.y = 66
        pkVs.blendMode = egret.BlendMode.ADD
        avatarGroup.addChild(pkVs)

        let line = Util.createBitmapByName('pk_line_png')
        line.width = stageW
        line.y = 350
        line.blendMode = egret.BlendMode.ADD
        line.visible = false
        this.addChild(line)
        this.line = line

        let ratio = Util.getRatio()
        let waitPic = Util.createBitmapByName('pk_end_wait_png')
        waitPic.width = ratio > 0.6 ? waitPic.width * 0.8 : waitPic.width
        waitPic.height = ratio > 0.6 ? waitPic.height * 0.8 : waitPic.height
        waitPic.blendMode = egret.BlendMode.ADD
        waitPic.x = ratio > 0.6 ? 30 : -30
        waitPic.y = 520
        waitPic.visible = false
        this.addChild(waitPic)
        this.waitPic = waitPic

        switch (this.type) {
            case InviteStatus.MATCHEND:
                this.matchEnd()
                this.avatarGroup.y = 420
                break
            default:
                this.pkEnd()
                this.close_btn = '返回'
                this.avatarGroup.y = 116
                this.removeEvent = NetEvent.PK_END
                break
        }
    }

    // 匹配成功
    private timer1
    private matchEnd() {
        let stageW = this.stage.stageWidth

        let label = new egret.TextField
        label.text = '匹配\n成功'
        label.width = stageW
        label.textAlign = egret.HorizontalAlign.CENTER
        label.y = 622
        label.textColor = Config.COLOR_MAIN
        label.size = 60
        label.bold = true
        label.lineSpacing = 30
        this.addChild(label)

        let seconds = 5
        let countDown = new egret.TextField
        countDown.text = '' + seconds
        countDown.width = stageW
        countDown.textAlign = egret.HorizontalAlign.CENTER
        countDown.y = label.y + label.textHeight + 50
        countDown.size = 60
        this.addChild(countDown)

        let timer = new egret.Timer(1000, 8)
        this.timer1 = timer
        timer.addEventListener(egret.TimerEvent.TIMER, () => {
            if (seconds <= 0) return
            seconds--
            countDown.text = '' + seconds
        }, this)

        // if (Config.DEBUG) {
        //     timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
        //         let scene = new BattleScene()
        //         ViewManager.getInstance().changeScene(scene)
        //     }, this)
        // }

        timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
            ViewManager.getInstance().showLoading('哦噢，网络好像出现了问题，\n请重新匹配！')
            this.close_btn = '返回'
            this.createNavButton()
        }, this)

        timer.start()
    }

    private timer
    public pkEnd() {
        this.line.visible = true
        this.waitPic.visible = true

        let info = new LineInfo(this.msg, '(可返回主页，稍后到挑战记录查看结果)')
        this.addChild(info)

        SocketX.getInstance().addEventListener(NetEvent.PK_INFO, (data) => {
            let result = data.data
            if (result.tipsCode != 12) {
                this.timer && clearInterval(this.timer)
                result = DataManager.getInstance().convertPkResult(result)
                let resultScene = new PkResultScene(result)
                ViewManager.getInstance().changeScene(resultScene)
            }
        })

        this.timer = setInterval(() => {
            SocketX.getInstance().sendMsg(NetEvent.PK_INFO, { pkCode: this.pkCode })
        }, 1000)
    }

    public onBack() {
        let isConnect = SocketX.getInstance().isconnect
        if (isConnect) {
            SocketX.getInstance().sendMsg(NetEvent.CACEL_MATCH, {})
            SocketX.getInstance().close()
        }
        DataManager.getInstance().removePkData()
        ViewManager.getInstance().backByName('pkList')
    }

    public release() {
        this.timer && clearInterval(this.timer)
        this.timer1 && this.timer1.stop()
    }
}



class BattleScene extends Scene {
    private index = 0
    private pkData
    private topic
    private userInfo
    private timer
    private timeNumber
    private timeText
    private topicGroup
    private scroller

    private selfProgress
    private otherProgress

    private submitButton

    private canSubmit = true
    private readonly TIMER = 15
    private readonly groupWidth = 514
    private opponentRate = 1
    public init() {
        this.setBackground()
        Util.setTitle('PK挑战')
        this.close_btn = ''

        this.initData()

        let stageW = this.stage.stageWidth
        let stageH = this.stage.stageHeight
        let userInfo = DataManager.getInstance().getUser()
        this.userInfo = userInfo

        let leftUser = new PkUser(userInfo)
        leftUser.x = 68
        leftUser.y = 116
        this.addChild(leftUser)

        let pkData = DataManager.getInstance().getPkData()
        if (Config.DEBUG) {
            pkData = {
                pkCode: "6d8bcc2061b311eaaab4c72eb1651d0c",
                pkType: 3,
                pkUser: { userId: "3", teamId: 1002, nickName: "V准宝", robot: 1 },
                questions: [
                    { id: 5578 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 },
                    { id: 5620 }
                ],
                status: 1,
                type: 3
            }
        }
        this.pkData = pkData

        let rightUser = new PkUser(pkData.pkUser, 'right')
        rightUser.x = stageW - rightUser.width - leftUser.x
        rightUser.y = leftUser.y
        this.addChild(rightUser)

        let pkVs = Util.createBitmapByName('pk_vs_png')
        pkVs.x = (stageW - pkVs.width) / 2
        pkVs.y = 182
        pkVs.blendMode = egret.BlendMode.ADD
        this.addChild(pkVs)

        // 倒计时
        let count_down_time = new egret.TextField()
        count_down_time.text = `00: ${this.TIMER}`
        count_down_time.width = stageW
        count_down_time.y = 115
        count_down_time.textAlign = egret.HorizontalAlign.CENTER
        count_down_time.size = 40
        this.addChild(count_down_time)
        this.timeText = count_down_time

        let line = Util.createBitmapByName('pk_line_png')
        line.width = stageW
        line.y = 320
        line.blendMode = egret.BlendMode.ADD
        this.addChild(line)

        let ratio = Util.getRatio()
        let processY = ratio > 0.6 ? 640 * 0.8 : 640
        let progress = new VProgress(this.pkData.questions.length)
        progress.x = 56
        progress.y = processY
        progress.setRate(1)
        this.addChild(progress)
        this.selfProgress = progress

        let progress2 = new VProgress(this.pkData.questions.length)
        progress2.x = stageW - progress2.width - progress.x
        progress2.y = processY
        progress2.setRate(this.opponentRate)
        this.addChild(progress2)
        this.otherProgress = progress2

        let trainId = this.pkData.questions[this.index]['id']

        let subject: Subject = Util.getTrain(trainId)
        //选项 
        if (!subject) return
        let group = new eui.Group()
        group.width = this.groupWidth
        group.touchEnabled = true
        group.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            this.noticeGroup && (this.noticeGroup.visible = false)
        }, this)

        let topic = new Topic(subject, this.groupWidth)
        this.topic = topic
        group.addChild(topic)
        this.topicGroup = group

        var myScroller: eui.Scroller = new eui.Scroller()
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = this.groupWidth
        myScroller.height = stageH - 720
        myScroller.y = 530
        myScroller.x = (stageW - myScroller.width) / 2
        //设置viewport
        myScroller.viewport = group
        this.scroller = myScroller
        this.addChild(myScroller)

        let notice = this.notice()
        this.addChild(notice)

        let submit = Util.createBitmapByName('pk_btn_png')
        let submitGroup = new eui.Group
        this.submitButton = submitGroup
        
        submitGroup.width = submit.width
        submitGroup.height = submit.height
        submitGroup.x = (stageW - submitGroup.width) / 2
        submitGroup.y = stageH - 130
        submitGroup.addChild(submit)
        this.addChild(submitGroup)

        let submitLabel = new egret.TextField
        submitLabel.text = '提    交'
        submitLabel.width = submitGroup.width
        submitLabel.height = submitGroup.height
        submitLabel.textAlign = egret.HorizontalAlign.CENTER
        submitLabel.verticalAlign = egret.VerticalAlign.MIDDLE
        submitLabel.textColor = Config.COLOR_MAIN
        submitLabel.size = 34
        submitGroup.addChild(submitLabel)

        submitGroup.touchEnabled = true
        submitGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            if (!this.canSubmit) return
            let selectOption = this.topic.getSelect()
            if (!selectOption) {
                this.updateNotice('请选择答案')
                return
            }
            let result = this.topic.getSelectResult()
            this.submitResult(result, selectOption)
            this.topic.setDisableSelected()
        }, this)
    }

    private noticeGroup
    private notice() {
        this.noticeGroup = new eui.Group

        let notice_icon = Util.createBitmapByName('notice_png')
        this.noticeGroup.addChild(notice_icon)
        this.noticeGroup.height = notice_icon.height

        let label = new egret.TextField
        label.size = 32
        label.bold = true
        label.x = notice_icon.width + 10
        label.y = 2
        label.height = this.noticeGroup.height
        label.verticalAlign = egret.VerticalAlign.MIDDLE
        this.noticeGroup.addChild(label)
        
        this.noticeGroup.y = this.stage.stageHeight - 180
        this.noticeGroup.visible = false
        return this.noticeGroup
    }

    private updateNotice(text) {
        let label = this.noticeGroup.$children[1]
        label.text = text
        this.noticeGroup.width = label.x + label.textWidth
        this.noticeGroup.x = (this.stage.stageWidth - this.noticeGroup.width) / 2 - 10
        this.noticeGroup.visible = true
    }

    private timestamp
    private initData() {
        this.timestamp = +new Date()
        this.timeNumber = this.TIMER
        //注册答题结束事件
        SocketX.getInstance().addEventListener(NetEvent.PK_PROGRESS, this.updateProgress, this)
        SocketX.getInstance().addEventListener(NetEvent.PK_ANSWER, (data) => {
            if (data.data.tipsCode == InviteStatus.PK_END_WAIT) { //答题结束
                let pk = new PkInviteScene(InviteStatus.PK_END_WAIT, '你的对手还在苦苦思索中\n请稍等...', this.pkData.pkCode)
                ViewManager.getInstance().changeScene(pk)
            }
        }, this)
        //倒计时
        let timer = new egret.Timer(1000, this.TIMER + 10)
        this.timer = timer
        timer.addEventListener(egret.TimerEvent.TIMER, () => {
            this.timeNumber--
            this.timeText.text = `00: ${this.timeNumber}`
            if (this.timeNumber < 10) {
                this.timeText.text = `00: 0${this.timeNumber}`
            }
            if (this.timeNumber == 0) {
                timer.stop()
                if (!this.canSubmit) return
                this.submitNull()
            }
        }, this)
        timer.start()
    }


    /**
     * 提交答案
     *  1.正常提交
     *  2.超时提交答案
     */
    private timer1
    public submitResult(result, reply) {
        this.canSubmit = false
        let qattrId = this.topic.getQAttrId()
        let useTime = (+new Date() - this.timestamp) / 1000
        let params = {
            userId: this.userInfo.userId,//答题用户ID
            pkCode: this.pkData.pkCode,//唯一PkCode
            type: this.pkData.pkType,//3=在线匹配,4=离线答题
            qid: this.pkData.questions[this.index].id,//问题ID
            qattrId,//问题属性ID
            reply,//用户答案
            isCorrect: result ? 1 : 0,//回答是否正确1=正确,0=错误
            useTime//答题时间
        }
        SocketX.getInstance().sendMsg(NetEvent.PK_ANSWER, params)
        let noticeText = '恭喜您回答正确！'
        if (result) {
            Util.playMusic('answer_ok_mp3')
            this.topic.setSelectedStatus(TopicItem.STATUS_OK)
        } else {
            noticeText = `回答错误，正确答案是${this.topic.getCorrectItem}`
            this.topic.setSelectedStatus(TopicItem.STATUS_ERROR)
            Util.playMusic('answer_err3_mp3')
        }
        this.updateNotice(noticeText)
        this.submitButton.visible = false
        // if (Config.DEBUG) {
        //     let pk = new PkInviteScene(InviteStatus.PK_END_WAIT)
        //     ViewManager.getInstance().changeScene(pk)
        //     return
        // }
        //如果有下一題，直接进入下一题
        if (this.index < this.pkData.questions.length - 1) {
            setTimeout(() => {
                this.next()
                this.selfProgress.setRate(this.index + 1)
                this.timestamp = +new Date()
            }, 2000)
        } else {
            this.timeToEnd()
        }
    }

    private timeToEnd() {
        this.timer1 = setTimeout(() => {
            console.log(333, this.pkData.pkCode)
            SocketX.getInstance().addEventListener(NetEvent.PK_INFO, (data) => {
                let result = data.data
                console.log("BattleScene -> timeToEnd -> result", result)
                if (result.status == 4) {
                    let pk = new PkInviteScene(InviteStatus.PK_END_WAIT, '你的对手还在苦苦思索中\n请稍等...', this.pkData.pkCode)
                    ViewManager.getInstance().changeScene(pk)
                } else {
                    result = DataManager.getInstance().convertPkResult(result)
                    let resultScene = new PkResultScene(result)
                    ViewManager.getInstance().changeScene(resultScene)
                }
            })
            SocketX.getInstance().sendMsg(NetEvent.PK_INFO, { pkCode: this.pkData.pkCode })
        }, 5000)
    }

    public submitNull() {
        this.canSubmit = false
        let qattrId = this.topic.getQAttrId()
        let useTime = this.TIMER - this.timeNumber
        let params = {
            userId: this.userInfo.userId,//答题用户ID
            pkCode: this.pkData.pkCode,//唯一PkCode
            type: this.pkData.pkType,//3=在线匹配,4=离线答题
            qid: this.pkData.questions[this.index].id,//问题ID
            qattrId: qattrId,//问题属性ID
            reply: 'null',//用户答案
            isCorrect: 0,//回答是否正确1=正确,0=错误
            useTime: useTime//答题时间
        }
        SocketX.getInstance().sendMsg(NetEvent.PK_ANSWER, params)
        Util.playMusic('answer_err3_mp3')
        this.selfProgress.setRate(this.index + 2)
        //如果有下一題，直接进入下一题
        if (this.index < this.pkData.questions.length - 1) {
            this.next()
            this.timestamp = +new Date()
        } else {
            this.timeToEnd()
        }
    }

    //进入下一题
    public next() {
        this.noticeGroup && (this.noticeGroup.visible = false)
        this.canSubmit = true
        this.submitButton.visible = true
        this.index++
        this.timeNumber = this.TIMER
        this.timer.reset()
        this.timeText.text = `00: ${this.timeNumber}`
        this.timer.start()
        this.topicGroup.removeChild(this.topic)
        let trainid = this.pkData.questions[this.index].id
        let subject: Subject = Util.getTrain(trainid)
        if (!subject) return
        //选项 
        let topic = new Topic(subject, this.groupWidth)
        this.topic = topic
        this.topicGroup.addChild(topic)
        this.scroller.viewport.scrollV = 0
    }

    /**
     * 更新进度条
     */
    public updateProgress(data) {
        if (data.data.seriaNo != this.opponentRate) {
            return
        }
        this.otherProgress.setRate(data.data.seriaNo + 1)
        this.opponentRate += 1
    }

    public release() {
        this.timer1 && clearTimeout(this.timer1)
    }
}
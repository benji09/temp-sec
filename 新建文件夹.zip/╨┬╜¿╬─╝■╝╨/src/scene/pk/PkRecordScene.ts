class PkRecordScene extends Scene {
    private groupView
    private itemY = 0
    private page = 1
    private pageSize = 20
    private end = false
    private ableScroll = true

    public init() {
        this.setBackground()
        this.close_btn = '返回PK挑战'
        Util.setTitle('PK挑战')
        this.name = 'pkRecord'

        let stageW = ViewManager.getInstance().stage.stageWidth

        let bg = Util.createBitmapByName('sign_bg_png')
        bg.width = stageW
        this.addChild(bg)

        let title = new egret.TextField
        title.text = 'PK挑战'
        title.x = 416
        title.y = 188
        title.size = 50
        title.bold = true
        this.addChild(title)

        let isConnect = SocketX.getInstance().isconnect
        if (isConnect) {
            this.getData()
        } else {
            SocketX.getInstance().connectPersonPk(() => {
                this.getData()
            })
        }

        let group = new eui.Group()
        this.groupView = group

        var myScroller: eui.Scroller = new eui.Scroller()
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = stageW
        myScroller.height = 690
        myScroller.x = 130
        myScroller.y = 350
        //设置viewport
        myScroller.viewport = group
        this.addChild(myScroller)


        myScroller.addEventListener(eui.UIEvent.CHANGE_END, () => {
            if (myScroller.viewport.scrollV + myScroller.height >= myScroller.viewport.contentHeight) {
                if (!this.end && this.ableScroll) {
                    this.ableScroll = false
                    SocketX.getInstance().sendMsg(NetEvent.PK_RECORDS, { page: this.page, pageSize: this.pageSize })
                }
            }
        }, this)

        ViewManager.getInstance().showLoading('数据加载中...')
    }

    private getData() {
        SocketX.getInstance().addEventListener(NetEvent.PK_RECORDS, (data) => {
            console.log("PkRecordScene -> init -> data", data)
            this.ableScroll = true
            ViewManager.getInstance().hideLoading()
            if (data.data.length == 0 && this.page == 1) {
                let tip = new LineInfo('暂无挑战数据')
                tip.y = -150
                this.addChild(tip)
                return
            }
            this.updateGroup(data.data || [])
        })
        SocketX.getInstance().sendMsg(NetEvent.PK_RECORDS, { page: this.page, pageSize: this.pageSize })
    }

    private updateGroup(list) {
        if (list.length < this.pageSize) {
            this.end = true
        }
        this.page += 1
        for (let data of list) {
            let item = new RecordItem(data)
            item.y = this.itemY + 10
            this.groupView.addChild(item)
            this.itemY += 65
        }
    }
}

class RecordItem extends eui.Group {
    private data
    constructor(data) {
        super()
        this.data = data
        this.width = 504
        this.height = 20
        this.init()
    }

    private init() {
        let size = 20
        let fightPerson = new egret.TextField
        fightPerson.text = Util.getStrByWith(this.data.sendName, 100, 20) + '与' + Util.getStrByWith(this.data.acceptName, 100, 20) + '对战'
        fightPerson.width = 280
        fightPerson.height = this.height
        fightPerson.size = size
        this.addChild(fightPerson)

        let result = new egret.TextField()
        result.text = this.data.pkResult.text
        result.width = 100
        result.height = this.height
        result.size = size
        result.x = fightPerson.width
        result.textAlign = egret.HorizontalAlign.CENTER
        if (this.data.pkResult.text == '平局') {
            result.textColor = 0xffffff
        } else if (this.data.pkResult.text == '胜利') {
            result.textColor = Config.COLOR_MAIN
        } else if (this.data.pkResult.text == '无效') {
            result.textColor = 0xf90008
        } else {
            result.textColor = 0xb7b6b6
        }
        this.addChild(result)

        let date = new egret.TextField()
        date.text = this.data.createTime
        date.width = 125
        date.height = this.height
        date.size = size
        date.x = fightPerson.width + result.width
        date.textAlign = egret.HorizontalAlign.RIGHT
        this.addChild(date)

        this.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            SocketX.getInstance().addEventListener(NetEvent.PK_INFO, (data) => {
                let result = data.data
                if (result.tipsCode == InviteStatus.WATTING) {
                    let pk = new PkInviteScene(InviteStatus.WATTING)
                    ViewManager.getInstance().changeScene(pk)
                } else {
                    result = DataManager.getInstance().convertPkResult(result)
                    let resultScene = new PkResultScene(result, 'pkRecord')
                    ViewManager.getInstance().changeScene(resultScene)
                }
            })
            SocketX.getInstance().sendMsg(NetEvent.PK_INFO, { pkCode: this.data.pkCode })
        }, this)
    }

    public updateScene() {
        let isConnect = SocketX.getInstance().isconnect
        if (!isConnect) {
            ViewManager.getInstance().showLoading('连接中......')
            SocketX.getInstance().connectPersonPk(() => {
                setTimeout(() => {
                    ViewManager.getInstance().hideLoading()
                }, 1000)
            })
        }
    }
}   
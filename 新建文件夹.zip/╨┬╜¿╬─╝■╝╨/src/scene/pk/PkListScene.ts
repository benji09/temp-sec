
class PkListScene extends Scene {
    private readonly config = [
        { icon: 'pk_person_png', title: '个人挑战赛', type: 1, status: 1 },
        { icon: 'pk_team_png', title: '团队挑战赛', type: 2, status: 0 }
    ]
    private pkRecord

    public init() {
        this.setBackground()
        Util.setTitle('PK挑战')
        this.close_btn = '首页'
        this.name = 'pkList'
        let stage = ViewManager.getInstance().stage
        
        // 挑战记录
        let pkRecord = this.createRightButton('挑战记录', () => {
            let scene = new PkRecordScene()
            ViewManager.getInstance().changeScene(scene)
        })
        pkRecord.touchEnabled = false
        this.pkRecord = pkRecord
        this.addChild(pkRecord)

        let isConnect = SocketX.getInstance().isconnect
        if (!isConnect) {
            ViewManager.getInstance().showLoading('连接中......')
            SocketX.getInstance().connectPersonPk(() => {
                setTimeout(() => {
                    ViewManager.getInstance().hideLoading()
                    pkRecord.touchEnabled = true
                }, 1000)
            })
        }

        let pkTitle = new egret.TextField
        pkTitle.text = 'PK挑战'
        pkTitle.size = 50
        pkTitle.textColor = Config.COLOR_MAIN
        pkTitle.x = (stage.stageWidth - pkTitle.textWidth) / 2
        pkTitle.y = 166
        pkTitle.bold = true
        this.addChild(pkTitle)
        
        let ratio = Util.getRatio()
        let y = ratio > 0.6 ? 318 * 0.8 : 318
        for (let data of this.config) {
            let item = new PkItem(data)
            this.addChild(item)
            item.y = y
            y += ratio > 0.6 ? 464 * 0.8 : 464
        }
    }

    public onBack() {
        let isConnect = SocketX.getInstance().isconnect
        isConnect && SocketX.getInstance().close()
        ViewManager.getInstance().back()
    }

    public updateScene() {
        let isConnect = SocketX.getInstance().isconnect
        console.log("PkListScene -> updateScene -> isConnect", isConnect)
        if (!isConnect) {
            this.pkRecord.touchEnabled = false
            ViewManager.getInstance().showLoading('连接中......')
            SocketX.getInstance().connectPersonPk(() => {
                setTimeout(() => {
                    ViewManager.getInstance().hideLoading()
                    this.pkRecord.touchEnabled = true
                }, 1000)
            })
        }
    }
}   
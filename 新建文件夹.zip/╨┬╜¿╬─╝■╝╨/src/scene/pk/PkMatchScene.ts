class PkMatchScene extends Scene {
    private timer
    private userInfo
    public init() {
        this.setBackground()
        Util.setTitle('PK挑战')
        this.close_btn = ''

        this.userInfo = DataManager.getInstance().getUser()
        if (!this.userInfo) {
            Http.getInstance().post(Url.HTTP_USER_INFO, "", res => {
                DataManager.getInstance().setUser(res.data)
                this.userInfo = res.data
                this.matchInit()
            })
        } else {
            this.matchInit()
        }
    }

    public matchInit() {
        let stageW = ViewManager.getInstance().stage.stageWidth
        //开始匹配
        SocketX.getInstance().sendMsg(NetEvent.PK_MATCH, { robot: false })

        this.addEventListener(egret.Event.REMOVED, () => this.timer.stop(), this)

        let infoGroup = new eui.Group
        this.addChild(infoGroup)

        let person_info_bg = Util.createBitmapByName('info_bg_png')
        person_info_bg.height = 268

        infoGroup.width = person_info_bg.width
        infoGroup.height = person_info_bg.height
        infoGroup.x = (stageW - infoGroup.width) / 2
        infoGroup.y = 165
        infoGroup.addChild(person_info_bg)

        // 头像边框
        let avatar_border = Util.createBitmapByName('avatar_border_png')
        avatar_border.x = -18
        avatar_border.y = -25
        infoGroup.addChild(avatar_border)

        // 头像
        let url = Config.DEBUG ? 'http://thirdwx.qlogo.cn/mmopen/vi_32/cKqXyr3j6icxgs4TSy6cpMMkbsWXSdAfXqFkLysDgacAbrzulVqj6eulmZGRianMKqDJ9nUbpf1o0VqWXNtKP5yA/132' : this.userInfo.avatar
        let avatar = Util.setUserImg(url, 130)
        avatar.x = 0
        avatar.y = -8
        infoGroup.addChild(avatar)
        
        let label = new egret.TextField
        label.textFlow = [
            {text: '用 户:\n'},
            {text: '来 自:'},
        ]
        label.size = 26
        label.lineSpacing = 65
        label.x = 230
        label.y = 62
        infoGroup.addChild(label)

        let info = new egret.TextField
        info.textFlow = [
            {text: `${Util.getStrByWith(this.userInfo.nickName, 180, 26)}\n`},
            {text: `${Util.getStrByWith(this.userInfo.teamName, 180, 26)}`},
        ]
        info.textAlign = 'right'
        info.size = label.size
        info.lineSpacing = label.lineSpacing
        info.x = 300
        info.width = 200
        info.y = label.y
        infoGroup.addChild(info)

        let y = 98
        for (let i = 0; i < 2; i++) {
            let line = Util.createBitmapByName('line_png')
            line.width = 294
            line.x = 222
            line.y = y
            infoGroup.addChild(line)
            y += 90
        }

        let ratio = Util.getRatio()
        let pk_time_bg = Util.createBitmapByName('pk_time_bg_png')
        pk_time_bg.width = ratio > 0.6 ? pk_time_bg.width * 0.8 : pk_time_bg.width
        pk_time_bg.height = ratio > 0.6 ? pk_time_bg.height * 0.8 : pk_time_bg.height
        pk_time_bg.x = ratio > 0.6 ? 150 : 100
        pk_time_bg.y = 520
        this.addChild(pk_time_bg)

        // let cancelButton = Util.createBitmapByName('pk_cancel_png')
        // cancelButton.x = (stageW - cancelButton.width) / 2
        // cancelButton.y = pk_time_bg.y + pk_time_bg.height + 70
        // this.addChild(cancelButton)
        // cancelButton.touchEnabled = true
        // cancelButton.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
        //     // TODO 通知后台取消匹配
        //     SocketX.getInstance().sendMsg(NetEvent.CACEL_MATCH, {})
        //     SocketX.getInstance().close()
        //     ViewManager.getInstance().back()
        //     Util.playMusic('model_select_mp3')
        // }, this)

        // let cancelText = new egret.TextField
        // cancelText.text = '取消匹配'
        // cancelText.x = (stageW - cancelText.textWidth) / 2
        // cancelText.y = cancelButton.y
        // cancelText.height = cancelButton.height
        // cancelText.verticalAlign = egret.VerticalAlign.MIDDLE
        // cancelText.size = 34
        // this.addChild(cancelText)

        let timerNumber = Config.DEBUG ? 3 : 15
        let matching = new egret.TextField
        matching.text = `匹配中\n00 : ${timerNumber}`
        matching.size = 60
        matching.lineSpacing = 40
        matching.x = (stageW - matching.textWidth) / 2
        matching.y = pk_time_bg.y + 10
        matching.height = pk_time_bg.height
        matching.verticalAlign = egret.VerticalAlign.MIDDLE
        matching.bold = true
        this.addChild(matching)

        var timer: egret.Timer = new egret.Timer(1000, 60)
        this.timer = timer
        timer.addEventListener(egret.TimerEvent.TIMER, () => {
            if (timerNumber <= 0) {
                timer.stop()
                // cancelButton.visible = false
                // cancelText.visible = false
                SocketX.getInstance().sendMsg(NetEvent.PK_MATCH, { robot: true })
            } else {
                timerNumber--
            }
            if (timerNumber < 10) {
                matching.text = `匹配中\n00 : 0${timerNumber}`
            } else {
                matching.text = `匹配中\n00 : ${timerNumber}`
            }
        }, this)

        //注册事件侦听器
        timer.addEventListener(egret.TimerEvent.TIMER_COMPLETE, () => {
            matching.text = `匹配中\n00 : 00`
        }, this)
        timer.start()
    }
}
/* 答题界面 */
class AnswerScene extends Scene {
    private _progress
    private type
    private curIdx = 1
    private isNext = false

    private favButton
    private commitButton
    private topic
    private numberText

    private answers: Answers
    private curSubject

    private levelData

    private topicGroup
    private scroller

    private start

    constructor(answers, type = AnswerType.TRAIN, levelData = null) {
        super()
        this.answers = answers
        this.type = type
        this.levelData = levelData
    }

    public init() {
        this.setBackground()
        this.start = +new Date()

        let stage = ViewManager.getInstance().stage

        if (this.type == AnswerType.TRAIN) {
            let trainTitle = this.trainTitle()
            this.addChild(trainTitle)

            // 进度条
            let pBar = new ProcessBar(this.answers.questions.length, this.curIdx)
            pBar.x = 158
            pBar.y = 100
            this.addChild(pBar)
            this._progress = pBar
        } else if (this.type == AnswerType.FAVOR) {
            let favor_line = Util.createBitmapByName('rule_line_png')
            favor_line.width = 560
            favor_line.x = (stage.stageWidth - favor_line.width) / 2
            favor_line.y = 156
            this.addChild(favor_line)

            let favorTitle = new egret.TextField
            favorTitle.text = this.levelData.name
            favorTitle.size = 40
            favorTitle.width = stage.stageWidth
            favorTitle.textAlign = egret.HorizontalAlign.CENTER
            favorTitle.y = 140
            this.addChild(favorTitle)
        }

        let trainId = this.answers.questions[this.curIdx - 1].qid
        let subject: Subject = Util.getTrain(trainId)
        if (!subject) return
        this.curSubject = subject

        //选项 
        var group = new eui.Group()
        group.height = 5000
        group.touchEnabled = true
        this.topicGroup = group

        let topic = new Topic(subject)
        topic.x = (stage.stageWidth - topic.width) / 2
        this.topic = topic

        group.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            this.noticeGroup && (this.noticeGroup.visible = false)
        }, this)
        group.addChild(topic)

        var myScroller: eui.Scroller = new eui.Scroller()
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = stage.stageWidth
        myScroller.height = stage.stageHeight - 500
        myScroller.y = 210
        //设置viewport
        myScroller.viewport = group
        this.addChild(myScroller)
        this.scroller = myScroller

        let notice = this.notice()
        this.addChild(notice)

        let button_x = 68
        let button_y = stage.stageHeight - 170
        
        // 收藏按钮
        let favorButton = this.favorButton()
        favorButton.x = button_x
        favorButton.y = button_y
        favorButton.visible = this.type == AnswerType.TRAIN
        this.addChild(favorButton)
        this.favButton = favorButton

        // 删除按钮
        let removeFavor = this.removeFavor()
        removeFavor.x = button_x
        removeFavor.y = button_y
        removeFavor.visible = this.type == AnswerType.FAVOR
        this.addChild(removeFavor)
        
        // 提交按钮
        let subButton = this.subButton()
        subButton.x = stage.stageWidth - subButton.width - button_x
        subButton.y = button_y
        this.addChild(subButton)
        this.commitButton = subButton
    }

    private trainTitle() {
        let group = new eui.Group

        let answer_title_bg = Util.createBitmapByName('answer_title_bg_png')
        answer_title_bg.x = 55
        answer_title_bg.y = 66
        group.addChild(answer_title_bg)

        let number = new egret.TextField()
        number.text = "Q" + this.curIdx
        number.x = answer_title_bg.x
        number.y = answer_title_bg.y + 4
        number.width = answer_title_bg.width
        number.height = answer_title_bg.height
        number.textAlign = egret.HorizontalAlign.CENTER
        number.verticalAlign = egret.VerticalAlign.MIDDLE
        this.numberText = number
        group.addChild(number)

        return group
    }

    private favorButton() {
        let button = new Button(
            this.answers.questions[this.curIdx - 1].isCollect ? 'icon_favor_png' : 'icon_favor_not_png', 
            this.answers.questions[this.curIdx - 1].isCollect ? '已收藏' : '收藏', 
            () => {
            //请求收藏id 
            let qid = this.answers.questions[this.curIdx - 1].qid
            let isFavor = this.answers.questions[this.curIdx - 1].isCollect
        
            Http.getInstance().post(Url.HTTP_FAVOR_SUBJECT, { qid: qid, type: isFavor ? 2 : 1 }, () => {
                this.answers.questions[this.curIdx - 1].isCollect = !isFavor
                button.changeIcon(this.answers.questions[this.curIdx - 1].isCollect ? 'icon_favor_png' : 'icon_favor_not_png')
                button.changeText(this.answers.questions[this.curIdx - 1].isCollect ? '已收藏' : '收藏')
            })
        })
        return button
    }

    private removeFavor() {
        let button = new Button('icon_remove_png', '删除', () => {
            //请求收藏id 
            let qid = this.answers.questions[this.curIdx - 1].qid
        
            if (!this.answers.questions[this.curIdx - 1]) return
            Http.getInstance().post(Url.HTTP_FAVOR_SUBJECT, { qid: qid, type: 2 }, () => {
                this.answers.questions.splice(this.curIdx - 1, 1)
                if (this.answers.questions.length == 0) {
                    let scene = new FavorScene()
                    ViewManager.getInstance().changeScene(scene)
                    return
                }
                // 最后一项
                if (this.curIdx >= this.answers.questions.length) {
                    this.curIdx = this.answers.questions.length - 1
                }
                this.next()
            })
        })
        return button
    }

    private ableClick = true
    private subButton() {
        let subButton = new Button('icon_next_png', '提交', () => {
            let isEnd = this.curIdx == this.answers.questions.length
            if (isEnd && this.isNext) {
                if (!this.ableClick) return
                this.ableClick = false
                if (this.type == AnswerType.TRAIN) {
                    Http.getInstance().post(Url.HTTP_TRAIN_END, {
                        lifecycleid: this.answers.lifecycleId,
                        levelid: this.levelData.levelid
                    }, (res) => {
                        DataManager.getInstance().updateUser('lv', res.data.lv)
                        console.log("subButton -> res", res)

                        if (res.data.isOpen && res.data.isPass) {
                            let passAlert = new Pass(res.data.isOpen)
                            this.addChild(passAlert)
                        } else {
                            let icon = 'icon_pass_png'
                            let text = '恭喜您完成\n本小关的题目，请进入下一小关'
                            if (!res.data.isPass) {
                                icon = 'icon_fail_png'
                                text = '很遗憾\n闯关失败，请再接再厉哦！'
                            }

                            let nextLevel = res.data.isendlevel ? undefined : res.data.nextlevel
                            let alert = new AlertPanel(text, icon, 240, nextLevel)
                            alert.setFn(() => {
                                ViewManager.getInstance().backByName('trainLevelScene')
                            })
                            this.addChild(alert)
                        }
                    })
                } else {
                    ViewManager.getInstance().back()
                }
            } else {
                if (this.isNext) { //下一题
                    this.isNext = false
                    this.next()
                } else { //提交
                    let selectOption = this.topic.getSelect()

                    if (!selectOption) {
                        this.updateNotice('请选择答案')
                        return
                    }
                    this.isNext = true
                    this.topic.setDisableSelected()
                    subButton.ableClick(false)

                    let qid = this.answers.questions[this.curIdx - 1].qid
                    let result = this.topic.getSelectResult()
                    let currentTime = + new Date()
                    let useTime = (currentTime - this.start) / 1000
                    let params = {
                        levelid: this.levelData.levelid,
                        lifecycleid: this.answers.lifecycleId,
                        qid,
                        serialno: this.curIdx,
                        qattrid: this.curSubject.qattrid,
                        reply: selectOption,
                        iscorrect: result ? 1 : 0,
                        useTime
                    }
                    Http.getInstance().post(Url.HTTP_TRAIN_SUBMIT, params, () => {
                        let noticeText = '恭喜您回答正确！'
                        if (result) {
                            Util.playMusic('answer_ok_mp3')
                            this.isNext && this.topic.setSelectedStatus(TopicItem.STATUS_OK)
                        } else {
                            Util.playMusic('answer_err3_mp3')
                            noticeText = `回答错误，正确答案是${this.topic.getCorrectItem}`
                            this.isNext && this.topic.setSelectedStatus(TopicItem.STATUS_ERROR)
                        }
                        this.updateNotice(noticeText)
                        let buttonText = "下一题"
                        if (isEnd) {
                            buttonText = "结束"
                        }
                        subButton.changeText(buttonText)
                        subButton.ableClick(true)
                    })
                }
            }
        })
        return subButton
    }
    
    public next() {
        this.noticeGroup && (this.noticeGroup.visible = false)
        this.start = +new Date()
        this.commitButton.changeText('提交')
        this.curIdx = this.curIdx + 1

        if (this.type == AnswerType.TRAIN) {
            this.numberText.text = `Q${this.curIdx}`
            this.favButton.changeIcon(this.answers.questions[this.curIdx - 1].isCollect ? 'icon_favor_png' : 'icon_favor_not_png')
            this.favButton.changeText(this.answers.questions[this.curIdx - 1].isCollect ? '已收藏' : '收藏')
        }
        if (this._progress) {
            this._progress.setRate(this.curIdx)
        }

        let trainId = this.answers.questions[this.curIdx - 1].qid
        let subject: Subject = Util.getTrain(trainId)
        if (!subject) return
        this.curSubject = subject

        this.topicGroup.removeChild(this.topic)
        //选项 
        let topic = new Topic(subject)
        topic.x = (this.stage.stageWidth - topic.width) / 2
        this.topic = topic
        this.topicGroup.addChild(topic)
        this.scroller.viewport.scrollV = 0
    }

    private noticeGroup
    private notice() {
        this.noticeGroup = new eui.Group

        let notice_icon = Util.createBitmapByName('notice_png')
        this.noticeGroup.addChild(notice_icon)
        this.noticeGroup.height = notice_icon.height

        let label = new egret.TextField
        label.size = 32
        label.bold = true
        label.x = notice_icon.width + 10
        label.y = 2
        label.height = this.noticeGroup.height
        label.verticalAlign = egret.VerticalAlign.MIDDLE
        this.noticeGroup.addChild(label)
        
        this.noticeGroup.y = this.stage.stageHeight - 240
        this.noticeGroup.visible = false
        return this.noticeGroup
    }

    private updateNotice(text) {
        let label = this.noticeGroup.$children[1]
        label.text = text
        this.noticeGroup.width = label.x + label.textWidth
        this.noticeGroup.x = (this.stage.stageWidth - this.noticeGroup.width) / 2
        this.noticeGroup.visible = true
    }

    public onBack() {
        if (this.type == AnswerType.TRAIN) {
            let alert = new AlertPanel('提示\n中途退出不做记录\n将重新开始闯关', '', 200, '', true)
            this.addChild(alert)
            return
        }
        ViewManager.getInstance().backByName('favorScene')
    }
}
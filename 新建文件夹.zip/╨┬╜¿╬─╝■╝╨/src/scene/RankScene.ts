class RankScene extends Scene {
    private label
    private personal_prot
    private team_prot
    private area_prot
    private currentIdx = 1
    private personRank = []
    private teamRank = []
    private areaRank = []
    private personPage = 1
    private teamPage = 1
    private size = 50
    private scrollView
    private topThree = new eui.Group
    private otherGroup = new eui.Group

    public constructor(label = '闯关排行榜') {
        super()
        this.label = label
        if (this.label === '闯关排行榜') {
            this.personal_prot = Url.HTTP_PERSON_RANK_LIST
            this.team_prot = Url.HTTP_TEAM_RANK_LIST
            this.area_prot = Url.HTTP_PERSON_RANK_AREA
        } else {
            this.personal_prot = Url.HTTP_PERSON_PK_RANK_LIST
            this.team_prot = Url.HTTP_TEAM_PK_RANK_LIST
            this.area_prot = Url.HTTP_PERSON_PK_RANK_AREA
        }
    }

    public init() {
        this.setBackground('rank_bg_png')
        Util.setTitle('排行榜')

        if (this.label === 'PK排行榜') {
            let categoryTitle = new egret.TextField
            categoryTitle.text = this.label
            categoryTitle.x = (this.stage.stageWidth - categoryTitle.width) / 2 - 20
            categoryTitle.y = 35
            categoryTitle.textColor = Config.COLOR_MAIN
            categoryTitle.size = 40
            this.addChild(categoryTitle)
        }

        this.initTitle()

        // 请求个人数据
        this.getRank(this.personal_prot, this.personPage, this.size)
            .then(data => {
                this.personRank = data.list
                this.personPage = data.page
                this.initRanker(this.currentIdx)
                this.addChildAt(this.topThree, 1)
            })

        // 请求战队数据
        this.getRank(this.team_prot, this.teamPage, this.size)
            .then(data => {
                this.teamRank = data.list
                this.teamPage = data.page
            })

        // 请求大区数据
        this.getRank(this.area_prot, 1, this.size)
            .then(data => {
                this.areaRank = data.list
            })

        // 积分规则
        let ruleText = this.label === '闯关排行榜' ? '闯关' : 'PK'
        let ruleBtn = this.createRightButton(ruleText + '游戏规则', () => {
            let scene = new RuleScene(this.label)
            ViewManager.getInstance().changeScene(scene)
        })
        this.addChild(ruleBtn)
    }
    
    private getRank(url, page, size): any {
        return new Promise(resolve => {
            Http.getInstance().post(url, { page, size }, json => {
                page = json.data.length == size ? page + 1 : - 1
                resolve({list: json.data, page})
            })
        })
    }

    private initTitle() {
        let rank_variety = [
            { name: '个人排行榜', y: 0 },
            { name: '战队排行榜', y: 0 },
            { name: '大区排行榜', y: 450 },
        ]
        let titleArr = []

        let x = 32
        rank_variety.forEach((item, i) => {
            let title = new RankTitle(item.name)
            title.x = x
            title.y = 120
            i != this.currentIdx - 1 && title.hideFlag()
            this.addChild(title)
            titleArr.push(title)
            x += title.width

            title.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                titleArr.forEach(t => t.hideFlag())
                title.showFlag()
                this.currentIdx = i + 1
                this.initRanker(this.currentIdx)
                this.topThree.y = item.y
                Util.playMusic('model_select_mp3')
            }, this)
        })
    }

    private topThreeUserData = [
        { w: 146, y: 194},
        { w: 120, y: 295},
        { w: 120, y: 295},
    ]
    private getMoreArrow
    private initRanker(type) {
        // 切换排名先删除清空子元素
        this.topThree.$children.length > 0 && this.topThree.removeChildren()
        this.otherGroup.$children.length > 0 && this.otherGroup.removeChildren()
        this.getMoreArrow && this.removeChild(this.getMoreArrow)
        this.scrollView && (this.scrollView.viewport.scrollV = 0, this.scrollView.stopAnimation())

        if (type == 3) {
            let rank_area_arrow = Util.createBitmapByName('rank_area_arrow_png')
            rank_area_arrow.x = (this.stage.stageWidth - rank_area_arrow.width) / 2
            rank_area_arrow.y = -130
            rank_area_arrow.blendMode = egret.BlendMode.ADD
            this.topThree.addChild(rank_area_arrow)
        }

        let rankDatas = type == 1 ? this.personRank : type == 2 ? this.teamRank : this.areaRank

        rankDatas.forEach((item, idx) => {
            if (idx > 2) return
            let topThreeUser = this.topThreeUser(item, this.topThreeUserData[idx].w, type)
            topThreeUser && (topThreeUser.y = this.topThreeUserData[idx].y)
            topThreeUser.x = idx == 0 ? (this.stage.stageWidth - topThreeUser.width) / 2 : idx == 1 ? 100 : this.stage.stageWidth - topThreeUser.width - 100
            this.topThree.addChild(topThreeUser)
        })

        let platform = Util.createBitmapByName('rank_platform_png')
        platform.x = (this.stage.stageWidth - platform.width) / 2
        platform.y = 350
        this.topThree.addChild(platform)

        let platform_line = Util.createBitmapByName('rank_platform_line_png')
        platform_line.x = (this.stage.stageWidth - platform_line.width) / 2
        platform_line.y = platform.y + platform.height - platform_line.height / 2 - 52
        platform_line.blendMode = egret.BlendMode.ADD
        this.topThree.addChild(platform_line)

        var myScroller: eui.Scroller = new eui.Scroller()
        //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
        myScroller.width = this.stage.stageWidth
        myScroller.height = this.stage.stageHeight - 734
        myScroller.y = platform_line.y + platform_line.height
        //设置viewport
        myScroller.viewport = this.otherGroup
        this.addChild(myScroller)
        this.scrollView = myScroller

        // 上滑加载更多
        myScroller.addEventListener(eui.UIEvent.CHANGE_END, () => {
            if (myScroller.viewport.scrollV + myScroller.height >= myScroller.viewport.contentHeight) {
                this.loadMoreData()
            }
        }, this)

        type != 3 && this.addItem(rankDatas)

        this.getMoreArrow = Util.createBitmapByName('rank_arrow_png')
        this.getMoreArrow.x = (this.stage.stageWidth - this.getMoreArrow.width) / 2
        this.getMoreArrow.y = myScroller.height + myScroller.y
        this.getMoreArrow.visible = rankDatas.length > 8
        this.addChild(this.getMoreArrow)
    }

    private topThreeUser(userInfo, w, type) {
        if (!userInfo) return
        let group = new eui.Group
        group.width = w

        if (type != 3) {
            let avatarGroup = this.avatarGroup(userInfo, w)
            group.addChild(avatarGroup)
        } else {
            let avatar = Util.createBitmapByName(`${userInfo.shortname}_png`)
            let avatar_ratio = avatar.width / avatar.height
            avatar.width = w
            avatar.height = w / avatar_ratio
            avatar.y = -60
            group.addChild(avatar)
        }

        try {
            let user = new egret.TextField
            let name = userInfo.userName || userInfo.teamName || ''
            let category = this.label === '闯关排行榜' ? '积分' : '胜率'
            let percent = this.label === '闯关排行榜' ? '' : '%'
            user.text = Util.getStrByWith(name, w, 24) + `\n${category}:${parseFloat(userInfo.score.toFixed(2)) + percent}`
            user.width = w + 60
            user.x = -30
            user.y = w + 15
            user.lineSpacing = 10
            user.size = 24
            user.textAlign = egret.HorizontalAlign.CENTER
            group.addChild(user)
        } catch (error) {
            
        }

        return group
    }

    private otherUser(userInfo) {
        let group = new eui.Group
        
        let item_bg = Util.createBitmapByName('rank_item_bg_png')
        item_bg.blendMode = egret.BlendMode.ADD
        item_bg.visible = userInfo.serialNo % 2 == 1
        group.addChild(item_bg)
        group.width = item_bg.width
        group.height = item_bg.height

        let number = new egret.TextField
        number.text = userInfo.serialNo
        number.x = 90
        number.width = 100
        number.height = group.height
        number.textAlign = egret.HorizontalAlign.CENTER
        number.verticalAlign = egret.VerticalAlign.MIDDLE
        number.size = 50
        group.addChild(number)

        let avatar = this.avatarGroup(userInfo, 88)
        avatar.x = 190
        avatar.y = 15
        group.addChild(avatar)

        let username = new egret.TextField
        username.text = userInfo.userName || userInfo.teamName
        username.x = 300
        username.width = 200
        username.height = group.height
        username.verticalAlign = egret.VerticalAlign.MIDDLE
        username.size = 24
        group.addChild(username)

        let icon = Util.createBitmapByName(this.label === '闯关排行榜' ? 'rank_icon_png' : 'rank_pk_icon_png')
        icon.x = 510
        icon.y = 40
        group.addChild(icon)

        try {
            let scoreLabel = new egret.TextField
            let percent = this.label === '闯关排行榜' ? '' : '%'
            scoreLabel.text = parseFloat(userInfo.score.toFixed(2)) + percent
            scoreLabel.x = 567
            scoreLabel.height = group.height
            scoreLabel.verticalAlign = egret.VerticalAlign.MIDDLE
            scoreLabel.size = 30
            group.addChild(scoreLabel)
        } catch (error) {
            
        }

        return group
    }

    private avatarGroup(userInfo, w) {
        let group = new eui.Group
        group.width = group.height = w

        let avatar_border = Util.createBitmapByName('avatar_border_png')
        avatar_border.width = avatar_border.height = w
        group.addChild(avatar_border)

        let avatar = Util.setUserImg(userInfo.avatar, w - 32)
        if (avatar) {
            avatar.x = avatar.y = 16
            group.addChild(avatar)
        }

        return group
    }

    private addItem(data, y = 0) {
        data.forEach(item => {
            if (item.serialNo < 4) return
            let otherUser = this.otherUser(item)
            otherUser.y = y
            this.otherGroup.addChild(otherUser)
            y += otherUser.height
        })
    }

    private loadMoreData() {
        if (this.currentIdx == 1 && this.personPage > 0) {
            this.getRank(this.personal_prot, this.personPage, this.size).then(data => {
                if (this.personPage == data.page) return
                this.personRank = this.personRank.concat(data.list)
                this.personPage = data.page
                this.addItem(data.list, this.scrollView.viewport.contentHeight)
            })
        }

        if (this.currentIdx == 2 && this.teamPage > 0) {
            this.getRank(this.team_prot, this.teamPage, this.size).then(data => {
                if (this.teamPage == data.page) return
                this.teamRank = this.teamRank.concat(data.list)
                this.teamPage = data.page
                this.addItem(data.list, this.scrollView.viewport.contentHeight)
            })
        }
    }
}
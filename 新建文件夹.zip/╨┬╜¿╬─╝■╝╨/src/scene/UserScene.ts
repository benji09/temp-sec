class UserScene extends Scene {
    private userInfo
    public constructor() {
        super()
    }

    public init() {
        Util.setTitle('个人中心')
        this.close_btn = '首页'

        this.userInfo = DataManager.getInstance().getUser()

        let bg = Util.createBitmapByName('bg_png')
        bg.width = this.stage.stageWidth
        bg.height = this.stage.stageHeight
        this.addChild(bg)

        let shareGroup = new eui.Group
        this.addChild(shareGroup)

        let title_bg = Util.createBitmapByName('user_title_png')
        title_bg.x = (this.stage.stageWidth - title_bg.width) / 2
        title_bg.y = 118
        shareGroup.addChild(title_bg)

        // 标题
        let title = new Title('个人中心')
        shareGroup.addChild(title)

        let userGroup = new eui.Group

        // 用户信息
        let infoGroup = this.infoGroup()
        infoGroup.y = 30
        userGroup.addChild(infoGroup)

        // 维度图
        let radarGroup = this.radarGroup()
        radarGroup.y = 270
        userGroup.addChild(radarGroup)

        // pk
        let pkGroup = this.pkGroup()
        pkGroup.y = 600
        userGroup.addChild(pkGroup)

        let myScroller: eui.Scroller = new eui.Scroller()
        myScroller.width = this.stage.stageWidth
        myScroller.height = this.stage.stageHeight - 450
        myScroller.y = 290
        myScroller.viewport = userGroup
        shareGroup.addChild(myScroller)

        // 保存图片
        let saveBtn = new Button('icon_save_png', '保存图片', () => {
            let alert = new AlertPanel("提示\n请自行截图保存图片！")
            this.addChild(alert)
        })
        saveBtn.x = 74
        saveBtn.y = this.stage.stageHeight - 120
        this.addChild(saveBtn)

        // 分享
        let shareBtn = new Button('icon_share_png', '分享', () => {
            let tips = new SharePanel()
            this.addChild(tips)
        })
        shareBtn.x = this.stage.stageWidth - shareBtn.width - 74
        shareBtn.y = saveBtn.y
        this.addChild(shareBtn)

        // 积分规则
        let ruleBtn = this.createRightButton('游戏规则', () => {
            let scene = new RuleScene()
            ViewManager.getInstance().changeScene(scene)
        })
        this.addChild(ruleBtn)

        let lv = Math.floor((this.userInfo.lv - 1) / 8)
        // 注册微信分享
        Util.registerShare(shareGroup, lv, this.userInfo.nickName)
    }

    private infoGroup() {
        let group = new eui.Group

        let info_bg = Util.createBitmapByName('info_bg_png')
        info_bg.x = (this.stage.stageWidth - info_bg.width) / 2
        group.addChild(info_bg)

        // 头像边框
        let avatar_border = Util.createBitmapByName('avatar_border_png')
        avatar_border.x = 62
        avatar_border.y = -21
        group.addChild(avatar_border)

        // 头像
        let avatar = Util.setUserImg(this.userInfo.avatar, 130)
        avatar.x = 78
        avatar.y = -5
        group.addChild(avatar)

        let name_label = new egret.TextField
        name_label.text = this.userInfo.nickName
        name_label.x = 260
        name_label.y = 37
        name_label.size = 40
        name_label.bold = true
        name_label.textColor = 0x39f4e6
        group.addChild(name_label)

        let score = new egret.TextField
        score.text = `总积分：${this.userInfo.score}`
        score.x = name_label.x
        score.y = 103
        group.addChild(score)

        let score_line = Util.createBitmapByName('line_png')
        score_line.width = 159
        score_line.x = 250
        score_line.y = 141
        group.addChild(score_line)

        let rank = new egret.TextField
        rank.text = `全国排名：${this.userInfo.personRank}`
        rank.x = 440
        rank.y = score.y
        score.size = rank.size = 26
        group.addChild(rank)

        let rank_line = Util.createBitmapByName('line_png')
        rank_line.width = 187
        rank_line.x = 435
        rank_line.y = score_line.y
        group.addChild(rank_line)
        return group
    }

    private radarGroup() {
        let group = new eui.Group

        let border = Util.createBitmapByName('border_png')
        border.x = (this.stage.stageWidth - border.width) / 2
        border.height = 294
        group.addChild(border)

        let x = 128
        let y = 42
        this.userInfo.attrInfo.forEach((item, index) => {
            let lv = this.userInfo.lv - 1 - index * 8
            if (lv < 0) {
                lv = 0
            } else if (lv > 8) {
                lv = 8
            }
            item.lv = lv
            if (index == 4) return
            let process = this.process(item, index)
            process.x = x
            process.y = y
            group.addChild(process)
            y += 44
        })

        let score = new egret.TextField
        score.text = `闯关积分：${this.userInfo.trainScore}`
        score.x = 175
        score.y = 227
        score.size = 16
        group.addChild(score)

        let line = Util.createBitmapByName('line_png')
        line.x = score.x
        line.y = 250
        line.width = 172
        group.addChild(line)

        // 雷达图
        let radar = this.radar()
        radar.x = 460
        radar.y = 60
        group.addChild(radar)
        
        return group
    }

    private process(item, index) {
        let group = new eui.Group

        let icon = Util.createBitmapByName(`train_icon_0${index + 1}_png`)
        icon.width = 44
        icon.height = 44
        group.addChild(icon)

        let process = Util.createBitmapByName(`process_${item.lv}_png`)
        process.x = 50
        process.y = 10
        process.blendMode = egret.BlendMode.ADD
        group.addChild(process)

        let title = new egret.TextField
        title.text = item.name
        title.x = process.x + process.width + 10
        title.y = process.y + 5
        title.size = 16
        group.addChild(title)

        return group
    }

    private radar() {
        let group = new eui.Group

        // 雷达图
        let radar_bg = Util.createBitmapByName('radar_bg_png')
        radar_bg.blendMode = egret.BlendMode.ADD
        group.addChild(radar_bg)

        let radar = new Radar(this.userInfo.attrInfo, 130, 125)
        radar.rotation = -18
        radar.x = -2
        radar.y = 43
        group.addChild(radar)

        let lock = Util.createBitmapByName('lock_png')
        let lock_ratio = lock.width / lock.height
        lock.width = 30
        lock.height = lock.width / lock_ratio
        lock.x = 65
        lock.y = 60
        lock.visible = this.userInfo.lv < 32
        group.addChild(lock)

        let arr = [
            { name: '知', attr: '疾病', x: 74, y: -30 },
            { name: '熟', attr: '品牌', x: 10, y: 154 },
            { name: '懂', attr: '产品', x: 136, y: 154 },
            { name: '晓', attr: '竞品', x: 172, y: 46 },
            { name: '最', attr: '活跃', x: -25, y: 46 },
        ]

        this.userInfo.attrInfo.forEach((item, index) => {
            let text = new egret.TextField
            text.textFlow = [
                { text: `${arr[index].name}`, style: { size: 18 }},
                { text: `\n${arr[index].attr}`, style: { size: 10}}
            ]
            text.x = arr[index].x
            text.y = arr[index].y
            group.addChild(text)
        })

        return group
    }

    private pkGroup() {
        let group = new eui.Group

        let border = Util.createBitmapByName('border_png')
        border.x = (this.stage.stageWidth - border.width) / 2
        border.height = 190
        group.addChild(border)
        group.height = border.height

        let fight = Util.createBitmapByName('fight_png')
        fight.x = 130
        fight.y = 56
        group.addChild(fight)

        let text = new egret.TextField
        text.textFlow = [
            { text: `本周参赛场次：${this.userInfo.pkCount}`},
            { text: `\n本周胜率：${this.userInfo.pkRate ? this.userInfo.pkRate : '0%'}`},
        ]
        text.x = 256
        text.y = 55
        text.size = 20
        text.lineSpacing = 40
        group.addChild(text)

        let line = Util.createBitmapByName('line_png')
        line.x = 254
        line.y = 90
        line.width = 375
        group.addChild(line)

        return group
    }

    public onBack() {
        let home = new IndexScene()
        ViewManager.getInstance().changeScene(home)
    }
}
class TrainScene extends Scene {
    private bandges
    private trainLevelGroup
    private userInfo
    private isInit = false
    private timer = null
    constructor() {
        super()
    }
    
    public init() {
        this.setBackground('train_bg_png')
        Util.setTitle('答题闯关')
        this.name = 'trainScene'

        let bandges = Util.getConfig('bandge')
        this.bandges = bandges

        let trainLevelGroup = new eui.Group()
        trainLevelGroup.y = 340
        this.addChild(trainLevelGroup)
        this.trainLevelGroup = trainLevelGroup

        this.trainLevel()

        // 我的收藏
        let favor_btn = this.createRightButton('我的收藏', () => {
            let scene = new FavorScene()
            ViewManager.getInstance().changeScene(scene)
        })
        this.addChild(favor_btn)
    }

    private trainLevel() {
        this.trainLevelGroup.$children.length && this.trainLevelGroup.removeChildren()

        this.userInfo = DataManager.getInstance().getUser()
        if (!this.userInfo) {
            this.timer = new egret.Timer(500, 5)
            this.timer.addEventListener(egret.TimerEvent.TIMER, this.timerFunc, this)
            this.timer.start()
        } else {
            this.initLevel()
        }
    }

    private timerFunc() {
        if (!this.isInit) {
            this.userInfo = DataManager.getInstance().getUser()
            if (this.userInfo) this.initLevel()
        }
    }

    private initLevel() {
        this.isInit = true
        if (this.timer) this.timer.stop()

        let currentTrain = Math.ceil(this.userInfo.lv / 8) - 1
        let grayFilter = Util.grayFilter()
        let unOpenId = 2
        
        // 关卡
        this.bandges.forEach((item, i) => {
            item.icon = `train_icon_0${i + 1}_png`
            let trainLevelItem = new TrainLevelItem(item, i)
            trainLevelItem.x = i % 2 == 0 ? 120 : this.stage.stageWidth - trainLevelItem.width - 120
            let y = (i > 1 ? 1 : 0) * (trainLevelItem.height + 40) + ( i % 2 == 0 ? 40 : 140 )
            let ratio = Util.getRatio()
            trainLevelItem.y = ratio > 0.6 ? y * 0.8 : y
            trainLevelItem.filters = this.userInfo.lv < item.start ? [grayFilter] : []
            if (i > unOpenId) trainLevelItem.filters = [grayFilter]
            this.trainLevelGroup.addChild(trainLevelItem)

            let lock = Util.createBitmapByName('lock_png')
            let lock_ratio = lock.width / lock.height
            lock.width = ratio > 0.6 ? 47 * 0.8 : 47
            lock.height = lock.width / lock_ratio
            lock.x = (trainLevelItem.width - lock.width) / 2 + 4
            lock.y = 115
            lock.visible = i > currentTrain || i > unOpenId
            trainLevelItem.addChild(lock)

            trainLevelItem.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                if (i <= unOpenId) {
                    if (this.userInfo.lv < item.start) {
                        let alert = new AlertPanel("提示\n请先通关前面的关卡再来哦！")
                        this.addChild(alert)
                    } else {
                        DataManager.getInstance().setCurrentBandge(item)
                        let scene = new TrainLevelScene(item, i)
                        ViewManager.getInstance().changeScene(scene)
                    }
                } else {
                    let alert = new AlertPanel(`${item.name} 关卡还未上线，\n敬请期待`)
                    this.addChild(alert)
                }
                Util.playMusic('model_select_mp3')
            }, this)

            if (i < this.bandges.length - 1) {
                let lineName = `train_line_0${i + 1}_png`
                let line = Util.createBitmapByName(lineName)
                line.height = ratio > 0.6 ? line.height * 0.8 : line.height
                line.x = (this.stage.stageWidth - line.width) / 2
                let line_y = i == 0 ? 165 : i == 1 ? 280 : 520
                line.y = ratio > 0.6 ? line_y * 0.85 : line_y
                this.trainLevelGroup.addChild(line)
            }

            if (i == currentTrain && i <= unOpenId) {
                egret.Tween.get(trainLevelItem, { loop: true })
                    .to({y: trainLevelItem.y + 15}, 2000)
                    .to({y: trainLevelItem.y}, 2000)
            }
        })
    }

    public onBack() {
        let scene = new IndexScene()
        ViewManager.getInstance().changeScene(scene)
    }

    public updateScene() {
        this.trainLevel()
    }
}
class FavorScene extends Scene {
    private flag = true
    constructor() {
        super()
    }

    public init() {
        this.setBackground('favor_bg_png')
        Util.setTitle('答题闯关')
        this.name = 'favorScene'

        // 标题
        let title = new Title('我的收藏', 128)
        this.addChild(title)

        let bandges = Util.getConfig('bandge')
        let trainLevelGroup = new eui.Group()
        trainLevelGroup.y = 340
        this.addChild(trainLevelGroup)

        let stage = ViewManager.getInstance().stage
        bandges.forEach((item, i) => {
            item.icon = `train_icon_0${i + 1}_png`
            let trainLevelItem = new TrainLevelItem(item, i)
            trainLevelItem.x = i % 2 == 0 ? 120 : stage.stageWidth - trainLevelItem.width - 120
            let y = (i > 1 ? 1 : 0) * (trainLevelItem.height + 40) + ( i % 2 == 0 ? 40 : 140 )
            let ratio = Util.getRatio()
            trainLevelItem.y = ratio > 0.6 ? y * 0.8 : y
            trainLevelGroup.addChild(trainLevelItem)

            trainLevelItem.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                if (!this.flag) return
                this.flag = false
                Http.getInstance().post(Url.HTTP_FAVOR_LIST, "", res => {
                    let favors = res.data
                    let idx = favors && favors.filter(item => item.sort - 1 == i)
                    if (idx && idx.length) {
                        this.train(idx[0])
                    } else {
                        let alert = new AlertPanel("提示\n暂无收藏！")
                        this.addChild(alert)
                        this.flag = true
                    }
                    Util.playMusic('model_select_mp3')
                })
            }, this)
        })
    }

    private train(item) {
        Http.getInstance().post(Url.HTTP_TRAIN_START, { type: AnswerType.FAVOR, tid: item.qattrId }, res => {
            let answer = new Answers()
            answer.lifecycleId = item.qattrId
            answer.questions = res.data
            let levelData = item
            levelData.name = item.attrVal
            levelData.flag = ""
            let scene = new AnswerScene(answer, AnswerType.FAVOR, levelData)
            ViewManager.getInstance().changeScene(scene)
        })
    }

    public onBack() {
        ViewManager.getInstance().backByName('trainScene')
    }

    public updateScene() {
        this.flag = true
    }
}
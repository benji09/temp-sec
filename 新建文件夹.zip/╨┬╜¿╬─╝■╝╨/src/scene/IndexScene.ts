/**
 * 首页界面
 */
class IndexScene extends Scene {
    public constructor() {
        super()
    }

    public init() {
        this.close_btn = ''
        this.setBackground('home_bg_png')
        this.name = 'home'
        this.createLayout()
    }

    private createLayout() {
        let ratio = Util.getRatio()
        let stage = ViewManager.getInstance().stage

        // 控制音乐播放
        let musicSwitch = new egret.Bitmap()
        musicSwitch.texture = RES.getRes('pause_png')
        musicSwitch.x = 20
        musicSwitch.y = 20
        musicSwitch.touchEnabled = true
        this.addChild(musicSwitch)

        let audio: any = document.querySelector('#audio')
        musicSwitch.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            Util.playMusic('model_select_mp3')
            let isPaused = audio.paused
            if (isPaused) {
                musicSwitch.texture = RES.getRes('play_png')
                musicStart()
            } else {
                musicSwitch.texture = RES.getRes('pause_png')
                musicStop()
            }
        }, this)

        // 排行榜
        let rank_btn = this.createRightButton('排行榜', () => {
            let scene = new RankCategoryScene()
            ViewManager.getInstance().changeScene(scene)
        })
        this.addChild(rank_btn)

        // 选项按钮
        let models = [
            { bg: 'home_item_01_png', y: 360, key: 1, label: '武器装备' },
            { bg: 'home_item_02_png', y: 660, key: 2, label: '答题闯关' },
            { bg: 'home_item_03_png', y: 660, key: 3, label: 'PK挑战' },
        ]
        
        for (let model of models) {
            let bg: egret.Bitmap = Util.createBitmapByName(model.bg)
            let label: egret.TextField = new egret.TextField
            label.text = model.label

            bg.width = ratio > 0.6 ? bg.width * 0.8 : bg.width
            bg.height = ratio > 0.6 ? bg.height * 0.8 : bg.height
            if (model.key == 1) {
                bg.x = (stage.stageWidth - bg.width) / 2
            } else if (model.key == 2) {
                bg.x = 0
            } else {
                bg.x = stage.stageWidth - bg.width
            }
            bg.y = ratio > 0.6 ? model.y * 0.8 : model.y
            label.x = bg.x
            label.width = bg.width
            label.textAlign = 'center'
            label.y = bg.y + bg.height - 40

            this.addChild(bg)
            this.addChild(label)
            bg.touchEnabled = true
            bg.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouch(model.key), this)
        }

        // 个人中心
        let userGroup = new eui.Group
        userGroup.y = stage.stageHeight - 100
        this.addChild(userGroup)

        let arrow = Util.createBitmapByName('home_arrow_png')
        arrow.x = (stage.stageWidth - arrow.width) / 2
        userGroup.addChild(arrow)

        let userInfo = new egret.TextField
        userInfo.text = '个人中心'
        userInfo.y = -4
        userInfo.width = stage.stageWidth
        userInfo.textAlign = 'center'
        userGroup.addChild(userInfo)

        userGroup.touchEnabled = true
        userGroup.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            let scene = new UserScene()
            Util.playMusic('model_select_mp3')
            ViewManager.getInstance().changeScene(scene)
        }, this)
    }

    // 页面跳转
    private onTouch(key) {
        return () => {
            Util.playMusic('model_select_mp3')
            switch (key) {
                case 1:
                    let equipScene = new EquipmentScene()
                    ViewManager.getInstance().changeScene(equipScene)
                    break
                case 2:
                    let trainScene = new TrainScene()
                    ViewManager.getInstance().changeScene(trainScene)
                    break
                case 3:
                    let pk = new PkListScene()
                    ViewManager.getInstance().changeScene(pk)
                    break
            }
        }
    }

    public updateScene() {
        Http.getInstance().post(Url.HTTP_USER_INFO, "", res => {
            DataManager.getInstance().setUser(res.data)
            Util.setTitle("V来计划-" + res.data.teamName)
        })
    }
}
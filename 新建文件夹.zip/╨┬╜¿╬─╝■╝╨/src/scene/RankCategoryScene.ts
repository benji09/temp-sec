class RankCategoryScene extends Scene {
    public init() {
        this.setBackground()
        Util.setTitle('排行榜')
        this.close_btn = '首页'
        Http.getInstance().get(Url.HTTP_UPDATE_CACHE_RANK)

        let category = ['闯关排行榜', 'PK排行榜']
        let y = 455
        category.forEach((item) => {
            let button = this.createButton(item)
            button.x = (this.stage.stageWidth - button.width) / 2
            button.y = y
            this.addChild(button)

            y += button.height + 145
        })
    }

    private createButton(label) {
        let group = new eui.Group

        let button_bg = Util.createBitmapByName('rank_button_png')
        group.width = button_bg.width
        group.height = button_bg.height
        group.addChild(button_bg)

        let button_label = new egret.TextField
        button_label.text = label
        button_label.textColor = Config.COLOR_MAIN
        button_label.width = button_bg.width
        button_label.height = button_bg.height
        button_label.textAlign = egret.HorizontalAlign.CENTER
        button_label.verticalAlign = egret.VerticalAlign.MIDDLE
        button_label.size = 40
        group.addChild(button_label)

        group.touchEnabled = true
        group.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
            Util.playMusic('model_select_mp3')
            let rank = new RankScene(label)
            ViewManager.getInstance().changeScene(rank)
        }, this)

        return group
    }

    public updateScene() {
        Util.setTitle('排行榜')
    }
}
class EquipList extends Scene {
    private config
    constructor(config) {
        super()
        this.config = config
    }

    public init() {
        this.setBackground('bg_with_title_png')

        // 标题
        let title = new Title(this.config.name, 120, this.config.icon)
        this.addChild(title)

        this.changeTypeList(this.config)
    }

    private changeTypeList(config) {
        Http.getInstance().post(Url.HTTP_EQUIP_LIST, { catid: config.type }, res => {
            var group = new eui.Group()
            group.width = this.stage.stageWidth
            this.addChild(group)

            let y = 40
            let list = res.data
            if (list != null) {
                list.forEach((item) => {
                    let equipItem = new EquipItem(item)
                    equipItem.x = (this.stage.stageWidth - equipItem.width) / 2
                    equipItem.y = y
                    y += equipItem.height + 50
                    equipItem.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onSeeItemDetail(item), this)
                    group.addChild(equipItem)
                })
            } else {
                let emptyTips = new egret.TextField()
                emptyTips.text = "暂无结果"
                emptyTips.width = this.stage.stageWidth
                emptyTips.textAlign = egret.HorizontalAlign.CENTER
                emptyTips.y = 600
                emptyTips.size = 40
                this.addChild(emptyTips)
            }

            group.height = y + 400
            var myScroller: eui.Scroller = new eui.Scroller()
            //注意位置和尺寸的设置是在Scroller上面，而不是容器上面
            myScroller.height = this.stage.stageHeight - 474
            myScroller.y = 340
            //设置viewport
            myScroller.viewport = group
            this.addChild(myScroller)
        })
    }


    private onSeeItemDetail(item) {
        return () => {
            let audio: any = document.querySelector('#audio')
            audio.volume = 0
            Util.playMusic('model_select_mp3')
            Http.getInstance().post(Url.HTTP_CMS_CONTENTLOG, { conid: item.contentId }, null)
            let thUserId = ''
            // if(item.url && item.url.toLowerCase().trim().endsWith('.pdf')){
                thUserId = "&wm=" + DataManager.getInstance().getUser().thUserId
            // }
            showIFrame(item.url + thUserId, item.type)
        }
    }
}
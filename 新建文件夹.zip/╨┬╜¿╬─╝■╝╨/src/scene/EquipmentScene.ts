class EquipmentScene extends Scene {
    constructor() {
        super()
    }

    public init() {
        this.setBackground('equipment_bg_png')
        Util.setTitle('武器装备')
        this.initList()
    }

    private initList() {
        let group = new eui.Group()
        group.y = 340
        this.addChild(group)

        let stage = ViewManager.getInstance().stage
        let currentTrain = 3
        let grayFilter = Util.grayFilter()

        EquipmentConfigs.forEach((item, i) => {
            let trainLevelItem = new TrainLevelItem(item)
            trainLevelItem.x = i % 2 == 0 ? 120 : stage.stageWidth - trainLevelItem.width - 120
            let y = (i > 1 ? 1 : 0) * (trainLevelItem.height + 40) + ( i % 2 == 0 ? 40 : 140 )
            let ratio = Util.getRatio()
            trainLevelItem.y = ratio > 0.6 ? y * 0.8 : y
            trainLevelItem.filters = i == 3 ? [grayFilter] : []
            group.addChild(trainLevelItem)

            let lock = Util.createBitmapByName('lock_png')
            let lock_ratio = lock.width / lock.height
            lock.width = ratio > 0.6 ? 47 * 0.8 : 47
            lock.height = lock.width / lock_ratio
            lock.x = (trainLevelItem.width - lock.width) / 2 + 4
            lock.y = 115
            lock.visible = i == currentTrain
            trainLevelItem.addChild(lock)

            trainLevelItem.addEventListener(egret.TouchEvent.TOUCH_TAP, () => {
                if (i == 3) return
                let scene = new EquipList(item)
                ViewManager.getInstance().changeScene(scene)
                Util.playMusic('model_select_mp3')
            }, this)
        })
    }
}
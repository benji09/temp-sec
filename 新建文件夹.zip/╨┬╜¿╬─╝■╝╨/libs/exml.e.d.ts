declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare class CTitleSkin extends eui.Skin{
}
declare class DailyTasks1Skin extends eui.Skin{
}
declare class DailyTasks2Skin extends eui.Skin{
}
declare class DailyTasks3Skin extends eui.Skin{
}
declare class DailyTasks4Skin extends eui.Skin{
}
declare class DailyTasks5Skin extends eui.Skin{
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare class RadarPanelSkin extends eui.Skin{
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare class SearchInputSkin extends eui.Skin{
}
declare class SignInIconSkin extends eui.Skin{
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare class TrainSummarySkin extends eui.Skin{
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
